# MotionLecture 장 유형(kind) 카탈로그

출처 코드: `/Users/keerhee/Project/src/motion/` — `MotionLecture.tsx`(KindView 분기) · `lib.tsx`(색·큐·공통 요소) ·
`kinds.tsx` … `kinds8.tsx` · `viz.tsx`. 빌드: `scripts/motion_build.py <id> narr|scenes [--estimate]`.
이 문서는 2026-10-16 코드 기준이다. 코드가 바뀌면 이 문서보다 코드를 믿는다.

---

## 0. 먼저 알아 둘 것

### 0.1 spec.py → scenes.json → 컴포넌트

```python
CHAPTERS = [("c1", "도입", 1), ("c2", "사례", 4)]   # (id, 진행 바 라벨, 시작 장 번호)
S = []
def slide(**kw): S.append(kw)
DATA = {}   # 선택. props.data 로 넘어간다(prompt·results·errors 만 읽는다)
```

- `slide(...)`의 키워드는 `sents`만 빼고 **그대로** 장 객체 `s`가 된다. 컴포넌트는 `s.<키>`를 읽는다.
- 빌드(`motion_build.py scenes`)가 장마다 덧붙이는 키: `n`(장 번호) · `cues`(큐 키→초) · `lead`(1.5초, 챕터 첫 장이면 +1.8) ·
  `dur`(음성 실측) · `tail`(2.5초) · `bumper`(챕터 시작 장 1.8초, 1장은 0) · `audio`(`sNN.mp3`).
  → **spec에 `cues=`, `n=`, `lead=` 같은 이름을 쓰면 빌드가 덮어쓴다**(아래 `cppi` 참고).
- 1장을 뺀 모든 장 하단(약 96px)에 챕터 진행 바가 그려진다. 본문 영역은 대개 `top 300 ~ bottom 96`, 좌우 100px.
- 화면 1920×1080, 30fps.

### 0.2 큐(cue)의 작동

- `sents`의 문장 앞에 `@키 `를 붙이면, 그 문장이 **시작하는 시각**이 `s.cues[키]`(장 시작 기준 초)가 된다. `@키 `는 TTS에서 빠진다.
  같은 키가 여러 문장에 있으면 **첫 문장**의 시각만 쓴다.
- 문장 시각 = `lead + Σ(앞 문장 wav 길이 + 1.0초, 물음표로 끝나면 1.5초)`.
- 컴포넌트는 `useCueFrame()(key, intro)`로 등장 프레임을 얻는다(`lib.tsx`):
  - `key`가 `s.cues`에 있으면 → `(cues[key] − 0.12초) × fps` (말 시작 직전에 뜬다).
  - 없으면(키 생략·오타·`""`) → `(0.25 + intro × 0.14)초 + min(0, lead − 1.5)` — **장 시작 직후 순서대로** 뜬다.
    즉 큐가 없는 요소는 에러 없이 처음부터 보인다.
- `CueCtx`(React context) = `{cues, dur, lead}`. 범퍼가 있는 장은 큐를 범퍼 길이만큼 당겨 넣고, 내용 전체를 범퍼 뒤로 민다.
- `useFocusKey(keys)` — 같은 묶음(카드·행·글머리) 가운데 **가장 최근에 시작한 큐**의 요소를 강조(주황/톤 테두리, 굵게)하고
  나머지는 흐리게 한다. 그래서 묶음 안 요소마다 큐를 따로 주면 "지금 말하는 것"이 켜진다.
- `prog(f, from, dur)` — from 프레임부터 dur 프레임 동안 0→1(ease-out cubic). `usePop` — spring 0→1.
- **`"s"` 큐**: 렌더러에서는 특별하지 않다. 다만 `motion_build.py narr`의 점검(명세에만 있고 `@`문장이 없는 큐 경고)에서
  `"s"`만 예외로 빠진다. 관례상 표지 `desc`처럼 "문장 하나에 맞춰 뜨거나, 없으면 처음부터 떠도 되는" 요소에 쓴다.
- 점검기 주의: 리스트의 마지막 원소가 `[a-z]+\d?` 꼴일 때만 큐로 인식한다. `L0`, `i10` 같은 키는 렌더는 되지만 점검에서 빠진다.
  dict의 `cue=` 값은 항상 인식한다.

### 0.3 색·톤 이름 (`lib.tsx`)

| 상수 | 값 | 용도 |
|---|---|---|
| `C.bg0` / `C.bg1` | `#071426` / `#0B1F3A` | 배경(방사형 그라데이션 + 움직이는 80px 격자) |
| `C.panel` / `C.panel2` | rgba(255,255,255,.045 / .08) | 카드 바탕 / 강조 카드 |
| `C.line` | rgba(255,255,255,.14) | 테두리 |
| `C.text` / `C.sub` / `C.muted` | `#EEF3FB` / `#A9B8D3` / `#6F82A3` | 본문 / 보조 / 흐림 |
| `C.orange` | `#F28C28` | 강조 기본색(eyebrow·banner·포커스) |
| `C.blue` `C.green` `C.red` `C.yellow` | `#4EA8FF` `#3DDC97` `#FF5C6C` `#FFD166` | 의미색 |

- **`tone` 문자열**(`toneColor`): `"green"` `"red"` `"orange"` `"muted"` → 해당 색, **그 밖의 모든 값(`"blue"`, `""`, 생략, 오타)은 파랑**.
- `plot` · `tree` · `matrix` · `trainsplit` 계열은 `"yellow"`, `"sub"`도 받는다. `figure`는 `"yellow"`까지(‘sub’는 파랑).
- `dl`의 수식 상자 `eq.tone="gold"` → 노랑.
- `"yellow"`를 일반 kind(cards·table 등)에 쓰면 **파랑**이 된다.

### 0.4 글꼴

- `FONT = 'Pretendard', 'Apple SD Gothic Neo', sans-serif` (public/fonts/Pretendard-*.otf, 400~800)
- `MONO = Menlo, 'SF Mono', 'Pretendard', monospace` (code·flow·promptmap 일부)
- 수식: KaTeX(`TeX` 컴포넌트, 인라인 모드).
- 기본 크기: 제목 64 · 부제 34 · 글머리 30 · 배너 32 · 노트 28(px).

### 0.5 거의 모든 kind가 공유하는 키

| 키 | 모양 | 설명 |
|---|---|---|
| `eyebrow` | str | 제목 위 주황 막대 + 작은 글씨. 생략 가능 |
| `title` | str | 64px. **공백 단위로 단어가 차례로 솟는다** |
| `subtitle` | str | 34px 회색. 생략 가능 |
| `banner` | `[텍스트, 큐]` | 하단 결론 띠(왼쪽 색 막대가 서고 판이 펼쳐짐) |
| `bannerTone` | tone | 배너 색. 기본 주황. **지원하지 않는 kind가 있다**(표 참고) |
| `note` | `[텍스트, 큐]` | 배너 아래 회색 인용선 문단 |
| `sents` | `["@큐 문장", "문장", …]` | 나레이션. 화면에는 안 나온다 |

글머리 공통 꼴 `items=[[텍스트, 큐, tone?]]` — formula·kpis·ask·plot·figure·matrix·tree·trainsplit·cppi에서 같다
(ask만 기본 tone이 주황, 나머지는 파랑).

예외: `cover`(Header 없음, 아래 참고), `prompt`(자체 머리), `cs`·`dl`(자체 머리: eyebrow·title(+`sub`)만, banner 대신 `k`).

### 0.6 범용성 한눈에

| 구분 | kind |
|---|---|
| **범용** | cover · split · table · steps · cards · kpis · roadmap · formula · ask · figure · plot · template · grid · weights · mapping · code · tree · matrix |
| 범용이지만 모양이 고정적 | cycle(3항목 + 게이트) · layers(6행 전제) · paper(논문 카드) · alloc(구성비 막대) · promptmap |
| **도메인 전용(재사용 비권장)** | flow(4단계·runs 버스 문구 고정) · prompt/results/errors(`DATA`·viz 의존, pension-xs) · cppi(합성 경로 고정) · trainsplit/bagging/boosting(영문 고정 내용) · cs(치트시트 덱 이식, 음성 없는 영상) · dl(CBF 발표 전용 하위꼴) |

---

## 1. 범용 레이아웃

### cover — 표지
용도: 오른쪽에 움직이는 점·선 네트워크, 왼쪽에 118px 큰 제목(왼→오 닦임), 주황 부제, 회색 설명 줄, 하단 푸터.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `eyebrow` | str | 사실상 필수 | |
| `title` | str | 필수 | 한 줄 권장(폭 1100px) |
| `subtitle` | str | 선택 | 주황 44px |
| `desc` | `[[텍스트, 큐]]` | **필수**(빈 리스트라도) | `.map`을 바로 부른다. 34px |
| `footer` | str | 선택 | **기본값이 `"BAF.60080 · 연기금 운용전략과 성과평가"`** — 다른 강의는 반드시 지정 |

banner·note 없음. 예(pension-xs-briefing2):
```python
slide(kind="cover", eyebrow="정리",
      title="계산은 코드, 판단은 에이전트, 결정은 사람", subtitle="여러분의 일은 실행에서 감독으로 옮겨간다",
      desc=[["오늘 할 일 — 예시 MVP를 열어 시연 화면에서 한 분기를 돌려 본다", "s"],
            ["다음 영상 — 자율주행 포트폴리오의 개념", "s2"]],
      footer="BAF.60080 · 연기금 운용전략과 성과평가",
      sents=["정리하겠습니다. 계산은 코드, 판단은 에이전트, 결정은 사람입니다.",
             "@s 오늘 바로 예시 엠브이피를 열어 시연 화면에서 한 분기를 돌려 보십시오.",
             "@s2 이어지는 영상에서 자율주행 포트폴리오의 개념을 살펴보겠습니다."])
```

### split — 두 칸 카드
용도: 왼쪽·오른쪽 카드(머리 + 글머리), 선택으로 가운데 두 막대 비교(gap), 아래 화살표 사슬·배너·노트.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `left`, `right` | `dict(head=str, tone=tone, items=[[텍스트, 큐]])` | **둘 다 필수** | 카드 상단 막대는 `items[0]`의 큐에 나타남. 글머리 34px(gap 있으면 29) |
| `gap` | `dict(cue, a=[라벨, 값], b=[라벨, 값], label)` | 선택 | 가운데 470px 카드. a=빨강·b=초록 막대, 높이 축 최대 **10 고정**, 값 뒤 `%`, 차이 `%p` 글자 고정 → 0~10% 수치 전용 |
| `chain` | `[[단계1, 단계2, …], 큐]` | 선택 | 화살표로 이어진 둥근 상자, 마지막 상자 주황 |
| `banner`, `bannerTone`, `note` | | 선택 | |

예(pension-w06as-t3):
```python
slide(kind="split", eyebrow="기본 지식 ③ 금리와 상품의 관계",
      title="금리는 양쪽에서 상품을 흔든다",
      left=dict(head="금리가 내리면", tone="red",
                items=[["보장선 비용 F₀가 비싸진다", "l1"], ["여유분이 줄어 주식을 덜 산다", "l2"]]),
      right=dict(head="금리가 오르면", tone="blue",
                 items=[["여유분은 늘어난다", "r1"],
                        ["그러나 원리금보장형의 수익률도 같이 올라 이겨야 할 목표가 높아진다", "r2"]]),
      banner=["같은 설계가 금리에 따라 다른 기준에서 걸릴 수 있다 — 문제 3 · 4", "b"],
      sents=["기본 지식 셋째, 금리와 상품의 관계입니다.",
             "@l1 금리가 내리면 보장선 비용이 비싸집니다.", "@l2 그래서 여유분이 줄고, 주식을 덜 삽니다.",
             "@r1 금리가 오르면 반대로 여유분이 늘어납니다.",
             "@r2 그런데 원리금보장형의 수익률도 같이 오르기 때문에, 이겨야 할 목표도 높아집니다.",
             "@b 그래서 같은 설계라도 금리에 따라 서로 다른 기준에서 걸릴 수 있습니다."])
```
gap 예(pension-xs): `gap=dict(cue="l2", a=["MVO · 기각", 8.58], b=["리스크 패리티 · 채택", 7.43], label="규율을 지킨 대가")`,
chain 예: `chain=[["W02 패널", "W04 공분산·BL", "W05 ERC", "W09 성과평가", "W15 TPA"], "b"]`.

### table — 표
용도: 주황 머리행 + 행이 왼쪽에서 미끄러져 들어오는 표. 현재 말하는 행에 주황 테두리. 선택으로 위 인용, 아래 패널.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `cols` | `[str]` | 필수 | 머리행 |
| `rows` | `[dict(cells=[str…], cue=큐, tone=tone?)]` | 필수 | **dict여야 한다**(리스트 아님). `tone`은 왼쪽 6px 막대색, `"muted"`는 글자까지 흐림. 첫 칸 굵게, 나머지 회색 |
| `widths` | `[수]` | 선택 | flex 비율. 기본 모두 1 |
| `accentCol` | int | 선택 | 그 열 글자를 노랑으로 |
| `dense` | bool | 선택 | 촘촘하게. 행 >6이거나 panel+행>3이면 자동 dense. 행 ≤4이고 dense 아니면 큰 글씨(33px) |
| `quote` | `[텍스트, 큐]` | 선택 | 표 위 주황 인용 상자 |
| `panel` | `dict(head, items=[[텍스트, 큐]])` | 선택 | 표 아래 주황 카드 |
| `banner`, `bannerTone`, `note` | | 선택 | 부제가 없으면 본문이 230px부터 시작 |

예(pension-w06as-t1):
```python
slide(kind="table", eyebrow="기본 지식 ⑤ 헤지 수단",
      title="국채를 살 것인가, 스왑을 맺을 것인가", subtitle="장점과 위험이 정반대다",
      cols=["수단", "방법", "장점", "위험"], widths=[2.3, 3.4, 2.6, 4.4],
      rows=[dict(cells=["30년 국채 매입 (현물)", "실제 장기 국채를 산다", "담보 부담이 없다", "자금이 실제로 든다"], cue="r1", tone="blue"),
            dict(cells=["금리스왑 (IRS)", "고정을 받고 변동을 준다", "적은 자금으로 큰 헤지", "금리가 오르면 현금 담보"], cue="r2", tone="orange")],
      banner=["스왑의 장점(적은 자금)과 위험(현금 담보)은 같은 동전의 양면이다", "b"],
      sents=["기본 지식 다섯째, 헤지 수단 두 가지입니다.",
             "@r1 첫째는 30년 국채를 실제로 사는 방법입니다.",
             "@r2 둘째는 금리스왑입니다.",
             "@b 스왑의 장점인 적은 자금과, 위험인 현금 담보는 같은 동전의 양면입니다."])
```

### steps — 번호 단계(가로 진행선)
용도: 위에 작은 주황 머리글, 가로로 번호 원(1,2,3…)과 카드. 진행선이 현재 단계까지 주황으로 찬다. 시간 순서·절차에 적합.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `head` | str | 선택(생략 시 빈 줄) | 단계 위 30px 주황 글 |
| `items` | `[[제목, 본문, 큐]]` | 필수 | 번호는 자동(1부터). **2개 이상**(1개면 진행선 계산이 0으로 나눔). 3~5개 권장 |
| `quote` | `[텍스트, 큐]` | 선택 | 아래 주황 인용 |
| `banner` | `[텍스트, 큐]` | 선택 | **bannerTone 미지원**(항상 주황) |
| `shift` | `[[이전, 이후], 큐]` | 선택 | "이전(회색, 줄 그어짐) ━ 이후(주황 상자)" 전환. 있으면 `note[0]`이 그 오른쪽 설명으로 쓰이고 노트 줄은 따로 안 그림 |
| `note` | `[텍스트, 큐]` | 선택 | |

예(pension-xs-briefing2):
```python
slide(kind="steps", eyebrow="채점 — 채점자가 회사를 직접 돌린다",
      title="더블클릭 한 번, 그리고 돌발 과제", subtitle="파이썬과 브라우저만 쓴다",
      head="채점자와 위원회가 보는 것",
      items=[["시연 화면에서 한 분기", "라이브 실행 → 사람 CIO 결정 → 1쪽 보고서", "i0"],
             ["공개 점검 T1~T8", "미리 돌려 볼 수 있는 시험", "i1"],
             ["라이브 점검 L1~L3", "발표 당일 주는 돌발 과제", "i2"]],
      banner=["코드를 고치지 않고 입력만 바꿔 대응한다", "b"],
      sents=["채점자는 여러분의 회사를 직접 돌립니다.",
             "@i0 압축을 풀고 더블클릭하면 시연 화면이 열립니다.",
             "@i1 공개 점검 여덟 개는 미리 알려 드리는 시험입니다.",
             "@i2 라이브 점검 세 개는 발표 당일 드립니다.",
             "@b 코드를 고치지 않고 입력만 바꿔 대응합니다."])
```
shift 예(pension-xs): `quote=["“AI 시스템은 …” — CFA Institute", "b"], shift=[["계산", "정책과 판단"], "n"], note=["설명 문장", "n"]`.

### cards — 카드 격자(한 줄)
용도: 같은 줄에 카드 2~4장. 위 색 막대가 차오르고, 말하는 카드가 커지며 빛나고 나머지는 흐려진다.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `cards` | `[[제목, 본문, 큐, tone, 번호?, 꼬리글?]]` | 필수 | 4~6원소. `[4]`가 있으면 제목 위 원형 배지(예 `"1"`, `"A"`), `[5]`가 있으면 구분선 아래 회색 꼬리글. 번호 없이 꼬리글만 쓰려면 `[4]`에 `""` |
| `cardH` | int | 선택 | 카드 최소 높이, 기본 380 |
| `size` | int | 선택 | 본문 글자 크기, 기본 31(꼬리글은 −4) |
| `banner`, `bannerTone`, `note` | | 선택 | |

예(pension-xs-briefing2):
```python
slide(kind="cards", eyebrow="과제",
      title="회사 = 제품 + 운영 규정 + 사람의 감독", subtitle="한 기금의 운용을 맡는 회사",
      cards=[["제품", "IPS 안에서 매 분기 에이전트가 스스로 운용하는 시스템", "k1", "blue"],
             ["운영 규정", "자동 기각 · 킬스위치 · 변경 관리 · 사고 대응", "k2", "green"],
             ["사람의 감독", "CIO가 IC 보고서를 받고 승인 · 조건부 승인 · 반려", "k3", "orange"]],
      banner=["계산은 코드, 판단은 에이전트, 결정은 사람", "b"],
      sents=["회사는 세 가지로 이뤄집니다.",
             "@k1 첫째는 제품입니다.", "@k2 둘째는 운영 규정입니다.", "@k3 셋째는 사람의 감독입니다.",
             "@b 원칙은 하나입니다. 계산은 코드, 판단은 에이전트, 결정은 사람."])
```
번호·꼬리글 예: `cards=[["Side", "Primary model picks the direction", "s1", "blue", "1", "Recall-first"], …], cardH=400, size=28`(fml-sup04-motion 형식).

### kpis — 큰 숫자 타일
용도: 테두리 있는 타일에 96px 숫자. `to`를 주면 `from`(회색, 끝나면 취소선) → 화살표 → `to`로 세어 바뀐다. 아래 글머리.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `kpis` | `[[라벨, from, to, 단위, 큐, tone, 자릿수?]]` | 필수 | `to=None`이면 `from`만 표시. `from`에 **문자열**도 됨(to=None일 때 그대로 표시). 자릿수 기본 **2**(정수면 `0` — 천 단위 쉼표). 단위는 숫자 옆 40px |
| `items` | `[[텍스트, 큐, tone?]]` | 선택 | |
| `banner`, `bannerTone`, `note` | | 선택 | |

예(pension-w06as-t1):
```python
slide(kind="kpis", eyebrow="과제 — 상황",
      title="2026년 9월, 금리 인하 전망", subtitle="1~2년 동안 국고채 금리가 1.5%p 정도 떨어질 것이라는 전망",
      kpis=[["국고채 30년물 금리", 4.60, 3.10, "%", "k1", "orange", 2],
            ["전망 — 금리 하락 폭", 1.5, None, "%p", "k2", "red", 1]],
      items=[["금리가 떨어지면 → 부채가 커진다 → 적립비율이 나빠진다", "i1", "red"],
             ["기금운용위원회에 세 안이 올라왔다", "i2", "blue"]],
      sents=["이제 과제의 상황입니다.",
             "@k1 2026년 9월 현재 국고채 30년물 금리는 4.60퍼센트입니다.",
             "@k2 금리가 1.5퍼센트포인트 정도 떨어질 것이라는 전망이 우세합니다.",
             "@i1 금리가 떨어지면 부채는 커지고, 적립비율은 나빠집니다.",
             "@i2 이 상황에서 기금운용위원회에 세 가지 안이 올라왔습니다."])
```
주의: 숫자 증가 애니메이션은 `to`가 있을 때만(타일 등장 18프레임 뒤 40프레임 동안). `to=None`이면 정적인 숫자가 팝업만 한다.

### roadmap — 노선도(타임라인)
용도: 가로 굵은 노선이 그룹별 색으로 이어지고, 역(번호 원 + 아래 글)이 놓인다. 그룹 큐마다 노란 열차 점이 그 그룹 마지막 역까지 달린다.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `groups` | `[dict(label=str, tone=tone, cue=큐, items=[str…])]` | 필수 | 역 번호는 전체 순번 자동. 역 글은 폭 200px·30px → 짧게. 전체 역 6~9개가 적당 |
| `banner`, `bannerTone` | | 선택 | note 없음 |

예(pension-w06as-guide):
```python
slide(kind="roadmap", eyebrow="팀별 과제 문서",
      title="네 문서는 같은 순서로 쓰였다", subtitle="읽고 → 틀을 잡고 → 풀고 → 결정한다",
      groups=[dict(label="읽는다", tone="blue", cue="n1", items=["상황", "기본 지식", "강의와 연결"]),
              dict(label="판단의 틀", tone="green", cue="n2", items=["세 가지 안", "판정 기준"]),
              dict(label="푼다", tone="orange", cue="n3", items=["계산 도구 사용법", "단계별 문제"]),
              dict(label="결정하고 답한다", tone="red", cue="n4", items=["최종 결정", "상대 팀이 물을 질문"])],
      banner=["다른 팀 문서도 읽어 두면 질의 시간에 도움이 된다", "b"],
      sents=["팀별 과제 문서의 구조입니다.", "@n1 먼저 상황과 기본 지식을 읽습니다.",
             "@n2 다음으로 세 가지 안과 판정 기준이 나옵니다.", "@n3 그다음 단계별 문제를 풉니다.",
             "@n4 끝으로 최종 결정을 씁니다.", "@b 다른 팀 문서도 읽어 두십시오."])
```

### formula — 수식 카드(+ 막대·글머리·표)
용도: 수식 카드가 가로로 1~3장(수식은 왼쪽에서 닦여 나옴), 선택으로 오른쪽 막대 비교 카드, 아래 글머리 또는 표.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `formulas` | `[dict(tex=LaTeX, cue, head?, cap?, tone?="orange", size?=60, h?=170)]` | 필수 | `cap`은 수식 아래 회색 설명. `h`는 수식 칸 최소 높이 |
| `bars` | `dict(head, tone?="blue", bars=[[라벨, 값, 표시문자, tone, 큐]], h?=300, w?=560, bw?=220)` | 선택 | 값에 비례해 자라는 세로 막대 |
| `items` | `[[텍스트, 큐, tone?]]` | 선택 | |
| `table` | `dict(cols, widths?, rows=[dict(cells, cue, tone?)])` | 선택 | table kind와 같은 행 꼴 |
| `banner`, `bannerTone`, `note` | | 선택 | |

예(pension-w06as-t2):
```python
slide(kind="formula", eyebrow="단계별 문제 2 — 되돌림의 식",
      title="적립비율은 얼마나 되돌아가는가",
      formulas=[dict(head="적립비율의 금리 민감도",
                     tex=r"\Delta FR\;\approx\;FR\times\left(D_L-D_A\right)\times\Delta y", size=72, h=220,
                     cap="금리가 Δy만큼 내리면(Δy<0) 적립비율이 떨어진다", cue="f1")],
      items=[["FR — 지금의 적립비율", "i1", "blue"],
             ["부채 듀레이션 − 자산 듀레이션", "i2", "orange"],
             ["Δy — 금리 변화", "i3", "green"]],
      banner=["상승 전과 후에 이 식의 어느 항이 달라졌는가 — 그것이 문제 2의 답이다", "b"],
      sents=["문제 2에서 쓸 식입니다.", "@f1 적립비율의 변화는 대략 …입니다.",
             "@i1 첫째 항은 지금의 적립비율입니다.", "@i2 둘째 항은 듀레이션 차이입니다.",
             "@i3 셋째 항은 금리 변화입니다.", "@b 그것이 문제 2의 답입니다."])
```

### ask — 큰 인용(질문)
용도: 파란 바탕 상자에 큰 따옴표 “ 와 50px 굵은 문장, 아래 주황 밑줄이 그어진다. 아래 글머리(기본 주황).

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `quote` | `[텍스트, 큐]` | **필수** | 질문·인용·핵심 한 문장 |
| `items` | `[[텍스트, 큐, tone?="orange"]]` | 선택 | |
| `banner`, `bannerTone` | | 선택 | note 없음 |

예(pension-w06as-t1):
```python
slide(kind="ask", eyebrow="질의 — 2팀이 물을 질문",
      title="이 질문에 숫자로 답할 준비를 한다",
      quote=["금리가 내릴 것이라는 전망이 틀리면, 1팀의 결정은 얼마의 손실을 내고 그것은 누구 돈인가?", "q"],
      items=[["손실의 크기 — 문제 4의 숫자로 답한다", "i1"],
             ["누구의 자금인가 — 결정문의 「남는 위험을 누가 지는가」와 같은 질문이다", "i2"],
             ["2팀 문서도 읽어 둔다 — 같은 도구, 반대 방향의 금리", "i3", "blue"]],
      sents=["마지막으로 질의 시간에 2팀이 물을 질문입니다.",
             "@q 금리가 내릴 것이라는 전망이 틀리면, 1팀의 결정은 얼마의 손실을 내고, 그것은 누구의 자금인가?",
             "@i1 손실의 크기는 문제 4에서 구한 숫자로 답하십시오.",
             "@i2 누구의 자금인가는 결정문의 질문과 같습니다.",
             "@i3 2팀 문서도 반드시 읽어 두십시오."])
```

### figure — 원본 그림(PNG) + 오른쪽 패널
용도: 흰 바탕 둥근 상자에 그림이 왼→오로 닦이며 나타난다. 선택으로 그림 위 강조 상자(라벨 포함), 오른쪽 수식 카드·글머리.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `fig` | `dict(src, cue?, w?=1060, h?=560, bg?="#FFFFFF")` | 필수 | `src`는 **`public/` 기준 경로**(예 `"lectures/<id>/fig/x.png"` → 파일은 `public/lectures/<id>/fig/x.png`). object-fit contain, 안쪽 여백 16 |
| `marks` | `[dict(x, y, w, h, cue, tone?="yellow", label?)]` | 선택 | 좌표는 그림 상자 안 **비율 0~1**. 라벨은 상자 위 44px. (현재 spec에서 실사용 예 없음) |
| `formulas` | `[dict(tex, cue, head?, tone?, size?=34, h?=84)]` | 선택 | plot과 같은 작은 수식 카드 |
| `items` | `[[텍스트, 큐, tone?]]` | 선택 | |
| `itemSize` | int | 선택 | 기본 28 |
| `full` | bool | 선택 | 참이면 오른쪽 패널 없이 그림만 가운데 |
| `banner`, `bannerTone`, `note` | | 선택 | 본문 top 290 |

오른쪽 패널은 `formulas`나 `items`가 있고 `full`이 아닐 때만 생긴다. 그림 폭 w + 40px 간격 + 패널(남은 폭)이므로
w=1200이면 패널이 약 380px로 좁다(→ `itemSize` 25 정도).

예(pension-xs-briefing2):
```python
FIG = "lectures/pension-xs-briefing2/fig/"
slide(kind="figure", eyebrow="시연 화면",
      title="한 분기를 처음부터 CIO 결정까지", subtitle="화면은 계산하지 않는다 — 엔진이 남긴 파일을 그대로 보여 준다",
      fig=dict(src=FIG + "demo.png", w=1200, h=675),
      items=[["단계마다 근거 파일", "i1"], ["⑨ 사람 CIO가 승인 · 반려", "i2", "orange"],
             ["1쪽 보고서", "i3", "green"], ["두 실행 비교", "i4"]],
      itemSize=25,
      sents=["시연 화면은 이렇게 생겼습니다.",
             "@i1 단계마다 근거 파일이 열립니다.", "@i2 아홉 번째 단계에서 사람 씨아이오가 승인이나 반려를 누릅니다.",
             "@i3 그러면 1쪽 보고서가 나옵니다.", "@i4 입력을 바꿔 다시 돌리면 두 실행을 나란히 비교할 수 있습니다."])
```
강조 상자 예: `marks=[dict(x=0.62, y=0.10, w=0.30, h=0.25, cue="i2", tone="orange", label="CIO 결정")]`.

### plot — 애니메이션 차트 + 오른쪽 수식·글머리
용도: SVG 축(왼쪽 1060×560) 위에 선이 그려지고 막대가 자라고, 수평·수직선, 띠, 점 표식이 큐에 맞춰 나타난다.

`plot=dict(...)`:

| 키 | 모양 | 비고 |
|---|---|---|
| `xr`, `yr` | `[min, max]` | **필수**. y는 범위 밖이면 잘림 |
| `w`, `h` | int | 기본 1060, 560 |
| `xticks`, `yticks` | `[수]` | 눈금 글씨 |
| `xlabel`, `ylabel` | str | |
| `series` | `[dict(pts=[[x,y]…], cue, tone, label?, type?="line"\|"bar", width?=3.5, dash?, draw?=40, barw?=0.6, stagger?=2, off?)]` | 선은 `draw` 프레임 동안 그려진다. bar는 `pts=[[x, y, tone?]]`, `stagger` 프레임 간격으로 자람, `off`는 막대 폭 단위 가로 이동(묶음 막대) |
| `hlines` | `[dict(y, cue, tone, label?, dash?)]` | |
| `vlines` | `[dict(x, cue, tone, label?)]` | 항상 점선 |
| `bands` | `[dict(pts=[[x, lo, hi]…], cue, tone)]` | 반투명 띠 |
| `marks` | `[dict(x, y, cue, tone, label?, r?=11, hollow?, dx?=18, dy?=-16)]` | 점 + 라벨 |
| `legend` | bool | `label`이 있는 series만 |
| `legendPos`, `legendW` | `"tl"`/`"tr"`/`"bl"`/`"br"`, 470 | |

0이 y 범위 안이면 0선이 자동으로 그려진다. 슬라이드 키: `plot`, `formulas`, `items`, `itemSize`(28), `banner`, `bannerTone`, `note`.

예(fml-sup02-motion 꼴을 리터럴 좌표로 줄임):
```python
slide(kind="plot", eyebrow="2 · Probability → decision", title="A threshold turns probabilities into calls",
      plot=dict(xr=[10, 40], yr=[0, 1], xticks=[10, 20, 30, 40], yticks=[0, 0.5, 1], xlabel="weight", ylabel="P(obese)",
                series=[dict(label="", tone="sub", pts=[[10, .02], [20, .12], [25, .5], [30, .88], [40, .98]], cue="p1")],
                hlines=[dict(y=0.5, label="threshold 0.5", tone="orange", cue="th", dash=True)],
                marks=[dict(x=30, y=.88, tone="blue", cue="mo", label="obese")]),
      items=[["Above the line → called obese", "th", "blue"], ["Blue dot: truly obese", "mo", "blue"]],
      banner=["Calls and truth on one chart → we can check every call", "b"],
      sents=["@p1 To turn probabilities into calls, we need a threshold.",
             "@th Here the threshold is set at 0.5.", "@mo Blue dots are truly obese.",
             "@b With both on the chart, we can check which calls were right."])
```

### template — 빈칸 결정문
용도: 왼쪽 주황 굵은 테두리 상자 안 문단. 문장 안 `[ … ]`는 주황 빈칸 상자가 되고 말하는 부분의 빈칸이 깜빡인다.

| 키 | 모양 | 비고 |
|---|---|---|
| `parts` | `[[텍스트, 큐]]` | 필수. `[ ]`(빈 대괄호)는 공백 상자 |
| `size` | int | 기본 36 |
| `banner`, `bannerTone`, `note` | | 선택 |

예(pension-w06as-t3):
```python
slide(kind="template", eyebrow="단계별 문제 6 — 최종 결정", title="결정문은 이 형식으로 쓴다", size=37,
      parts=[["상품심의위원회는 [A / B / C]를 디폴트옵션으로 등록한다.", "t1"],
             ["다른 두 설계를 고르지 않은 이유는 [기준과 숫자]다.", "t2"]],
      note=["조건 예 — 어느 금리 수준에서 설계를 다시 심의할지.", "n"],
      sents=["문제 6은 최종 결정입니다.", "@t1 먼저 무엇을 등록하는지 씁니다.",
             "@t2 다른 두 설계를 고르지 않은 이유를 씁니다.", "@n 조건의 예를 들면 …입니다."])
```

### grid — 빈 판정표(? 칸)
용도: 행 머리(주황 큰 글자) × 열 머리 격자, 모든 칸에 `?`가 깜빡인다. 말하는 열이 강조된다. "채워야 할 표"를 보여 줄 때.

| 키 | 모양 | 비고 |
|---|---|---|
| `rows` | `[str]` | 필수. 짧은 라벨(44px) |
| `rowsCue` | 큐 | 행 등장 시각(행마다 6프레임 간격) |
| `cols` | `[[라벨, 큐]]` | 필수 |
| `cw` | 수 | 행 머리 폭 배수(기본 1 = 150px) |
| `banner`, `bannerTone`, `note` | | 선택 |

예(pension-w06as-t3):
```python
slide(kind="grid", eyebrow="단계별 문제 5", title="금리별로 한 표에 정리한다", subtitle="문제 2~4의 판정을 모은다",
      rows=["A", "B", "C"], rowsCue="g0",
      cols=[["금리 1.5%", "g1"], ["금리 3.0%", "g1"], ["금리 4.5%", "g1"]],
      banner=["세 금리 모두에서 통과하는 상품이 있는가?", "b"],
      sents=["문제 5는 금리별 정리입니다.", "@g0 세 상품을 행으로,",
             "@g1 금리 세 개를 열로 놓습니다.", "@b 세 금리 모두에서 통과하는 상품이 있는지 보십시오."])
```

### weights — 배점 막대
용도: 위에 100% 가로 띠가 항목 몫만큼 차고, 오른쪽 위 큰 숫자가 합계까지 센다(`/ N점` — "점" 고정). 아래 항목 행(숫자·이름·설명).

| 키 | 모양 | 비고 |
|---|---|---|
| `items` | `[[라벨, 점수, 설명, 큐, tone]]` | 필수 |
| `banner`, `bannerTone` | | 선택(note 없음) |

예(pension-xs-briefing2):
```python
slide(kind="weights", eyebrow="점수 (100점)", title="창의성이 가장 크다",
      items=[["창의성", 35, "자기 목적 IPS가 구성 · 규칙을 실제로 바꿨다", "w1", "blue"],
             ["완성도 · 재현성", 25, "T1 · T5 · T6 · T8 · 재실행 3회", "w2", "green"],
             ["감독 · 하네스", 20, "T2 · T3 · T4 · T7 · CIO 개입", "w3", "orange"]],
      sents=["점수는 100점입니다.", "@w1 창의성이 35점으로 가장 큽니다.",
             "@w2 완성도와 재현성이 25점,", "@w3 감독과 하네스가 20점입니다."])
```

### mapping — 왼쪽↔오른쪽 대응선
용도: 두 열 머리, 행마다 왼쪽 상자 → 선이 뻗음 → 오른쪽 상자. "A는 B에 해당한다" 대응표.

| 키 | 모양 | 비고 |
|---|---|---|
| `heads` | `[왼쪽 머리, 오른쪽 머리]` | 필수 |
| `pairs` | `[[왼쪽, 오른쪽, 큐]]` | 필수. 왼쪽 폭 560px |
| `note` | `[텍스트, 큐]` | **필수**(바로 읽는다) |

banner 없음. 예(pension-xs, 줄임):
```python
slide(kind="mapping", eyebrow="대응", title="논문의 층과 harness의 단계",
      heads=["논문", "harness"],
      pairs=[["IPS가 파이프라인을 통제", "Phase 5-4 — CLAUDE.md에 포인터 등록", "r0"],
             ["CMA 병렬 생성", "Phase 2-2 팬아웃/팬인", "r2"]],
      note=["harness의 첫 번째 원칙은 “하네스는 진화하는 시스템이다”이다.", "n"],
      sents=["논문의 층과 하네스의 단계를 나란히 놓아 보겠습니다.",
             "@r0 아이피에스 통제는 페이즈 5의 4에 해당합니다.", "@r2 씨엠에이 병렬 생성은 팬아웃, 팬인입니다.",
             "@n 하네스는 진화하는 시스템입니다."])
```

### code — 코드/문서 창(타이핑)
용도: 맥 창 모양(빨·노·초 점 + 파일명) 안에서 줄이 70자/초로 타이핑된다. 말하는 줄은 파랑 배경, `mark` 큐의 줄은 주황. 선택으로 오른쪽 패널, 창 안 도장.

| 키 | 모양 | 비고 |
|---|---|---|
| `file` | str | 창 제목 |
| `lines` | `[[줄, 큐]]` | 필수. `#`로 시작하는 줄은 주황. 빈 줄은 `["", ""]`. 같은 큐의 줄은 이어서 타이핑. 큐가 `""`이면 처음부터 순서대로 |
| `mark` | `[큐, 라벨]` | 그 큐 줄을 주황 강조. **라벨(`[1]`)은 현재 쓰이지 않는다** |
| `stamp` | `[텍스트, 큐]` | 창 오른쪽 아래 빨간 도장이 떨어져 박힌다 |
| `panel` | `dict(head, items=[[텍스트, 큐]])` | 있으면 오른쪽 주황 카드 + 코드 글씨 23px(없으면 29px) |
| `banner` | `[텍스트, 큐]` | bannerTone 미지원 |

예(pension-xs, 줄임):
```python
slide(kind="code", eyebrow="연결", title="정책 문서가 시스템에 꽂히는 자리", subtitle="CLAUDE.md는 새 세션마다 읽힌다",
      file="CLAUDE.md",
      lines=[["# 자율주행 포트폴리오 MVP", ""], ["", ""],
             ["## 하네스", "c1"], ["트리거: 자산배분 관련 요청 시 스킬을 사용하라.", "c1"],
             ["- 정책: ips.md — 이 파이프라인의 헌법이다.", "c3"]],
      mark=["c3", "헌법"],
      banner=["사람을 규율하던 문서가 그대로 기계를 규율한다", "b"],
      sents=["정책 문서가 시스템에 꽂히는 자리입니다.", "@c1 하네스 절에는 트리거가 적혀 있습니다.",
             "@c3 그리고 정책입니다. 아이피에스 문서는 이 파이프라인의 헌법입니다.",
             "@b 사람을 규율하던 문서가 그대로 기계를 규율합니다."])
```
stamp 예(pension-xs): `stamp=["자동 반영 차단", "c4"]`.

### tree — 결정 트리 도해
용도: 노드가 큐에 맞춰 자라고 가지가 뻗는다. `paths`가 켜지면 그 경로 노드·가지가 굵은 색으로 빛난다. 결정트리·고립트리 공용이지만 일반 트리 도해로도 쓸 수 있다.

`tree=dict(...)`:

| 키 | 모양 | 비고 |
|---|---|---|
| `nodes` | `[dict(id, x, y, t, type, cue, parent?, edge?, sub?, wd?)]` | 좌표는 SVG 픽셀(0~w, 0~h). `type`: `"q"`(질문, 파랑 테두리·패널 바탕) · `"good"`(초록) · `"bad"`(빨강) · `"leaf"`(노랑). `edge`는 가지 라벨, `sub`는 노드 아래 작은 글, `wd`는 폭 강제 |
| `paths` | `[dict(ids=[id…], cue, tone)]` | 경로 강조 |
| `notes` | `[dict(x, y, t, cue, tone?="sub", size?=26, anchor?, w?)]` | 자유 위치 글 |
| `w`, `h` | int | 기본 1060×560 |
| `full` | bool | 참이면 오른쪽 패널 없이 전체 폭(w를 1720 정도로) |

슬라이드 키: `tree`, `formulas`, `items`, `itemSize`, `banner`, `bannerTone`, `note`. 예(fml-midterm-cs, 줄임):
```python
slide(kind="tree", eyebrow="Trees · how a tree decides", title="A decision tree asks yes/no questions",
      tree=dict(w=1060, h=560, nodes=[
          dict(id="r", x=530, y=60, t="income > $50k ?", type="q", cue="n0"),
          dict(id="a", x=270, y=240, t="debt ratio < 40% ?", type="q", parent="r", edge="no", cue="n1"),
          dict(id="l1", x=130, y=420, t="approve", type="good", parent="a", edge="yes", cue="n2"),
          dict(id="l2", x=400, y=420, t="reject", type="bad", parent="a", edge="no", cue="n2")],
          paths=[dict(ids=["r", "a", "l1"], cue="pa", tone="yellow")]),
      items=[["Grown to the end → overfits", "i3", "red"]],
      banner=["Root question → branches → leaf holding the decision", "b"],
      sents=["Now trees.", "@n0 It starts at the root.", "@n1 Each answer sends the applicant down a branch.",
             "@n2 Until a leaf is reached.", "@pa For example, this applicant is approved.",
             "@i3 A tree grown to the end overfits.", "@b Root, branches, leaf."])
```

### matrix — 2×2 혼동행렬
용도: 2×2 칸이 차례로 차며 숫자를 센다. `rowCue`에 첫 행(초록 테두리, 재현율), `colCue`에 첫 열(노랑 테두리, 정밀도)이 둘러지고 아래 두 줄 글.
열 머리 `"positive"`/`"negative"`는 **영어 고정**. 일반 2×2 표로 쓰려면 이 점을 감안.

| 키 | 모양 | 비고 |
|---|---|---|
| `cm` | `dict(rows=[행1, 행2], cells=[[라벨, 수, 큐, tone]×4], rowCue, colCue, rowText, colText, predLabel?="Predicted")` | cells 순서: 좌상·우상·좌하·우하 |

슬라이드 키: `cm`, `formulas`, `items`, `itemSize`, `banner`, `bannerTone`, `note`. 예(fml-sup02-motion):
```python
slide(kind="matrix", eyebrow="4 · ROC curve", title="Lower the threshold to 0.1",
      cm=dict(predLabel="Predicted (threshold 0.1)", rows=["Actually obese", "Not obese"],
              cells=[["TP", 4, "c1", "green"], ["FN", 0, "c1", "muted"], ["FP", 2, "c2", "red"], ["TN", 2, "c2", "muted"]],
              rowCue="rr", colCue="pp", rowText="Recall = 4 / 4 = 1.0", colText="Precision = 4 / 6 ≈ 0.67"),
      items=[["No false negatives", "c1", "green"], ["Two false positives", "c2", "red"]], itemSize=26,
      banner=["A lower threshold catches every positive and pays with false positives", "b"],
      sents=["What happens if we lower it to 0.1?", "@c1 Every obese mouse is caught.",
             "@c2 But two are wrongly called obese.", "@rr Recall is one.", "@pp Precision drops to four out of six.",
             "@b A lower threshold gives more false positives."])
```

---

## 2. 모양이 고정적인 범용 kind

### cycle — 순환도(자기개선)
용도: 왼쪽 원 위에 번호 노드, 가운데 원에 두 줄 글, 노드 사이(3번→1번 자리, 왼쪽 위)에 빨간 게이트 상자. 오른쪽에 번호 목록. 모두 나온 뒤 주황 호가 돈다.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `items` | `[[텍스트, 큐]]` | 필수 | 게이트 위치가 **3항목 기준으로 고정** |
| `gate` | `[텍스트, 큐]` | **필수** | |
| `center` | `[줄1, 줄2]` | 선택 | 기본 `["메타", "에이전트"]` |
| `head` | str | 선택 | |
| `note` | `[텍스트, 큐]` | **필수** | |
| `banner` | `[텍스트, 큐]` | **필수** | `bannerTone` 지원 |

예(pension-xs, 줄임):
```python
slide(kind="cycle", eyebrow="층⑤ 자기개선", title="자기개선 — 스스로를 고쳐 쓴다",
      head="메타 에이전트가 하는 일",
      items=[["과거 예측을 실현 수익률과 대조한다", "i0"], ["어느 에이전트가 틀렸는지 남긴다", "i1"],
             ["다른 에이전트의 코드와 프롬프트를 고쳐 쓴다", "i2"]],
      gate=["사람 승인", "g"],
      banner=["여기서 감독이 필요하다", "b"], bannerTone="red",
      note=["우리 MVP는 제안까지만 하고 반영은 사람이 결정한다.", "g"],
      sents=["다섯 번째 층은 자기개선입니다.", "@i0 먼저 과거 예측을 대조합니다.", "@i1 틀린 곳을 남깁니다.",
             "@i2 그리고 코드와 프롬프트를 고쳐 씁니다.", "@b 바로 여기서 감독이 필요합니다.",
             "@g 그래서 반영은 사람이 결정합니다."])
```
fts-midterm-cs는 `center=["Box–", "Jenkins"]`로 썼다.

### layers — 여섯 층
용도: 세로로 쌓인 층 막대(왼쪽 색 칸 이름 · 설명 · 오른쪽 칩), 마지막 층에서 맨 위로 되돌아가는 주황 화살표(세로 글), 노란 점이 위→아래로 흐른다.
색 계산이 **6행 전제**(`i===5`가 주황). 행 수가 다르면 색이 어긋난다.

| 키 | 모양 | 필수 |
|---|---|---|
| `rows` | `[[이름, 설명, 칩, 큐]]` (6행) | 필수 |
| `loop` | `[화살표 글, 큐]` | 필수 |
| `banner` | `[텍스트, 큐]` | 필수(bannerTone 미지원) |

예: pension-xs 4장(위 출력 참조 — `rows=[["거버넌스", "IPS가 전 과정을 제약한다", "W01 · W15", "r0"], …6행], loop=["고쳐 쓴다", "loop"], banner=[…, "b"]`).

### paper — 논문 카드
용도: 왼쪽 2열 표(항목/내용, 머리 "항목"·"내용" 고정), 오른쪽 세로 큰 숫자 타일들(0에서 센다), 아래 인용과 노트.

| 키 | 모양 | 필수 | 비고 |
|---|---|---|---|
| `rows` | `[[항목, 내용, 큐]]` | 필수 | |
| `kpis` | `[[숫자문자열, 라벨, 큐]]` | 필수 | `"50"`, `"20+"` — `+`는 떼고 센 뒤 다시 붙인다. 숫자 외 글자는 안 됨 |
| `quote` | `[텍스트, 큐]` | **필수** | |
| `note` | `[텍스트, 큐]` | **필수** | |

예(pension-xs):
```python
slide(kind="paper", eyebrow="논문", title="The Self Driving Portfolio",
      rows=[["저자", "Andrew Ang · Nazym Azimbayev · Andrey Kim", "r0"], ["분량", "31쪽 · 전시 11개", "r2"]],
      kpis=[["50", "전문 에이전트", "r4"], ["20+", "구성 방법", "r4"]],
      quote=["“에이전틱 AI는 투자자의 역할을 분석 실행에서 감독으로 옮긴다” — 초록 첫 문장", "q"],
      note=["Andrew Ang은 팩터투자 연구자다.", "n"],
      sents=["이 세션의 바탕이 되는 논문입니다.", "@r0 저자는 …입니다.", "@r2 분량은 31쪽입니다.",
             "@r4 전문 에이전트 약 50개가 20가지가 넘는 방법을 다룹니다.", "@q 초록의 첫 문장이 주장입니다.",
             "@n 앤드루 앵은 팩터투자 연구자입니다."])
```

### alloc — 구성비 가로 막대
용도: 위에 범례, 안마다 한 줄: 주황 원 태그 · 이름 · 100% 가로 막대(조각이 차례로 참, 조각 안 `NN%`) · 오른쪽 칩들.

| 키 | 모양 | 비고 |
|---|---|---|
| `legend` | `[[라벨, tone]]` | 필수 |
| `opts` | `[dict(tag, name, cue, parts=[[라벨, 퍼센트, tone]], chips=[[텍스트, tone]])]` | 필수. 퍼센트 0인 조각은 생략. 칩 영역 560px |
| `banner`, `bannerTone`, `note` | | 선택 |

예(pension-w06as-t4, 줄임):
```python
slide(kind="alloc", eyebrow="세 안", title="보수형 · 균형형 · Yale 추종형",
      legend=[["주식", "blue"], ["국채", "green"], ["현금", "muted"], ["사모투자", "orange"]],
      opts=[dict(tag="A", name="보수형", cue="a",
                 parts=[["주식", 65, "blue"], ["국채", 30, "green"], ["현금", 5, "muted"], ["사모", 0, "orange"]],
                 chips=[["현금성 35%", "green"], ["지출률 4.0%", "blue"]])],
      banner=["결정할 문제 — 세 안 가운데 무엇을 승인할 것인가", "q"],
      sents=["세 안을 보겠습니다.", "@a 에이는 보수형입니다.", "@q 무엇을 승인할지 결정합니다."])
```

### promptmap — 프롬프트 노선도
용도: roadmap과 비슷하나 역 원 안에 `P1`→`1`, 역마다 3줄(아이디·설명·산출물). 위아래로 엇갈려 놓인다. 하단 `note`가 **배너로** 그려진다.

| 키 | 모양 | 비고 |
|---|---|---|
| `groups` | `[dict(label, tone, cue, items=[[아이디, 설명, 산출물]])]` | 원 안 글은 `아이디.replace("P","")`. 산출물에 `.`이 있으면 MONO 글꼴 |
| `note` | `[텍스트, 큐]` | **필수**(배너로 표시) |

예: pension-xs 21장(`groups=[dict(label="구조를 세운다", tone="blue", cue="g1", items=[["P1", "환경을 준비해줘", "환경 · harness"], …]), …]`).

---

## 3. 도메인 전용 kind (재사용 비권장)

### flow — 오케스트레이터 흐름 (pension-xs)
용도: 4열 단계(번호 원·패턴·에이전트 상자들), 단계 사이 화살표, 단계별 산출 파일이 아래 주황 "버스"로 떨어진다. 아래 주황 패널.
**4단계 고정**(열 폭·화살표 계산), 버스 글 `runs/{날짜}/ — 모든 값은 이 폴더의 JSON을 거친다` **고정**.

| 키 | 모양 |
|---|---|
| `stages` | `[dict(n, agents=[str], pattern, out, cue)]` ×4 |
| `panel` | `dict(head, items=[[텍스트, 큐]])` — 필수(버스 등장도 `panel.items[0]` 큐) |

예: pension-xs 14장(`stages=[dict(n="1", agents=["cma-builder"], pattern="파이프라인", out="cma.json", cue="s1"), …]`).

### prompt — 프롬프트 실습 장 (pension-xs)
용도: 큰 주황 태그(P1…), 제목, "어디" 칩·장소·옆말. 왼쪽 채팅 창(오른쪽 정렬 파란 말풍선 "입력 · 프롬프트"가 타이핑 → "출력 · Claude Code" 줄들/표/결정 카드), 선택으로 오른쪽 viz 위젯, 맨 아래 초록 "확인" 줄.
라벨 "어디", "입력 · 프롬프트", "출력 · Claude Code", "근거", "확인" **고정**(한국어). Header·eyebrow 없음.

| 키 | 모양 | 비고 |
|---|---|---|
| `tag`, `title`, `where`, `side` | str | |
| `prompt` | `[[줄, 큐]]` | 필수. 같은 큐 줄은 이어 타이핑(34자/초) |
| `out` | `[[줄, 큐, tone]]` | tone `""`이면 회색, `"red"`면 ✕ 아이콘 |
| `outTable` | `dict(cols, rows=[[[셀…], 큐]])` | 열 폭 `[2.6,1.6,1.4,3.6]` 고정(4열) |
| `cards` | `[[번호, 제목, 본문, 근거, 큐]]` | 결정 카드(높이 340) |
| `viz` | `dict(type=…, …)` | 아래 표. 있으면 채팅 창이 1.45:1로 좁아진다 |
| `check` | `[텍스트, 큐]` | **필수** |

`out`·`outTable`·`cards` 가운데 하나는 있어야 "출력" 머리가 뜬다(셋 다 없으면 머리 없음).

viz 종류(`viz.tsx`): `tree`(items `[[이름, 깊이, 큐]]`) · `chips`(items `[[이름, 층]]`) · `bands`(items `[[라벨, lo, hi]]`, clauses `[[글, 큐]]`) ·
`split_window`(total, train, test, shrink `dict(cue,label,before,after)`, kpi `[라벨, 값, 큐]`) · `scores`(dims, cands `[[이름, [점수…]|None, 큐, 합계?]]`, winner `[이름, 큐]`) ·
`threshold_move`(frm, to, cands, scores) — 여기까지는 props만 읽는다.
`weights`(threshold; **`DATA.tickers`, `DATA.alloc` 필요**, 후보 이름·큐 `o1~o3` 하드코딩) · `exp_real`(**`DATA.meta.portfolios`**) · `errors`(**`DATA.meta`**, `DATA.tickers`)는 pension-xs 데이터 전용.

예: pension-xs 30장(`kind="prompt", tag="P9", … cards=[["1", "집행 승인", "…", "…", "o1"], …], check=[…, "chk"]`).

### results — 결과표 + 기대 대 실현 막대 (pension-xs)
`cols`, `rows`(table 꼴 dict), `panel`. 열 폭 7열 고정, 오른쪽 아래 위젯이 `exp_real`(DATA.meta.portfolios, 큐 `r0~r2` 하드코딩). 다른 강의에서 쓰지 말 것.

### errors — 자산별 예측오차 (pension-xs)
`gld=dict(cue, exp, real, err)`, `mae=[문자열, 큐]`, `head`, `items=[[텍스트, 큐]]`, `banner`(필수). 왼쪽 막대는 `DATA.meta.forecast_error`·`DATA.tickers`에서. pension-xs 전용.

### cppi — CPPI 개념도 (pension-w06as-t3)
합성 수익률 경로(코드에 하드코딩)로 보장선·적립금·여유분·급락 고착을 그린다. 범례 문구 한국어 고정, "개념도 — 합성 경로, 과제 숫자 아님" 표기.
키: `items=[[텍스트, 큐, tone]]`, `banner`, `bannerTone`, `cues=dict(floor, path, cush, lock)`.
**알려진 문제**: spec의 `cues=dict(...)`는 빌드가 `s.cues`(큐→초)로 덮어쓰므로 `s.cues.floor`는 `undefined`가 되어,
차트 네 요소는 큐와 무관하게 **장 시작 직후 순서대로** 그려진다(글머리 items만 큐를 따른다). 쓰려면 컴포넌트를 `s.chartCues` 같은 다른 이름으로 고쳐야 한다.

### trainsplit · bagging · boosting — 고정 그림 (FML)
그림 안 글이 **영어로 하드코딩**되어 있고 큐 키도 고정이다. 바꿀 수 있는 것은 eyebrow·title·subtitle·banner·note(+trainsplit의 오른쪽 `items`·`formulas`).

| kind | 고정 큐 키 | 내용 |
|---|---|---|
| `trainsplit` | `a0` `sh` `sp` `ok` `b0` `bt` `lk` | ① row 1~10 섞어서 80/20 ② 2015~2024 순서대로 과거/미래, 누출 화살표 |
| `bagging` | `fam` `b1` `b2` `b3` `rf` | Ensemble→Bagging, 부트스트랩 3개 → 트리 → 투표 "default 2–1", 랜덤 포레스트 문장 (전체 폭) |
| `boosting` | `fam` `t1` `t2` `t3` `sum` `cmp` | 순차 트리 3개, 가중합, 배깅 대 부스팅 비교 카드 (전체 폭) |

예(fml-sup05-motion): `slide(kind="bagging", eyebrow="3 · Ensembles", title="Bagging: …", subtitle="…", banner=["…", "b"], sents=["…", "@fam …", "@b1 …", "@b2 …", "@b3 …", "@rf …", "@b …"])`.

### cs — 치트시트 덱 이식 (pension-w08-cs · cbf-dl-motion)
`kinds6.tsx`. 원래 `cs_build.js` 덤프를 build.py가 글자 수로 큐를 매겨 **음성 없는** 영상으로 만든 것. 하위꼴은 `cs=` 키로 고른다.
공통: 머리는 `eyebrow`·`title`·**`sub`**(subtitle 아님, 50px 제목). 결론 띠는 **`k=dict(text, cue)`**. 문자열 안 `$…$`는 KaTeX로 조판된다
(`tex`·`cue`·`cs`·`key`·`src`·`kind`·`size` 키는 제외). 글머리 상자 `L`/`R` = `dict(head, items=[dict(text, cue)])`, `darkR=True`면 R이 주황.

| cs= | 키 |
|---|---|
| `cover` | `org`, `title`(`\n` 줄바꿈), `sub`, `chain=[str]` — 큐 키 고정 `t`, `sub`, `c0`…`cN` |
| `divider` | `num`, `title`, `sub` — 큐 `t`, `sub` |
| `closing` | `statements=[dict(text, cue)]`, `message`(`\n`), `note` — 큐 `msg`, `note` |
| `agenda` | `items=[dict(num, title, kicker, desc, cue)]`(2열 격자), `k` |
| `sheet` | `eqs=[dict(tex, cap?, size?, cue)]`, `L`, `R`, `darkR`, `k` |
| `rules` | `L`, `R`, `darkR`, `k` |
| `qa` | `q=dict(label, text, cue)`, `eqs?`(첫 개만), `L`, `R`, `darkR`, `k` |
| `table` | `head=[열]`, `widths`, `rows=[dict(cells, cue, tone?)]`, `L?`, `R?`, `k` (마지막 열 노랑) |
| `pictureSide` | `fig=dict(src, cue)`(바탕 `#F5F4EF`), `head`, `eqs?`, `lines=[dict(text, cue)]`, `k` |
| `flow` | `steps=[dict(cap, lines=[str], dark?, cue)]`(→ 화살표), `k` |
| `qaEqRead` | `q`, `eqs[0]`, `under=dict(text, cue)`, `R`, `k` |
| `hedgeVerdict` | `q`, `eqs[0]`, `side=dict(head, items)`, `L`, `R` |
| `problem` | `q`, `opts=[dict(text, cue)]` |
| `derive` | `eqs=[…]`(왼쪽에 단계별), `R`, `k` |

나레이션 강의에서도 `slide(kind="cs", cs="rules", title=…, sub=…, L=…, R=…, k=dict(text=…, cue="k"), sents=[…])`처럼 쓸 수 있다
(motion_build 점검은 dict의 `cue=`도 인식). 예(pension-w08-cs scenes.json의 rules 장을 spec 꼴로):
```python
slide(kind="cs", cs="rules", eyebrow="중간고사 치트시트 · 1부",
      title="비유동성 프리미엄은 견딜 조건과 거둘 조건이 모두 필요하다", sub="4번 — 비중만 5%에서 20%로 늘리려는 누리연금",
      L=dict(head="견딜 수 있는 조건", items=[dict(text="먼 지급 시계", cue="L0"), dict(text="안정된 이사회", cue="L1")]),
      R=dict(head="거둘 수 있는 조건", items=[dict(text="상위 GP 접근권", cue="R0"), dict(text="누리연금: 비어 있다", cue="R1")]),
      darkR=True, k=dict(text="접근권 없이 늘린 비중은 보수와 잠금 비용만 진다", cue="k"),
      sents=["…", "@L0 …", "@L1 …", "@R0 …", "@R1 …", "@k …"])
```

### dl — CBF Direct Lending 하위꼴 (cbf-dl-motion)
`kinds8.tsx`. 하위꼴은 `dl=` 키. 머리는 eyebrow·title만(**부제 없음**), 결론 띠 `k=dict(text, cue)`. 원래 음성 없는 영상용이지만 몇몇은 범용으로 쓸 만하다(★).
보조 카드 `side=dict(head, items=[dict(text, cue, tone?)])`, 수식 `eq=dict(tex, cap?, cue, size?=44, h?=96, tone?="gold")`.

| dl= | 키 | 비고 |
|---|---|---|
| ★`stats` | `items=[dict(num=dict(to, pre?, suf?, dec?) 또는 big=str, label(`\n`), tone?, hero?, cue)]`, `cols`(4), `big`(60), `hero`(큰 타일 하나), `side`, `k` | 숫자가 0에서 세어 오르는 타일 격자 |
| ★`cards` | `topline=dict(text, cue)`, `cards=[dict(head, items=[str], cue, tone?, dark?, num?)]`, `size`(34), `stats=[stats 항목]`, `k` | 카드 안 줄이 차례로 |
| ★`bars` | `bars=[dict(v, label, disp?, tone, cue)]`, `min`, `max`, `groups=[dict(label, from, to)]`, `h`, `side`, `eq`, `k` | 세로 막대 |
| ★`timeline` | `bands=[dict(x0, x1, text, dark?, cue)]`, `points=[dict(x, top, bot=[str], cue)]`, `foot=dict(text, cue)`, `k` | x는 픽셀(0~1720) |
| ★`numlist` | `items=[dict(head, text, cue)]`, `k` | 번호 붙은 질문 목록 |
| `line` | `x=[라벨]`, `ymin`, `ymax`, `yticks`(%), `thresh=dict(v, label, cue)`, `series=[dict(y, labels?, name, tone, cue, labelDy?)]`, `eq?`, `side`(필수), `k` | y축 `%` 고정 |
| `asym` | `rows=[dict(label, up, upDisp, upNote, tone?, cue)]`(2행), `side`(필수), `k` | −100…+300% 축 고정 |
| `zones` | `zones=[dict(head, lines=[str], w?, dark?, red?, cue)]`, `axis`, `k` | |
| `eci` | `q=dict(label, text, cue)`, `top`/`bot`=`dict(head, sub, pct, items, flex?, cue)`, `k` | |
| `stack` | `parts=[dict(name, v, tone, cue)]`, `max`, `eqs`, `side`, `k` | "합계 약 x%" 고정 |
| `energy` | `steps=[dict(cap, lines, cue)]`, `focus=dict(head, items)`, `k` | |

예(cbf-dl-motion build.py의 stats 장을 spec 꼴로):
```python
slide(kind="dl", dl="stats", eyebrow="CBF Direct Lending", title="138개 부도 기업에서도 원금은 지켰다",
      items=[dict(num=dict(to=138, suf="곳"), label="27년간 부도 기업", cue="i0"),
             dict(num=dict(to=3.75, dec=2, suf="%"), label="연평균 부도율", cue="i1"),
             dict(num=dict(to=71, suf="%"), label="부도 대출 평균 회수율", cue="i2"),
             dict(num=dict(to=1.1, dec=1, suf="%"), label="연 손실률\n원금 · 실현+미실현", tone="red", cue="i3")],
      cols=4, big=60, k=dict(text="부도는 났지만 원금 손실은 작았다", cue="k"),
      sents=["…", "@i0 …", "@i1 …", "@i2 …", "@i3 …", "@k …"])
```

---

## 4. kind별 공통 키 지원표

| kind | subtitle | banner | bannerTone | note | 비고 |
|---|---|---|---|---|---|
| cover | ○(주황) | × | × | × | desc·footer |
| split · table · cards · kpis · formula · grid · template · alloc · plot · figure · matrix · tree · trainsplit · bagging · boosting | ○ | ○ | ○ | ○ | |
| steps | ○ | ○ | × | ○ | quote·shift |
| code | ○ | ○ | × | × | |
| weights · roadmap · ask · cppi | ○ | ○ | ○ | × | |
| cycle | ○ | 필수 | ○ | 필수 | |
| layers | ○ | 필수 | × | × | |
| mapping | ○ | × | × | 필수 | |
| paper | ○ | × | × | 필수 | quote 필수 |
| promptmap | ○ | (note가 배너) | × | 필수 | |
| flow · results | ○ | × | × | × | panel |
| errors | ○ | 필수 | × | × | |
| prompt | × | × | × | × | check 필수 |
| cs · dl | `sub`(cs만) | `k` | × | × | |
