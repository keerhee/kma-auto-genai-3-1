---
name: motion-lecture
description: 덱(PPTX·PDF)이나 대본을 장표 이미지 없이 Remotion으로 «다시 그리는» 나레이션 모션그래픽 강의영상(MotionLecture 컴포지션)을 만든다. spec.py 한 파일에 대본(문장 단위 · @큐)과 장면 명세(장 유형 kind 33종)를 쓰고, 문장 단위 TTS(Voicebox 복제음성 · edge-tts)로 실측 큐 시각을 잡아 렌더한다. "MotionLecture로", "모션그래픽 강의영상", "모션 그래픽 영상으로 다시", "리모션으로 덱을 다시 그려서", "특강I처럼", "FML 보충처럼 모션그래픽", "치트시트 모션영상", "motion lecture" 등에 사용. 원본 장표 위에 하이라이트를 얹는 navy-vox-lecture · kayrhee-slide-video와 달리 화면을 새로 짓는다. 연출이 센 숏폼·홍보 영상은 motion-studio · showreel.
---

# motion-lecture — MotionLecture 모션그래픽 강의영상

장표를 이미지로 쓰지 않고, 장마다 **장 유형(kind)** 컴포넌트로 새로 그린다. 요소는 나레이션 문장이 시작하는 순간(큐)에 나타나고, 지금 말하는 항목만 밝게 켜진다. 차분한 다크 네이비 강의 톤(격자 배경 · 주황 강조 · 하단 챕터 진행 바 · 챕터 범퍼)이 기본이다.

## 0. 어디에 있나 (스킬은 문서, 코드는 프로젝트)
- 프로젝트 루트: `/Users/keerhee/Project` (Remotion 4 · `src/index.ts` → `src/Root.tsx`에 `MotionLecture` 등록)
- 컴포지션: `src/motion/MotionLecture.tsx` · 공통 `lib.tsx` · 차트 `viz.tsx` · 장 유형 `kinds.tsx` ~ `kinds8.tsx`
- 빌드: `scripts/motion_build.py <id> narr|scenes [--estimate]` · 음성 `scripts/gen_audio_sentences.py`(Voicebox) / `scripts/gen_audio_edge.py`(edge-tts)
- 점검: `node scripts/motion_stills.mjs <id> <outDir> [--at 0.92] [장번호…]` · 렌더·마무리: `scripts/motion_finish.sh <id> <dest.mp4>`
- 강의 하나 = `lectures/<id>/script/spec.py` + `public/lectures/<id>/{audio,fig}/`. 완성본 `out/<id>.mp4` → dest로 복사
- **장 유형 33종의 props · 예시 = `reference/kinds.md`** (spec을 쓰기 전에 필요한 kind만 찾아 읽는다)
- 지난 작업 예시 spec: `lectures/pension-xs`(원조 · 40장) · `pension-w06as-*` · `fml-sup02~05-motion` · `fts-midterm-cs` · `fml-midterm-cs` · `auto-tesla2008-motion`(한국어 케이스 스토리 · 삽화 figure)

## 1. 흐름
1. **원본 읽기** — 덱 텍스트(pdftotext · python-pptx)와 렌더(pdftoppm)를 보고, 원문 수치·인용을 따로 적는다(없는 숫자 지어내지 않기).
2. **lectureId 정하기** — `<과정>-<주제>-motion` 꼴(예 `fml-sup03-motion`). 폴더 `lectures/<id>/script/`.
3. **spec.py 쓰기** (§2) — 장마다 kind 하나 · 대본 문장 · 큐. 그림이 필요하면 `public/lectures/<id>/fig/`에 PNG.
4. `/usr/bin/python3 scripts/motion_build.py <id> narr` → `narration.json` + 큐 점검(«명세에만 있는 큐» · «'돈' 사용»).
5. **음성** (§3) — 문장 단위 TTS → `public/lectures/<id>/audio/sNN.mp3` + `_sent/`.
6. **스틸 점검** — `motion_build.py <id> scenes` → `motion_stills.mjs <id> /tmp/<id>_stills` → 장마다 한 장을 직접 보고 겹침·잘림·빈칸을 고친다.
7. **렌더** — `zsh scripts/motion_finish.sh <id> "<dest>.mp4"` (scenes 실측 → 토막 렌더(워커 2) → 오디오 −16 LUFS 재정규화 → 복사). 백그라운드로 돌린다.
8. 결과를 열어(`open`) 보여 주고, 메모리에 lectureId · 음성 · 함정을 남긴다.

## 2. spec.py 쓰는 법
```python
CHAPTERS = [("c1", "도입", 2), ("c2", "사례", 4)]     # (id, 진행 바 라벨, 시작 장 번호) — 시작 장(1장 제외)에 범퍼 1.8초
S = []
def slide(**kw): S.append(kw)
slide(kind="cards", eyebrow="장면 ②", title="모든 것이 동시에 무너지다", subtitle="…",
      cards=[["리먼 사태", "투자 시장이 얼어붙었다", "c1", "blue", "1"], …],
      banner=["위기의 본질은 언제나 현금이다", "b"], bannerTone="red",
      sents=["이천팔 년 가을, 모든 것이 한꺼번에 무너집니다.",
             "@c1 리먼 사태로 …", "@b 위기의 본질은 결국 현금이었습니다."])
```
- `sents`의 **문장 맨 앞** `@키 `만 큐다(문장 중간의 `@키`는 그대로 읽힌다 ⛔). 같은 문장에 둘을 띄우려면 두 요소에 같은 키를 준다.
- 큐가 없는 요소는 에러 없이 장 시작 직후 뜬다. 배너는 마지막 문장 큐에 걸어야 처음부터 뜨지 않는다.
- 묶음(카드·행·글머리) 요소마다 큐를 따로 주면 «지금 말하는 것»만 켜진다(useFocusKey).
- **tone**: `green` `red` `orange` `muted`만 그 색, 나머지(`blue` · 오타 · `yellow`)는 파랑. 주황은 강조 기본색.
- 제목은 한 줄(약 30자 · 영어 55자) — 두 줄이면 부제가 본문(top 290)과 겹친다.
- `cover`의 `footer` 기본값은 연기금 과정명 → 다른 과정은 반드시 `footer=` 지정.
- spec 필드에 `lead` `cues` `n` `dur` `tail` `audio` 이름을 쓰지 않는다(빌드가 덮어씀 — dl 장은 `topline`).
- numpy를 쓰는 spec은 `/usr/bin/python3`로 빌드(PATH python3엔 numpy가 없을 수 있다). 차트 값은 손으로 적지 말고 데이터·시뮬레이션에서 계산(고정 시드).
- 연기금 강의 폴더 영상은 하이라이트 상자를 넣지 않는다(메모리 feedback_no_lecture_highlights).

### 장 유형 고르기 (자세한 props = reference/kinds.md)
| 필요 | kind |
|---|---|
| 표지 | `cover` (eyebrow · title · subtitle · desc=[[글, 큐]] · footer) |
| 왼쪽 «무슨 일» / 오른쪽 «의미» | `split` (left/right=dict(head, tone, items=[[글, 큐]])) |
| 2~4개 나란히 | `cards` ([[제목, 본문, 큐, 톤, 배지?, 꼬리?]]) |
| 큰 숫자 · 전후 | `kpis` ([[라벨, from, to\|None, 단위, 큐, 톤, 자릿수?]] — 글자 값은 from에 문자열 · to None) |
| 시간 흐름 | `roadmap` (groups=[dict(label, tone, cue, items=[…])]) · `steps` (items=[[제목, 본문, 큐]]) |
| 그림 + 요점 | `figure` (fig=dict(src="lectures/<id>/fig/x.png", w, h, bg) · items · marks) |
| 인용 · 질문 | `ask` (quote=[글, 큐] · items) |
| 표 | `table` (cols · rows=[dict(cells, cue, tone?)] · accentCol) |
| 수식 | `formula` (KaTeX) · 차트 `plot` · 순환 `cycle` · 대응 `mapping` · 층 `layers` |
| 특정 과정 전용 | `cppi` `cs` `dl` `prompt` `results` `errors` `trainsplit` `bagging` `boosting` (kinds.md 참고) |
새 꼴이 필요하면 `src/motion/kindsN.tsx`를 새로 만들어 MotionLecture.tsx의 switch에 등록하고 kinds.md에 한 절 보탠다.

## 3. 음성
- **Voicebox(한국어 복제음성)**: `/usr/bin/python3 scripts/gen_audio_sentences.py lectures/<id>/script/narration.json public/lectures/<id>/audio <profile_id> --tempo T --pitch P`
  - 문장마다 생성 → 문장 사이 1.0초(물음표 1.5초) 정확한 무음 → 장별 `sNN.mp3`(−16 LUFS). 문장 캐시는 **내용 해시**(`_sent/h_<sha1(profile|tempo|pitch|v2|문장)[:16]>.wav`) — 문장이 같으면 다른 강의의 `_sent/h_*.wav`를 **그대로 복사**해 재사용할 수 있다. ⛔ 다른 도구가 이미 무음을 잘라 낸 wav에 이 스크립트의 필터(silenceremove)를 또 걸어 심지 않는다 — 말머리가 잘리고 튄다(2026-10-16 테슬라: 39문장 전부 다시 생성). 심을 땐 Voicebox 원본(자르지 않은 것)만.
  - 프로필 · 속도 기준선: 메모리 reference_voicebox_api (빌조쉬 tempo 0.85 · pitch 0.96 / Jehyun Lee 1.0 · 1.0 / 매튜리).
  - 숫자는 한글로 쓴다(«이천팔 년», «약 사억 육천오백만 달러»). 숫자 여러 개 나열 문장은 잘린다 → 나눈다. 빌조쉬는 «돈»을 된소리로 → 자금·자본.
  - 문장 s/char가 기준선보다 많이 낮으면 잘림 — 스크립트가 3회 재시도 후 쉼표에서 나눠 붙인다.
- **영어**: `scripts/gen_audio_edge.py`(edge-tts Andrew −8%) — 5단어 안팎 짧은 문장은 실패하니 늘린다.
- **음성 없이 음향만**: scenes의 `audio`를 비우고, 합성 사운드트랙을 `out/<id>_parts/audio.m4a`로 미리 두면 render_chunks가 그걸 얹는다(pension-w08-cs · cbf-dl-motion).
- 스틸 점검 · 번들링은 TTS가 끝난 뒤에(audio 폴더 임시 파일 때문에 ENOENT).

## 4. 점검 · 렌더 함정
- `scenes --estimate`는 글자 수로 어림 — 실제보다 길게(최대 약 1.9배) 나온다. 스틸 점검 전에 `scenes`를 다시 돌린다(narr만 다시 돌리면 옛 scenes.json으로 그려진다).
- 다시 렌더하기 전에 `out/<id>_parts`를 지운다(옛 토막을 그대로 쓴다).
- 렌더가 `Timeout … rendering the component`로 멈추면 메모리 스왑부터(`sysctl vm.swapusage`, Voicebox · 다른 큰 작업 내리기) → `RENDER_TIMEOUT` · `--chunk 1000`, 남은 크롬 `pkill -f chrome-headless-shell`.
- 장별 loudnorm 뒤 이어 붙이면 −16.9 LUFS로 떨어진다 → motion_finish.sh가 오디오만 한 번 더 맞춘다(결과 −16.0 확인).
- 미리보기: Studio `npx remotion studio src/index.ts --props=lectures/<id>/scenes.json --port 3123`.

## 5. 끝낼 때
- 완성 파일 경로 · 길이 · LUFS를 알리고 `open`으로 재생(요청 시).
- 메모리에 project 메모 한 장(lectureId · 원본 · 음성 · 새 kind · 함정).
