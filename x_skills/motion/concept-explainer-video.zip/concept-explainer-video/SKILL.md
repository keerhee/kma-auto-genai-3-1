---
name: concept-explainer-video
description: Build a narrated concept-explainer video in the NeoMatrix explainer style — dark navy 1920×1080 HTML scenes (eyebrow + big title + cards + bottom callout) whose elements appear step by step in sync with sentence-level narration (Voicebox cloned voice such as 빌조쉬, offline Supertonic on CPU, or edge-tts), cross-faded and loudness-normalised. Use when the user asks for "개념 설명 영상", "설명 영상 만들어줘", "NeoMatrix 소개영상 스타일", "용어 풀이 영상", "explainer video", "concept scenes with narration", "빌조쉬 목소리 설명 영상", or wants to add explainer scenes to an existing video. Not for turning an existing PPTX into a lecture video (use kayrhee-slide-video / navy-vox-lecture) or for live animated decks (live-deck-video).
---

# Concept Explainer Video

A short video that explains ideas one scene at a time. Each scene is an HTML page;
each sentence of narration reveals the next piece of the page. This is the method
behind the NeoMatrix Substack explainer (the scenes AX0–RC, P1–A1).

```
script.json ──tts.py──▶ out/_sent/<ID>_<kk>.wav   (one wav per sentence, cached by text)
scenes.html ─┐
script.json ─┴render.py──▶ Chrome screenshot per step ▶ cross-fade on sentence starts
                           ▶ per-scene mp4 ▶ concat ▶ loudnorm −16 LUFS ▶ explainer.mp4
```

## Requirements

- `ffmpeg`/`ffprobe`, Python 3.9+, Google Chrome (or Chromium/Edge; `CHROME=` to override).
  On Linux, render.py prefers Playwright's `chrome-headless-shell` (Linux Chromium `--headless=new`
  cuts ~90 px off the bottom of a 1920×1080 shot)
- Narration, one of (`--engine auto` picks the first that applies):
  - **Voicebox** local server at `127.0.0.1:17493` with a cloned-voice profile (best quality; Mac)
  - **Supertonic** offline, CPU only, ~4× faster than real time — `bash scripts/setup_local.sh` once
    (sherpa-onnx + models from GitHub releases + Pretendard from npm). Works in sandboxes where
    Hugging Face, jsDelivr and Microsoft's speech server are blocked (e.g. Claude cloud sessions)
  - **edge-tts**: `uv run --with edge-tts python scripts/tts.py … --engine edge` (network)
- QA `--whisper` head check: mlx-whisper when importable (Apple Silicon), else the offline Korean
  ASR installed by setup_local.sh
- Fonts: Pretendard from the jsDelivr CDN, or the locally installed copy (setup_local.sh); else
  Apple SD Gothic Neo / Noto Sans KR / Malgun Gothic

## Workflow

1. **Make a work folder** and copy the templates:
   `templates/scenes_template.html → scenes.html`, `templates/script_example.json → script.json`.
2. **Plan scenes** (read `references/style.md` first). One idea per scene, 4–8 sentences each.
   Order the video so terms come before they are used, and end with a one-line-each RECAP.
3. **Write `script.json`** — per scene: `id` (matches the HTML section id), `sents`
   (narration, written the way it should be *read aloud*), and `steps` (same length as `sents`:
   the reveal level shown while that sentence plays; non-decreasing).
4. **Write `scenes.html`** — one `<section class="scene" id="…">` per scene, reusing the four
   sample layouts (term cards 2×2, compare two cards, formula + bars, recap list). Give every
   element that should appear later `data-s="N"`. Step 0 = header only.
5. **Check the layout** before any audio: `python scripts/render.py script.json --sheet`
   → `out/contact_sheet.png` (final step of every scene). Read it; fix overlaps and overflow.
   Preview a single step in a browser: `scenes.html?s=COMPARE&k=2`.
6. **Narrate**
   ```bash
   # Voicebox 빌조쉬 (the voice used in the NeoMatrix explainer)
   uv run --with mlx-whisper python scripts/tts.py script.json \
       --engine voicebox --profile <PROFILE_ID> --tempo 0.85 --pitch 0.96 --whisper
   # sandbox / Linux / no Voicebox — offline Supertonic (after scripts/setup_local.sh)
   python scripts/tts.py script.json --engine supertonic --sid 6 --whisper
   # edge-tts where speech.platform.bing.com is reachable
   uv run --with edge-tts python scripts/tts.py script.json --engine edge --voice ko-KR-InJoonNeural
   ```
   Supertonic voices: `--sid 0-4` female, `5-9` male (6 = default male narrator); `--speed 0.9`
   slows delivery natively (prefer it to `--tempo`). Synthesis is non-deterministic, so a flagged
   sentence is simply regenerated up to `--tries` times.
   Profile ids: `curl 127.0.0.1:17493/profiles`. Only sentences whose text changed are regenerated.
   `UNRESOLVED` lists sentences that failed every retry — **reword them** (see style.md §3) and rerun.
7. **Render**: `python scripts/render.py script.json [--out name.mp4] [--only ID,ID]`.
8. **Verify**: grab frames at a few timestamps and look at them; confirm
   `ffmpeg -i out.mp4 -af ebur128 -f null -` reports about −16 LUFS; listen to any sentence tts flagged.

## Timing (render.py constants — keep unless asked)

| | value | meaning |
|---|---|---|
| `LEAD` | 0.5 s | silence before the first sentence of a scene |
| `GAP` | 1.0 s | pause between sentences |
| `TAIL` | 1.95 s | hold after the last sentence (covers the 0.8 s fade-out) |
| `XF` | 0.4 s | cross-fade of a newly revealed step, starting 0.1 s before its sentence |
| fades | 0.5 in / 0.8 out | every scene fades from and to black, so scenes join cleanly |

## Mixing with an existing video

To insert explainer scenes into another video (what the NeoMatrix explainer did), render the
scenes with the same 1920×1080 / 30 fps / 48 kHz settings, then concat the per-scene files from
`out/scenes/<ID>.mp4|.wav` with the other segments and run loudnorm once on the joined audio.

## Files

- `scripts/setup_local.sh` — one-time install of Supertonic TTS, offline Korean ASR and Pretendard (no Hugging Face/CDN needed)
- `scripts/tts.py` — sentence narration (Voicebox, Supertonic or edge-tts), onset-blip + whisper checks, "하나." lead-cut retry, text-keyed cache
- `scripts/render.py` — screenshots, per-scene video, concat, −16 LUFS; `--sheet` contact sheet
- `templates/scenes_template.html` — CSS tokens and four layouts
- `templates/script_example.json` — matching four-scene script (renders to a ~90 s sample)
- `references/style.md` — visual rules, narration rules, pronunciation traps
