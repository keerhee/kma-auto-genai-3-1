#!/usr/bin/env python3
"""Render a concept explainer video from script.json + scenes.html + sentence wavs (tts.py).

Per scene
  audio  = LEAD silence, sentences separated by GAP, TAIL silence
  video  = one screenshot per distinct step (scenes.html?s=ID&k=step, headless Chrome 1920×1080);
           each new step cross-fades in (XF s) 0.1 s before the first sentence that uses it;
           the scene fades in from black and out to black
Then all scenes are concatenated and the narration is loudness-normalised to -16 LUFS.

Usage
  python render.py script.json [--out video.mp4] [--only INTRO,RECAP] [--sheet]
  --sheet  only write out/contact_sheet.png (final step of every scene) for a layout check
Env: CHROME=/path/to/chrome if auto-detection fails.
"""
import argparse, glob, json, os, platform, shutil, subprocess as sp, sys

LEAD, GAP, TAIL, XF, SR, FPS = 0.5, 1.0, 1.95, 0.4, 48000, 30

ap = argparse.ArgumentParser()
ap.add_argument("script")
ap.add_argument("--out", default="")
ap.add_argument("--only", default="")
ap.add_argument("--sheet", action="store_true")
a = ap.parse_args()

work = os.path.dirname(os.path.abspath(a.script))
spec = json.load(open(a.script, encoding="utf-8"))
html = os.path.join(work, spec.get("scenes_html", "scenes.html"))
OUT = os.path.join(work, "out")
SC = os.path.join(OUT, "scenes")
SHOT = os.path.join(OUT, "shots")
for d in (SC, SHOT):
    os.makedirs(d, exist_ok=True)
only = set(filter(None, a.only.split(",")))


def chrome():
    env = os.environ.get("CHROME")
    if env:
        return env
    cands = {"Darwin": ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                        "/Applications/Chromium.app/Contents/MacOS/Chromium",
                        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"],
             "Windows": [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                         r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                         r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"],
             }.get(platform.system(), [])
    # Linux: prefer Playwright's chrome-headless-shell. Linux Chromium's --headless=new makes the
    # viewport ~90 px shorter than --window-size, so the bottom callout gets cut off.
    pw = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", os.path.expanduser("~/.cache/ms-playwright"))
    cands += sorted(glob.glob(os.path.join(pw, "chromium_headless_shell-*", "*", "headless_shell")), reverse=True)
    cands += [shutil.which(n) or "" for n in ("google-chrome", "chromium", "chromium-browser", "chrome")]
    cands += sorted(glob.glob(os.path.join(pw, "chromium-*", "chrome-linux*", "chrome")), reverse=True)
    for c in cands:
        if c and os.path.exists(c):
            return c
    sys.exit("Chrome not found — set CHROME=/path/to/chrome")


CH = chrome()
def run(c): sp.run(c, check=True, stdout=sp.DEVNULL, stderr=sp.DEVNULL)
def dur(p): return float(sp.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).decode())


def shot(sid, k):
    png = os.path.join(SHOT, f"{sid}_{k}.png")
    url = "file://" + html.replace(os.sep, "/") + f"?s={sid}&k={k}"
    extra = ["--no-sandbox"] if hasattr(os, "geteuid") and os.geteuid() == 0 else []  # root in containers
    if "headless_shell" not in os.path.basename(CH):
        extra.append("--headless=new")
    run([CH, "--disable-gpu", *extra, "--hide-scrollbars", "--force-device-scale-factor=1",
         "--virtual-time-budget=4000", "--window-size=1920,1080", f"--screenshot={png}", url])
    return png


def validate(sc):
    n, m = len(sc["sents"]), len(sc["steps"])
    if n != m:
        sys.exit(f"{sc['id']}: {n} sentences but {m} steps — one step per sentence")


def scene(sc):
    sid = sc["id"]
    sents = [os.path.join(OUT, "_sent", f"{sid}_{k:02d}.wav") for k in range(len(sc["sents"]))]
    miss = [s for s in sents if not os.path.exists(s)]
    if miss:
        sys.exit(f"missing narration: {miss[0]} — run tts.py first")
    starts, t = [], LEAD
    for w in sents:
        starts.append(t); t += dur(w) + GAP
    total = t - GAP + TAIL
    gap, lead = os.path.join(SC, "gap.wav"), os.path.join(SC, "lead.wav")
    run(["ffmpeg", "-y", "-f", "lavfi", "-i", f"anullsrc=r={SR}:cl=mono", "-t", str(GAP), gap])
    run(["ffmpeg", "-y", "-f", "lavfi", "-i", f"anullsrc=r={SR}:cl=mono", "-t", str(LEAD), lead])
    lst = [lead]
    for i, w in enumerate(sents):
        lst.append(w)
        if i < len(sents) - 1:
            lst.append(gap)
    sl = os.path.join(SC, f"{sid}_list.txt")
    open(sl, "w").write("".join(f"file '{f}'\n" for f in lst))
    wav, mp4 = os.path.join(SC, f"{sid}.wav"), os.path.join(SC, f"{sid}.mp4")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", sl, "-af", f"apad=whole_dur={total}",
         "-ar", str(SR), "-ac", "2", wav])
    steps = sc["steps"]
    changes = [(0.0, steps[0])]
    for k, s in enumerate(steps):
        if s != changes[-1][1]:
            changes.append((starts[k], s))
    imgs = [shot(sid, s) for _, s in changes]
    cmd = ["ffmpeg", "-y"]
    for p in imgs:
        cmd += ["-loop", "1", "-framerate", str(FPS), "-t", f"{total}", "-i", p]
    fc, last = [], "[0:v]"
    for j in range(1, len(imgs)):
        t0 = max(changes[j][0] - 0.1, 0)
        fc.append(f"[{j}:v]format=rgba,fade=in:st={t0:.3f}:d={XF}:alpha=1[f{j}]")
        fc.append(f"{last}[f{j}]overlay=format=auto[o{j}]")
        last = f"[o{j}]"
    fc.append(f"{last}fade=in:st=0:d=0.5,fade=out:st={total-1.0:.3f}:d=0.8,format=yuv420p[v]")
    cmd += ["-filter_complex", ";".join(fc), "-map", "[v]", "-t", f"{total}", "-r", str(FPS),
            "-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p", mp4]
    run(cmd)
    print(f"{sid:10s} {total:6.2f}s  steps {[(round(x, 1), s) for x, s in changes]}", flush=True)
    return mp4, wav


scenes = [s for s in spec["scenes"] if not only or s["id"] in only]
for s in scenes:
    validate(s)

if a.sheet:
    pngs = [shot(s["id"], max(s["steps"])) for s in scenes]
    cols = 3 if len(pngs) > 4 else 2
    lst = os.path.join(SHOT, "sheet.txt")
    inputs = []
    for p in pngs:
        inputs += ["-i", p]
    n = len(pngs)
    rows = (n + cols - 1) // cols
    fc = "".join(f"[{i}:v]scale=640:360[s{i}];" for i in range(n))
    pad = cols * rows - n
    for i in range(pad):
        fc += f"color=c=black:s=640x360:d=1[p{i}];"
    ins = "".join(f"[s{i}]" for i in range(n)) + "".join(f"[p{i}]" for i in range(pad))
    fc += f"{ins}xstack=inputs={cols*rows}:layout=" + "|".join(
        f"{(i % cols) * 640}_{(i // cols) * 360}" for i in range(cols * rows)) + "[o]"
    out = os.path.join(OUT, "contact_sheet.png")
    run(["ffmpeg", "-y", *inputs, "-filter_complex", fc, "-map", "[o]", "-frames:v", "1", out])
    print("sheet", out)
    sys.exit()

parts = [scene(s) for s in scenes]
vl, al = os.path.join(OUT, "v_list.txt"), os.path.join(OUT, "a_list.txt")
open(vl, "w").write("".join(f"file '{v}'\n" for v, _ in parts))
open(al, "w").write("".join(f"file '{w}'\n" for _, w in parts))
vid, aud = os.path.join(OUT, "video.mp4"), os.path.join(OUT, "audio.wav")
run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", vl, "-c", "copy", vid])
run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", al, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
     "-ar", str(SR), "-ac", "2", aud])
final = a.out or os.path.join(work, (spec.get("output") or "explainer") + ".mp4")
run(["ffmpeg", "-y", "-i", vid, "-i", aud, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac",
     "-b:a", "192k", "-shortest", "-movflags", "+faststart", final])
print(f"final {final}  {dur(final):.1f}s  (video {dur(vid):.1f}s / audio {dur(aud):.1f}s)")
