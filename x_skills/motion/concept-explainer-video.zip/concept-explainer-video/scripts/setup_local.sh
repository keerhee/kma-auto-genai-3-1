#!/usr/bin/env bash
# One-time setup for sandboxes / Linux boxes without Voicebox or edge-tts access
# (e.g. Claude cloud sessions: Hugging Face, jsDelivr and speech.platform.bing.com blocked,
#  GitHub releases + PyPI + npm open).
#
#   bash scripts/setup_local.sh
#
# Installs
#   - sherpa-onnx, soundfile, numpy        (pip)
#   - Supertonic-3 TTS int8 (31 languages incl. ko, 10 voices)   ~140 MB  (GitHub release)
#   - Korean zipformer ASR int8 for the head check (--whisper)    ~75 MB   (GitHub release)
#   - Pretendard font into ~/.local/share/fonts                            (npm)
# into ${CEV_MODELS:-~/.cache/cev-models}. Safe to rerun; existing parts are skipped.
set -euo pipefail
M="${CEV_MODELS:-$HOME/.cache/cev-models}"
REL=https://github.com/k2-fsa/sherpa-onnx/releases/download
mkdir -p "$M"

python3 -c "import sherpa_onnx, soundfile, numpy" 2>/dev/null || \
  pip install -q sherpa-onnx soundfile numpy 2>/dev/null || \
  pip install -q --break-system-packages sherpa-onnx soundfile numpy

get() {  # get <url> <dest-dir-name> <extracted-dir-name>
  [ -d "$M/$2" ] && { echo "have $2"; return; }
  echo "downloading $2 …"
  curl -fsSL "$1" -o "$M/tmp.tar.bz2"
  tar xjf "$M/tmp.tar.bz2" -C "$M" && rm "$M/tmp.tar.bz2"
  mv "$M/$3" "$M/$2"
}
get $REL/tts-models/sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 supertonic-3 \
    sherpa-onnx-supertonic-3-tts-int8-2026-05-11
get $REL/asr-models/sherpa-onnx-zipformer-korean-2024-06-24.tar.bz2 asr-ko \
    sherpa-onnx-zipformer-korean-2024-06-24
rm -f "$M"/asr-ko/*-avg-1.onnx "$M"/asr-ko/test_wavs -r 2>/dev/null || true   # keep int8 only

if ! fc-list 2>/dev/null | grep -qi pretendard; then
  echo "installing Pretendard …"
  T=$(mktemp -d); (cd "$T" && npm pack -q pretendard@1.3.9 >/dev/null && tar xzf pretendard-*.tgz)
  mkdir -p "$HOME/.local/share/fonts"
  cp "$T"/package/dist/public/static/Pretendard-*.otf "$HOME/.local/share/fonts/"
  fc-cache -f >/dev/null 2>&1 || true; rm -rf "$T"
fi
echo "ready: $M"
