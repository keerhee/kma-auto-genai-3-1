#!/usr/bin/env python3
"""Sentence-level narration for a concept explainer script.

Writes <work>/out/_sent/<SCENE>_<kk>.wav (48 kHz mono) for every sentence in script.json.
A sidecar .txt stores the sentence; a wav is regenerated only when its text changed (or --force).

Engines (--engine auto picks: voicebox if --profile given, else supertonic if its model is
installed, else edge)
  voicebox    local Voicebox (Qwen3-TTS) cloned voice at 127.0.0.1:17493
  supertonic  offline Supertonic-3 via sherpa-onnx, CPU only (scripts/setup_local.sh installs it);
              --sid 0-4 female, 5-9 male (default 6)
  edge        Microsoft edge-tts (needs network; run with `uv run --with edge-tts`)

Voicebox voices sometimes open a sentence with a stray syllable ("또", "도") or a short blip.
Each sentence is checked (onset blip + optional whisper head match) and regenerated,
alternating plain synthesis and the "하나. <문장>" lead-cut (synthesise a throwaway lead-in,
cut at the pause after it).

Usage
  python tts.py script.json [--engine auto|voicebox|supertonic|edge] [--profile ID]
                [--sid 6] [--speed 1.0] [--voice ko-KR-InJoonNeural]
                [--tempo 0.85] [--pitch 0.96] [--only INTRO,RECAP] [--force] [--whisper] [--tries 6]
  --whisper  head check with mlx-whisper when importable (Apple Silicon:
             uv run --with mlx-whisper ...), otherwise with the offline Korean ASR from setup_local.sh
"""
import argparse, asyncio, json, math, os, re, shutil, struct, subprocess, sys, time, urllib.request

SR = 48000
ap = argparse.ArgumentParser()
ap.add_argument("script")
ap.add_argument("--engine", default=os.environ.get("CEV_ENGINE", "auto"),
                choices=["auto", "voicebox", "supertonic", "edge"])
ap.add_argument("--models", default=os.environ.get("CEV_MODELS", os.path.expanduser("~/.cache/cev-models")),
                help="folder with supertonic-3/ and asr-ko/ (scripts/setup_local.sh)")
ap.add_argument("--sid", type=int, default=6, help="supertonic voice 0-9 (0-4 female, 5-9 male)")
ap.add_argument("--speed", type=float, default=1.0, help="supertonic speaking rate (larger = faster)")
ap.add_argument("--steps", type=int, default=8, help="supertonic denoising steps (quality/speed)")
ap.add_argument("--api", default=os.environ.get("VOICEBOX_API", "http://127.0.0.1:17493"))
ap.add_argument("--profile", default=os.environ.get("VOICEBOX_PROFILE", ""),
                help="Voicebox profile id (list: curl 127.0.0.1:17493/profiles)")
ap.add_argument("--language", default="ko")
ap.add_argument("--voice", default="ko-KR-InJoonNeural", help="edge-tts voice")
ap.add_argument("--tempo", type=float, default=1.0, help="speed factor after synthesis (빌조쉬: 0.85)")
ap.add_argument("--pitch", type=float, default=1.0, help="pitch factor (빌조쉬: 0.96)")
ap.add_argument("--only", default="")
ap.add_argument("--force", action="store_true")
ap.add_argument("--whisper", action="store_true", help="check each sentence head with mlx-whisper")
ap.add_argument("--tries", type=int, default=6)
a = ap.parse_args()
ST_DIR, ASR_DIR = os.path.join(a.models, "supertonic-3"), os.path.join(a.models, "asr-ko")
if a.engine == "auto":
    a.engine = ("voicebox" if a.profile else
                "supertonic" if os.path.exists(os.path.join(ST_DIR, "tts.json")) else "edge")
print("engine", a.engine, flush=True)

work = os.path.dirname(os.path.abspath(a.script))
spec = json.load(open(a.script, encoding="utf-8"))
only = set(filter(None, a.only.split(",")))
SENT = os.path.join(work, "out", "_sent")
os.makedirs(SENT, exist_ok=True)

AF = f"aresample={SR}"
if a.pitch != 1.0 or a.tempo != 1.0:
    AF = (f"aresample={SR},asetrate={int(SR*a.pitch)},aresample={SR},"
          f"atempo={a.tempo/a.pitch:.6f}")
if a.engine == "voicebox":
    AF += ",highshelf=f=6500:g=-2.5"

# Latin tokens whisper writes as letters but the script spells in hangul
NORM = [(r"MFDFA", "엠에프디에프에이"), (r"API", "에이피아이"), (r"HTTP", "에이치티티피"),
        (r"AI", "에이아이"), (r"[Qq]", "큐"), (r"%", "퍼센트")]
hang = lambda t: re.sub(r"[^가-힣]", "", t)
DIG, UNIT = "영일이삼사오육칠팔구", ["", "십", "백", "천"]


def num2ko(n):
    """Sino-Korean reading of an integer (whisper writes 백 번 as 100번)."""
    if n == 0:
        return "영"
    out, big = "", ["", "만", "억", "조"]
    for b in range(len(big)):
        part, n = n % 10000, n // 10000
        if part:
            s = ""
            for i in range(3, -1, -1):
                d = part // 10 ** i % 10
                if d:
                    s += ("" if d == 1 and i > 0 else DIG[d]) + UNIT[i]
            out = s + big[b] + out
        if not n:
            break
    return out


def norm(t):
    for x, y in NORM:
        t = re.sub(x, y, t)
    t = re.sub(r"\d+", lambda m: num2ko(int(m.group())), t.replace(",", ""))
    return hang(t)


def ff(*args):
    subprocess.run(["ffmpeg", "-y", "-v", "error", *args], check=True)


# ---------------- engines ----------------
def voicebox_raw(text, raw):
    body = {"profile_id": a.profile, "text": text, "language": a.language, "engine": "qwen", "model_size": "1.7B"}
    r = urllib.request.Request(a.api + "/generate", data=json.dumps(body).encode(),
                               headers={"Content-Type": "application/json"}, method="POST")
    g = json.load(urllib.request.urlopen(r, timeout=600))
    for _ in range(600):
        st = json.load(urllib.request.urlopen(f"{a.api}/history/{g['id']}", timeout=60))
        if st.get("status") == "completed":
            break
        if st.get("status") == "failed":
            raise RuntimeError(st.get("error"))
        time.sleep(1.5)
    open(raw, "wb").write(urllib.request.urlopen(f"{a.api}/audio/{g['id']}", timeout=120).read())


def edge_raw(text, raw):
    import edge_tts  # uv run --with edge-tts
    mp3 = raw + ".mp3"
    asyncio.run(edge_tts.Communicate(text, a.voice).save(mp3))
    ff("-i", mp3, raw)
    os.remove(mp3)


_st = None
def supertonic_raw(text, raw):
    global _st
    import sherpa_onnx as so, soundfile as sf, numpy as np
    if _st is None:
        f = lambda n: os.path.join(ST_DIR, n)
        _st = so.OfflineTts(so.OfflineTtsConfig(model=so.OfflineTtsModelConfig(
            supertonic=so.OfflineTtsSupertonicModelConfig(
                duration_predictor=f("duration_predictor.int8.onnx"), text_encoder=f("text_encoder.int8.onnx"),
                vector_estimator=f("vector_estimator.int8.onnx"), vocoder=f("vocoder.int8.onnx"),
                tts_json=f("tts.json"), unicode_indexer=f("unicode_indexer.bin"), voice_style=f("voice.bin")),
            num_threads=os.cpu_count() or 2, provider="cpu")))
    g = so.GenerationConfig()
    g.sid, g.num_steps, g.speed = a.sid, a.steps, a.speed
    g.extra["lang"] = a.language
    au = _st.generate(text, g)
    if not len(au.samples):
        raise RuntimeError("supertonic produced no audio")
    sf.write(raw, np.asarray(au.samples), au.sample_rate, subtype="PCM_16")


synth = {"voicebox": voicebox_raw, "supertonic": supertonic_raw, "edge": edge_raw}[a.engine]


# ---------------- analysis ----------------
def db_frames(wav, hop=0.01):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", wav, "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"])
    x = struct.unpack(f"<{len(raw)//2}h", raw)
    w = int(SR * hop)
    return [20 * math.log10(max(1, math.sqrt(sum(v * v for v in x[i:i + w]) / w)) / 32768)
            for i in range(0, len(x) - w, w)], len(x) / SR


def burst(db):
    """Speech opens with a short isolated blip (<0.15 s) followed by a pause (>=0.15 s)."""
    i = next((k for k, v in enumerate(db) if v > -35), None)
    if i is None:
        return True
    j = i
    while j < len(db) and db[j] > -45:
        j += 1
    k = j
    while k < len(db) and db[k] <= -45:
        k += 1
    return (j - i) < 15 and (k - j) >= 15 and k < len(db)


_asr = None
def transcribe(wav):
    """mlx-whisper when available (Apple Silicon), else offline Korean zipformer (setup_local.sh)."""
    global _asr
    try:
        import mlx_whisper
        return mlx_whisper.transcribe(wav, path_or_hf_repo="mlx-community/whisper-large-v3-turbo",
                                      language=a.language)["text"].strip()
    except ImportError:
        pass
    import sherpa_onnx as so
    if _asr is None:
        if not os.path.exists(os.path.join(ASR_DIR, "tokens.txt")):
            sys.exit("--whisper: no mlx-whisper and no offline ASR — run scripts/setup_local.sh")
        f = lambda n: os.path.join(ASR_DIR, n)
        _asr = so.OfflineRecognizer.from_transducer(
            encoder=f("encoder-epoch-99-avg-1.int8.onnx"), decoder=f("decoder-epoch-99-avg-1.int8.onnx"),
            joiner=f("joiner-epoch-99-avg-1.int8.onnx"), tokens=f("tokens.txt"), num_threads=os.cpu_count() or 2)
    # the zipformer drops the first syllable when speech starts at sample 0 -> pad 0.4 s both sides
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", wav, "-af", "adelay=400,apad=pad_dur=0.4",
                                   "-ac", "1", "-ar", "16000", "-f", "s16le", "-"])
    x = [v / 32768 for v in struct.unpack(f"<{len(raw)//2}h", raw)]
    st = _asr.create_stream(); st.accept_waveform(16000, x); _asr.decode_stream(st)
    return st.result.text.strip()


def check(text, wav):
    db, dur = db_frames(wav)
    ok_len = len(text) < 25 or 0.05 <= dur / len(text) <= 0.24
    ok_head, t = True, ""
    if a.whisper:
        t = transcribe(wav)
        h, w = norm(t)[:3], hang(text)[:3]   # >=2 of the first 3 syllables in place (넷째/내째 ASR slips)
        ok_head = sum(x == y for x, y in zip(h, w)) >= min(2, len(w))
    ok = ok_head and not burst(db) and ok_len
    return ok, (ok_head, not burst(db), ok_len), t


# ---------------- makers ----------------
def plain(text, out):
    raw = out + ".raw.wav"
    synth(text, raw)
    ff("-i", raw, "-filter:a", AF + ",silenceremove=start_periods=1:start_threshold=-50dB,"
       "areverse,silenceremove=start_periods=1:start_threshold=-50dB,areverse,afade=t=in:d=0.01",
       "-ar", str(SR), "-ac", "1", out)
    os.remove(raw)


def leadcut(text, out):
    raw, proc = out + ".raw.wav", out + ".proc.wav"
    synth("하나. " + text, raw)
    ff("-i", raw, "-filter:a", AF, "-ar", str(SR), "-ac", "1", proc)
    db, _ = db_frames(proc)
    spoke = next((i for i, v in enumerate(db) if v > -35), 0)
    cut = None
    for thr, minlen in ((-48, 8), (-42, 5)):
        i = spoke
        while i < min(len(db), 180) and cut is None:
            if db[i] < thr:
                j = i
                while j < len(db) and db[j] < thr:
                    j += 1
                if j - i >= minlen and i * 0.01 > 0.2 and j < len(db):
                    cut = j * 0.01 - 0.04
                i = j
            i += 1
        if cut is not None:
            break
    ff("-ss", f"{cut or 0.6:.3f}", "-i", proc, "-af",
       "areverse,silenceremove=start_periods=1:start_threshold=-50dB,areverse,afade=t=in:d=0.01",
       "-ar", str(SR), "-ac", "1", out)
    os.remove(raw); os.remove(proc)


if a.engine == "voicebox" and not a.profile:
    sys.exit("voicebox engine needs --profile <id> (or VOICEBOX_PROFILE). List: curl 127.0.0.1:17493/profiles")

t0, bad = time.time(), []
for sc in spec["scenes"]:
    if only and sc["id"] not in only:
        continue
    for k, s in enumerate(sc["sents"]):
        name = f"{sc['id']}_{k:02d}"
        wav, txt = os.path.join(SENT, name + ".wav"), os.path.join(SENT, name + ".txt")
        same = os.path.exists(txt) and open(txt, encoding="utf-8").read() == s
        if os.path.exists(wav) and same and not a.force:
            continue
        best = None
        for tr in range(2 if a.engine == "edge" else a.tries):
            cand = wav + f".c{tr}.wav"
            (leadcut if (a.engine == "voicebox" and tr % 3 == 2) else plain)(s, cand)
            ok, score, t = check(s, cand)
            if best is None or score > best[0]:
                best = (score, cand)
            if ok:
                break
        shutil.move(best[1], wav)
        for f in os.listdir(SENT):
            if f.startswith(name + ".wav.c"):
                os.remove(os.path.join(SENT, f))
        open(txt, "w", encoding="utf-8").write(s)
        if not ok:
            bad.append(name)
        print(f"{name} {'ok ' if ok else 'BEST'} try{tr} {db_frames(wav)[1]:5.2f}s  {s[:30]}  ({time.time()-t0:.0f}s)", flush=True)
print("UNRESOLVED", ",".join(bad) if bad else "-")
