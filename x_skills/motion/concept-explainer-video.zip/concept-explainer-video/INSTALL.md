# concept-explainer-video 설치

NeoMatrix 소개영상의 설명 장면 방식(어두운 네이비 HTML 장면 + 문장 단위 나레이션 + 단계별 등장)을
Claude Code 스킬로 옮긴 것이다. 샘플 결과물은 `examples/sample_explainer.mp4`(90초).

## 설치

압축을 풀어 `concept-explainer-video/` 폴더를 스킬 폴더에 넣는다.

- 한 프로젝트에서만: `<프로젝트>/.claude/skills/concept-explainer-video/`
- 모든 프로젝트에서: `~/.claude/skills/concept-explainer-video/`

Claude Code를 다시 열고 "개념 설명 영상 만들어줘", "NeoMatrix 소개영상 스타일로 설명 영상" 같이 요청하면 쓰인다.

## 필요한 것

- ffmpeg · Python 3.9+ · Google Chrome(또는 Chromium/Edge, 경로가 다르면 `CHROME=` 환경변수)
- `uv` (edge-tts·mlx-whisper를 설치 없이 불러 쓴다)
- 나레이션 엔진 셋 중 하나 (`--engine auto`가 아래 순서로 고른다)
  - Voicebox 로컬 서버(127.0.0.1:17493) + 복제음성 프로필 — 프로필 ID는 기기마다 다르니 `curl 127.0.0.1:17493/profiles`로 확인
  - Supertonic 오프라인 음성(CPU) — `bash scripts/setup_local.sh`를 한 번 실행. Claude 클라우드 세션처럼
    Hugging Face·jsDelivr·마이크로소프트 음성 서버가 막힌 환경에서도 GitHub·PyPI·npm만으로 설치된다
  - edge-tts: `--engine edge --voice ko-KR-InJoonNeural` (speech.platform.bing.com 접속 필요)

## 빠른 시험

```bash
mkdir demo && cd demo
cp <스킬>/templates/scenes_template.html scenes.html
cp <스킬>/templates/script_example.json script.json
bash <스킬>/scripts/setup_local.sh                           # 최초 1회 (Voicebox 없는 환경)
python <스킬>/scripts/tts.py script.json --whisper           # auto → Supertonic, 발음 검사 포함
python <스킬>/scripts/render.py script.json                  # → explainer.mp4
```
