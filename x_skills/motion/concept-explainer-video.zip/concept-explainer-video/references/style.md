# Style guide — NeoMatrix explainer scenes

## 1. Visual rules

**Canvas.** 1920×1080, background `#0A1119`, side margin 110 px. Everything is absolutely
positioned; nothing scrolls. Keep content between y = 300 and y = 930; the callout sits at y = 972.

**Header (every scene, visible from step 0).**

| element | class | size | role |
|---|---|---|---|
| eyebrow | `.eyebrow` | 22 px mono, letter-spacing 4 px | section tag: `기본 개념 · …`, `TEAM X · 002 풀어 보면`, `SUMMARY` |
| title | `h1` | 60 px bold | the claim of the scene in one line |
| subtitle | `.sub` | 28 px gray | what the scene is about, plainly |

**Body.** Cards (`.card`, `#111924`, radius 10) with a 6 px left bar in a meaning colour.
Card title 30–36 px, body 22–26 px. Never below 21 px — it must read on a phone.

**Callout.** `.callout` at the bottom: 33 px semibold with an 8 px left bar. It is the
takeaway sentence and appears on the last step.

**Colour means something** (use consistently across the whole video):

| token | hex | use |
|---|---|---|
| `--OR` | `#E8A04C` | default accent, key numbers, the "answer" |
| `--BL` | `#7490DF` | a section/team colour, neutral terms |
| `--GR` | `#4CC38A` | good / works / the fix |
| `--RD` | `#E5675C` | bad / failure / the problem |

**Steps.** Step 0 shows only the header. Each step adds one element (a card, a row, a line).
Reveal in reading order: left→right, top→bottom. A comparison shows the problem first, then the fix.
The callout comes last. 3–6 steps per scene.

**Charts.** Inline SVG drawn from real computed values (generate SVG paths with a small Python
script and substitute `{{placeholders}}` if needed). Label directly on the chart; no legends when a
label fits. If a chart shows illustrative data, say so in a small gray line
("예시 시계열(GARCH 합성)로 실제 계산한 값").

**Layouts in the template.** INTRO (2×2 term cards), COMPARE (problem vs fix), FORMULA (formula
card + symbol gloss + bar chart), RECAP (one line per part). Most scenes are one of these.

## 2. Narration rules

- One sentence ↔ one step entry in `steps`. Several sentences may share a step.
- 15–45 characters per sentence works best; split longer ones.
- Write numbers and symbols **as they are read**: `삼 더하기 일`, `오십육 퍼센트`, `에이피아이`,
  `에이치티티피 이백`, `루트 이`. The screen shows `3 + 1`, `56%`, `API`, `HTTP 200`.
- Define a term the first time it appears, in everyday words ("파드는 서버에서 돌아가는 프로그램 하나").
- When a symbol means something different from earlier (e.g. alpha = strategy vs excess return), say so aloud.
- End each scene on the callout sentence; end the video with a RECAP scene and one closing line.

## 3. Pronunciation traps (Voicebox cloned voices)

- **Stray first syllable / blip** ("또", "도" before the sentence): tts.py detects the onset blip and
  retries, alternating plain synthesis with the "하나. <문장>" lead-cut.
- **A number at the very start of a sentence** is often misread (백 → "깩"). Move it inward:
  "백 번이면 …" → "앞설 확률은 백 번이면 …".
- **빌조쉬 reads "돈" as "똔"** — write "자금" instead.
- whisper writes Korean numbers as digits (백 번 → 100번); tts.py converts digits back to hangul
  before comparing, so do not rely on a sentence head that whisper cannot spell (Latin acronyms are
  normalised only for API · HTTP · AI · MFDFA · Q — add to `NORM` in tts.py when you use others).
- 빌조쉬 settings used in the NeoMatrix explainer: `--tempo 0.85 --pitch 0.96`.
- **Supertonic** (offline): no lead-in blips; the flags it raises are almost always the offline ASR
  mishearing a head syllable (넷째 → 내째), which the head check tolerates (2 of the first 3
  syllables). Still write numbers in hangul and spell Latin acronyms the way they should be read.

## 4. Checklist before sending

- Contact sheet read: no text overflow, nothing below y = 1030, callout on one line
- `UNRESOLVED -` from tts.py (or the flagged sentences listened to)
- Frames checked at a few timestamps; final loudness ≈ −16 LUFS
