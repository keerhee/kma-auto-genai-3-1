#!/usr/bin/env python3
"""flow-diagram-video renderer: spec.json -> MP4 (or step stills).

usage:
  python render.py spec.json out.mp4 [--fps 24] [--size 1920x1080] [--workers 2] [--audio bgm.mp3]
  python render.py spec.json stills_dir --stills        # PNG near the end of every step + contact sheet
  python render.py spec.json frame.png --at 12.5        # single frame
  python render.py spec.json --check                    # layout warnings + duration only
"""
import argparse, base64, json, math, os, subprocess, sys, tempfile, shutil
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent / "engine" / "player.html"


def open_page(pw, spec):
    browser = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
    page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
    page.goto(ENGINE.as_uri())
    info = page.evaluate("s => FDV.init(s)", spec)
    return browser, page, info


def probe(spec):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b, p, info = open_page(pw, spec)
        b.close()
    info["warnings"] = list(dict.fromkeys(info["warnings"]))
    return info


def render_chunk(args):
    spec, a, b, fps, out, size = args
    from playwright.sync_api import sync_playwright
    vf = [] if size == "1920x1080" else ["-vf", f"scale={size.replace('x', ':')}:flags=lanczos"]
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "image2pipe", "-framerate", str(fps), "-c:v", "mjpeg", "-i", "-",
           *vf, "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", out]
    enc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    with sync_playwright() as pw:
        br, page, _ = open_page(pw, spec)
        cdp = page.context.new_cdp_session(page)
        for f in range(a, b):
            page.evaluate("t => FDV.seek(t)", f / fps)
            r = cdp.send("Page.captureScreenshot", {"format": "jpeg", "quality": 92, "optimizeForSpeed": True})
            enc.stdin.write(base64.b64decode(r["data"]))
        br.close()
    enc.stdin.close(); enc.wait()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec"); ap.add_argument("out", nargs="?")
    ap.add_argument("--fps", type=int, default=None); ap.add_argument("--size", default=None)
    ap.add_argument("--workers", type=int, default=max(1, min(4, (os.cpu_count() or 2))))
    ap.add_argument("--audio"); ap.add_argument("--stills", action="store_true")
    ap.add_argument("--at", type=float); ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    spec = json.loads(Path(a.spec).read_text(encoding="utf-8"))
    meta = spec.get("meta", {})
    fps = a.fps or meta.get("fps", 24)
    size = a.size or meta.get("size", "1920x1080")

    info = probe(spec)
    total = info["total"]
    print(f"duration {total:.1f}s · scenes {len(spec['scenes'])} · steps {len(info['marks'])}")
    for w in info["warnings"]:
        print("  WARN", w)
    if a.check:
        sys.exit(1 if info["warnings"] else 0)

    from playwright.sync_api import sync_playwright
    if a.at is not None or a.stills:
        out = Path(a.out or "stills")
        with sync_playwright() as pw:
            br, page, _ = open_page(pw, spec)
            if a.at is not None:
                page.evaluate("t => FDV.seek(t)", a.at); page.screenshot(path=str(out)); print("saved", out)
            else:
                out.mkdir(parents=True, exist_ok=True)
                for i, m in enumerate(info["marks"]):
                    page.evaluate("t => FDV.seek(t)", max(0, m - 0.5))
                    page.screenshot(path=str(out / f"step_{i + 1:02d}.png"))
                cols = 4
                subprocess.run(["ffmpeg", "-v", "error", "-y", "-pattern_type", "glob", "-i", str(out / "step_*.png"),
                                "-vf", f"scale=480:-1,tile={cols}x{math.ceil(len(info['marks']) / cols)}:padding=6:color=0x05080c",
                                "-frames:v", "1", str(out / "contact_sheet.png")], check=True)
                print("saved", len(info["marks"]), "stills +", out / "contact_sheet.png")
            br.close()
        return

    out = Path(a.out or "out.mp4")
    n = math.ceil(total * fps)
    W = max(1, min(a.workers, n))
    tmp = Path(tempfile.mkdtemp(prefix="fdv_"))
    bounds = [round(n * k / W) for k in range(W + 1)]
    jobs = [(spec, bounds[k], bounds[k + 1], fps, str(tmp / f"seg{k:02d}.mp4"), size) for k in range(W)]
    print(f"rendering {n} frames @ {fps}fps, {W} workers ...")
    with ProcessPoolExecutor(W) as ex:
        segs = list(ex.map(render_chunk, jobs))
    lst = tmp / "list.txt"; lst.write_text("".join(f"file '{s}'\n" for s in segs))
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst)]
    if a.audio:
        cmd += ["-i", a.audio, "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "192k", "-shortest",
                "-af", f"afade=t=out:st={max(0, total - 2)}:d=2"]
    cmd += ["-c:v", "copy", "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True)
    shutil.rmtree(tmp, ignore_errors=True)
    print("saved", out)


if __name__ == "__main__":
    main()
