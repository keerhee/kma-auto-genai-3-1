/* flow-diagram-video engine — deterministic seek(t) renderer.
   Every visual state is a pure function of t, so frames can be captured in any order. */
(function () {
  const COLORS = { gold: '#e8b04b', blue: '#6f9cf0', purple: '#a58cf0', green: '#4fc28a', teal: '#3fbfae',
    red: '#e86a5c', gray: '#9aa5b4', orange: '#f08a4b', white: '#e8edf3', pink: '#e87bb0' };
  const col = c => COLORS[c] || c || COLORS.gray;
  const rgba = (c, a) => { const h = col(c).replace('#', ''); const n = parseInt(h.length === 3 ? h.split('').map(x => x + x).join('') : h, 16);
    return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const ease = p => 1 - Math.pow(1 - clamp(p), 3);
  const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const MARK = { check: 'green', x: 'red', warn: 'gold', dot: 'gray', info: 'blue' };
  const T = { appear: 0.45, stagger: 0.09, draw: 0.6, capFade: 0.4, sceneIn: 0.4, sceneOut: 0.35, endFade: 0.9, item: 0.18 };

  const FDV = { warnings: [] };
  let S, SCENES = [], FLAT = [], TOTAL = 0, playing = false;

  function div(cls, html, parent) { const d = document.createElement('div'); if (cls) d.className = cls; if (html != null) d.innerHTML = html; if (parent) parent.appendChild(d); return d; }

  /* ---------- element builders ---------- */
  const B = {
    node(e) {
      const c = col(e.color), d = div('el node' + (e.dashed ? ' dashed' : ''));
      d.style.cssText += `width:${e.w}px;height:${e.h || 96}px;border-color:${rgba(c, .9)};background:linear-gradient(${rgba(c, .16)},${rgba(c, .07)}),#141c26;`;
      const tc = e.titleColor ? col(e.titleColor) : (e.color === 'gray' || !e.color ? '#e8edf3' : c);
      d.innerHTML = (e.icon ? `<div class="ic">${icon(e.icon, 30, c)}</div>` : '') +
        `<div class="tx"><div class="tt" style="color:${tc}">${esc(e.title)}</div>${e.sub ? `<div class="ss">${esc(e.sub)}</div>` : ''}</div>`;
      if (e.titleSize) d.querySelector('.tt').style.fontSize = e.titleSize + 'px';
      return d;
    },
    group(e) {
      const c = col(e.color || 'gold'), d = div('el group');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;border-color:${rgba(c, .75)};background:${rgba(c, .025)};`;
      if (e.tag) div('tag', esc(e.tag), d).style.background = c;
      return d;
    },
    pill(e) {
      const c = col(e.color), d = div('el pill');
      d.innerHTML = `<div class="pb" style="border-color:${rgba(c, .85)};background:${rgba(c, .13)};color:${c}">${esc(e.text)}</div>` +
        (e.mark ? icon(e.mark, 34, c) : '');
      if (e.size) d.querySelector('.pb').style.fontSize = e.size + 'px';
      return d;
    },
    text(e) {
      const d = div('el txt', esc(e.text).replace(/\n/g, '<br>'));
      d.style.cssText += `font-size:${e.size || 24}px;color:${col(e.color || 'white')};opacity:${e.alpha ?? 1};text-align:${e.align || 'left'};font-weight:${e.weight || 700};`;
      if (e.w) d.style.width = e.w + 'px';
      return d;
    },
    bubble(e) {
      const c = col(e.color || 'blue'), d = div('el bubble');
      d.style.cssText += `width:${e.w || 440}px;height:${e.h || 92}px;border-color:${rgba(c, .9)};background:linear-gradient(${rgba(c, .2)},${rgba(c, .1)}),#141c26;`;
      if (e.title) d.classList.add('tall');
      d.innerHTML = (e.title ? `<div class="bh">${icon(e.icon || 'users', 30, c)}<div><div class="bht" style="color:${c}">${esc(e.title)}</div>${e.sub ? `<div class="bhs">${esc(e.sub)}</div>` : ''}</div></div>` : icon(e.icon || 'users', 30, c)) + `<div class="bt"></div>` +
        `<svg class="tail" width="50" height="36" viewBox="0 0 50 36"><path d="M2 0 L2 34 L40 0" fill="#18233a" stroke="${rgba(c, .9)}" stroke-width="2.5" stroke-linejoin="round"/><path d="M4 0 L38 0" stroke="#18233a" stroke-width="4"/></svg>`;
      return d;
    },
    card(e) {
      const d = div('el card');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;`;
      if (e.color) d.style.borderColor = rgba(e.color, .8);
      div('ct', esc(e.title), d);
      (e.items || []).forEach(([m, t]) => { const c = col(MARK[m] || m); div('row', icon(m, 34, c) + `<span style="color:${c}">${esc(t)}</span>`, d).classList.add('item'); });
      return d;
    },
    panel(e) {
      const c = col(e.color), d = div('el panel');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;border-color:${rgba(c, .85)};background:linear-gradient(${rgba(c, .13)},${rgba(c, .05)}),#141c26;`;
      div('pt', esc(e.title), d).style.color = c;
      (e.rows || []).forEach(([ic, t]) => div('row', icon(ic, 28, c) + `<span>${esc(t)}</span>`, d).classList.add('item'));
      return d;
    },
    summary(e) {
      const c = col(e.color), d = div('el summary');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;border-color:${rgba(c, .85)};background:linear-gradient(${rgba(c, .16)},${rgba(c, .06)}),#141c26;`;
      d.innerHTML = icon(e.icon || 'check', 64, c) + `<div class="st" style="color:${c}">${esc(e.title)}</div><div class="sb">${esc(e.body)}</div>`;
      return d;
    },
    stack(e) {
      const d = div('el stack'), n = e.n || 10, gap = 6, bh = (e.h - gap * (n - 1)) / n;
      d.style.cssText += `width:${e.w}px;height:${e.h}px;`;
      for (let i = 0; i < n; i++) div('blk', null, d).style.cssText = `height:${bh}px;background:${col(e.color || '#5b6675')}`;
      if (e.caption) { const c = div('cap', esc(e.caption), d); c.style.top = (e.h + 10) + 'px'; }
      return d;
    },
    mark(e) {
      const c = col(e.color || 'red'), s = e.size || 56, d = div('el mark');
      d.style.cssText += `width:${s}px;height:${s}px;border-color:${c};box-shadow:0 0 18px ${rgba(c, .5)}`;
      d.innerHTML = icon(e.icon || 'x', s * 0.55, c);
      return d;
    },
    timeline(e) {
      const d = div('el tl'), n = e.steps.length, w = e.w;
      d.style.cssText += `width:${w}px;height:${e.h || 300}px;`;
      const xs = e.steps.map((_, i) => n === 1 ? w / 2 : 70 + i * (w - 140) / (n - 1));
      const cy = 50 + 18 + 50; // num + margin + radius
      const line = `<svg width="${w}" height="${cy * 2}" style="position:absolute;left:0;top:0;overflow:visible">
        <line x1="${xs[0]}" y1="${cy}" x2="${xs[n - 1]}" y2="${cy}" stroke="#2a3542" stroke-width="10" stroke-linecap="round"/>
        ${xs.map(x => `<circle cx="${x}" cy="${cy}" r="3" fill="#56657a"/>`).join('')}
        <line class="fill" x1="${xs[0]}" y1="${cy}" x2="${xs[0]}" y2="${cy}" stroke="${col(e.lineColor || 'gold')}" stroke-width="10" stroke-linecap="round"/>
        <circle class="head" cx="${xs[0]}" cy="${cy}" r="22" fill="${rgba(e.lineColor || 'gold', .28)}"/>
        <circle class="head2" cx="${xs[0]}" cy="${cy}" r="11" fill="${col(e.lineColor || 'gold')}"/></svg>`;
      d.innerHTML = line;
      e.steps.forEach((s, i) => {
        const c = col(s.color || 'gold'), st = div('step item', null, d);
        st.style.left = xs[i] + 'px'; st.style.top = '0px';
        st.innerHTML = `<div class="num" style="color:${c}">${s.num ?? i + 1}</div><div class="circ" style="border-color:${c}">${icon(s.icon || 'dot', 44, c)}</div>` +
          `<div class="stt" style="color:${c}">${esc(s.title)}</div>${s.sub ? `<div class="sts">${esc(s.sub).replace(/\n/g, '<br>')}</div>` : ''}`;
      });
      d._xs = xs;
      return d;
    }    ,
    /* ---------- v2 kinds ---------- */
    lane(e) {
      const c = col(e.color || 'gold'), d = div('el lane');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;`;
      d.innerHTML = `<div class="lb">${icon(e.icon || 'users', 38, c)}<div class="ln" style="color:${c}">${esc(e.label || '')}</div></div>` +
        `<div class="band" style="left:${e.labelW ?? 110}px;background:${rgba(c, .1)};border-color:${rgba(c, .16)}"></div>`;
      return d;
    },
    diamond(e) {
      const c = col(e.color || 'gold'), w = e.w || 170, h = e.h || 120, d = div('el diamond');
      d.style.cssText += `width:${w}px;height:${h}px;`;
      d.innerHTML = `<svg width="${w}" height="${h}" style="position:absolute;left:0;top:0;overflow:visible"><path class="dshape" d="M${w / 2},2 L${w - 2},${h / 2} L${w / 2},${h - 2} L2,${h / 2} Z" fill="${rgba(c, .14)}" stroke="${rgba(c, .9)}" stroke-width="2.5" stroke-linejoin="round"/></svg><div class="dt" style="color:${c}">${esc(e.text || '')}</div>`;
      return d;
    },
    dots(e) {
      const c = col(e.color || 'gray'), r = e.r || 20, g = e.gap || 56, R = e.rows || 3, C = e.cols || 4, d = div('el dots');
      const w = (C - 1) * g + 2 * r, h = (R - 1) * g + 2 * r;
      d.style.cssText += `width:${w}px;height:${h}px;`;
      let s = `<svg width="${w}" height="${h}" style="position:absolute;left:0;top:0;overflow:visible">`;
      for (let i = 0; i < R * C; i++) { const cx = r + (i % C) * g, cy = r + Math.floor(i / C) * g;
        s += `<g class="dg" transform="translate(${cx},${cy})"><circle class="halo" r="${r + 10}" fill="${rgba(e.litColor || 'gold', .25)}" opacity="0"/><circle class="dc" r="${r}" fill="${rgba(c, .1)}" stroke="${rgba(c, .75)}" stroke-width="2.5"/></g>`; }
      d.innerHTML = s + '</svg>' + (e.label ? `<div class="dl">${esc(e.label)}</div>` : '');
      d._centers = Array.from({ length: R * C }, (_, i) => [r + (i % C) * g, r + Math.floor(i / C) * g]);
      return d;
    },
    gate(e) {
      const c = col(e.color || 'blue'), w = e.w || 40, d = div('el gate');
      d.style.cssText += `width:${w}px;height:${e.h}px;border-color:${rgba(c, .9)};background:linear-gradient(${rgba(c, .22)},${rgba(c, .08)}),#141c26;`;
      d.innerHTML = (e.icon !== false ? `<div class="gi">${icon(e.icon || 'users', 36, c)}</div>` : '') + (e.label ? `<div class="gl" style="color:${c}">${esc(e.label)}</div>` : '');
      return d;
    },
    window(e) {
      const d = div('el win');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;`;
      d.innerHTML = `<div class="wb"><i style="background:#e86a5c"></i><i style="background:#e8b04b"></i><i style="background:#4fc28a"></i><div class="wu">${esc(e.url || '')}</div></div>`;
      return d;
    },
    skel(e) {
      const d = div('el skel'), h = e.h || 14;
      d.style.cssText += `width:${e.w}px;height:${h}px;border-radius:${h / 2}px;background:${e.color ? rgba(e.color, .35) : 'rgba(255,255,255,.12)'}`;
      if (e.hi !== false) div('sh', null, d).style.cssText = `width:${(e.hiW || 0.08) * 100}%;border-radius:${h / 2}px`;
      return d;
    },
    spark(e) {
      const c = col(e.color || 'teal'), w = e.w, h = e.h, d = div('el spark'), P = e.points || [2, 4, 3, 6, 5, 8, 7, 9];
      d.style.cssText += `width:${w}px;height:${h}px;`;
      const lo = Math.min(...P), hi = Math.max(...P), px = 28, top = e.label ? 52 : 24, bot = 24;
      const pts = P.map((v, i) => [px + i * (w - 2 * px) / (P.length - 1), h - bot - (v - lo) / ((hi - lo) || 1) * (h - top - bot)]);
      d.innerHTML = (e.label ? `<div class="spl">${esc(e.label)}</div>` : '') + `<svg width="${w}" height="${h}" style="position:absolute;left:0;top:0"><path class="sp" d="M${pts.map(p => p.join(',')).join(' L')}" fill="none" stroke="${c}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
      return d;
    },
    table(e) {
      const c = col(e.color || 'teal'), d = div('el table'), cols = e.cols || ['a', 'b', 'c'], n = e.rows ?? 3;
      d.style.cssText += `width:${e.w}px;height:${e.h}px;`;
      d.style.gridTemplateColumns = `repeat(${cols.length},1fr)`;
      let s = cols.map(k => `<div class="th" style="color:${c}">${esc(k)}</div>`).join('');
      for (let r = 0; r < n; r++) cols.forEach((_, k) => { s += `<div class="td item"><span style="width:${[80, 65, 72, 58][(r + k) % 4]}%"></span></div>`; });
      d.innerHTML = s;
      return d;
    },
    db(e) {
      const c = col(e.color || 'teal'), w = e.w || 240, h = e.h, ry = e.ry || 22, d = div('el db');
      d.style.cssText += `width:${w}px;height:${h}px;`;
      d.innerHTML = `<svg width="${w}" height="${h}" style="position:absolute;left:0;top:0;overflow:visible">
        <path d="M2,${ry} L2,${h - ry} A${w / 2 - 2},${ry} 0 0 0 ${w - 2},${h - ry} L${w - 2},${ry}" fill="${rgba(c, .12)}" stroke="${rgba(c, .9)}" stroke-width="2.5"/>
        <ellipse cx="${w / 2}" cy="${ry}" rx="${w / 2 - 2}" ry="${ry - 2}" fill="#16262a" stroke="${rgba(c, .9)}" stroke-width="2.5"/></svg>
        <div class="dbt" style="color:${c};top:${ry * 2 + 4}px">${esc(e.title || '')}</div>` +
        (e.rows || []).map(rw => `<div class="dbr item" style="border-color:${rgba(c, .8)};color:${c};background:${rgba(c, .14)}">${esc(rw)}</div>`).join('') +
        (e.sub ? `<div class="dbs">${esc(e.sub)}</div>` : '');
      d.style.paddingTop = (ry * 2 + 48) + 'px';
      return d;
    },
    code(e) {
      const c = col(e.color || 'teal'), d = div('el code');
      d.style.cssText += `width:${e.w}px;height:${e.h}px;border-color:${rgba(c, .85)};background:linear-gradient(${rgba(c, .1)},${rgba(c, .04)}),#121920;`;
      div('cdt', (e.icon ? icon(e.icon, 30, c) : '') + `<span>${esc(e.title || '')}</span>`, d).style.color = c;
      if (e.chips) div('chips', e.chips.map(([t, cc]) => `<span style="color:${col(cc)};border-color:${rgba(cc, .85)};background:${rgba(cc, .13)}">${esc(t)}</span>`).join(''), d);
      (e.lines || []).forEach(l => div('cl item', esc(l), d).classList.toggle('mono', !/^[가-힣]/.test(l) || e.mono));
      return d;
    },
    track(e) {
      const c = col(e.color || 'green'), w = e.w, d = div('el track'), max = e.max || 10, pad = 30, ly = 110;
      d.style.cssText += `width:${w}px;height:${e.h || 140}px;`;
      const X = v => pad + (w - 2 * pad) * clamp(v / max);
      let s = `<svg width="${w}" height="${ly + 40}" style="position:absolute;left:0;top:0;overflow:visible">
        <line x1="${X(0)}" y1="${ly}" x2="${X(max)}" y2="${ly}" stroke="rgba(255,255,255,.1)" stroke-width="8" stroke-linecap="round"/>
        <line class="tf" x1="${X(0)}" y1="${ly}" x2="${X(0)}" y2="${ly}" stroke="${c}" stroke-width="8" stroke-linecap="round"/>
        <g class="th"><circle r="18" fill="${rgba(c, .3)}"/><circle r="8" fill="${c}"/></g></svg>`;
      (e.milestones || []).forEach(m => { const mc = col(m.color || '#c9d1db');
        s += `<div class="ms" style="left:${X(m.at)}px;top:${ly - 108}px"><div class="ml">${esc(m.label || '')}</div><div class="mv" style="color:${col(m.subColor || m.color || 'gray')}">${esc(m.sub ?? (e.prefix || 'D+') + m.at)}</div>` +
          `<div class="mc" style="border-color:${mc};background:${rgba(m.color || 'gray', .14)}">${icon(m.icon || 'dot', 26, mc)}</div></div>`; });
      if (e.counter !== false) s += `<div class="tc" style="color:${col(e.counterColor || 'gold')}"><span class="tcv"></span><span class="tcn">${esc(e.note || '')}</span></div>`;
      d.innerHTML = s; d._X = X; d._ly = ly;
      return d;
    },
    spot(e) {
      const c = col(e.color || 'gold'), r = e.r || 34, d = div('el spot');
      d.style.cssText += `width:${2 * r}px;height:${2 * r}px;border-color:${rgba(c, .95)};box-shadow:0 0 22px ${rgba(c, .55)},inset 0 0 14px ${rgba(c, .3)}`;
      return d;
    }

  };

  /* ---------- geometry ---------- */
  function box(sc, id) { const r = sc.rects[id]; if (!r) throw new Error('unknown element id: ' + id); return r; }
  function anchor(r, side, off = 0) {
    const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    return side === 'r' ? [r.x + r.w, cy + off] : side === 'l' ? [r.x, cy + off] : side === 't' ? [cx + off, r.y] : [cx + off, r.y + r.h];
  }
  function endpoints(sc, e) {
    const parse = v => { if (Array.isArray(v)) return { pt: v };
      if (String(v).includes('#')) { const [id, n] = String(v).split('#'); const r = box(sc, id), it = sc.items.find(x => x.e.id === id), c = it.d._centers[+n];
        if (!c) throw new Error('no dot #' + n + ' in ' + id); return { pt: [r.x + c[0], r.y + c[1]] }; }
      const [id, side] = String(v).split('.'); return { r: box(sc, id), side }; };
    const A = parse(e.from), Bn = parse(e.to);
    const ca = A.pt || [A.r.x + A.r.w / 2, A.r.y + A.r.h / 2], cb = Bn.pt || [Bn.r.x + Bn.r.w / 2, Bn.r.y + Bn.r.h / 2];
    const dx = cb[0] - ca[0], dy = cb[1] - ca[1];
    const sa = (A.r && (A.r.w + (Bn.r ? Bn.r.w : 0))) || 1, sb = (A.r && (A.r.h + (Bn.r ? Bn.r.h : 0))) || 1;
    const horiz = Math.abs(dx) / sa > Math.abs(dy) / sb;
    const fs = e.fromSide || A.side || (horiz ? (dx > 0 ? 'r' : 'l') : (dy > 0 ? 'b' : 't'));
    const ts = e.toSide || Bn.side || (horiz ? (dx > 0 ? 'l' : 'r') : (dy > 0 ? 't' : 'b'));
    const p0 = A.pt || anchor(A.r, fs, e.fromOff || 0), p1 = Bn.pt || anchor(Bn.r, ts, e.toOff || 0);
    // small gaps so arrowheads don't touch borders
    const gap = (p, s, g) => s === 'r' ? [p[0] + g, p[1]] : s === 'l' ? [p[0] - g, p[1]] : s === 't' ? [p[0], p[1] - g] : s === 'b' ? [p[0], p[1] + g] : p;
    return { p0: A.pt ? p0 : gap(p0, fs, 2), p1: Bn.pt ? p1 : gap(p1, ts, 6), fs, ts };
  }
  function pathD(e, p0, p1, fs) {
    let pts = [p0];
    if (e.via) pts = pts.concat(e.via);
    else if (e.route === 'elbow') {
      if (fs === 'r' || fs === 'l') { const mx = e.elbowAt ?? (p0[0] + p1[0]) / 2; pts.push([mx, p0[1]], [mx, p1[1]]); }
      else { const my = e.elbowAt ?? (p0[1] + p1[1]) / 2; pts.push([p0[0], my], [p1[0], my]); }
    }
    pts.push(p1);
    if (e.route === 's' && pts.length === 2) {
      const k = e.sBend ?? 0.5, horiz = fs === 'r' || fs === 'l';
      if (horiz) { const mx = p0[0] + (p1[0] - p0[0]) * k; return `M${p0[0]},${p0[1]} C${mx},${p0[1]} ${mx},${p1[1]} ${p1[0]},${p1[1]}`; }
      const my = p0[1] + (p1[1] - p0[1]) * k; return `M${p0[0]},${p0[1]} C${p0[0]},${my} ${p1[0]},${my} ${p1[0]},${p1[1]}`;
    }
    if (e.curve && pts.length === 2) {
      const mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2, dx = p1[0] - p0[0], dy = p1[1] - p0[1], L = Math.hypot(dx, dy) || 1;
      return `M${p0[0]},${p0[1]} Q${mx - dy / L * e.curve},${my + dx / L * e.curve} ${p1[0]},${p1[1]}`;
    }
    const R = 14; let d = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 1; i < pts.length - 1; i++) {
      const [a, b, c] = [pts[i - 1], pts[i], pts[i + 1]];
      const l1 = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, l2 = Math.hypot(c[0] - b[0], c[1] - b[1]) || 1, r = Math.min(R, l1 / 2, l2 / 2);
      d += ` L${b[0] - (b[0] - a[0]) / l1 * r},${b[1] - (b[1] - a[1]) / l1 * r} Q${b[0]},${b[1]} ${b[0] + (c[0] - b[0]) / l2 * r},${b[1] + (c[1] - b[1]) / l2 * r}`;
    }
    return d + ` L${pts[pts.length - 1][0]},${pts[pts.length - 1][1]}`;
  }

  /* ---------- build ---------- */
  function buildScene(sc, si) {
    const layer = div('scene', null, document.getElementById('scenes'));
    sc.layer = layer; sc.items = []; sc.rects = {};
    const N = SCENES.length;
    if (sc.type === 'title') {
      const mk = (cls, html, top, size, color, at) => { const d = div('el ' + cls, html, layer); d.style.top = top + 'px'; if (size) d.style.fontSize = size + 'px'; if (color) d.style.color = color; sc.items.push({ e: { id: '_t' + at }, d, at, kind: 'title' }); };
      const y0 = sc.subtitle ? 250 : 300;
      mk('ttl', esc(sc.title), y0, sc.size || 104, '#eef2f6', 0.15);
      if (sc.accent) mk('ttl', esc(sc.accent), y0 + 128, sc.size || 104, col(sc.accentColor || 'gold'), 0.45);
      if (sc.subtitle) mk('tsub', esc(sc.subtitle), y0 + (sc.accent ? 290 : 160), 0, null, 0.8);
      if (sc.spinner !== false) {
        const sp = div('el', `<svg width="200" height="200" viewBox="-100 -100 200 200" style="overflow:visible">
          <circle r="76" fill="none" stroke="rgba(255,255,255,.28)" stroke-width="2.5" stroke-dasharray="7 8"/>
          <g transform="translate(-26,-26)">${icon(sc.spinnerIcon || 'refresh', 52, col('gold'))}</g>
          ${['blue', 'gold', 'teal'].map(c => `<g class="orb"><circle r="15" fill="${rgba(c, .3)}"/><circle r="8" fill="${col(c)}"/></g>`).join('')}</svg>`, layer);
        sp.style.left = '860px'; sp.style.top = (sc.subtitle ? 690 : 640) + 'px';
        sc.items.push({ e: { id: '_spin' }, d: sp, at: 1.05, kind: 'spinner' });
      }
      if (sc.mini) {
        const m = sc.mini, fc = col(m.fromColor || 'gold'), tc = col(m.toColor || 'blue'), L = m.len || 520;
        const chip = (t, c) => `<div class="mchip" style="color:${c};border-color:${rgba(c, .9)};background:${rgba(c, .14)}">${esc(t)}</div>`;
        const mn = div('el mini', chip(m.from, fc) + `<svg width="${L}" height="40" style="overflow:visible"><line x1="6" y1="20" x2="${L - 14}" y2="20" stroke="rgba(255,255,255,.45)" stroke-width="2.5" stroke-dasharray="8 7"/><path d="M${L - 16},13 L${L - 4},20 L${L - 16},27z" fill="rgba(255,255,255,.6)"/><g class="md"><circle r="13" fill="${rgba('green', .3)}"/><circle r="6" fill="${col('green')}"/></g></svg>` + chip(m.to, tc), layer);
        mn.style.top = (sc.subtitle ? 650 : 600) + 'px'; mn._L = L;
        sc.items.push({ e: { id: '_mini' }, d: mn, at: m.at ?? 2.0, kind: 'mini' });
      }
    } else {
      const h = div('hdr', `<div class="bar" style="background:${col(sc.bar || 'gold')}"></div><div class="t">${esc(sc.header || '')}</div>`, layer);
      if (sc.page !== false) div('pg', `${si + 1} / ${N}`, layer);
      const svgNS = 'http://www.w3.org/2000/svg';
      const ordered = (sc.elements || []).filter(e => e.kind !== 'edge');
      const BOTTOM = ['group', 'lane', 'window']; const rank = e => BOTTOM.includes(e.kind) ? 0 : 1;
      ordered.sort((a, b) => rank(a) - rank(b));
      const svg = document.createElementNS(svgNS, 'svg'); svg.setAttribute('class', 'edges');
      let svgInserted = false;
      for (const e of ordered) {
        if (!svgInserted && !BOTTOM.includes(e.kind)) { layer.appendChild(svg); svgInserted = true; }
        const fn = B[e.kind]; if (!fn) { FDV.warnings.push(`scene ${si + 1}: unknown kind "${e.kind}" (${e.id})`); continue; }
        const d = fn(e); d.style.left = e.x + 'px'; d.style.top = e.y + 'px'; if (e.z) d.style.zIndex = e.z;
        layer.appendChild(d); sc.items.push({ e, d, kind: e.kind });
      }
      if (!svgInserted) layer.appendChild(svg);
      sc.svg = svg;
    }
  }

  function measureAndEdges(sc, si) {
    const svgNS = 'http://www.w3.org/2000/svg';
    for (const it of sc.items) {
      const d = it.d, e = it.e;
      sc.rects[e.id] = { x: d.offsetLeft, y: d.offsetTop, w: d.offsetWidth, h: d.offsetHeight };
      // layout checks
      if (['node', 'card', 'panel', 'summary', 'code'].includes(it.kind) && (d.scrollWidth > d.clientWidth + 2 || d.scrollHeight > d.clientHeight + 2))
        FDV.warnings.push(`scene ${si + 1} "${sc.header || sc.title}": text overflows ${it.kind} "${e.id}" (content ${d.scrollWidth}x${d.scrollHeight} > box ${d.clientWidth}x${d.clientHeight})`);
      if (it.kind === 'node') { d.querySelectorAll('.tt,.ss').forEach(x => { const lh = parseFloat(getComputedStyle(x).fontSize) * 1.25; if (x.offsetHeight > lh * 1.5 && !e.wrapOk) FDV.warnings.push(`scene ${si + 1}: node "${e.id}" text wraps to 2+ lines ("${x.textContent}") — widen w or set wrapOk:true`); });
        const tt = d.querySelector('.tx'); if (tt && tt.scrollWidth > tt.clientWidth + 2) FDV.warnings.push(`scene ${si + 1}: node "${e.id}" title too wide — widen w or shorten text`); }
      const r = sc.rects[e.id];
      if (it.kind !== 'spot' && !e.safeOk)
      if (r.x < 40 || r.x + r.w > 1880 || r.y < 120 || r.y + r.h > (sc.allowUnderCaption ? 1060 : 885))
        if (sc.type !== 'title') FDV.warnings.push(`scene ${si + 1}: "${e.id}" out of safe area (x ${r.x}–${r.x + r.w}, y ${r.y}–${r.y + r.h}; safe x 40–1880, y 120–885)`);
    }
    const solid = sc.items.filter(it => ['node', 'card', 'panel', 'summary', 'pill', 'bubble', 'mark', 'timeline', 'diamond', 'db', 'code', 'gate', 'spark', 'table', 'dots', 'track'].includes(it.kind) && !it.e.overlapOk);
    for (let i = 0; i < solid.length; i++) for (let j = i + 1; j < solid.length; j++) {
      const a = sc.rects[solid[i].e.id], b = sc.rects[solid[j].e.id];
      const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      if (ox > 4 && oy > 4) {
        const hidden = (sc.steps || []).some(s => (s.hide || []).includes(solid[i].e.id) || (s.hide || []).includes(solid[j].e.id));
        if (!hidden) FDV.warnings.push(`scene ${si + 1}: "${solid[i].e.id}" overlaps "${solid[j].e.id}" (${ox}x${oy}px) — set overlapOk:true if intended`);
      }
    }
    if (!sc.svg) return;
    const defs = document.createElementNS(svgNS, 'defs'); sc.svg.appendChild(defs);
    (sc.elements || []).filter(e => e.kind === 'edge').forEach((e, k) => {
      let ep; try { ep = endpoints(sc, e); } catch (err) { FDV.warnings.push(`scene ${si + 1}: edge "${e.id}": ${err.message}`); return; }
      const c = col(e.color), d = pathD(e, ep.p0, ep.p1, ep.fs), mid = `m${si}_${k}`;
      const g = document.createElementNS(svgNS, 'g');
      g.innerHTML = `<mask id="mk${mid}" maskUnits="userSpaceOnUse" x="0" y="0" width="1920" height="1080"><path class="mp" d="${d}" fill="none" stroke="#fff" stroke-width="40" stroke-linecap="butt"/></mask>
        <marker id="ar${mid}" viewBox="0 0 12 12" refX="10" refY="6" markerWidth="12" markerHeight="12" markerUnits="userSpaceOnUse" orient="auto"><path d="M1,1 L11,6 L1,11 z" fill="${c}"/></marker>
        <g mask="url(#mk${mid})"><path class="vp" d="${d}" fill="none" stroke="${rgba(c, .9)}" stroke-width="${e.width || 3}" ${e.dashed ? 'stroke-dasharray="11 9"' : ''} ${e.arrow === false ? '' : `marker-end="url(#ar${mid})"`}/></g>
        <g class="dot" opacity="0"><circle r="16" fill="${rgba(c, .28)}"/><circle r="7" fill="#fff"/><circle r="7" fill="none" stroke="${c}" stroke-width="3"/></g>`;
      if (e.label) {
        const t = document.createElementNS(svgNS, 'text'); t.setAttribute('class', 'edge-label'); t.setAttribute('fill', col(e.labelColor || e.color));
        t.setAttribute('text-anchor', e.labelAnchor || 'middle'); t.textContent = e.label; g.appendChild(t);
      }
      sc.svg.appendChild(g);
      const vp = g.querySelector('.vp'), L = vp.getTotalLength();
      const mp = g.querySelector('.mp'); mp.setAttribute('stroke-dasharray', `${L + 2} ${L + 2}`);
      const lab = g.querySelector('text');
      if (lab) { const p = vp.getPointAtLength(L * (e.labelAt ?? 0.5)); lab.setAttribute('x', p.x + (e.labelDx || 0)); lab.setAttribute('y', p.y + (e.labelDy ?? -16)); }
      sc.items.push({ e, kind: 'edge', g, vp, mp, L, dot: g.querySelector('.dot'), lab });
    });
  }

  function schedule(sc) {
    let t = sc.start;
    sc.steps = sc.steps && sc.steps.length ? sc.steps : [{ dur: 4 }];
    sc.steps.forEach(st => { st.start = t; st.dur = st.dur ?? 3.5; t += st.dur; });
    sc.dur = t - sc.start;
    if (sc.type === 'title') { sc.items.forEach(it => { it.appear = sc.start + it.at; it.hideAt = Infinity; }); return; }
    const all = (sc.elements || []).map(e => e.id);
    for (const it of sc.items) {
      const id = it.e.id; let first = -1, hideAt = Infinity;
      sc.steps.forEach((st, i) => {
        const show = st.show === '*' ? all : (st.show || []);
        if (first < 0 && show.includes(id)) { first = i; it.order = show.indexOf(id); }
        if (first >= 0 && i > first && (st.hide || []).includes(id) && hideAt === Infinity) hideAt = st.start;
      });
      if (first < 0) { if (it.e.always) { first = 0; it.order = 0; } else { FDV.warnings.push(`scene "${sc.header}": element "${id}" never shown`); first = sc.steps.length; } }
      it.step = first;
      const st = sc.steps[Math.min(first, sc.steps.length - 1)];
      it.appear = first >= sc.steps.length ? Infinity : st.start + (it.e.delay ?? (it.order || 0) * (st.stagger ?? T.stagger));
      it.hideAt = hideAt;
    }
  }

  /* ---------- per-frame state ---------- */
  function revealCount(sc, id, si, total) {
    let cnt = null;
    for (let i = 0; i <= si; i++) { const r = sc.steps[i].reveal; if (r && r[id] != null) cnt = r[id]; }
    if (cnt === null) { const any = sc.steps.some(s => s.reveal && s.reveal[id] != null); cnt = any ? 0 : total; }
    return Math.min(cnt, total);
  }
  function setState(sc, id, key, si, dflt) {
    let v = dflt, k = -1;
    for (let i = 0; i <= si; i++) { const s = sc.steps[i].set; if (s && s[id] && s[id][key] !== undefined) { v = s[id][key]; k = i; } }
    return { v, k };
  }
  function setAnim(sc, it, key, si, t, dflt, dur) {
    const cur = setState(sc, it.e.id, key, si, dflt);
    if (cur.k < 0) return { v: cur.v, prev: cur.v, p: 1, t0: it.appear };
    const prev = setState(sc, it.e.id, key, cur.k - 1, dflt), t0 = Math.max(sc.steps[cur.k].start, it.appear + 0.3);
    return { v: cur.v, prev: prev.v, p: ease((t - t0) / dur), t0 };
  }
  function stepIndex(sc, t) { let k = 0; sc.steps.forEach((s, i) => { if (t >= s.start) k = i; }); return k; }

  function seekScene(sc, t) {
    const si = stepIndex(sc, t), step = sc.steps[si], tl = t - step.start;
    const focus = step.focus || [], flowNow = step.flow || [];
    const dim = step.dim === true ? 'all' : (step.dim || []);
    for (const it of sc.items) {
      const e = it.e;
      let a = ease((t - it.appear) / T.appear);
      if (t >= it.hideAt) a *= 1 - ease((t - it.hideAt) / 0.3);
      if (it.kind === 'edge') {
        const p = clamp((t - it.appear) / (e.drawDur || T.draw));
        let vis = t >= it.hideAt ? a : 1;
        it.mp.setAttribute('stroke-dashoffset', (it.L + 2) * (1 - p));
        it.g.style.opacity = (t < it.appear ? 0 : vis) * ((dim === 'all' && !focus.includes(e.id)) || dim.includes?.(e.id) ? 0.3 : 1);
        if (it.lab) it.lab.style.opacity = clamp((p - 0.6) / 0.4);
        const flowing = (e.flow || flowNow.includes(e.id)) && p >= 1;
        if (flowing) {
          const speed = e.speed || 420, tf = t - it.appear - (e.drawDur || T.draw), cyc = it.L / speed + 0.55;
          const ph = ((tf % cyc) + cyc) % cyc * speed;
          if (ph <= it.L) { const pt = it.vp.getPointAtLength(ph); it.dot.setAttribute('transform', `translate(${pt.x},${pt.y})`);
            it.dot.setAttribute('opacity', Math.min(1, ph / 40, (it.L - ph) / 40)); } else it.dot.setAttribute('opacity', 0);
        } else it.dot.setAttribute('opacity', 0);
        continue;
      }
      const d = it.d;
      if (it.kind === 'mini') {
        d.style.opacity = a; d.style.transform = `translateY(${(1 - a) * 18}px)`;
        const L = d._L, ph = ((t - it.appear) * 0.55) % 1.25, x = 6 + (L - 26) * clamp(ph);
        const md = d.querySelector('.md'); md.setAttribute('transform', `translate(${x},20)`); md.setAttribute('opacity', ph > 1 ? 0 : Math.min(1, ph * 8, (1 - ph) * 8));
        continue;
      }
      if (it.kind === 'title' || it.kind === 'spinner') {
        d.style.opacity = a; d.style.transform = `translateY(${(1 - a) * 18}px)`;
        if (it.kind === 'spinner') d.querySelectorAll('.orb').forEach((o, k) => { const ang = t * 1.3 + k * 2.094; o.setAttribute('transform', `translate(${Math.cos(ang) * 76},${Math.sin(ang) * 76})`); });
        continue;
      }
      let op = a; if ((dim === 'all' && !focus.includes(e.id)) || (Array.isArray(dim) && dim.includes(e.id))) op *= 0.3;
      d.style.opacity = op;
      if (it.kind === 'spot') {
        const m = setAnim(sc, it, 'at', si, t, e.at || [e.x, e.y], e.moveDur || 0.7), r = d.offsetWidth / 2;
        const x = m.prev[0] + (m.v[0] - m.prev[0]) * m.p, y = m.prev[1] + (m.v[1] - m.prev[1]) * m.p;
        d.style.left = (x - r) + 'px'; d.style.top = (y - r) + 'px';
        d.style.transform = `scale(${(1.25 - 0.25 * a) * (1 + 0.04 * Math.sin(t * 4))})`;
        continue;
      }
      d.style.transform = `translateY(${(1 - a) * 12}px) scale(${0.97 + 0.03 * a})`;
      // focus glow
      if (focus.includes(e.id) && a > 0) {
        const c = col(e.color || 'gold'), k = ease(tl / 0.3) * (0.75 + 0.25 * Math.sin(t * 3.9));
        const tgt = it.kind === 'pill' ? d.querySelector('.pb') : d;
        if (['diamond', 'db', 'dots', 'track'].includes(it.kind)) d.style.filter = `drop-shadow(0 0 ${14 * k}px ${rgba(c, .8)})`;
        else tgt.style.boxShadow = `0 0 0 ${2 * k}px ${rgba(c, .9)}, 0 0 ${34 * k}px ${rgba(c, .55 * k)}`;
      } else if (it.kind !== 'mark') { (it.kind === 'pill' ? d.querySelector('.pb') : d).style.boxShadow = 'none'; d.style.filter = ''; }
      // partial reveals
      const subs = d.querySelectorAll('.item');
      if (subs.length && it.kind !== 'timeline') {
        const cnt = revealCount(sc, e.id, si, subs.length);
        const prev = (si > 0 && it.step < si) ? revealCount(sc, e.id, si - 1, subs.length) : 0;
        const base = it.step === si ? (it.appear - step.start) + 0.3 : 0;
        subs.forEach((s, i) => {
          let o = i < prev ? 1 : i < cnt ? ease((tl - base - (i - prev) * T.item) / 0.35) : 0;
          s.style.opacity = o; s.style.transform = `translateX(${(1 - o) * -10}px)`;
        });
      }
      if (it.kind === 'timeline') {
        const n = subs.length, xs = d._xs;
        const cnt = revealCount(sc, e.id, si, n), prev = (si > 0 && it.step < si) ? revealCount(sc, e.id, si - 1, n) : 0;
        const base = it.step === si ? (it.appear - step.start) + 0.25 : 0, per = 0.55;
        const x0 = xs[Math.max(prev - 1, 0)], x1 = cnt > 0 ? xs[cnt - 1] : xs[0];
        const fd = Math.max(per * (cnt - prev), 0.001), fp = clamp((tl - base) / fd);
        // fill extends a bit beyond the last revealed step to hint the next one
        const nextX = cnt < n && cnt > 0 ? xs[cnt - 1] + Math.min(40, (xs[cnt] - xs[cnt - 1]) * 0.12) : x1;
        const fx = cnt === 0 ? xs[0] : (fp < 1 ? x0 + (x1 - x0) * fp : nextX);
        d.querySelector('.fill').setAttribute('x2', fx);
        ['.head', '.head2'].forEach(s => { const h = d.querySelector(s); h.setAttribute('cx', fx); h.style.opacity = cnt > 0 && (cnt < n || fp < 1) ? 1 : 0; });
        subs.forEach((s, i) => {
          let o;
          if (i < prev) o = 1; else if (i >= cnt) o = 0;
          else { const frac = (xs[i] - x0) / ((x1 - x0) || 1); o = ease((tl - base - frac * fd) / 0.35); }
          s.style.opacity = o; s.style.transform = `translateY(${(1 - o) * 14}px)`;
        });
      }
      seekV2(sc, it, si, t);
      if (it.kind === 'bubble') {
        const st = setAnim(sc, it, 'text', si, t, e.text || '', 1), txt = st.v || '', dur = Math.min(1.2, 0.07 * txt.length), p = clamp((t - Math.max(st.t0, it.appear) - 0.25) / dur);
        d.querySelector('.bt').style.color = col(setState(sc, e.id, 'textColor', si, e.textColor || 'white').v);
        d.querySelector('.bt').textContent = txt.slice(0, Math.round(p * txt.length));
      }
    }
  }

  function seekV2(sc, it, si, t) {
    const e = it.e, d = it.d;
    if (it.kind === 'dots') {
      const lit = setAnim(sc, it, 'lit', si, t, e.lit || [], 0.4), fade = setAnim(sc, it, 'fade', si, t, e.fade || [], 0.5), lc = e.litColor || 'gold';
      d.querySelectorAll('.dg').forEach((g, i) => {
        const ln = lit.v.includes(i), lp = lit.prev.includes(i), lo = ln ? (lp ? 1 : lit.p) : (lp ? 1 - lit.p : 0);
        const fn = fade.v.includes(i), fp = fade.prev.includes(i), fo = fn ? (fp ? 1 : fade.p) : (fp ? 1 - fade.p : 0);
        g.querySelector('.halo').setAttribute('opacity', lo * (0.75 + 0.25 * Math.sin(t * 4 + i)));
        const dc = g.querySelector('.dc'); dc.setAttribute('fill', lo > 0.5 ? rgba(lc, .85) : rgba(e.color || 'gray', .1)); dc.setAttribute('stroke', lo > 0.5 ? col(lc) : rgba(e.color || 'gray', .75));
        g.setAttribute('opacity', 1 - 0.75 * fo);
      });
    } else if (it.kind === 'track') {
      const m = setAnim(sc, it, 'value', si, t, e.value ?? 0, e.animDur || 1.6), v = m.prev + (m.v - m.prev) * m.p, X = d._X;
      d.querySelector('.tf').setAttribute('x2', X(v));
      const th = d.querySelector('.th'); th.setAttribute('transform', `translate(${X(v)},${d._ly})`); th.style.opacity = m.p < 1 && m.v !== m.prev ? 1 : (e.head === false ? 0 : 0.85);
      const tcv = d.querySelector('.tcv'); if (tcv) tcv.textContent = (e.prefix ?? 'D+') + Math.floor(v + 1e-6);
      d.querySelectorAll('.ms').forEach((ms, i) => { const at = e.milestones[i].at, o = clamp((v - at) / 0.35 + 1);
        ms.style.opacity = at === 0 ? 1 : o; ms.style.transform = `translate(-50%,${(1 - o) * 10}px)`; });
    } else if (it.kind === 'skel') {
      const sh = d.querySelector('.sh'); if (sh) { const ph = ((t * (e.speed || 0.22) + (e.phase ?? (e.x * 0.0013))) % 1); sh.style.left = (ph * 100 - 4) + '%'; }
    } else if (it.kind === 'spark') {
      const sp = d.querySelector('.sp'), L = sp._L || (sp._L = sp.getTotalLength());
      sp.setAttribute('stroke-dasharray', `${L} ${L}`); sp.setAttribute('stroke-dashoffset', L * (1 - ease((t - it.appear - 0.2) / 1.0)));
    } else if (it.kind === 'diamond') {
      const tx = setState(sc, e.id, 'text', si, e.text || '').v, dt = d.querySelector('.dt'); if (dt.textContent !== tx) dt.textContent = tx;
    }
  }

  function captionAt(t) {
    let k = 0; FLAT.forEach((s, i) => { if (t >= s.start) k = i; });
    const cur = FLAT[k], prev = k > 0 ? FLAT[k - 1].caption || '' : '', now = cur.caption || '';
    const p = (t - cur.start) / T.capFade;
    if (prev === now || p >= 1) return { text: now, op: now ? 1 : 0, box: now ? 1 : 0 };
    if (p < 0.5) return { text: prev, op: 1 - 2 * p, box: prev ? (now ? 1 : 1 - 2 * p) : 0 };
    return { text: now, op: 2 * p - 1, box: now ? (prev ? 1 : 2 * p - 1) : 0 };
  }

  FDV.seek = function (t) {
    t = clamp(t, 0, TOTAL - 1e-3);
    document.getElementById('progf').style.width = (t / TOTAL * 100) + '%';
    let cur = SCENES.findIndex(sc => t >= sc.start && t < sc.start + sc.dur); if (cur < 0) cur = SCENES.length - 1;
    SCENES.forEach((sc, i) => {
      if (i !== cur) { sc.layer.style.display = 'none'; return; }
      sc.layer.style.display = 'block';
      const fin = i === 0 ? 1 : ease((t - sc.start) / T.sceneIn), fout = i === SCENES.length - 1 ? 1 : clamp((sc.start + sc.dur - t) / T.sceneOut);
      sc.layer.style.opacity = Math.min(fin, fout);
      seekScene(sc, t);
    });
    const c = captionAt(t), ct = document.getElementById('capt');
    if (ct.textContent !== c.text) ct.textContent = c.text;
    ct.style.opacity = c.op; document.getElementById('cap').style.opacity = c.box;
    document.getElementById('fade').style.opacity = clamp((t - (TOTAL - T.endFade)) / T.endFade) * 0.92;
    const bl = document.querySelectorAll('.blob');
    bl.forEach((b, i) => b.style.transform = `translate(${Math.sin(t * 0.13 + i * 2) * 60}px,${Math.cos(t * 0.11 + i) * 40}px)`);
  };

  FDV.init = async function (spec) {
    S = spec; SCENES = spec.scenes; FDV.warnings = [];
    const blobs = document.getElementById('blobs');
    [['#1d3a5a', 0, -60, 1000], ['#33301c', 1100, 420, 900], ['#16403b', 1350, -150, 750]].forEach(([c, x, y, s]) =>
      div('blob', null, blobs).style.cssText = `left:${x}px;top:${y}px;width:${s}px;height:${s}px;background:radial-gradient(circle,${c} 0%,transparent 68%);opacity:.7`);
    SCENES.forEach((sc, i) => buildScene(sc, i));
    await document.fonts.ready;
    let t = 0;
    SCENES.forEach((sc, i) => { sc.start = t; schedule(sc); t += sc.dur; });
    TOTAL = t;
    SCENES.forEach((sc, i) => { sc.layer.style.display = 'block'; measureAndEdges(sc, i); sc.layer.style.display = 'none'; });
    SCENES.forEach(sc => { if (sc.type !== 'title') schedule(sc); });  // re-schedule now that edges exist
    FLAT = []; SCENES.forEach(sc => sc.steps.forEach(s => FLAT.push(s)));
    FDV.total = TOTAL;
    FDV.marks = FLAT.map(s => s.start + s.dur);   // end time of every step (for stills)
    FDV.seek(0);
    return { total: TOTAL, warnings: FDV.warnings, marks: FDV.marks };
  };

  FDV.play = function () {
    if (playing) return; playing = true; const t0 = performance.now();
    const loop = () => { const t = (performance.now() - t0) / 1000; FDV.seek(t % TOTAL); requestAnimationFrame(loop); };
    loop();
  };
  window.FDV = FDV;
})();
