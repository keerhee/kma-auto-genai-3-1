# 스펙 레퍼런스

```json
{
  "meta": { "title": "...", "fps": 24, "size": "1920x1080" },
  "scenes": [ { "type": "title", ... }, { "type": "diagram", ... } ]
}
```

## 장면

### title
| 필드 | 설명 |
|---|---|
| `title` | 흰색 큰 제목 (104px) |
| `accent` | 둘째 줄 강조 제목 (기본 골드, `accentColor`) |
| `subtitle` | 회색 부제 |
| `spinner` | 기본 true — 점선 원 위를 도는 3색 점 + 가운데 아이콘(`spinnerIcon`, 기본 refresh) |
| `steps` | 보통 `[{dur:2}, {dur:5, caption:"출처 · 날짜 · 예시 표기"}]` |
| `mini` | 스피너 대신 주체 A→B 미니 흐름: `{from, to, fromColor, toColor, len, at}` (점선 위로 초록 점이 흐름). `spinner:false`와 함께 쓴다 |

### diagram
| 필드 | 설명 |
|---|---|
| `header` | 좌상단 제목 |
| `bar` | 제목 앞 막대 색 |
| `page` | false면 `n / N` 숨김 |
| `elements` | 요소 배열 (아래) |
| `steps` | 단계 배열 (아래) |
| `allowUnderCaption` | true면 자막 바 영역까지 안전 영역 허용 |

## 단계 (step)
| 필드 | 설명 |
|---|---|
| `dur` | 초 (기본 3.5) |
| `caption` | 하단 자막. 빈 문자열이면 자막 바 숨김 |
| `show` | 이 단계에서 나타날 id 목록(순서대로 0.09초 간격). `"*"`는 전부 |
| `stagger` | 등장 간격 덮어쓰기 (예: 0.25) |
| `hide` | 이 단계 시작에 사라질 id |
| `focus` | 글로우 강조할 id |
| `dim` | `true`면 focus 외 전부 30% 투명, 또는 흐리게 할 id 목록 |
| `flow` | 이 단계 동안 흐름 점을 보낼 edge id |
| `reveal` | `{id: n}` — card 항목, panel 행, timeline 단계, code 줄, db 행, table 셀을 n개까지 표시 |
| `set` | `{id: {키: 값}}` — 요소 상태를 이 단계부터 바꾼다(이후 단계에 유지). 키: bubble `text`·`textColor`, diamond `text`, dots `lit`·`fade`, track `value`, spot `at` |

요소 필드 `delay`(초)를 주면 단계 시작 기준 등장 시각을 직접 지정한다. `always: true`면 첫 단계부터 표시.

## 요소 (모두 `id`, `kind`, `x`, `y` 필요)

| kind | 필드 | 용도 |
|---|---|---|
| `node` | `w h icon title sub color dashed titleColor titleSize wrapOk` | 기본 박스. 회색 노드는 제목이 흰색 |
| `group` | `w h tag color` | 점선 컨테이너 + 좌상단 태그 (항상 맨 아래 레이어) |
| `edge` | `from to` (+ 아래 표) | 연결선 |
| `pill` | `text color mark size` | 둥근 배지. `mark: "x" / "check" / "warn"` 아이콘 덧붙임 |
| `text` | `text size color alpha align weight w` | 자유 텍스트 (`\n` 줄바꿈) |
| `bubble` | `w h text icon color` | 말풍선, 타자 치듯 글자가 나타남 |
| `card` | `w h title items color` | 상태 카드. `items: [["x","거부"],["check","정상"],["warn","일부"]]`, `color`는 테두리 강조 |
| `panel` | `w h title color rows` | 제목 + 아이콘 행 목록. `rows: [["key","..."],["lock","..."]]` |
| `summary` | `w h icon title body color` | 정리용 큰 카드 |
| `timeline` | `w h steps lineColor` | 번호·원 아이콘·제목·부제의 단계 타임라인. `steps: [{icon,color,title,sub,num}]` |
| `stack` | `w h n caption color` | 블록을 쌓은 벽(격리·방화벽 표현) |
| `mark` | `size icon color` | 원형 아이콘 배지(예: 접근 불가 ✕) |

### v2 요소

| kind | 필드 | 용도 |
|---|---|---|
| `lane` | `w h icon label color labelW` | 스윔레인 밴드. 왼쪽 라벨 열(기본 110px)에 아이콘+이름, 오른쪽에 옅은 색 띠. 맨 아래 레이어 |
| `diamond` | `w h text color` | 판정 마름모. 꼭짓점이 상자 변 중점이라 `.l/.r/.t/.b` 앵커가 정확히 닿음 |
| `dots` | `rows cols r gap color label lit fade litColor` | 후보 점 격자. edge의 `from: "dotsId#n"`으로 n번째 점에서 선을 뽑음 |
| `gate` | `w h icon label color` | 세로 캡슐 기둥(판정·관문). 아이콘은 위, 라벨은 아래 |
| `window` | `w h url` | 브라우저 창 목업(빨·노·초 점 + 주소). 맨 아래 레이어, 위에 다른 요소를 얹음 |
| `skel` | `w h color hi hiW speed` | 스켈레톤 줄(밝은 조각이 천천히 지나감). `hi:false`면 정지 |
| `spark` | `w h points color label` | 미니 선 차트 패널, 등장 시 선이 그려짐 |
| `table` | `w h cols rows color` | 열 이름 + 스켈레톤 셀 표 |
| `db` | `w h ry title rows sub color` | DB 실린더. `rows`는 테이블·스키마 칩 |
| `code` | `w h icon title chips lines color mono` | 제목+칩+코드 줄 박스. 한글로 시작하는 줄은 일반체, 나머지는 고정폭 |
| `track` | `w max value milestones color note prefix counter head` | D+N 기한 트랙. `milestones:[{at,icon,label,sub,color}]`, 값은 `set.value`로 카운트업(기본 1.6초, `animDur`) |
| `spot` | `at r color moveDur` | 스포트라이트 고리. `x,y` 대신 중심 `at:[x,y]`, `set.at`으로 이동 |

bubble 추가 필드: `title`·`sub`를 주면 머리줄(아이콘+제목+부제) 아래 큰 따옴표 문구가 타자 치듯 나오는 큰 말풍선이 된다.

edge 추가: `route: "s"` — 가로(또는 세로) S자 3차 곡선, `sBend`(0–1, 기본 0.5)로 꺾이는 위치 조정. 팬아웃에 쓴다.

공통: `z`(쌓임 순서), `overlapOk`(겹침 경고 끄기), `safeOk`(안전 영역 경고 끄기), `delay`, `always`.

### edge 필드
| 필드 | 설명 |
|---|---|
| `from`, `to` | `"id"`(변 자동 선택) · `"id.r"`/`.l`/`.t`/`.b` · 좌표 `[x,y]` |
| `fromOff`, `toOff` | 변을 따라 앵커를 옮김(px) |
| `fromSide`, `toSide` | 변 강제 지정 |
| `route` | `"elbow"` — 직각 꺾임. `elbowAt`으로 꺾는 x(가로 출발) 또는 y(세로 출발) |
| `via` | 경유점 `[[x,y],...]` (모서리는 자동으로 둥글게) |
| `curve` | 2차 곡선 휨(px). 왼→오 선에서 음수면 위로 볼록 |
| `color`, `dashed`, `width`, `arrow:false` | 스타일 |
| `label`, `labelAt`(0–1), `labelDx`, `labelDy`, `labelAnchor`(start/middle/end), `labelColor` | 라벨 |
| `flow: true` | 그려진 뒤 계속 흐름 점 |
| `speed`, `drawDur` | 점 속도(px/s, 기본 420), 그리는 시간(기본 0.6초) |

## 아이콘
`clock terminal bot file doc folder lock key database server cloud cpu bell alert warn headset user users refresh trash pause hourglass check x flag globe chat mail gear git search chart play code link shield calendar money bolt layers eye dot`
(dots·track 마일스톤·code 머리에도 같은 아이콘 이름을 쓴다)
새 아이콘은 `engine/icons.js`에 24×24 stroke path로 추가한다.

## 타이밍 상수 (engine.js 의 `T`)
등장 0.45초 · 등장 간격 0.09초 · 선 그리기 0.6초 · 자막 전환 0.4초 · 장면 페이드 0.4/0.35초 · 끝 페이드 0.9초 · 카드 항목 간격 0.18초 · 타임라인 단계당 0.55초.
