# svg-infographic

**English** · [한국어](./README.ko.md)

Create flat, structured technical visuals for agentic coding workflows: architecture diagrams, cloud topologies,
process flows, before/after comparisons, roadmaps, and share-ready infographics. The package supports Claude Code
and Codex.

The skill computes the layout first (a required numeric layout pass — grid arithmetic and per-box text budgets
before any drawing), writes an editable SVG, runs a source lint that catches high-confidence failures, then exports
a crisp 2x PNG with a bundled render script that verifies the output dimensions. The goal is a first render that
passes review, not a render-and-fix loop.

## Quick Start

Provide the subject, intended reader, main message, language, and any required output size. If you do not know
the visual format, describe the relationship you need to explain and let the skill propose one.

```text
Use svg-infographic to turn this architecture note into an editable Korean technical diagram and a verified
2× PNG. Before creating files, propose an output directory and tell me which defaults I can change.
```

The skill confirms the output location and adjustable defaults before writing files. The remaining sections
explain the available diagram types, validation path, and environment requirements.

## Runtime Support

**Supported: Claude Code + Codex.** Evidence covers the same frozen, fresh-context briefs on macOS and a fresh
Codex App task in a Windows 11 ARM64 VM. The Windows result applies to that recorded VM configuration,
not every Windows machine or filesystem. Linux browser rendering remains documented but unverified.

## Best For

- Architecture and topology diagrams from text notes
- Technical one-pagers for docs, decks, and social posts
- Migration or modernization before/after visuals
- Process, data, or request-path flows
- Korean/CJK diagrams that must render correctly

## How It Works

The skill follows a fixed five-step workflow designed so the **first render passes review**:

1. **Preflight** — confirms intent, audience, ratio, and language; shows the defaults you can change; checks the
   tools needed for the requested output; and proposes an output directory before writing anything.
2. **Archetype** — picks the diagram shape from your content (see the table below) and loads that archetype's layout skeleton, visual guidance, and failure checks.
3. **Layout pass** — fixes the canvas regions, card grid, and per-box text budgets *numerically* before drawing. Copy that won't fit its box is shortened here — not after a broken render.
4. **Author + source lint** — writes the SVG from the computed numbers, runs `scripts/check-svg.mjs` to catch
   broken references, implicit or extreme marker sizing, opt-in header/card layout drift, and high-confidence
   text overflow, then reviews any heuristic warnings instead of treating them as a pass.
5. **Render + verify** — exports a 2× PNG via the canonical `scripts/render.mjs`. The optional
   `scripts/render.sh` Bash wrapper calls the same renderer. It runs the lint again before opening a browser and
   verifies the PNG dimensions; the skill then reviews the pixels against a quality bar (rendering, containment,
   message).

You don't need to know any of this to use the skill — but it explains what the skill tells you at each step, and why the output tends to be right the first time.

## Supported Archetypes

| You describe | The skill draws |
| --- | --- |
| systems/components and their links | Topology / component diagram |
| ordered steps or handoffs | Process flow (swimlane variant for parallel tracks) |
| a simple request path with an approval gate | Approval / sequence-lite |
| options, trade-offs, qualitative scoring | Decision / risk matrix, or cards |
| old vs new | Before / after panels |
| layered capability or containment | Layer stack, or nested "onion" model |
| time, phases, milestones | Roadmap / timeline |
| a few headline items or numbers | Icon cards / KPI grid (not a chart) |

Each archetype ships with a layout skeleton, visual guidance, and its own checks in [`references/archetypes.md`](./references/archetypes.md). If your content fits none of them, the skill says so instead of forcing a shape.

## Example Prompts

Start from whatever you have — the skill adapts to the input mode:

- **brief-first** — just a topic or goal; the skill asks a few focused questions, then proposes a structure.
- **source-first** — a doc, notes, an existing SVG, or a README; the skill summarizes it and agrees the key message before drawing.
- **research-first** — "draft it from scratch"; the skill states its assumptions first (external lookup may be unavailable depending on your environment).

To make it clear that you want this skill, name `svg-infographic` directly. You can also describe the artifact
you want in ordinary language:

```text
Turn this migration plan into an editable technical SVG and a verified 2× PNG. Show the proposed output path
and visual defaults before creating files.
```

```text
Use svg-infographic to draw this cloud architecture as a clean topology diagram:
Application Gateway -> APIM -> AKS -> PostgreSQL.
```

```text
Use svg-infographic to turn this monolith-to-microservices plan into a before/after infographic.
```

```text
Use svg-infographic to make a Korean 4:5 social infographic explaining these four layers.
```

See the repository-only
[`intent and invocation contract`](../../examples/intent-invocation-contract) for examples of how the skills
handle mixed or ambiguous requests.

## Detailed Example

Use a longer prompt when you want the skill to make layout decisions, choose an archetype, and verify the output.

```text
Use svg-infographic to create a technical infographic from the content below.

Topic: AI code review loop

Audience: engineers skimming how a PR-review pipeline works
Key message: an AI reviewer in the loop catches risky changes before human sign-off
(state a key message so the title can lead with the conclusion, not just a topic)

Goal:
- Show the flow from a developer opening a PR, to an AI agent reviewing it, to a human reviewer approving it, to changes being patched and verified.
- Make it a clean flat technical infographic suitable for docs, slides, or a social post.

Content:
1. Developer opens PR
   - code changes
   - test results attached
2. AI Review Agent
   - analyze diff
   - flag risky areas
   - check missing tests
3. Human Reviewer
   - inspect comments that need judgment
   - filter false positives
4. Patch & Verify
   - apply fixes
   - rerun tests
5. Merge Ready
   - approved
   - PR merge

Visual direction:
- Use a left-to-right process flow.
- Put each step in a rounded card.
- Add a simple line icon to each card.
- Highlight the AI Review Agent step with an accent color.
- Add a small legend at the bottom:
  - solid arrow = normal path
  - dashed arrow = feedback loop

Output:
- Propose an output directory inside the current project and ask before writing files.
- Create both the SVG source and a 2x PNG.
- Use the skill defaults for style, font, and colors, but tell me before drawing that I can change them.
```

For more worked prompts, browse the [example gallery](https://github.com/kyungseo/skillstead/tree/main/examples/svg-infographic): **each example folder's README ships the exact prompt (English + Korean) that produced it**, so you can copy a pattern close to what you need.

## Before Generation

When you run it, the skill shows defaults like the table below before writing files, then tells you what you can change. This makes the result predictable and gives you a chance to adjust the style before files are written.

| Item | Default | You can change |
| --- | --- | --- |
| Style | flat / muted technical, light background | dark mode, or the hand-drawn **sketch preset** on request |
| Icons | line icons inside soft circular badges | iconless line, solid, mono |
| Font | Pretendard -> Apple SD Gothic Neo -> Malgun Gothic / Noto Sans KR fallback | a specific font |
| Color | semantic colors per step, accent for the key card | brand colors |
| Ratio | chosen for the request, such as wide landscape or 4:5 social | any target size |
| Language | inferred from the prompt | English, Korean, or bilingual |
| Output | SVG + 2x PNG, inside the current project | SVG only |
| Footer | none | an optional source / date / author footer on request (a labeled footer, not a watermark) |

## Output

The skill proposes an output directory inside your current project before writing files.

- `*.svg` — primary editable vector asset for docs, HTML, and PPTX workflows
- `*.png` — 2x preview/export for sharing, thumbnails, and social posts

## Review Before Handoff

The skill checks the output at three stages, not just at the end:

- **Pre-render (source)** — the source lint reports hard failures with a location and suggested fix. Repeated
  page-title, panel-header, and icon-text-card structures can opt into layout contracts that check rail bounds,
  divider clearance, and shared vertical centers. Remaining containment arithmetic, rendered-ink alignment,
  contrast classes, EN/KO geometry parity, and heuristic warnings are reviewed explicitly.
- **Rendering (PNG)** — no text overflow, correct Korean/CJK glyphs (no tofu), PNG dimensions verified as exactly 2× (automated by the render script), icons render, and the SVG stays editable.
- **Message** — the archetype fits the content, there is one clear reading order, the title carries the conclusion, text density stays low per box, and the depth and language fit your audience.

For a busy architecture or flow diagram, the skill can group nodes into layout zones to reduce crossings. This is an optional layout aid, not a required format.

## Style Defaults

By default, the output uses:

- light background
- muted technical palette
- rounded structural cards and panels
- simple line icons in soft tinted circles
- CSS variables collected in one place
- Korean/CJK-safe font stack: Pretendard, Apple SD Gothic Neo, Malgun Gothic, Noto Sans KR, sans-serif

Before drawing, the skill tells you these defaults and gives you a chance to change ratio, language, brand color, theme, or output format.

## Requirements and the no-Node path

Installing or discovering the skill does not require Node.js, and the skill can author an editable SVG without
it. The complete automated lint-and-render workflow requires:

- Node.js 18 or newer for `scripts/check-svg.mjs` and the canonical `scripts/render.mjs`
- Chrome, Edge, or Chromium for PNG export

The optional `scripts/render.sh` wrapper requires Bash (Git Bash on Windows), but native Windows PowerShell and
CMD can run `node scripts/render.mjs` directly.

The checker uses only the Node.js standard library, so there is no `npm install` step or third-party npm package.
During preflight, the agent checks the installed Node version. If Node 18+ is missing, it shows the exact command
for the detected package manager and asks whether it should install Node and continue the automated checks. It
does not change the system without approval and does not use a remote `curl | sh` installer.

If you decline the install, the skill keeps the earlier quality floor: it completes the full manual source
checklist, renders a 2× PNG directly with Chrome, Edge, or Chromium, verifies its dimensions, and performs the
same visual QA. The handoff states that automated source lint did not run, while distinguishing the manual source
check and PNG verification that did pass; if no platform dimension reader is available, it reports that exact
check separately. Only when a Chromium-based browser is also unavailable does the fallback stop at an SVG-only
draft with both limitations stated.

## Install

Copy the complete package into a Claude Code or Codex skills directory. Claude Code uses `~/.claude/skills/`
globally or `.claude/skills/` in a project; Codex uses `~/.agents/skills/` globally or `.agents/skills/` in a
project. The skill is a multi-file package, so copy the whole folder:

```text
<skills-dir>/svg-infographic/
├── SKILL.md                  # core workflow (entry point)
├── README.md                 # this guide
├── README.ko.md              # Korean guide
├── CHANGELOG.md              # per-skill release history
├── LICENSE.txt               # Apache-2.0 full text (travels with the package)
├── assets/
│   └── fonts/                # bundled faces + their OFL notices (Pretendard, Hi Melody)
├── references/
│   ├── design-kernel.md      # the contract the whole package answers to
│   ├── archetypes.md         # archetype catalog: skeletons, premium recipe, checks
│   ├── authoring.md          # detailed rules, icon set, manual render fallback
│   ├── sketch.md             # opt-in tidy hand-drawn preset (paper, handwriting, rough)
│   ├── PROMPT-GALLERY.md     # request phrasing per TypePack, with the build command
│   ├── package-surface.yaml  # which files belong to which digest — the membership SSoT
│   ├── language-policy.yaml  # what must be English-canonical
│   ├── delivery/             # font delivery policy (portable vs system)
│   ├── skins/                # palette profiles, derivation, PageFrame, registry
│   ├── typography/           # families, faces, licensing
│   ├── types/                # TypePack manifest, per-type specs and inputs
│   ├── media/                # canonical skin contact sheet
│   └── legacy/               # superseded contracts kept for provenance
└── scripts/
    ├── generate.mjs          # TypePack build + receipt verify (entry point)
    ├── check-svg.mjs         # source lint gate, incl. --palette-profile
    ├── check-layout.mjs      # layout container / binding / reservation gate
    ├── check-language.mjs    # English-canonical guard for the normative surface
    ├── compose.mjs           # multi-fragment composition and its receipts
    ├── skin.mjs              # profile resolve/validate, manifest, delivery, typography-check
    ├── preflight.mjs         # digest computation and package integrity
    ├── measure-text.mjs      # browser text measurement (bundled face, fail-closed)
    ├── render.mjs            # canonical lint → browser render → 2× verification
    ├── render.sh             # thin Bash wrapper for render.mjs
    ├── font-probe.mjs        # runtime font load/computed check
    ├── font-subset.py        # OFL-safe subsetter (build-only; pinned fontTools + brotli)
    ├── route-orthogonal.mjs  # connector routing (lib)
    ├── treatment.mjs         # surface treatment resolver (lib)
    ├── residual-disposition.mjs  # residual floor decision (lib)
    ├── preflight-lib.mjs     # digest helpers (lib)
    ├── run-tests.sh          # the whole suite; SVGINFO_STRICT=1 refuses to skip
    ├── *.test.mjs            # one suite per script above
    └── fixtures/ …           # per-area fixture trees (layout, skin, compose, legacy)
```

GitHub install commands (global and project scope) for macOS, Linux, and Windows are in [`docs/INSTALL.md`](https://github.com/kyungseo/skillstead/blob/main/docs/INSTALL.md).

## Examples

Browse the full gallery:

**https://github.com/kyungseo/skillstead/tree/main/examples/svg-infographic**

It includes English and Korean examples for topology, layer/onion models, before/after comparison, process flow, roadmap, a decision matrix, CI/CD artifact promotion, an issue-tracker approval flow, and a self-demo.

The repository also publishes a browsable gallery of the TypePack catalog — each type with its Korean and English canonical example, the prompt that produced it and the receipt facts behind it:

**https://github.com/kyungseo/skillstead/blob/main/gallery/index.html**

Both are optional reading. This skill runs from the files in this directory alone.

## Boundaries

Use this skill for flat, structural visuals — or the opt-in **sketch preset** for a "tidy hand-drawn" look (paper background, Korean handwriting font, rough strokes, highlighter; the layout stays computed). It is not designed for:

- photo-heavy or illustration-heavy marketing graphics
- statistical charts such as bar, line, scatter, or heatmap charts
- mascots, character art, or scene illustration (also excluded from the sketch preset)

If PNG export is unavailable, the skill still delivers SVG and states the limitation.
