# Authoring reference

Detailed geometry, connector, panel, emphasis, color, and icon rules, plus the manual render fallback. Organized by principle; each rule exists because skipping it produced a broken render at least once.

## 1. Geometry & containment

- **Containment is arithmetic, not eyeballing.** Every child (card, icon, arrow, badge, label) sits inside its container/panel bounds **plus inner padding**, unless it is a deliberate outside-the-frame callout. For a row of repeated cards, compute the last card's far edge as `start + (n−1)·(cardW+gap) + cardW` and confirm it is `≤ container_edge − padding`; same for a column's bottom edge. If a row won't fit, shrink `cardW`/`gap`, wrap to a second row, or widen the canvas.
- **Page header:** the H-C editorial stack (design-kernel §6) — optional muted eyebrow row → H1 (1–2 lines) with the computed `--focus` title-keyline (canonical default; the eyebrow square locator is the explicit alternative, never doubled with the keyline) → optional muted subtitle → breathing room. The vertical accent rail is a **rejected** composition: never author it in new output. The legacy rail formula and its opt-in lint contract live only in `legacy/page-title-rail.md` (pre-kernel examples, until the catalog regeneration; the header-cluster contract replaces it in CP3).
- **Containment and distribution are machine-guarded** (`scripts/check-layout.mjs`, design-kernel §7): annotate containers (`data-layout-container` + `data-min-pad`/`data-symmetry`) and repeated rows (`data-layout-group` equal-gap) so padding, inset balance, and gap uniformity are verified from the layout receipt instead of eyeballed; a local nudge that breaks a group invariant is an error, and unsupported geometry must be classified `data-layout-unverified` — never silently passed.
- **Containment is judged on visual bounds, not the fill rect.** A child's visual edge = its rect/path edge **plus** half its stroke width, the drop-shadow spread (conservative margin: `abs(offset) + ~3 × stdDeviation`), and anything drawn outside the base rect (badge, corner label, marker/arrowhead). Pass condition on every side: `child_visual_edge ≤ parent_edge − inner_padding`. In a padded panel, a child that merely *touches* the parent edge is a containment failure even though the coordinates read "inside" — and a generous shadow *filter region* says nothing about containment. Keep left/right inner padding balanced, and fix an overflow by recomputing card width, gutters, or position inside the current region before reaching for a wider canvas.
- **Paired / side-by-side boxes:** always leave a **visible gutter of 24–32px**; never let two boxes touch. Balance the left/right outer margins.
- **Generous margins; align to a grid; consistent gutters.** Pick the margin and gutter values once in the layout pass and reuse them everywhere.
- **Fill the box.** Size text so boxes read full — avoid a small label marooned in a large box. Prefer 2–3 lines of body text or an icon to balance a card, rather than shrinking the type.

## 2. Text

- **Vertical centering:** center text with `dominant-baseline="central"` and set `y` to the box's vertical center. For two lines, straddle the center: title at `center−11`, sub at `center+10`, both `central`. Never rely on the default alphabetic baseline for box labels — it sits high.
- **Wrapping (SVG has no auto-wrap — the historical top failure mode):** break lines yourself with `<tspan x=.. dy=..>`. Keep ~28–36 chars/line for Latin, ~60% of that for Korean; 2–3 lines per box; abbreviate an over-long token rather than let it overflow. The text budget is set in the layout pass — re-check against the box width after writing.
- **Type scale stays unified across the diagram** — never vary sizes per box to make something fit; fix the layout instead.
- **Pill/badge labels — size the background from the text, not from a guess.** `pill_width ≥ text_width + 2 × padding` with ≥ 14–16px horizontal padding per side. All-caps or bold Latin labels (plus any letter-spacing) run wider than the body chars/line budget suggests — measure the rendered width in a browser when possible (same font stack the renderer uses), otherwise estimate conservatively from font size, weight, and script. With `text-anchor="middle"`, the text `x` must equal the computed rect center. When EN and KO share geometry, size the shared pill from the wider language's label. Never compress glyphs with `textLength`, and never shrink one label's font size to force a fit — fix the box geometry and padding first.

## 3. Connectors

- **Routing:** prefer straight orthogonal (horizontal/vertical) connectors; avoid crossings — route around, or move the node. Leave an **8–12px gap** between the arrowhead and the target box. Place edge labels *beside* the line, never on top of it.
- **Corridor budget — plan connectors numerically like cards.** For a horizontal connector, `corridor = target_visual_left − source_visual_right` (visual edges include stroke and shadow, §1). Compute the marker's real length before drawing: with the default `markerUnits="strokeWidth"`, `head_advance = markerWidth × stroke_width × (refX / viewBox_width)` — a "small" `markerWidth="8"` becomes a ~24px head on a 3px line; with `markerUnits="userSpaceOnUse"` the footprint is fixed in user units, so **prefer it** and set `refX` to the viewBox far edge so the tip lands exactly on the path endpoint. A standard arrow passes only when all of these hold: tip-to-target gap 8–12px; a *visible* shaft of ≥ 12–16px behind the head after subtracting source/target clearance, the head itself, and any segment hidden under a card or panel by paint order; the head does not take up most of the visible run; nothing intrudes into a card's stroke or shadow. "The target gap is right but the shaft is ≈ 0" is a **fail**, not a pass. Don't shrink a marker below directional legibility in the 2× PNG, and check the shaft–head joint there. The same formulas apply to vertical runs on the y-axis.
- **Adaptive connector vocabulary — pick the form from meaning plus corridor; don't force one form everywhere.** *Standard arrow*: the line itself carries the relation (dependency, request, data flow) and the corridor affords the full budget above. *Compact arrow*: a relation line is still needed and the corridor is short, but a readable shaft survives the budget. *Standalone chevron / right-facing triangle*: a plain "next stage" transition between adjacent stages where the line adds no meaning — a deliberate choice, never a fallback for a clipped shaft; center it in the corridor with clear space on both sides, and echo the marker's shape so it reads as flow, not as an icon or play button. *Reflow*: branch, merge, async, feedback, and labeled edges keep their rails — when the final segment cannot meet the shaft minimum, recompute the route or card positions instead of disguising the edge as a glyph. EN/KO variants share connector geometry and transition semantics.
- **Curved connectors (flat preset recipe).** A gentle curve often reads more naturally than an orthogonal elbow, especially between boxes at different heights. The geometry is preset-independent — the sketch preset's curves follow the same rules, minus the rough filter:
  - **Entry/exit perpendicular to the box edge.** The path must leave the source edge and approach the target edge at ≈90° to that edge; a curve that grazes a border at a shallow angle reads as clutter. Keep the 8–12px tip gap and the ≥ 12–16px visible shaft exactly as for straight arrows.
  - **Single bend by default.** One quadratic (`Q`) or one cubic (`C`) with both control points on the *same side* of the chord — monotone curvature, no inflection. For `M x1 y1 Q cx cy x2 y2`, a good default control point is the chord midpoint offset perpendicular by 10–20% of the chord length. An S-curve (two bends) is allowed only when it routes around a real obstacle **and** still reads cleanly in the 2× PNG — never as a default shape.
  - **Open-V stroked head is the default arrowhead** — it reads lighter than a filled triangle at every size and joins a curve cleanly:

    ```xml
    <marker id="ah" viewBox="0 0 12 12" refX="9" refY="6" markerWidth="11.25" markerHeight="11.25"
      markerUnits="userSpaceOnUse" orient="auto-start-reverse">
      <path d="M2 2 L10 6 L2 10" fill="none" stroke="#44546a" stroke-width="2" stroke-linecap="round"/>
    </marker>
    ```

  - **Size the head by its *visible* geometry, not the marker viewport.** The V glyph `M2 2 L10 6 L2 10` spans 8 of the 12 viewBox units, so `visible_head ≈ markerWidth × 8/12`. The contract is **visible ≈3× the shaft** (visual fail at ≈4× or more; below ≈2.5× a major-flow head reads weak at fit-to-page scale). For the canonical open-V that means **`markerWidth ≈ 4.5 × shaft`**:

    | shaft (px) | markerWidth | visible head |
    | --- | --- | --- |
    | 2.0 | 9 | ≈6.0 (3×) |
    | 2.5 | 11.25 | ≈7.5 (3×) |
    | 3.0 | 13.5 | ≈9.0 (3×) |

    The lint computes the visible ratio from the marker's actual glyph extent and warns outside ≈2.5–4×. A filled triangle is not forbidden, but apply the same visible-extent arithmetic to its own glyph span — never an unsized default.
  - **Shaft weight is part of fit-to-page readability.** A ≈3× head on a hairline shaft still disappears when the page is zoomed to fit: major stage connectors need ≈2.5–3px shafts on 1400–1600-wide canvases (secondary edges ≈2–2.5px). Fix a weak connector by adjusting shaft weight and corridor use together — never by enlarging only the head.
  - **`markerUnits="userSpaceOnUse"` is mandatory on every referenced marker** — the lint gate (`scripts/check-svg.mjs`, run automatically by `render.sh`) hard-errors otherwise, because the default `strokeWidth` units silently multiply the head by the stroke width (a "10" head on a 3px line renders 30px). Declare a reviewed exception with `data-lint-allow="marker-footprint"` only when an oversized head is a deliberate design decision.
- **Fan-out** (one source → many targets): one vertical stem from the source, one horizontal bus, then a centered vertical branch to each target. No orphan stubs, and no line that nearly overlaps a box edge.
- **Zone aid for busy diagrams:** if nodes collide, assign each to a **3×3 zone** (top-left … center … bottom-right), route edges only between zones, and wrap co-located nodes in one group frame. A quick sketching aid to cut crossings — not a required schema; simple diagrams don't need it.
- **Marker paint contract (canonical):** marker interiors never use `currentColor`, `context-stroke` or inherited paint. Either author one marker per role with direct stroke (`id="ah-edge"` … `data-stroke-role="edge-line"` `stroke="#2E6DA4"`), or let the materializer generate per-role markers. A connector references the marker matching its own stroke role.
- **Sketch arrowhead band:** rough displacement visually thins the head, so the flat contract (visible ≈3× shaft) reads weak in sketch. Sketch targets **visible ≈3.5× shaft** within an acceptance band of **3.0–4.5×**. `data-lint-allow="marker-footprint"` stays reserved for pre-kernel legacy examples — new sketch output must meet the band, not bypass it.
- **Machine-verifiable connector subset (boundary record):** future label-clearance and corridor-overlap lint (backlog `svg-infographic-connector-machine-guards`) may only *prove* violations where geometry is resolvable from source: straight segments from absolute `M/L/H/V` commands, translate-only transforms, numeric stroke-width, and label mask rects with numeric geometry. Curves/arcs, relative or exponent coordinates, non-translate transforms and CSS-resolved stroke widths degrade to warnings — never silent passes, never false errors (no-false-certainty).
- **Semantics:** one `<marker>` arrowhead definition reused via `marker-end`. Solid = sync/request/normal; dashed `stroke-dasharray="5 4"` = async/batch/private/feedback. Legend whenever both appear.

## 4. Panels & header bands

- **Header band on a rounded panel:** use a **top-only rounded** header — a `<path>` with rounded top corners and a square bottom edge (`M x+r,y H x+w-r A r r 0 0 1 x+w,y+r V y+h H x V y+r A r r 0 0 1 x+r,y Z`), or a header rect clipped to the panel. **Never stack a fully-rounded rect plus a square "cover" rect** — it smears the lower corners in the PNG.
- **Budget title, subtitle, and divider as one vertical unit.** Compute `headerH = padTop + titleH + gap + subtitleH + padBottom`; the divider begins after `subtitleBottom + padBottom`, never through the subtitle's line box. For repeated panel headers, opt into the source check with plain numeric values and centered-baseline text:

```xml
<g data-layout-role="panel-header" data-layout-top="0" data-layout-bottom="132"
   data-layout-gap="16" data-layout-padding-top="20" data-layout-padding-bottom="24">
  <text data-layout-role="header-title" y="38" font-size="32" dominant-baseline="middle">…</text>
  <text data-layout-role="header-subtitle" y="82" font-size="20" dominant-baseline="middle">…</text>
  <line data-layout-role="header-divider" x1="0" y1="120" x2="936" y2="120"/>
</g>
```

The contract accepts `translate()` but not rotate/scale/skew. It accumulates non-nested `<tspan>` lines with plain numeric `y`/`dy`; nested spans, relative units, and unsupported baselines become `W-LAYOUT`, not a silent pass. Divider bounds include half its stroke width. Keep `data-layout-bottom` close to the divider—more than the documented small slack produces a warning so downstream bands do not inherit accidental empty space. A reviewed exception may use `data-lint-allow="layout-geometry"`; record why the PNG check is sufficient.

The line box is a **source-coordinate model**, not rendered ink measurement. `middle` and `central`, font fallback, and mixed CJK/Latin glyphs can look optically different even when their source boxes align. Final typography alignment remains part of the 2× PNG pass.
- **Band containers** (premium base): light tinted fill, hairline border, `rx 14–22`; white content cards on top with a subtle `<filter>` drop shadow at low opacity. Keep shadows soft — a heavy shadow reads as clutter at 2×.

## 5. Emphasis & corner decorations

- **Emphasis toolkit (use these, in this order of preference):** stronger stroke in the card's family color → soft shadow → number/status badge → corner label → filled icon badge. These alone carry a "key step" clearly.
- **Top accent bar on a rounded card — default no.** Two failure modes make it risky:
  1. *Corner smear* — a bar sharing the card's `x`/`y`/`width` has square corners that collide with the card's `rx` arc and render torn in headless-Chromium PNG.
  2. *Band collision* — if the card top already carries a number badge, status label, or KEY-STEP-style tag, the bar crosses their horizontal band and the card top reads cluttered.
  **If a card top has a number badge or a status label, never add a top accent bar.** Reserve it for a card with a clearly separated header band (its own row, nothing else in it), and even then inset the fill clear of the corner radius (`≥ rx` in from each side and below the top) — it must never touch the corner-radius zone.
- **Corner decorations stay apart:** a number/corner badge, a status label (e.g. a caution tag), and a top-right icon must **not** crowd the same corner. Give each **≥ 20–24px clearance** between bounding boxes. Reliable arrangement: badge top-left, status label on the **same row just right of the badge**, icon top-right. This is the top failure mode for 2×2 / decision-matrix quadrant cards; verify against the **exported PNG**, not just the SVG source.

## 6. Color & contrast

- **Tokens:** every paint-bearing shape carries direct `fill`/`stroke` plus `data-fill-role`/`data-stroke-role` annotations (SKILL.md §3, design-kernel §5). Colors encode role, not decoration — rebrand by re-running the `skin.mjs` materializer against a profile, never by hand-editing hex or maintaining a variable block.
- **Dark variant:** a separate direct-paint artifact (`diagram.light.svg` / `diagram.dark.svg`), each materialized from the same profile — never a `prefers-color-scheme` media query inside one SVG (design-kernel §5). PNG renders from each artifact directly.
- **On-focus text:** default to **light (white/near-white) text on a saturated fill** — never dark text on a mid/dark accent. A light-tinted chip may keep dark ink; a saturated fill needs light text. Annotate those labels `data-fill-role="on-focus"` with a direct light fill.
- **Gotcha — blanket text color rules hide contrast problems.** An inline `fill="#FFFFFF"` usually wins over a global `text{ fill:… }` rule in headless Chrome, but inherited text (`<tspan>`, grouped labels, generated variants) can silently lose its on-focus contrast. When the diagram mixes dark body text and light on-focus text, **avoid a blanket `text{fill}` rule entirely** — set ink color per group/class — and always inspect the PNG (aim for an AA-like separation).

## 7. Icons

Icon-first is the default: a simple **line icon inside a soft tinted circle** per card or node.

- **Icon vs number:** a **number badge only when sequence or cross-reference matters** (numbered steps). When the icon alone identifies the item, use the icon only — never icon + redundant number.
- **Placement:** icon circle `r≈34–38` with a light tint fill (`#E3EEF8`), with the selected registry path expanded as a concrete path and centered inside at ~40px. Derive both the circle center and the complete text cluster from card geometry (`centerY = card_y + card_h/2`) — never a hand-tuned per-language offset; EN and KO variants share the same formula. For repeated icon-text cards, annotate the card group with `data-layout-role="icon-text-card" data-layout-center-y="118"`; mark its actual background rect `card-frame`, the circle `icon-center`, and centered-baseline text lines `card-title` / `card-body`. The lint checks frame, icon, and the accumulated text cluster against the same target. The card-specific `data-layout-center-tolerance` defaults to 2px; keep explicit values in the reviewed 0–8px range. For backward compatibility, a larger value emits `W-LAYOUT` but remains the supplied comparison tolerance, unlike the page-title contract's 2px fallback. Treat that warning as unverified geometry requiring correction or explicit 2× PNG disposition, never as alignment proof.

```xml
<g data-layout-role="icon-text-card" data-layout-center-y="118">
  <rect data-layout-role="card-frame" width="444" height="236" rx="24"/>
  <circle data-layout-role="icon-center" cx="72" cy="118" r="28"/>
  <text data-layout-role="card-title" y="94" font-size="24" dominant-baseline="middle">…</text>
  <text data-layout-role="card-body" y="122" font-size="16" dominant-baseline="middle">
    <tspan x="124" dy="0">…</tspan><tspan x="124" dy="24">…</tspan>
  </text>
</g>
```

The source-coordinate model limitation described in §4 also applies to card-center checks; confirm rendered ink and optical centering in the final 2× PNG.

- **Recolor:** the icon registry is the authoring source. Before an SVG counts as canonical, place the selected registry geometry as **concrete paths** carrying `data-stroke-role` (and `data-fill-role` where filled) with direct paint — today this expansion is the generator/author's responsibility; automatic expansion inside the materializer remains the catalog regeneration candidate (`svg-infographic-materializer-icon-expansion`). Per-instance `currentColor` recoloring never appears in canonical output.
- **Style options to offer:** default = soft circular background + thin line icon. Alternatives: no background (line icon only), filled/solid icon, or mono. Stroke width ~1.7–1.9.

The bundled icon list is not copied into this document. Query the registry SSoT with
`node scripts/skin.mjs icons`; use `node scripts/skin.mjs icons --json` when path data is needed
for authoring or tooling. Each entry is a 24×24 concrete path in the same round-cap/round-join line
grammar. The placeholder stroke is replaced with role-annotated direct paint when an icon is
expanded into canonical output.

Canonical example (icon expanded to a concrete path): `<circle cx="172" cy="726" r="38" data-fill-role="icon-tint" fill="#EAF0F6"/><path d="…terminal glyph at 152,706 scaled 40px…" data-stroke-role="edge-line" stroke="#2E6DA4" fill="none" stroke-width="3"/>`. There is no separate `data-color-role` schema — fill/stroke annotations cover icons too.

Need an icon that isn't in the set? Compose it from the same 24×24 line grammar (stroke 1.8, round caps/joins) so it matches — don't mix icon families.

## 8. Render — manual fallback

Use `scripts/render.sh` when possible; it automates everything below plus the dimension check. This manual path
also preserves the pre-v0.7.1 quality floor when Node 18+ is unavailable and the user declines installation.
Complete every SKILL.md §4 source-check item before rendering; this path replaces the automated lint, not the
manual checks or PNG review.

Any Chromium-based browser works — Chrome, Microsoft Edge, or Chromium — with the **same headless flags on every OS**. Discover the binary first (use the first that resolves):

- **macOS** — test each path, use the first executable: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`, `.../Microsoft Edge.app/Contents/MacOS/Microsoft Edge`, `/Applications/Chromium.app/Contents/MacOS/Chromium`.
- **Linux** — `command -v google-chrome || command -v google-chrome-stable || command -v chromium || command -v chromium-browser`.
- **Windows (PowerShell)** — `Get-Command chrome, msedge -ErrorAction SilentlyContinue`; else `Test-Path` these known locations **in order** (the same four render.sh probes) and use the first hit:
  1. `C:\Program Files\Google\Chrome\Application\chrome.exe`
  2. `C:\Program Files (x86)\Google\Chrome\Application\chrome.exe`
  3. `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`
  4. `C:\Program Files\Microsoft\Edge\Application\msedge.exe`

  Only after all four fail may you report "no Chromium-based browser". To use the bundled `render.sh` instead of this manual path, remember Git Bash may be installed without being on PATH — test `C:\Program Files\Git\bin\bash.exe` before concluding bash is unavailable.

Wrapper HTML (W/H = SVG viewBox), placed next to the .svg in the session scratchpad (not in the repo):

```html
<!doctype html><html><head><meta charset="utf-8"><style>
*{margin:0;padding:0}html,body{width:Wpx;height:Hpx;overflow:hidden}
img{display:block;width:Wpx;height:Hpx}
</style></head><body><img src="diagram.svg"></body></html>
```

macOS / Linux:

```bash
BROWSER="$(command -v google-chrome || command -v chromium || echo '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')"
"$BROWSER" --headless=new --disable-gpu --hide-scrollbars \
  --force-device-scale-factor=2 --window-size=W,H \
  --screenshot="diagram.png" "file://$PWD/wrapper.html"
```

Windows (PowerShell) — same flags; build a proper `file://` URL (forward slashes) and keep the path quoted so spaces don't break it:

```powershell
$chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
$url = "file:///" + ((Resolve-Path .\wrapper.html).Path -replace '\\','/')
& $chrome --headless=new --disable-gpu --hide-scrollbars `
  --force-device-scale-factor=2 --window-size=W,H `
  --screenshot="diagram.png" $url
```

Verify that the PNG is exactly `2W × 2H`. Use an available platform-native reader rather than installing another
tool only for this check:

- **macOS:** `sips -g pixelWidth -g pixelHeight diagram.png`
- **Linux:** use `python3` to read the PNG IHDR when available; otherwise inspect the dimensions reported by the
  installed image/file utility and record when exact verification is unavailable.
- **Windows PowerShell:** load the image with `System.Drawing.Image`, read `Width` and `Height`, then dispose it.

After the dimension check, perform SKILL.md §7 visual QA. Report automated source lint as not run, while reporting
the manual source checklist and PNG checks separately.

Notes:

- `--window-size` = viewBox (not 2×); the scale factor upscales.
- Transparent background: add `--default-background-color=00000000`.
- On locked-down Linux / CI / containers, add `--no-sandbox` **only if** the render fails with a sandbox error (not a default).
- Prefer a wrapper path without spaces; if it has spaces, keep it quoted.
- Fonts are the locally installed ones — Korean/CJK falls back to Apple SD Gothic Neo (macOS), Malgun Gothic (Windows), Noto Sans KR (Linux). **On Linux the CJK font is not guaranteed** — if Korean renders as tofu (□), install Noto Sans CJK/KR (e.g. `fonts-noto-cjk`) and re-render.
- If no Chromium-based browser is available, deliver the SVG only and state the limitation.
