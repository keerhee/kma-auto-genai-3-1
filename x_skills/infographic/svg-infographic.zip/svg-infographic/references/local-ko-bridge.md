# 로컬 부록 — 한국어 환경 · 브리지 스킬 연계

> 이 파일만 로컬 추가분이다. 나머지는 전부 upstream `kyungseo/skillstead` v0.10.0 원본이다 (테스트 표면 제외).

## 1. 이 설치본의 범위

upstream `kyungseo/skillstead` v0.10.0의 **런타임 전체**(SKILL.md · references · scripts ·
Pretendard 400/700 · Hi Melody)를 담았다. 스킬 업로드의 **200개 파일 제한** 때문에
자체 회귀 테스트 표면만 제외했다.

| 포함 | 제외 |
|---|---|
| SKILL.md, README, CHANGELOG, LICENSE, `references/**`(design-kernel · TypePack 9종 · skins · typography · delivery), `scripts/*.mjs`, `scripts/font-subset.py`, `assets/fonts` | `scripts/*.test.mjs`, `scripts/run-tests.sh`, `scripts/{fixtures,layout-fixtures,skin-fixtures,compose-fixtures,legacy}` |

`references/package-surface.yaml`의 verification 선언도 함께 제거해 preflight가 통과한다
(`node scripts/check-svg.mjs diagram.svg` 확인 완료). 총 97개 파일.

회귀 테스트가 필요하면 원본을 따로 받는다:
`git clone --depth 1 https://github.com/kyungseo/skillstead.git`

로컬 추가분은 이 파일 하나뿐이며 `package-surface.yaml`에 `kind: doc`으로 등록돼 있다.

## 2. Chromium이 없는 환경 (Claude 컨테이너 등)

`scripts/render.mjs`는 Chromium 계열 브라우저를 찾아 2× PNG를 굽고 IHDR로 치수를 검증한다.
브라우저가 없는 환경에서는 이 경로가 실패하므로 다음 순서로 처리한다.

1. **소스 린트는 그대로 돌린다** — Node 18+만 있으면 된다.
   ```bash
   node scripts/check-svg.mjs diagram.svg
   node scripts/check-layout.mjs diagram.svg      # layout 주석이 있을 때
   node scripts/skin.mjs resolve current --mode light
   ```
2. **PNG는 cairosvg로 굽는다** — 브리지 스킬(`svg-infographic-navy-deck`, `svg-infographic-docx`)의
   `render_for_deck.sh` / `render_for_docx.sh`가 이 경로를 담당한다.
3. 이때 결과물을 "machine-linted + browser-rendered"로 표기하지 않는다.
   **"소스 린트 통과, PNG는 cairosvg 렌더"**로 정확히 적는다.

## 3. 폰트 전달(font delivery) 모드 선택

| 모드 | 언제 | 주의 |
|---|---|---|
| `portable` (기본, 승인 등급) | SVG 자체를 배포·보관할 때. 사용한 글리프만 서브셋해 `@font-face` data URI로 임베드 | 서브셋 도구(`pyftsubset`, fonttools 4.53.1 + brotli) 필요. **cairosvg는 data URI `@font-face`를 신뢰할 수 없다** |
| `system` | **PNG로 구워 PPT·Word에 넣는 브리지 경로** | 렌더 환경에 폰트가 설치돼 있어야 한다. 컨테이너: `fc-list \| grep -i noto`, 없으면 `apt-get install -y fonts-noto-cjk` |

즉 **최종 산출물이 PNG면 `system` 모드 + `Noto Sans CJK KR`**, 최종 산출물이 SVG면 `portable`.
PowerPoint는 SVG에 임베드된 폰트를 보존하지 않으므로, SVG를 PPT에서 편집하려면 대상 PC에
Pretendard가 설치돼 있어야 한다.

## 4. TypePack 우선 라우팅 (0.10.0에서 바뀐 핵심)

`references/archetypes.md`의 타입별 규칙은 **묘비(pointer)만 남았다.** 실제 규칙은 TypePack에 있다.

```
references/types/selection.md   → 콘텐츠 신호 → TypePack 선택
references/types/specs/<id>.md  → 입력 계약 · 레이아웃 공식 · 검증 체크리스트 (유일한 규칙)
references/types/inputs/<id>.canonical.yaml → 정답 입력 예시
```

9종: `approval-gate` · `before-after` · `cards-kpi-grid` · `decision-matrix` · `layer-stack` ·
`nested-scope` · `process-flow` · `roadmap-timeline` · `topology-component`.

## 5. 한국어 저작 시 자주 걸리는 것

1. 텍스트 예산 — 한글은 라틴의 **약 60%** 문자 수. layout pass에서 줄 수를 확정하고 문구를 먼저 줄인다.
2. `&` → `&amp;` 이스케이프. 유니코드 첨자(₁, ²)는 렌더 후 □ 여부를 눈으로 확인.
3. 출력 파일명은 ASCII만.
4. PageFrame 헤더는 **H-C editorial stack**(eyebrow → H1 + title-keyline → subtitle). 세로 액센트 레일은
   폐기된 구성이므로 다시 만들지 않는다.
5. 캔버스에 제목을 넣을지 여부는 용도에 따른다 — 슬라이드·책 삽입용은 제목을 **넣지 않는다**
   (덱 `head()` / Word 캡션이 제목을 담당). 브리지 스킬 규정을 따른다.

## 6. 브리지 스킬

| 스킬 | 용도 | 캔버스 | 렌더 |
|---|---|---|---|
| `svg-infographic-navy-deck` | report-navy-deck 강의 PPT 삽입 | WIDE 1500×600 / PANEL 1260×700 | cairosvg 2× |
| `svg-infographic-docx` | korean-book-docx 책·교재 삽입 | 1220px 폭 고정 | cairosvg 2440px |

같은 도해를 덱과 책에 함께 쓸 때 **PNG를 재사용하지 않는다.** SVG 소스를 공유하고
각 규격으로 layout pass를 다시 돌린다.
