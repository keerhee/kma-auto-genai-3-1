# 콜센터 실시간 관제 시스템 실습 키트

가상의 "하늘카드 고객센터"를 대상으로, Claude Code에게 프롬프트를 주어 실시간 관제 대시보드를 만드는 실습 자료다. 회사명·상담사 이름·수치는 모두 가상이다.

| 폴더·파일 | 내용 |
|---|---|
| `data/queues.csv` | 큐 3개 — 우선순위, SL 목표, 평균 처리시간, 평균 인내시간 |
| `data/agents.csv` | 상담사 30명(가명) — 팀, 처리 가능한 큐, 근무시간, 점심 시작 |
| `data/forecast_30min.csv` | 09:00~18:00 30분 구간별·큐별 인입 예측 |
| `data/calls_yesterday.csv` | 어제 콜 이력 |
| `data/check_10calls.csv` | KPI 손계산 검증용 10콜 |
| `docs/system_spec.md` | 요구사항 정의서 — Claude Code가 구현 기준으로 읽는다 |
| `docs/monitoring_manual.md` | 관제 운영 매뉴얼 — KPI 정의, 임계치, 경보 대응 절차 |
| `prompts/step_prompts.md` | STEP 0~11 단계별 프롬프트 원문 |

시작: 이 폴더에서 터미널을 열고 `claude`를 실행한 뒤 `prompts/step_prompts.md`의 STEP 0부터 붙여 넣는다.
