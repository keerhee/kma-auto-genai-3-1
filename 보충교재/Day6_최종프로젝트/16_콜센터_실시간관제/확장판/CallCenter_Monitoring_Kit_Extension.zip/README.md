# 콜센터 실시간 관제 시스템 확장 키트 — 통화 텍스트로 인입 원인 보기

기본 키트(CallCenter_Monitoring_Kit.zip)로 STEP 0~11을 마친 `callcenter-monitor` 폴더에 이 키트를 풀어 STEP 12부터 진행한다. 대본·인물·수치는 모두 가상이며, 대본 속 카드번호·전화번호·생년월일도 가짜다.

| 폴더·파일 | 내용 |
|---|---|
| `data/call_topics.csv` | 상담 주제 8종 — 큐, 큐 안 평소 비중, 대표 키워드 |
| `data/transcripts_seed.jsonl` | 가상 상담 대본 120건 (정답 주제·감정 포함) — 규칙을 만들 때 본다 |
| `data/transcripts_test.jsonl` | 가상 상담 대본 45건 — 평가에만 쓴다 |
| `docs/voice_analytics_spec.md` | 확장 요구사항 정의서 |
| `docs/monitoring_manual.md` | 관제 매뉴얼 새 판 — 4.7 인입 원인 경보 신설 |
| `prompts/step_prompts_ext.md` | STEP 12~18 단계별 프롬프트 원문 |
