"""텍스트 처리 — 개인정보 마스킹, 고객 발화 추출, 문자 오류율(CER)."""
import re

# 카드번호(4-4-4-4), 휴대폰, 생년월일을 가린다. STT 결과에는 숫자가 한글로 나올 수도 있다.
PII_PATTERNS = [
    (re.compile(r"\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}"), "[카드번호]"),
    (re.compile(r"01[016789][\s-]?\d{3,4}[\s-]?\d{4}"), "[전화번호]"),
    (re.compile(r"(19|20)\d{2}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일"), "[생년월일]"),
]


def mask_pii(text: str) -> str:
    for pat, rep in PII_PATTERNS:
        text = pat.sub(rep, text)
    return text


def customer_text(turns, first_n=None):
    """고객 발화만 이어 붙인다. first_n이 있으면 앞의 n개 발화만(통화 초반 STT를 흉내)."""
    said = [t["text"] for t in turns if t["speaker"] == "고객"]
    return " ".join(said[:first_n] if first_n else said)


def full_text(turns):
    return " ".join(f'{t["speaker"]}: {t["text"]}' for t in turns)


def _edit(a, b):
    """레벤시테인 거리 (치환·삭제·삽입 수의 최소 합)"""
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def cer(ref: str, hyp: str) -> float:
    """문자 오류율 = (치환+삭제+삽입) / 정답 글자 수. 공백과 문장부호는 빼고 비교한다."""
    norm = lambda s: re.sub(r"[\s\.,\?!·]", "", s)
    r, h = norm(ref), norm(hyp)
    return _edit(r, h) / max(1, len(r))


if __name__ == "__main__":
    print(mask_pii("카드 번호는 9410 2385 7716 0423이에요. 제 번호는 010-4821-7730이에요."))
    print(round(cer("결제일을 바꾸고 싶어요", "결재일을 바꾸고 시퍼요"), 3))
