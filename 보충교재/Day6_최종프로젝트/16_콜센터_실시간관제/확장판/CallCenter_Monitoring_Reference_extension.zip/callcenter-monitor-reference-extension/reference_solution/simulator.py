"""가상 콜 이벤트 시뮬레이터.

09:00~18:00 하루를 빠르게 재생하며 콜 인입·대기·응대·포기·후처리와 상담사 상태를
SQLite(live.db)에 계속 기록한다. 대시보드는 이 DB만 읽는다.

시간 단위: 하루 0시 기준 초(예 09:00 = 32400). 기본 속도: 실제 1초 = 가상 20초.
실행: python simulator.py --speed 20
"""
import argparse, csv, math, os, random, sqlite3, time

import classify
import json
import kpi

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
DB = os.path.join(HERE, "live.db")
START, END = 9 * 3600, 18 * 3600

SCHEMA = """
CREATE TABLE calls(call_id TEXT PRIMARY KEY, queue_id TEXT, arrive_ts INT, answer_ts INT,
                   talk_end_ts INT, acw_end_ts INT, abandon_ts INT, agent_id TEXT);
CREATE TABLE agents(agent_id TEXT PRIMARY KEY, agent_name TEXT, team TEXT, skills TEXT,
                    state TEXT, since_ts INT, call_id TEXT);
CREATE TABLE clock(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE call_text(call_id TEXT PRIMARY KEY, ts INT, queue_id TEXT, topic_true TEXT,
                       topic_pred TEXT, sentiment TEXT, snippet TEXT);
CREATE TABLE kpi_history(ts INT PRIMARY KEY, sl REAL, asa REAL, abandon_rate REAL, waiting INT,
                         longest_wait INT, occupancy REAL, aht REAL, answered INT, abandoned INT);
"""


def read_csv(name):
    with open(os.path.join(DATA, name), encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def hm(s):
    h, m = s.split(":")
    return int(h) * 3600 + int(m) * 60


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--speed", type=float, default=20)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--until", type=str, default="18:00", help="이 가상 시각에서 멈춘다")
    a = ap.parse_args()
    random.seed(a.seed)

    for f in (DB, DB + "-wal", DB + "-shm"):   # 지난 실행의 DB와 WAL 파일을 지운다
        if os.path.exists(f):
            os.remove(f)
    con = sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)

    queues = {q["queue_id"]: q for q in read_csv("queues.csv")}
    forecast = {(hm(r["interval_start"]), r["queue_id"]): float(r["forecast_calls"]) for r in read_csv("forecast_30min.csv")}
    agents = {}
    for r in read_csv("agents.csv"):
        s0, s1 = r["shift"].split("-")
        agents[r["agent_id"]] = dict(r, skills=r["skills"].split("|"), start=int(s0) * 3600, end=int(s1) * 3600,
                                     lunch=hm(r["lunch"]), state="오프라인", since=START, call=None, busy_until=0)
        con.execute("INSERT INTO agents VALUES(?,?,?,?,?,?,?)",
                    (r["agent_id"], r["agent_name"], r["team"], r["skills"], "오프라인", START, None))
    con.execute("INSERT INTO clock VALUES('scenario','정상'),('sim_ts',?),('command','')", (START,))
    con.commit()

    # 확장편: 주제 구성비와 가상 상담 대본 (STT가 넘겨줄 텍스트를 흉내 낸다)
    topics = read_csv("call_topics.csv")
    mix = {}
    for tp in topics:
        mix.setdefault(tp["queue_id"], []).append((tp["topic_id"], float(tp["share_in_queue"])))
    scripts = {}
    for name in ("transcripts_seed.jsonl", "transcripts_test.jsonl"):
        for line in open(os.path.join(DATA, name), encoding="utf-8"):
            r = json.loads(line)
            scripts.setdefault(r["topic_id"], []).append(r)

    def pick_topic(qid):
        ids, w = zip(*mix[qid])
        return random.choices(ids, w)[0]

    waiting = []          # [call_id, queue_id, arrive_ts, give_up_ts]
    calls = {}            # call_id → dict (DB에 쓸 값)
    dirty_calls, n = set(), 0
    scenario = "정상"
    until = hm(a.until)
    t = START
    tick_real = 0.5
    step = int(a.speed * tick_real)       # 틱당 가상 초

    while t < min(END, until):
        # ---- 대시보드에서 보낸 시나리오 명령 읽기 ----
        cmd = con.execute("SELECT v FROM clock WHERE k='command'").fetchone()[0]
        if cmd:
            scenario = cmd
            con.execute("UPDATE clock SET v='' WHERE k='command'")
            con.execute("UPDATE clock SET v=? WHERE k='scenario'", (scenario,))
        surge = 1.8 if scenario == "인입 급증" else 1.0
        outage = {f"A{i:02d}" for i in range(9, 17)} if scenario == "상담사 이탈" else set()
        app_down = scenario == "앱 장애"      # 일반 문의 큐에 앱 로그인 장애 콜이 평소 인입의 60%만큼 더 들어온다

        for _ in range(step):
            t += 1
            # 1) 상담사 근무 상태 갱신 (출근·점심·퇴근·장애 이탈)
            for ag in agents.values():
                if ag["state"] in ("통화", "후처리"):
                    continue                      # 통화 중이면 끝난 뒤에 반영
                in_shift = ag["start"] <= t < ag["end"]
                if not in_shift:
                    new = "오프라인"
                elif ag["agent_id"] in outage:
                    new = "장애 이탈"
                elif ag["lunch"] <= t < ag["lunch"] + 3600:
                    new = "휴식"
                else:
                    new = "대기"
                if new != ag["state"]:
                    ag["state"], ag["since"] = new, t
            # 2) 인입 (포아송)
            slot = START + (t - START) // 1800 * 1800
            for qid, q in queues.items():
                base = forecast.get((slot, qid), 0) / 1800
                streams = [(base * surge, None)]
                if app_down and qid == "Q2":
                    streams.append((base * 0.6, "T6"))
                for lam, forced in streams:
                    if random.random() < lam:
                        n += 1
                        cid = f"C{n:05d}"
                        patience = random.expovariate(1 / float(q["patience_sec"]))
                        waiting.append([cid, qid, t, t + patience])
                        calls[cid] = dict(call_id=cid, queue_id=qid, arrive_ts=t, answer_ts=None, talk_end_ts=None,
                                          acw_end_ts=None, abandon_ts=None, agent_id=None)
                        calls[cid]["_topic"] = forced or pick_topic(qid)
                        dirty_calls.add(cid)
            # 3) 포기
            for w in [w for w in waiting if w[3] <= t]:
                waiting.remove(w)
                calls[w[0]]["abandon_ts"] = t
                dirty_calls.add(w[0])
            # 4) 통화·후처리 종료
            for ag in agents.values():
                if ag["state"] == "통화" and t >= ag["busy_until"]:
                    calls[ag["call"]]["talk_end_ts"] = t
                    dirty_calls.add(ag["call"])
                    ag["state"], ag["since"], ag["busy_until"] = "후처리", t, t + random.randint(15, 45)
                elif ag["state"] == "후처리" and t >= ag["busy_until"]:
                    calls[ag["call"]]["acw_end_ts"] = t
                    dirty_calls.add(ag["call"])
                    ag["state"], ag["since"], ag["call"] = "대기", t, None
            # 5) 배정: 오래 쉰 상담사부터, 우선순위 높은 큐 → 오래 기다린 콜
            idle = sorted([g for g in agents.values() if g["state"] == "대기"], key=lambda g: g["since"])
            for ag in idle:
                cand = [w for w in waiting if w[1] in ag["skills"]]
                if not cand:
                    continue
                w = min(cand, key=lambda w: (int(queues[w[1]]["priority"]), w[2]))
                waiting.remove(w)
                aht = float(queues[w[1]]["aht_sec"]) - 30
                talk = int(random.lognormvariate(math.log(aht * 0.9), 0.45))
                c = calls[w[0]]
                c["answer_ts"], c["agent_id"] = t, ag["agent_id"]
                dirty_calls.add(w[0])
                # 연결되면 통화 텍스트(STT 결과라고 가정)를 분류해 기록한다
                pool = scripts[c["_topic"]]
                if app_down and c["_topic"] == "T6" and random.random() < 0.6:
                    pool = [r for r in pool if r["sentiment"] == "부정"] or pool
                tr = random.choice(pool)
                tp, se, text = classify.classify(tr["turns"], c["queue_id"])
                con.execute("INSERT OR REPLACE INTO call_text VALUES(?,?,?,?,?,?,?)",
                            (c["call_id"], t, c["queue_id"], c["_topic"], tp, se, text[:40]))
                ag["state"], ag["since"], ag["call"], ag["busy_until"] = "통화", t, w[0], t + max(20, talk)
            # 6) 1분마다 KPI 스냅숏 저장
            if t % 60 == 0:
                _flush(con, calls, dirty_calls, agents, t)
                k = kpi.compute(con, t)
                con.execute("INSERT OR REPLACE INTO kpi_history VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (t, k["sl"], k["asa"], k["abandon_rate"], k["waiting"], k["longest_wait"],
                             k["occupancy"], k["aht"], k["answered"], k["abandoned"]))
        _flush(con, calls, dirty_calls, agents, t)
        con.commit()
        time.sleep(tick_real)
    print("시뮬레이션 종료", kpi.fmt_ts(t))


def _flush(con, calls, dirty, agents, t):
    for cid in dirty:
        c = calls[cid]
        con.execute("INSERT OR REPLACE INTO calls VALUES(?,?,?,?,?,?,?,?)",
                    (c["call_id"], c["queue_id"], c["arrive_ts"], c["answer_ts"], c["talk_end_ts"],
                     c["acw_end_ts"], c["abandon_ts"], c["agent_id"]))
    dirty.clear()
    for g in agents.values():
        con.execute("UPDATE agents SET state=?, since_ts=?, call_id=? WHERE agent_id=?",
                    (g["state"], g["since"], g["call"], g["agent_id"]))
    con.execute("UPDATE clock SET v=? WHERE k='sim_ts'", (t,))


if __name__ == "__main__":
    main()
