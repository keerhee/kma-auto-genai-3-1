"""가상 상담 대본을 음성 파일로 만든다 (교육용 녹취 대용).

엔진 순서: edge-tts(인터넷 필요, 자연스러운 한국어 두 목소리) → macOS say(오프라인, Yuna)
→ Windows SAPI(오프라인, 한국어 음성 Heami). 화자마다 목소리를 달리하고 발화 사이에 0.4초 쉼을 넣는다.
결과: audio/<call_id>.wav (16kHz 모노 — STT 입력 표준)
실행: python tts_make.py --n 10 --source test
"""
import argparse, asyncio, json, os, platform, shutil, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
OUT = os.path.join(HERE, "audio")
VOICE = {"상담사": "ko-KR-SunHiNeural", "고객": "ko-KR-InJoonNeural"}


async def _edge(text, voice, path):
    import edge_tts
    await edge_tts.Communicate(text, voice).save(path)


def synth(text, speaker, path, engine):
    if engine == "edge":
        asyncio.run(_edge(text, VOICE[speaker], path))
    elif engine == "say":
        rate = "190" if speaker == "상담사" else "165"          # 같은 목소리라 속도로 구분한다
        subprocess.run(["say", "-v", "Yuna", "-r", rate, "-o", path, text], check=True)
    elif engine == "sapi":
        ps = ("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
              f"$s.SelectVoice('Microsoft Heami Desktop'); $s.Rate={0 if speaker == '상담사' else -2};"
              f"$s.SetOutputToWaveFile('{path}'); $s.Speak('{text}'); $s.Dispose()")
        subprocess.run(["powershell", "-Command", ps], check=True)


def pick_engine():
    try:
        import edge_tts  # noqa
        return "edge"
    except ImportError:
        pass
    if platform.system() == "Darwin":
        return "say"
    if platform.system() == "Windows":
        return "sapi"
    raise SystemExit("TTS 엔진이 없습니다. pip install edge-tts 를 먼저 실행하세요.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=10)
    ap.add_argument("--source", choices=["seed", "test"], default="test")
    ap.add_argument("--engine", choices=["auto", "edge", "say", "sapi"], default="auto")
    a = ap.parse_args()
    if not shutil.which("ffmpeg"):
        raise SystemExit("ffmpeg가 필요합니다. 맥은 brew install ffmpeg, 윈도는 winget install ffmpeg")
    engine = pick_engine() if a.engine == "auto" else a.engine
    ext = {"edge": ".mp3", "say": ".aiff", "sapi": ".wav"}[engine]
    os.makedirs(OUT, exist_ok=True)
    rows = [json.loads(l) for l in open(os.path.join(DATA, f"transcripts_{a.source}.jsonl"), encoding="utf-8")][: a.n]
    for r in rows:
        with tempfile.TemporaryDirectory() as tmp:
            parts = []
            for i, turn in enumerate(r["turns"]):
                p = os.path.join(tmp, f"{i:02d}{ext}")
                synth(turn["text"], turn["speaker"], p, engine)
                parts.append(p)
            # 발화 사이 0.4초 쉼을 넣어 하나의 wav로 합친다
            inputs, filt = [], ""
            for i, p in enumerate(parts):
                inputs += ["-i", p]
                filt += f"[{i}:a]aresample=16000,aformat=channel_layouts=mono,apad=pad_dur=0.4[a{i}];"
            filt += "".join(f"[a{i}]" for i in range(len(parts))) + f"concat=n={len(parts)}:v=0:a=1[out]"
            out = os.path.join(OUT, f"{r['call_id']}.wav")
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex", filt,
                            "-map", "[out]", "-ar", "16000", "-ac", "1", out], check=True)
        print("저장", out)
    print(f"엔진 {engine}, {len(rows)}건 완료")


if __name__ == "__main__":
    main()
