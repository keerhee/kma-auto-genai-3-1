# 실시간 관제 시스템 — 레퍼런스 구현 확장판 (강사용, STEP 0~18)

수강생이 단계별 프롬프트로 만든 결과와 비교하거나, 막혔을 때 확인용으로 쓴다.
`data/`와 `docs/`는 수강생 키트와 같은 것을 한 단계 위 폴더에 둔다.

| 파일 | 역할 |
|---|---|
| simulator.py | 가상 콜 이벤트 생성 → live.db |
| kpi.py | 매뉴얼 2장 KPI 계산 |
| alerts.py, thresholds.json | 매뉴얼 3장 임계치와 3분 지속 경보 |
| erlang.py | Erlang C 필요 인원 |
| ai_summary.py | claude -p 로 관제 요약 (실패하면 규칙 기반) |
| app.py | Streamlit 대시보드 |
| tests/test_kpi.py | 10콜 손계산 검증 |
| textproc.py | 개인정보 마스킹, 고객 발화 추출, 문자 오류율(CER) |
| classify.py | 주제·감정 규칙 분류기 (v1 키워드, v2 표현 추가) — 실행하면 seed/test 정확도 |
| cause.py | 인입 원인 지표와 원인 경보 (매뉴얼 4.7) |
| tts_make.py | 대본 → 녹취 wav (edge-tts, 맥 say, 윈도 SAPI) |
| stt_eval.py | faster-whisper STT → 마스킹 → CER → 분류 |
| tests/test_ext.py | 마스킹, CER, 분류기 test 정확도 검증 |

실행: `pip install streamlit pandas altair` 후 `./run.sh` (윈도는 `run.bat`).
속도 바꾸기: `SPEED=60 ./run.sh`. 테스트: `python -m pytest -q tests`.

확장편 추가 패키지: `pip install edge-tts faster-whisper` (ffmpeg 필요). 시나리오 버튼에 "앱 장애"가 추가된다.
※ tts_make.py와 stt_eval.py는 인터넷과 모델 내려받기가 필요해 제작 환경에서 실행 검증을 하지 못했다. 처음 한 번 강사가 직접 돌려 보길 권한다.
