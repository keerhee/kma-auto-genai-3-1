"""확장편 검증: 마스킹, CER 손계산, 분류기 test 정확도 하한"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import classify, textproc


def test_mask():
    t = textproc.mask_pii("카드 번호는 9410 2385 7716 0423이에요. 제 번호는 010-4821-7730이에요. 1985년 3월 12일")
    assert "9410" not in t and "4821" not in t and "1985" not in t


def test_cer():
    assert round(textproc.cer("결제일을 바꾸고 싶어요", "결재일을 바꾸고 시퍼요"), 2) == 0.30


def test_classifier_on_test_set():
    acc = classify.evaluate(os.path.join(classify.DATA, "transcripts_test.jsonl"))[0]
    assert acc >= 0.85
