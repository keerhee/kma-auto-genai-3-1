"""STT(음성 인식) → 개인정보 마스킹 → 문자 오류율(CER) → 주제·감정 분류.

faster-whisper(Whisper의 빠른 구현)를 노트북 CPU에서 돌린다. 처음 실행할 때 모델(small, 약 460MB)을 내려받는다.
정답 텍스트는 대본의 모든 발화를 이어 붙인 것이다. STT 결과에는 화자 구분이 없다는 점에 주의한다.
결과: stt_results.csv (call_id, CER, 주제 정답·예측, 감정 정답·예측, 마스킹된 STT 텍스트)
실행: python stt_eval.py --model small
"""
import argparse, csv, glob, json, os

import classify, textproc

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="small", help="tiny / base / small / medium")
    a = ap.parse_args()
    from faster_whisper import WhisperModel
    model = WhisperModel(a.model, device="cpu", compute_type="int8")

    truth = {}
    for name in ("transcripts_seed.jsonl", "transcripts_test.jsonl"):
        for l in open(os.path.join(DATA, name), encoding="utf-8"):
            r = json.loads(l); truth[r["call_id"]] = r

    out = []
    for wav in sorted(glob.glob(os.path.join(HERE, "audio", "*.wav"))):
        cid = os.path.splitext(os.path.basename(wav))[0]
        segs, _ = model.transcribe(wav, language="ko", beam_size=5)
        hyp = " ".join(s.text.strip() for s in segs)
        r = truth[cid]
        ref = " ".join(t["text"] for t in r["turns"])
        masked = textproc.mask_pii(hyp)
        tp = classify.topic_of(masked, r["queue_id"])
        se = classify.sentiment_of(masked)
        out.append(dict(call_id=cid, cer=round(textproc.cer(ref, hyp), 3), topic_true=r["topic_id"], topic_pred=tp,
                        sent_true=r["sentiment"], sent_pred=se, stt_text=masked))
        print(cid, f"CER {out[-1]['cer']:.1%}", tp, se)
    with open(os.path.join(HERE, "stt_results.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=out[0].keys()); w.writeheader(); w.writerows(out)
    n = len(out)
    print(f"평균 CER {sum(o['cer'] for o in out)/n:.1%}, 주제 정확도 {sum(o['topic_true']==o['topic_pred'] for o in out)/n:.0%}, "
          f"감정 정확도 {sum(o['sent_true']==o['sent_pred'] for o in out)/n:.0%} (n={n})")


if __name__ == "__main__":
    main()
