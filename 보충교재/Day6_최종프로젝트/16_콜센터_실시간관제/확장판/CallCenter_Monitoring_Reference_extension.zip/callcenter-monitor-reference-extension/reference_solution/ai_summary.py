"""AI 관제 요약 — 현재 KPI·경보 스냅숏과 관제 매뉴얼 4장(대응 절차)을 묶어
Claude Code 헤드리스 모드(claude -p)에 보내고, 관제사용 3줄 요약과 조치 권고를 받는다.
API 키가 필요 없다(Claude 구독으로 로그인한 Claude Code를 그대로 쓴다).
claude 명령이 없거나 실패하면 규칙 기반 요약으로 대신한다."""
import json, os, re, shutil, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
MANUAL = os.path.join(HERE, "..", "docs", "monitoring_manual.md")


def manual_section4():
    txt = open(MANUAL, encoding="utf-8").read()
    m = re.search(r"## 4\..*?(?=\n## 5\.)", txt, re.S)
    return m.group(0) if m else txt[:4000]


def build_prompt(snapshot):
    return (
        "너는 카드사 고객센터의 실시간 관제 보조자다. 아래 [현재 상황]과 [대응 절차]만 근거로 답한다.\n"
        "출력 형식:\n1) 상황 요약 3줄 이내\n2) 지금 할 조치 최대 3개 — 각 조치 끝에 근거 절차 번호(예: 4.2)를 괄호로 단다\n"
        "3) 15분 뒤 다시 볼 지표 1개\n4) 원인 경보가 있으면 고객 공지 문안 초안 2문장(4.7-3)\n추측이나 매뉴얼에 없는 조치는 쓰지 않는다.\n\n"
        f"[현재 상황]\n{json.dumps(snapshot, ensure_ascii=False, indent=1)}\n\n[대응 절차]\n{manual_section4()}"
    )


def rule_based(snapshot):
    lines = [f"{snapshot['시각']} 기준 서비스레벨 {snapshot['서비스레벨']}, 대기 {snapshot['대기 콜']}건, 포기율 {snapshot['포기율']}."]
    for a in snapshot["경보"]:
        lines.append(f"- [{a['level']}] {a['label']} {a['value']} → 매뉴얼 4장 해당 등급 절차를 따른다.")
    if not snapshot["경보"]:
        lines.append("- 지속 경보 없음. 정상 모니터링을 유지한다.")
    return "\n".join(lines) + "\n(규칙 기반 요약 — claude 명령을 쓸 수 없어 대신 표시함)"


def summarize(snapshot, timeout=90):
    if shutil.which("claude"):
        try:
            r = subprocess.run(["claude", "-p", build_prompt(snapshot)], capture_output=True,
                               text=True, timeout=timeout)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
        except Exception:
            pass
    return rule_based(snapshot)
