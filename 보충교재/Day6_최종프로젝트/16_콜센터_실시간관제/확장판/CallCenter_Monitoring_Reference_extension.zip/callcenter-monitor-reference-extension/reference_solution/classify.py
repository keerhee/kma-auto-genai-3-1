"""상담 주제·감정 분류기 (규칙 기반).
주제: data/call_topics.csv의 키워드를 고객 발화에서 찾아 점수가 가장 높은 주제를 고른다.
감정: 부정·긍정 표현 사전으로 판정한다. 둘 다 없으면 중립.
실행: python classify.py  → transcripts_seed.jsonl 정답 라벨과 비교한 정확도를 출력한다."""
import csv, json, os, re
from collections import Counter

import textproc

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")

with open(os.path.join(DATA, "call_topics.csv"), encoding="utf-8-sig") as f:
    TOPICS = {r["topic_id"]: r for r in csv.DictReader(f)}
RULES_V1 = {tid: [k for k in r["keywords"].split("|")] for tid, r in TOPICS.items()}
# v2: 오분류 사례를 보고 추가한 표현 (STEP 15에서 Claude Code가 제안 → 사람이 검토해 채택)
EXTRA = {
    "T1": ["없어졌", "어디 갔", "막아"],
    "T2": ["결제하는데", "카드를 내밀", "안 긁"],
    "T3": ["결재", "빠져나가", "금액이 맞는지", "납기"],
    "T4": ["쌓인", "깎아", "모은"],
    "T5": ["안 쓰려", "새로 받", "망가져", "그만 쓰"],
    "T6": ["어플", "튕겨", "들어가지지"],
    "T7": ["늘리", "늘려", "쓸 수 있는 금액"],
    "T8": ["빌릴", "빌린", "빌리"],
}
RULES_V2 = {tid: RULES_V1[tid] + EXTRA.get(tid, []) for tid in RULES_V1}
RULES = RULES_V2

NEG = ["짜증", "화가", "몇 번째", "오래 기다", "책임지", "불편해서", "답답", "말이 됩니까"]
POS = ["감사", "고맙", "다행", "덕분"]


def topic_of(text, queue_id=None, rules=None):
    rules = rules or RULES
    if queue_id:
        cands = [t for t in rules if TOPICS[t]["queue_id"] == queue_id]
        if len(cands) == 1:
            return cands[0]               # 주제가 하나뿐인 큐(분실·도난)는 바로 정한다
    scores = Counter()
    for tid, kws in rules.items():
        if queue_id and TOPICS[tid]["queue_id"] != queue_id:
            continue                      # 큐가 정해져 있으면 그 큐의 주제만 후보로 둔다
        for k in kws:
            scores[tid] += len(re.findall(re.escape(k), text))
    if not scores or max(scores.values()) == 0:
        return "기타"
    return scores.most_common(1)[0][0]


def sentiment_of(text):
    neg = sum(text.count(w) for w in NEG)
    pos = sum(text.count(w) for w in POS)
    return "부정" if neg > pos else "긍정" if pos > neg else "중립"


def classify(turns, queue_id=None, rules=None):
    text = textproc.mask_pii(textproc.customer_text(turns))
    return topic_of(text, queue_id, rules), sentiment_of(text), text


def evaluate(path=os.path.join(DATA, "transcripts_seed.jsonl"), use_queue=True, rules=None):
    rows = [json.loads(l) for l in open(path, encoding="utf-8")]
    conf = Counter()
    ok_t = ok_s = 0
    for r in rows:
        t, s, _ = classify(r["turns"], r["queue_id"] if use_queue else None, rules)
        ok_t += t == r["topic_id"]; ok_s += s == r["sentiment"]
        conf[(r["topic_id"], t)] += 1
    return ok_t / len(rows), ok_s / len(rows), conf, len(rows)


if __name__ == "__main__":
    test = os.path.join(DATA, "transcripts_test.jsonl")
    for name, rules in (("v1 키워드만", RULES_V1), ("v2 표현 추가", RULES_V2)):
        a1, s1, conf, n1 = evaluate(rules=rules)
        a2, s2, _, n2 = evaluate(test, rules=rules)
        print(f"{name}: 주제 정확도 seed {a1:.1%} / test {a2:.1%}, 감정 seed {s1:.1%} / test {s2:.1%}")
    wrong = [(k, v) for k, v in conf.items() if k[0] != k[1]]
    print("v2 seed 오분류:", sorted(wrong, key=lambda x: -x[1]))
