"""인입 원인 지표 — 최근 30분 연결 콜의 주제 비중, 평소 대비 배수, 부정 감정 비율.
원인 경보는 매뉴얼 4.7과 thresholds.json의 cause 기준을 따르고, 3분 연속 유지될 때만 올린다."""
import csv, json, os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
CFG = json.load(open(os.path.join(HERE, "thresholds.json"), encoding="utf-8"))["cause"]
WINDOW = 1800

with open(os.path.join(DATA, "call_topics.csv"), encoding="utf-8-sig") as f:
    TOPICS = {r["topic_id"]: r for r in csv.DictReader(f)}
NAME = {t: r["topic_name"] for t, r in TOPICS.items()}


def baseline_share():
    """평소 비중 = 큐별 하루 예측 인입 × 큐 안 주제 비중을 전체로 나눈 값"""
    vol = Counter()
    with open(os.path.join(DATA, "forecast_30min.csv"), encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            vol[r["queue_id"]] += int(r["forecast_calls"])
    raw = {t: vol[r["queue_id"]] * float(r["share_in_queue"]) for t, r in TOPICS.items()}
    tot = sum(raw.values())
    return {t: v / tot for t, v in raw.items()}


BASE = baseline_share()


def shares(con, now):
    rows = con.execute("SELECT topic_pred, sentiment FROM call_text WHERE ts BETWEEN ? AND ?",
                       (now - WINDOW, now)).fetchall()
    n = len(rows)
    cnt = Counter(r[0] for r in rows)
    neg = sum(1 for r in rows if r[1] == "부정")
    out = []
    for t in TOPICS:
        sh = cnt[t] / n if n else 0
        out.append(dict(topic=t, name=NAME[t], count=cnt[t], share=sh, base=BASE[t],
                        ratio=sh / BASE[t] if BASE[t] else 0))
    return dict(n=n, topics=out, other=cnt["기타"], neg_rate=neg / n if n else None)


def _levels(s):
    lv = {}
    for x in s["topics"]:
        if x["count"] >= CFG["min_calls"]:
            if x["ratio"] >= CFG["spike_red"]:
                lv[x["name"] + " 급증"] = ("red", f'평소의 {x["ratio"]:.1f}배 ({x["count"]}건)')
            elif x["ratio"] >= CFG["spike_yellow"]:
                lv[x["name"] + " 급증"] = ("yellow", f'평소의 {x["ratio"]:.1f}배 ({x["count"]}건)')
    if s["neg_rate"] is not None and s["n"] >= CFG["min_calls"]:
        if s["neg_rate"] > CFG["neg_red"]:
            lv["부정 감정"] = ("red", f'{s["neg_rate"]:.0%}')
        elif s["neg_rate"] > CFG["neg_yellow"]:
            lv["부정 감정"] = ("yellow", f'{s["neg_rate"]:.0%}')
    return lv


def alerts(con, now, persist=3):
    """최근 persist분 동안 계속 황색 이상인 원인 경보만 돌려준다."""
    snaps = [_levels(shares(con, now - 60 * k)) for k in range(persist)]
    out = []
    for key, (lv, val) in snaps[0].items():
        if all(key in s for s in snaps):
            worst = "red" if all(s[key][0] == "red" for s in snaps) else "yellow"
            out.append(dict(label=key, level=worst, value=val))
    return out
