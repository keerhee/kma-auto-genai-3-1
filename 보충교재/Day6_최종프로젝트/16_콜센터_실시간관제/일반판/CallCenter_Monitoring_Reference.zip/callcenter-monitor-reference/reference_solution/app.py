"""하늘카드 고객센터 실시간 관제 대시보드 (Streamlit).
실행: streamlit run app.py   (simulator.py를 먼저 켜 둔다)"""
import csv, os, sqlite3

import altair as alt
import pandas as pd
import streamlit as st

import ai_summary, alerts, erlang, kpi

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "live.db")
COLOR = {"green": "#2E9E6B", "yellow": "#E0A100", "red": "#D64545"}
STATE_COLOR = {"대기": "#2E9E6B", "통화": "#2E5BAA", "후처리": "#7FA3D8", "휴식": "#B8BCC6",
               "장애 이탈": "#D64545", "오프라인": "#E4E6EB"}

st.set_page_config(page_title="실시간 관제", layout="wide")
st.markdown("""<style>
.block-container{padding-top:2.6rem;padding-bottom:0.5rem}
.tile{border-radius:10px;padding:10px 14px;color:#fff}
.tile .l{font-size:15px;opacity:.9}.tile .v{font-size:34px;font-weight:700;line-height:1.15}
.ag{display:inline-block;width:92px;margin:3px;padding:6px 4px;border-radius:6px;text-align:center;font-size:13px;color:#fff}
.ag.off{color:#6B7280}
</style>""", unsafe_allow_html=True)


def con():
    c = sqlite3.connect(DB, timeout=5)
    c.row_factory = sqlite3.Row
    return c


forecast = {}
with open(os.path.join(HERE, "..", "data", "forecast_30min.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        forecast[(r["interval_start"], r["queue_id"])] = int(r["forecast_calls"])

# ---- 사이드바: 시나리오 주입 ----
with st.sidebar:
    st.header("시나리오 주입")
    st.caption("교육용 가상 상황을 시뮬레이터에 보낸다.")
    for name in ["정상", "인입 급증", "상담사 이탈"]:
        if st.button(name, use_container_width=True):
            c = con(); c.execute("UPDATE clock SET v=? WHERE k='command'", (name,)); c.commit()
    st.divider()
    ai_btn = st.button("AI 관제 요약 받기", type="primary", use_container_width=True)


@st.fragment(run_every="2s")
def board():
    if not os.path.exists(DB):
        st.warning("live.db가 없습니다. 먼저 simulator.py를 실행하세요.")
        return
    c = con()
    now = int(c.execute("SELECT v FROM clock WHERE k='sim_ts'").fetchone()[0])
    scen = c.execute("SELECT v FROM clock WHERE k='scenario'").fetchone()[0]
    k = kpi.compute(c, now)
    hist = [dict(r) for r in c.execute("SELECT * FROM kpi_history ORDER BY ts DESC LIMIT 10")][::-1]
    act = alerts.evaluate(hist)

    st.markdown(f"### 하늘카드 고객센터 실시간 관제 &nbsp; `가상 시각 {kpi.fmt_ts(now)}` &nbsp; 시나리오: **{scen}**")

    # ① KPI 타일
    cols = st.columns(6)
    for col, m in zip(cols, ["sl", "asa", "abandon_rate", "waiting", "longest_wait", "occupancy"]):
        lv = alerts.level(m, k[m])
        col.markdown(f"<div class='tile' style='background:{COLOR[lv]}'><div class='l'>{alerts.CFG['metrics'][m]['label']}</div>"
                     f"<div class='v'>{alerts.fmt(m, k[m])}</div></div>", unsafe_allow_html=True)

    left, right = st.columns([1.35, 1])
    # ② 큐별 현황
    with left:
        st.markdown("**큐별 현황** (최근 30분)")
        rows = []
        for qid, q in kpi.QUEUES.items():
            qk = kpi.compute(c, now, qid)
            rows.append({"큐": q["queue_name"], "대기": qk["waiting"], "최장 대기(초)": qk["longest_wait"],
                         "SL": alerts.fmt("sl", qk["sl"]), f"SL 목표": f"{float(q['sl_target'])*100:.0f}/{q['sl_seconds']}",
                         "포기율": alerts.fmt("abandon_rate", qk["abandon_rate"])})
        st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    # ③ 경보
    with right:
        st.markdown("**지속 경보** (3분 이상 유지된 것만)")
        if act:
            for a in act:
                st.markdown(f"<span style='color:{COLOR[a['level']]};font-weight:700'>● {a['level'].upper()}</span> "
                            f"{a['label']} {a['value']}", unsafe_allow_html=True)
        else:
            st.success("지속 경보 없음")

    # ④ 상담사 상태판
    st.markdown("**상담사 상태판**")
    html = ""
    for r in c.execute("SELECT agent_id, agent_name, state, since_ts FROM agents ORDER BY agent_id"):
        bg = STATE_COLOR.get(r["state"], "#999")
        cls = "ag off" if r["state"] == "오프라인" else "ag"
        mins = max(0, (now - r["since_ts"]) // 60)
        html += f"<span class='{cls}' style='background:{bg}'>{r['agent_name']}<br>{r['state']} {mins}분</span>"
    st.markdown(html, unsafe_allow_html=True)

    g1, g2 = st.columns([1.6, 1])
    # ⑤ 인입 실적 vs 예측
    with g1:
        acts = kpi.interval_actuals(c)
        df = []
        for (iv, q), fc in forecast.items():
            df.append({"구간": iv, "구분": "예측", "콜": fc, "큐": q})
            if (iv, q) in acts:
                df.append({"구간": iv, "구분": "실적", "콜": acts[(iv, q)], "큐": q})
        d = pd.DataFrame(df).groupby(["구간", "구분"], as_index=False)["콜"].sum()
        ch = alt.Chart(d).mark_line(point=True).encode(
            x=alt.X("구간:N", title="30분 구간"), y=alt.Y("콜:Q", title="인입 콜"),
            color=alt.Color("구분:N", scale=alt.Scale(domain=["예측", "실적"], range=["#9AA3B2", "#1B2C5E"])),
            strokeDash=alt.condition("datum.구분 == '예측'", alt.value([5, 4]), alt.value([0])))
        st.markdown("**30분 구간 인입: 예측과 실적**")
        st.altair_chart(ch.properties(height=230), use_container_width=True)
    # ⑥ 인력 산정
    with g2:
        st.markdown("**Erlang C 인력 산정** (현재 구간)")
        iv = kpi.fmt_ts(now // 1800 * 1800)[:5]
        elapsed = max(60, now % 1800)
        arrived = sum(v for (i, q), v in kpi.interval_actuals(c).items() if i == iv)
        pace = arrived * 1800 / elapsed                 # 지금 속도로 30분을 채우면
        fc = sum(v for (i, q), v in forecast.items() if i == iv)
        aht = k["aht"] or 250
        need_fc = erlang.required_agents(fc, 1800, aht, 20, 0.80)
        need_now = erlang.required_agents(pace, 1800, aht, 20, 0.80)
        st.metric("예측 기준 필요 인원", f"{need_fc}명")
        st.metric("현재 인입 속도 기준 필요 인원", f"{need_now}명")
        gap = k["staffed"] - need_now
        st.metric("가용 인원과의 차이", f"{k['staffed']}명 가용", delta=f"{gap:+d}명", delta_color="normal")
    st.session_state["snapshot"] = {
        "시각": kpi.fmt_ts(now), "시나리오": scen, "서비스레벨": alerts.fmt("sl", k["sl"]),
        "평균 응답속도": alerts.fmt("asa", k["asa"]), "포기율": alerts.fmt("abandon_rate", k["abandon_rate"]),
        "대기 콜": k["waiting"], "최장 대기(초)": k["longest_wait"], "점유율": alerts.fmt("occupancy", k["occupancy"]),
        "가용 상담사": k["staffed"], "상태별 인원": k["states"], "경보": act,
        "현재 구간 인입 예측": fc, "현재 구간 인입 속도 환산": round(pace), "Erlang C 필요 인원": need_now}


board()
if ai_btn and "snapshot" in st.session_state:
    with st.spinner("Claude가 상황을 정리하는 중…"):
        st.session_state["ai"] = ai_summary.summarize(st.session_state["snapshot"])
if "ai" in st.session_state:
    st.info(st.session_state["ai"])
