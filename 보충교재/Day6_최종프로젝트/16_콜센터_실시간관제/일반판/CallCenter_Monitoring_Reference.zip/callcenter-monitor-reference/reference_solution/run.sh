#!/bin/bash
# 시뮬레이터와 대시보드를 한 번에 켠다 (맥·리눅스). 끝낼 때는 Ctrl+C.
cd "$(dirname "$0")"
pkill -f "python.*simulator.py" 2>/dev/null
python3 simulator.py --speed ${SPEED:-20} &
SIM=$!
trap "kill $SIM 2>/dev/null" EXIT
sleep 2
streamlit run app.py
