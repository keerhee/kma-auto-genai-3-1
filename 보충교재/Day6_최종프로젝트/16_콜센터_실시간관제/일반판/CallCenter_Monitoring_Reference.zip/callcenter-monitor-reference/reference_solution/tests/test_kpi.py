"""손계산 검증: data/check_10calls.csv (일반 문의, 기준 20초)
손계산 정답 — SL 5/10 = 50.0%, ASA 123/7 = 17.6초, 포기율 3/10 = 30.0%"""
import csv, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kpi

rows = list(csv.DictReader(open(os.path.join(os.path.dirname(__file__), "..", "..", "data", "check_10calls.csv"), encoding="utf-8")))
ans = [(r["queue_id"], int(r["wait_sec"])) for r in rows if r["outcome"] == "응대"]
abd = [r["queue_id"] for r in rows if r["outcome"] == "포기"]
m = kpi._metrics(ans, abd, lambda q: int(kpi.QUEUES[q]["sl_seconds"]))


def test_sl():
    assert round(m["sl"] * 100, 1) == 50.0


def test_asa():
    assert round(m["asa"], 1) == 17.6


def test_abandon():
    assert round(m["abandon_rate"] * 100, 1) == 30.0
