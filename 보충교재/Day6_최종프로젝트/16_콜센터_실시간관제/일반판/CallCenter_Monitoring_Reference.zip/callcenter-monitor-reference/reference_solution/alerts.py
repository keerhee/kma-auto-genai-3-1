"""경보 규칙 — thresholds.json의 색 기준을 적용하고, 같은 등급이 3분 이상
이어질 때만 경보를 낸다(순간 튐으로 경보가 깜박이는 것을 막는다)."""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(HERE, "thresholds.json"), encoding="utf-8"))
ORDER = {"green": 0, "yellow": 1, "red": 2}


def level(metric, value):
    if value is None:
        return "green"
    c = CFG["metrics"][metric]
    if c["direction"] == "high":
        return "red" if value < c["red"] else "yellow" if value < c["yellow"] else "green"
    return "red" if value > c["red"] else "yellow" if value > c["yellow"] else "green"


def fmt(metric, value):
    if value is None:
        return "-"
    u = CFG["metrics"][metric]["unit"]
    return f"{value*100:.1f}%" if u == "%" else f"{value:.0f}{u}"


def evaluate(history_rows):
    """history_rows: kpi_history 최근 행들(오래된 것 → 최신). 지속 경보 목록 반환."""
    n = CFG["persist_minutes"]
    if len(history_rows) < n:
        return []
    recent = history_rows[-n:]
    out = []
    for m in CFG["metrics"]:
        lv = [level(m, r[m]) for r in recent]
        worst_common = min(lv, key=lambda x: ORDER[x])   # n분 내내 유지된 등급
        if worst_common != "green":
            out.append(dict(metric=m, label=CFG["metrics"][m]["label"], level=worst_common,
                            value=fmt(m, recent[-1][m]), ts=recent[-1]["ts"]))
    return out
