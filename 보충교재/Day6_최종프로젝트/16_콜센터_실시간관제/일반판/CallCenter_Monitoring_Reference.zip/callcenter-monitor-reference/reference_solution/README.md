# 실시간 관제 시스템 — 레퍼런스 구현 (강사용)

수강생이 단계별 프롬프트로 만든 결과와 비교하거나, 막혔을 때 확인용으로 쓴다.
`data/`와 `docs/`는 수강생 키트와 같은 것을 한 단계 위 폴더에 둔다.

| 파일 | 역할 |
|---|---|
| simulator.py | 가상 콜 이벤트 생성 → live.db |
| kpi.py | 매뉴얼 2장 KPI 계산 |
| alerts.py, thresholds.json | 매뉴얼 3장 임계치와 3분 지속 경보 |
| erlang.py | Erlang C 필요 인원 |
| ai_summary.py | claude -p 로 관제 요약 (실패하면 규칙 기반) |
| app.py | Streamlit 대시보드 |
| tests/test_kpi.py | 10콜 손계산 검증 |

실행: `pip install streamlit pandas altair` 후 `./run.sh` (윈도는 `run.bat`).
속도 바꾸기: `SPEED=60 ./run.sh`. 테스트: `python -m pytest -q tests`.
