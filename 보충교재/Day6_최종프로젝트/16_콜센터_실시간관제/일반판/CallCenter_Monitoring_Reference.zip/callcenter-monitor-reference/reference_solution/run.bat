@echo off
rem 시뮬레이터와 대시보드를 한 번에 켠다 (윈도). 끝낼 때는 두 창을 모두 닫는다.
cd /d %~dp0
start "simulator" python simulator.py --speed 20
timeout /t 2 > nul
streamlit run app.py
