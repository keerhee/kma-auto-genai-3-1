"""관제 KPI 계산 — 정의는 docs/monitoring_manual.md 2장을 그대로 따른다.

구간 기준: 최근 30분(가상 시각) 동안 '결과가 난' 콜(응대 또는 포기).
"""
import csv, os

WINDOW = 1800
HERE = os.path.dirname(os.path.abspath(__file__))


def load_queues():
    with open(os.path.join(HERE, "..", "data", "queues.csv"), encoding="utf-8-sig") as f:
        return {q["queue_id"]: q for q in csv.DictReader(f)}


QUEUES = load_queues()


def fmt_ts(t):
    t = int(t)
    return f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}"


def _metrics(answered, abandoned, sl_sec_of):
    """answered: [(queue_id, wait)] / abandoned: [queue_id]"""
    offered = len(answered) + len(abandoned)
    within = sum(1 for q, w in answered if w <= sl_sec_of(q))
    return dict(
        sl=within / offered if offered else None,
        asa=sum(w for _, w in answered) / len(answered) if answered else None,
        abandon_rate=len(abandoned) / offered if offered else None,
        answered=len(answered), abandoned=len(abandoned),
    )


def compute(con, now, queue_id=None):
    """now 시점의 실시간 KPI 사전."""
    lo = now - WINDOW
    qf, args = ("AND queue_id=?", (queue_id,)) if queue_id else ("", ())
    ans = con.execute(f"SELECT queue_id, answer_ts-arrive_ts FROM calls WHERE answer_ts BETWEEN ? AND ? {qf}",
                      (lo, now) + args).fetchall()
    abd = [r[0] for r in con.execute(f"SELECT queue_id FROM calls WHERE abandon_ts BETWEEN ? AND ? {qf}",
                                     (lo, now) + args)]
    m = _metrics(ans, abd, lambda q: int(QUEUES[q]["sl_seconds"]))
    wait = con.execute(f"SELECT COUNT(*), MIN(arrive_ts) FROM calls WHERE answer_ts IS NULL AND abandon_ts IS NULL {qf}",
                       args).fetchone()
    m["waiting"] = wait[0]
    m["longest_wait"] = int(now - wait[1]) if wait[1] is not None else 0
    h = con.execute(f"SELECT AVG(acw_end_ts-answer_ts) FROM calls WHERE acw_end_ts BETWEEN ? AND ? {qf}",
                    (lo, now) + args).fetchone()[0]
    m["aht"] = h
    st = dict(con.execute("SELECT state, COUNT(*) FROM agents GROUP BY state").fetchall())
    busy = st.get("통화", 0) + st.get("후처리", 0)
    avail = busy + st.get("대기", 0)
    m["occupancy"] = busy / avail if avail else None
    m["staffed"] = avail
    m["states"] = st
    return m


def interval_actuals(con):
    """30분 구간별 실제 인입 수 {('10:00','Q2'): 87, ...}"""
    out = {}
    for t, q, c in con.execute("SELECT arrive_ts/1800*1800, queue_id, COUNT(*) FROM calls GROUP BY 1,2"):
        out[(fmt_ts(t)[:5], q)] = c
    return out
