"""Erlang C 인력 산정 — 필요 상담사 수를 계산한다."""
import math


def erlang_c(traffic: float, agents: int) -> float:
    """대기 확률 P(대기>0). traffic = 부하(얼랑) = 인입률 × 평균처리시간."""
    if agents <= traffic:
        return 1.0
    # 수치 안정을 위해 점화식으로 계산
    inv_b = 1.0
    for k in range(1, agents + 1):
        inv_b = 1.0 + inv_b * k / traffic
    b = 1.0 / inv_b                                   # Erlang B
    return b / (1 - (traffic / agents) * (1 - b))     # Erlang C


def service_level(traffic: float, agents: int, target_sec: float, aht_sec: float) -> float:
    """기준시간 이내 응대 비율 예측."""
    if agents <= traffic:
        return 0.0
    pw = erlang_c(traffic, agents)
    return 1 - pw * math.exp(-(agents - traffic) * target_sec / aht_sec)


def required_agents(calls: float, interval_sec: float, aht_sec: float,
                    target_sec: float, sl_target: float, max_agents: int = 200) -> int:
    """구간 인입량(calls)에서 SL 목표를 맞추는 최소 상담사 수."""
    traffic = calls * aht_sec / interval_sec
    n = max(1, math.ceil(traffic))
    while n < max_agents and service_level(traffic, n, target_sec, aht_sec) < sl_target:
        n += 1
    return n


if __name__ == "__main__":
    # 손계산 확인용: 30분 160콜, AHT 280초 → 부하 24.9얼랑
    for n in range(25, 33):
        print(n, round(service_level(160 * 280 / 1800, n, 20, 280), 3))
    print("필요 인원:", required_agents(160, 1800, 280, 20, 0.80))
