# 단계별 프롬프트 (복사용)

모든 프롬프트는 Claude 데스크톱 앱 Code 탭의 입력창에 붙여 넣습니다. 대괄호 [ ]는 본인 값으로 바꿉니다. 키와 비밀번호는 절대 입력창에 넣지 않습니다.

사람이 직접 하는 일은 세 가지뿐입니다: 앱 설치, Supabase 가입, 로그인 명령 한 줄(Code 탭 터미널 창, Ctrl+`)과 브라우저 승인.

## 0-3 · 실습 키트 풀기

```text
다운로드 폴더의 AJU_TestDrive_LabKit_II.zip을
현재 폴더에 풀어 주세요. 기존 파일은 덮어쓰지 마세요.
README.md를 읽고 폴더 구조를 표로 보여 주세요.

node, npm, git 버전을 확인하세요.
없거나 너무 오래된 것이 있으면 winget으로 직접
설치하고, 설치 후 다시 확인해 결과를 알려 주세요.
앱 코드는 아직 만들지 마세요.
```

## 1 · 프로젝트 규칙 만들기

```text
docs/requirements.md와 data 폴더를 읽으세요.
이를 기준으로 CLAUDE.md와 docs/plan.md를 만드세요.
앱 코드는 아직 작성하지 마세요.

CLAUDE.md에 넣을 작업 규칙:
- 한 단계씩 구현하고, 끝나면 직접 실행해 확인한 뒤
  내가 눈으로 볼 항목을 알려 주고 멈춘다
- 비밀값을 대화, 로그, Git에 출력하지 않는다
- 실행하지 않은 검사를 통과했다고 쓰지 않는다
- 단계가 끝날 때마다 Git 커밋을 남긴다

plan.md에는 고객 여정, 관리자 여정, 데이터 구조,
단계별 완료 조건을 넣으세요.
Git 저장소가 없으면 git init 후 첫 커밋을 하세요.
```

## 2 · 고객 예약 화면 (mock)

```text
plan.md의 2단계를 진행하세요.
현재 폴더에 Next.js(App Router, TypeScript,
Tailwind) 프로젝트를 만들되 docs와 data는 보존하세요.
DB 없이 data 폴더의 CSV와 JSON을 mock으로 씁니다.

화면은 requirements.md 3장을 따르세요.
assets/images를 public/images로 복사하고
models.csv의 image_file로 차종 카드에 연결하세요.
상단에 'DEMO · 실제로 저장되지 않음' 띠를 붙이세요.

끝나면 개발 서버를 켜고 앱의 미리보기 브라우저에
띄워 주세요. 여기서 멈추세요.
```

## 2 피드백 · 모바일 화면 점검

```text
Playwright로 360px 폭에서 / 와 /reserve의
다섯 단계를 차례로 진행하며 스크린샷을 찍어
docs/screens에 저장하고 열어 주세요.
가로 스크롤이나 잘린 글자가 있으면 고치세요.
```

## 2 피드백 · 발견한 문제 고치기 (예시)

```text
뒤로 갔다가 돌아오면 선택한 날짜가 사라집니다.
선택값이 유지되게 고치고, 같은 흐름을 직접
다시 실행해 결과를 알려 주세요.
```

## 3-3 · Supabase 프로젝트 만들기와 연결

```text
Supabase CLI(npx supabase)로 개발용 프로젝트를
만들고 이 앱에 연결하세요.
- orgs list로 내 조직 ID를 확인하세요
- 프로젝트 이름 aju-testdrive-dev, 리전 서울
  (ap-northeast-2)
- DB 비밀번호는 강력하게 생성해 .env.local에만 저장
- 프로젝트가 준비되면 API 키를 조회해 .env.local에
  URL, publishable key, secret key, APP_URL을 기록
- 키와 비밀번호는 대화에 절대 출력하지 마세요

공식 Next.js SSR 문서 방식대로 브라우저용과 서버용
클라이언트를 나누고, secret key 모듈은 server-only로.
.env.example과 .gitignore를 만들고 .env.local이
Git에서 빠졌는지 확인하세요.
끝나면 대시보드 주소와 채워진 항목 이름만 알려 주세요.
```

## 4 · DB 만들기

```text
requirements.md 4장과 5장을 따라
supabase/migrations에 SQL을 만드세요.
seed는 data 폴더의 CSV로 만들고, 다시 실행해도
중복되지 않게 하세요.

적용 전에 SQL의 보안과 중복 예약 방어를
스스로 검토하고 결과를 짧게 보고하세요.

.env.local의 DB_PASSWORD를 값 출력 없이 써서
Supabase CLI로 개발 DB에 연결(link)하고 적용하세요.
적용 후 테이블별 행 수를 표로 보여 주세요.
테이블을 지우는 SQL로 오류를 해결하지 마세요.
```

## 4 피드백 · 적용 오류가 날 때

```text
migration 적용 중 아래 오류가 났습니다.
원인을 먼저 설명하고 필요한 SQL만 고쳐 다시
적용하세요. DROP이나 RLS 해제로 풀지 마세요.
[오류 문구 붙여넣기 — 키 값은 지우고]
```

## 5 · 실제 예약 저장

```text
고객 예약 화면을 Supabase에 연결하세요.
requirements.md 6장의 규칙을 모두 지키세요.
- 슬롯 조회와 예약 생성은 서버 API로만 처리
- 예약 생성은 4단계의 DB 트랜잭션 함수를 호출
- 중복 클릭 방지와 idempotency key 적용
- DB 장애 때 성공 화면을 보이지 않음
- rate limit은 rate_limits 테이블로 구현
- 동의 문구는 docs/privacy_consent_draft.md 사용

DEMO 띠는 개발 DB 연결이 확인되면 떼세요.
끝나면 test_customers.csv의 01번 고객으로 직접
예약 1건을 넣고, 저장된 행을 이름과 번호를
가린 채 보여 주세요.
```

## 6 · 관리자 화면과 직원 계정

```text
관리자 로그인과 /admin 화면을 만드세요.
requirements.md 7장을 따르고, 공개 가입 화면은
만들지 마세요.

직원 계정 staff@example.com을 Supabase Auth 관리
API로 만들고(이메일 확인 완료 상태), 그 UUID를
admin_users에 등록하세요.
임시 비밀번호는 무작위로 만들어 staff-login.local.txt
에만 저장하고 Git에서 빼세요. 대화에 출력하지 마세요.

끝나면 로그아웃 상태와 일반 계정으로 /admin과
관리자 API를 직접 호출해 거절되는지 보여 주고,
staff-login.local.txt를 메모장으로 열어 주세요.
```

## 7 · 깨뜨려 보기 (테스트)

```text
docs/test_scenarios.md의 14개 시나리오를
자동 테스트로 작성하고 실행하세요.
개발 DB의 테스트 데이터만 쓰고, 끝나면 지우세요.
브라우저 흐름은 Playwright로 확인하세요.

lint, typecheck, build도 실행하세요.
결과는 docs/test-report.md에 통과, 실패, 미실행으로
기록하세요. 실패는 고친 뒤 그 항목만 다시 실행하고,
미실행을 통과로 적지 마세요.
```

## 8-1 · GitHub에 올리기

```text
이 프로젝트를 GitHub 비공개 저장소
aju-testdrive에 올리세요.
먼저 .env.local, 키, 고객정보, DB 덤프가 Git에
추적되지 않는지 검사하세요.
gh CLI가 없으면 설치하세요. 로그인이 필요하면
앱의 터미널 창에 내가 칠 명령 한 줄만 알려 주세요.
커밋하고 push한 뒤 저장소 주소를 알려 주세요.
```

## 8-2 · Vercel 미리보기 배포

```text
npx vercel로 미리보기 배포를 하세요.
로그인이 필요하면 앱의 터미널 창에 내가 칠
명령 한 줄만 알려 주세요.
.env.local의 앱용 변수 4개만 값 출력 없이 Vercel에
등록하세요. DB 비밀번호와 staff-login 파일은
올리지 마세요. 미리보기는 개발 DB에 연결합니다.

배포 주소가 나오면 Supabase Auth의 Site URL과
Redirect URL을 CLI로 반영하고, 안 되면 대시보드에서
넣을 위치와 값을 알려 주세요.
배포 주소에서 예약 1건과 관리자 로그인을
Playwright로 확인하고 결과를 보여 주세요.
```

## 9 · 기존 사이트 버튼 연결

```text
(기존 사이트 원본 폴더를 Code 탭에서 열고 실행)
이 프로젝트의 프레임워크와 라우팅부터 확인하세요.
'시승 예약' 버튼과 모바일 메뉴를 아래 주소로
연결하세요: [8단계에서 확인한 배포 주소]
현재 화면 스타일을 유지하고, 상대주소 /reserve로
임의 연결하지 마세요.
바뀐 파일과 확인 방법을 알려 주세요.
```

## 문제 해결 · 빨간 오류가 났을 때

```text
다음 오류를 해결하세요. 원인을 먼저 설명하고
필요한 파일만 고치세요. 패키지 전체 업데이트나
DB 삭제는 하지 마세요. 고친 뒤 같은 명령으로
다시 확인하세요.
[키와 개인정보를 지운 오류 문구]
```

## 문제 해결 · 화면이 예전 그대로일 때

```text
지금 켜진 개발 서버의 폴더와 포트를 확인하세요.
내가 보는 주소와 수정한 프로젝트가 같은지
점검하고, 필요하면 서버를 다시 켜 주세요.
```

## 문제 해결 · 예약 저장이 실패할 때

```text
예약 저장 실패를 진단하세요. 환경변수는 있는지만
보고 값은 출력하지 마세요. migration, 서버 API,
함수 권한, RLS, 제약조건 순서로 확인하세요.
RLS를 끄거나 anon에 권한을 주지 마세요.
```

## 문제 해결 · 새 세션에서 이어 갈 때

```text
CLAUDE.md, docs/plan.md, docs/test-report.md와
Git 상태를 읽고 끝난 단계와 남은 단계를
구분해 요약하세요. 기존 구현을 보존하면서
다음 미완료 단계부터 이어 가세요.
```

