# 아주 오토모티브 시승 예약 시스템 — 요구사항 명세 (교육용)

이 문서는 Claude Code가 읽고 따르는 기준 문서다. 프롬프트가 "requirements.md N장"을 가리키면 이 문서의 해당 장을 뜻한다.
값은 모두 교육용 가정이다. 실제 운영시간·시승차 보유·개인정보 문구는 운영 담당자가 확정한다.

## 1. 목표와 범위

고객이 차종 → 전시장 → 날짜와 시간 → 연락처와 동의 → 최종 확인 순서로 시승을 신청하고, 직원은 관리자 화면에서 접수 건을 확정·취소·방문 완료로 처리한다.

- 완성 범위: 고객 예약, 슬롯별 수용량 관리, 관리자 로그인, 상태 변경, 모바일 화면, 오류 처리, 배포
- 제외 범위: 휴대폰 인증, 문자·알림톡 발송, 고객 직접 취소, CRM 연동
- 제외 기능이 동작하는 것처럼 보이는 문구("인증 완료", "문자 발송 완료")를 화면에 쓰지 않는다
- 기존 사이트(https://aju-automotive.ai.studio/)는 시각 참고용이다. 별도 예약 앱을 만들고 마지막에 기존 사이트의 '시승 예약' 버튼을 이 앱 주소로 연결한다

## 2. 운영 규칙

| 항목 | 값 |
|---|---|
| 차종 | `data/models.csv` — 폴스타 3, 폴스타 4, 폴스타 5 |
| 전시장 | `data/locations.csv` — 교육용 전시장 A 1곳. 실제 주소·전화번호를 지어내지 않는다 |
| 시승차 | `data/vehicles.csv` — 차종마다 1대 |
| 운영시간 | 10:00~18:00, 1시간 슬롯, 마지막 시작 17:00 (하루 8슬롯) |
| 수용량 | 시승차 1대당 한 슬롯에 예약 1건 |
| 예약 가능 기간 | 서울 기준 내일부터 30일 뒤까지 |
| 시간대 | 화면은 Asia/Seoul, DB는 timestamptz |
| 최초 상태 | pending(접수). 직원이 확인하면 confirmed(확정) |
| 슬롯을 점유하는 상태 | pending, confirmed |
| 슬롯을 점유하지 않는 상태 | cancelled, completed, no_show |
| 상태 전이 | `data/status_transitions.csv` |
| 고객 입력 | 이름, 휴대폰, 필수 동의. 메모·마케팅 동의는 선택 |
| 수집 금지 | 주민등록번호, 운전면허증 사진, 면허번호 |

세부 수치는 `data/booking_rules.json`에 있다. 코드는 이 파일의 값을 상수로 읽어 쓴다.

## 3. 화면

| 경로 | 내용 |
|---|---|
| `/` | 시승 소개, 차종 카드 3개(이미지·이름·차체 유형), '시승 예약' 버튼 |
| `/reserve` | 5단계 마법사: ① 차종 ② 전시장 ③ 날짜와 시간 ④ 고객정보와 동의 ⑤ 최종 확인 |
| `/reserve/success` | 예약번호, 접수 상태, 일정만 표시. 개인정보를 URL에 넣지 않는다 |
| `/admin/login` | 직원 로그인 (공개 가입 없음) |
| `/admin` | 오늘 예약, 필터, 목록, 상세, 상태 변경 |

- 이전 단계로 돌아가도 선택값이 유지된다. 상위 선택이 바뀌면 무효가 된 하위 선택은 초기화한다
- 예약된 슬롯과 지난 시간은 선택할 수 없다
- 접수 완료 문구: "예약이 접수되었습니다. 담당자 확인 후 확정 안내드립니다."
- mock 단계에서는 화면 상단에 "DEMO · 실제로 저장되지 않음" 띠를 표시한다
- 360px 폭에서 가로 스크롤이 없어야 한다. 모든 입력에 label을 연결한다

## 4. 데이터

| 테이블 | 핵심 컬럼 |
|---|---|
| models | code, name_ko, name_en, body_type, image_file, active, sort_order |
| locations | code, name, timezone, active |
| vehicles | code, model_id, location_id, label, active |
| slots | vehicle_id, starts_at, ends_at, is_blocked |
| reservations | slot_id, customer_name, customer_phone, status, memo, consent_version, consented_at, marketing_opt_in, idempotency_key, request_hash, created_at |
| reservation_events | reservation_id, actor_id, from_status, to_status, created_at |
| admin_users | user_id(auth.users), role, created_at |
| rate_limits | bucket_key, window_start, count |

- seed는 `data/` 의 CSV에서 만든다. 다시 실행해도 중복되지 않게(upsert) 한다
- slots는 차량별로 서울 기준 내일~30일 뒤, 매일 10~17시 정각 시작 1시간 블록을 만든다. 함수로 만들어 매일 다시 실행해도 안전하게 한다
- (vehicle_id, starts_at) unique, ends_at > starts_at check
- 직원이 임의 시간의 슬롯을 만들 수 없다

## 5. 중복 예약 방지

- reservations에 `status in ('pending','confirmed')` 조건의 partial unique index를 slot_id에 건다. 화면에서 회색 처리하는 것은 보조 수단일 뿐이다
- 예약 생성은 DB 트랜잭션 함수 하나로 처리한다: 슬롯 행 잠금(for update) → 차량·차종·전시장 활성 여부, 차단 여부, 예약 기간, 미래 시각 재검증 → insert
- 함수 실행 권한은 서버 역할에만 준다. public, anon, authenticated 권한은 회수한다
- security definer를 쓰면 search_path를 고정하고 객체명을 schema까지 적는다
- 같은 idempotency key와 같은 내용의 재전송은 기존 예약을 돌려준다. 같은 키에 다른 내용이면 거절한다
- unique 충돌은 개인정보 없이 "방금 예약된 시간입니다. 다른 시간을 선택해주세요."로 응답한다

## 6. 예약 API

- 공개 슬롯 조회 API는 개인정보 없는 필드(slot_id, starts_at, 예약 가능 여부)만 돌려준다
- 예약 생성 API는 서버에서 입력을 다시 검증한다. 클라이언트가 보낸 차종·전시장·차량 관계와 날짜를 믿지 않는다
- 서버 전용 secret key는 server-only 모듈에서만 읽는다
- 버튼 중복 클릭 방지, 처리 중 표시, 요청별 idempotency key. 실패 후 재시도는 같은 키, 내용이 바뀌면 새 키
- 응답은 예약번호, 상태, 일정만. 예약번호만으로 남의 예약을 조회하는 API는 만들지 않는다
- DB 장애나 설정 누락 시 성공 화면을 보이지 않는다. 운영 환경에서 mock으로 대체하지 않는다
- rate limit은 DB의 rate_limits 테이블로 구현한다(서버 메모리 Map 금지). 값은 booking_rules.json
- 동의 버전과 서버 접수 시각을 저장한다
- 고객정보와 비밀값을 로그에 남기지 않는다

## 7. 관리자

- Supabase Auth 이메일·비밀번호 로그인. 직원 계정은 Auth 관리 API(서버 전용 키)로 만들고, 임시 비밀번호는 staff-login.local.txt에만 저장한다. 공개 가입은 없다
- 서버에서 사용자를 검증하고 admin_users로 권한을 확인한다. getSession 결과나 localStorage의 role만 믿지 않는다
- 관리자 페이지, 목록 API, 상태 변경 API 각각에서 권한을 검사한다. 쿠키 기반 쓰기 요청은 origin을 검사한다
- 화면: 오늘 예약, 날짜·차종·상태 필터, 목록, 상세, 상태 변경 버튼
- 이름·휴대폰은 목록에서 마스킹(홍*동, 010-****-0001)하고 상세에서만 전체를 보인다. 전체 다운로드 기능은 만들지 않는다
- 상태 전이는 `data/status_transitions.csv`만 허용한다. completed, no_show는 슬롯 종료 후에만
- 상태 변경은 트랜잭션에서 권한과 현재 상태를 다시 확인하고 reservation_events에 기록한다
- 슬롯 차단도 같은 슬롯 잠금을 쓰고 활성 예약이 있으면 거절한다
- 관리자·개인정보 응답은 캐시하지 않는다

## 8. 보안과 개인정보

- 모든 테이블에 RLS를 켠다. 공개 사용자는 reservations, admin_users, reservation_events, rate_limits를 읽거나 쓸 수 없다
- 로그인한 사용자 누구나 관리자가 되는 정책, 사용자가 자기 권한을 추가하는 경로를 만들지 않는다
- 동의 문구는 `docs/privacy_consent_draft.md`를 쓴다. 보유기간이 확정되기 전에는 운영 배포를 막는다
- `.env.local`, `staff-login.local.txt`, 키, 실제 고객정보, DB 덤프는 Git에 올리지 않는다

## 9. 디자인

- 흰색 바탕, 검정 글자, 오렌지 포인트(#FF7A00 계열 한 색), 모바일 우선
- 차종 이미지는 `public/images`의 실제 파일만 쓴다. 다른 브랜드 사진을 폴스타로 표시하지 않는다. 외부 이미지를 임의로 가져오지 않는다
- 공식 판매 자격, 제휴, 실제 전시장 정보를 지어내지 않는다

## 10. 단계별 완료 조건

| 단계 | 완료 조건 |
|---|---|
| 1 규칙 | CLAUDE.md, docs/plan.md 존재 |
| 2 화면 | mock으로 5단계 흐름 끝까지 진행, 360px 스크린샷 확인 |
| 3 연결 | Supabase 프로젝트 생성, .env.local 5개 값 채워짐, Git 추적 제외 확인 |
| 4 DB | 테이블 8개, 차종 3, 차량 3, 슬롯 약 720행 |
| 5 저장 | 예약 1건이 DB에 남고 새로고침 후 유지 |
| 6 관리자 | 직원 로그인, 확정·취소 가능, 비로그인 접근 거절 |
| 7 테스트 | docs/test-report.md에 14개 시나리오 결과 기록 |
| 8 배포 | 미리보기 주소에서 예약과 관리자 로그인 확인 |
