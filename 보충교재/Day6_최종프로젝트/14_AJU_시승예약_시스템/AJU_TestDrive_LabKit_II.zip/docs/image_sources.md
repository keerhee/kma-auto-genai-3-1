# 이미지 목록과 출처

| 파일 | 차종 | 원본 위치 |
|---|---|---|
| polestar-3.jpg | 폴스타 3 | aju-automotive.ai.studio/assets/polestar_3_suv_*.jpg |
| polestar-4.jpg | 폴스타 4 | aju-automotive.ai.studio/assets/polestar_4_white_*.jpg |
| polestar-4-studio.jpg | 폴스타 4 | aju-automotive.ai.studio/assets/regenerated_image_*.avif (JPG로 변환) |
| polestar-5-front.jpg | 폴스타 5 | polestar.com dato-assets 01-polestar-5 hero |
| polestar-5-rear.jpg | 폴스타 5 | polestar.com dato-assets 02-polestar-5 intro |
| polestar-5-track.jpg | 폴스타 5 | polestar.com dato-assets 06-polestar-5 goodwood |

- 교육용 실습에서만 쓴다. 외부 공개 운영 전에는 사용 권한을 확인한다
- 사이트에 함께 쓰인 다른 브랜드 일반 차량 사진(Unsplash)은 시승 차종이 아니므로 키트에서 뺐다
