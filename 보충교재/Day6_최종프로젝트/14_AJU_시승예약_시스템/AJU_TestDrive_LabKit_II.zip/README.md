# AJU TestDrive Lab Kit II

Claude Code로 시승 예약 시스템을 만드는 실습 키트입니다. 이 폴더의 압축을 프로젝트 폴더에 풀고, `prompts/PROMPTS_KR.md`의 프롬프트를 순서대로 Claude 데스크톱 앱의 Code 탭 입력창에 붙여 넣습니다.

| 폴더 | 내용 |
|---|---|
| docs/requirements.md | Claude Code가 따르는 요구사항 명세 (1~10장) |
| docs/test_scenarios.md | 7단계 테스트 시나리오 14개 |
| docs/privacy_consent_draft.md | 교육용 동의 문구 초안 |
| docs/acceptance_checklist.md | 최종 완료 체크 |
| docs/image_sources.md | 이미지 출처 |
| data/models.csv | 차종 3개 (폴스타 3·4·5) |
| data/locations.csv | 교육용 전시장 A |
| data/vehicles.csv | 시승차 3대 |
| data/booking_rules.json | 운영시간, 예약 기간, 상태, 문구, rate limit |
| data/status_transitions.csv | 허용 상태 전이 |
| data/test_customers.csv | 가짜 테스트 고객 10명 (실제 번호 아님) |
| assets/images | 차종 이미지 6장 |
| prompts/PROMPTS_KR.md | 단계별 복사용 프롬프트 |

테스트 번호 010-0000-XXXX는 실제 발송에 쓰지 않습니다.
