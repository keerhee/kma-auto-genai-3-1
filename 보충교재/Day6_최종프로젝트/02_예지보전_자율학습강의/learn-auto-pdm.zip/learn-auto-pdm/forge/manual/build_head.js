setSubject("Day5 예지보전 · learn-auto-pdm"); let SB = "kma-day5-pdm";
PLACE.cc = { name: "Code 탭 입력칸", hint: "Claude 데스크톱 앱 Code 탭 아래쪽 칸 — 붙여 넣고 Enter", color: C.blue };
// 진도 표시 (6장면 중 현재 위치)
const SCENES = ["시작", "설명", "실행", "완료", "확인·퀴즈", "다음"];
function progress(s, x, y, w, cur) {
  const n = SCENES.length, gw = w / n;
  SCENES.forEach((t, i) => {
    const on = i === cur, past = i < cur;
    rect(s, x + i * gw + 0.02, y, gw - 0.04, 0.50, on ? C.navy : past ? C.panelBlue : "F3F4F6");
    s.addText((i + 1) + " " + t, { x: x + i * gw, y, w: gw, h: 0.50, align: "center", valign: "middle", fontFace: F, fontSize: 13, bold: on, color: on ? C.white : past ? C.navy : C.muted });
  });
}

// 수업 체험 장면 슬라이드: 좌 앱 화면 / 우 설명 패널
function scene(o) {
  const s = np();
  const cy = head(s, "수업 체험 " + (o.n + 1) + "/6", 2.1, o.title, o.sub, pg());
  progress(s, LX, cy, CW, o.n);
  const top = cy + 0.64, bot = 6.94, aw = 7.15;
  appScreen(s, LX, top, aw, bot - top, o.msgs);
  const rx = LX + aw + 0.24, rw = CW - aw - 0.24;
  const th = bot - top - 1.30;
  panel(s, rx, top, rw, th, C.panelBlue, C.blue, "지금 일어나는 일", o.what, { fs: 16, valign: "top" });
  rect(s, rx, top + th + 0.14, rw, 1.16, P.fill, { color: P.acc, width: 1.25 });
  rect(s, rx, top + th + 0.14, rw, 0.40, P.acc);
  s.addText("내가 할 일", { x: rx + 0.16, y: top + th + 0.14, w: rw - 0.3, h: 0.40, valign: "middle", fontFace: F, fontSize: 16, bold: true, color: C.white });
  s.addText(o.todo, { x: rx + 0.18, y: top + th + 0.58, w: rw - 0.36, h: 0.68, valign: "top", fontFace: F, fontSize: 17, bold: true, color: P.ink });
}

// 화면 신호 카드(작은 모형 + 뜻 + 할 일)
function signalCell(s, x, y, w, h, title, drawMock, mean, todo) {
  rect(s, x, y, w, h, C.white, { color: C.hair, width: 1 });
  rect(s, x, y, w, 0.46, C.navy);
  s.addText(title, { x: x + 0.16, y, w: w - 0.3, h: 0.46, valign: "middle", fontFace: F, fontSize: 17, bold: true, color: C.white });
  const mw = 2.95;
  drawMock(x + 0.16, y + 0.62, mw, h - 0.78);
  s.addText([
    { text: "뜻", options: { bold: true, color: C.blue, breakLine: true } },
    { text: mean, options: { color: C.body, breakLine: true, paraSpaceAfter: 6 } },
    { text: "내가 할 일", options: { bold: true, color: P.acc, breakLine: true } },
    { text: todo, options: { color: C.navy, bold: true } },
  ], { x: x + mw + 0.32, y: y + 0.58, w: w - mw - 0.44, h: h - 0.70, valign: "top", fontFace: F, fontSize: 16, lineSpacingMultiple: 1.05 });
}
