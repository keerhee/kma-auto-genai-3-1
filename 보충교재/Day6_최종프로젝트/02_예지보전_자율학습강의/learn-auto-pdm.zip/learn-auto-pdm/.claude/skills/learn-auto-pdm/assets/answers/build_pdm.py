"""learn-auto-pdm 정답 예시 — Day5 예지보전 실습을 한 번에 실행하고 대시보드를 만든다.

실행: python build_pdm.py   (작업 폴더 안에서 — data/ 아래에 Day5 실습 파일 4개가 있어야 한다)
출력: outputs/ 아래 csv·md, 작업 폴더에 index.html (GitHub Pages 첫 화면)
그리고 현재 폴더에 expected.json (course-forge 검증용)

원본 강의: keerhee/kma-auto-genai-3-1 · Day5_예지보전 (본 강의 6단계, 보강 실습 B)
"""
import json
from pathlib import Path

import pandas as pd

DATA = Path("data")
OUT = Path("outputs")
COLS = ["진동(mm/s)", "온도(℃)", "압력(bar)"]
BASE_N = 12      # 기준선: 처음 12점(08:00~11:40) — 정상 운전 구간
K_SIGMA = 3      # 추세 판정: 기준선 평균 + 3σ
RUN = 3          # 3번 연속 넘으면 추세
CUT_RATE = 0.25  # 예지보전으로 줄일 수 있는 정지손실 비율 (추정)


def read(name):
    return pd.read_csv(DATA / name, encoding="utf-8-sig")


# ── Block 1: 단위 점검 ─────────────────────────────────────────────
def unit_check():
    raw = read("Day5_설비센서_단위혼재_함정_가상.csv")
    rules = [  # (열, 조건, 원래 단위, 변환식)
        ("온도(℃)", lambda v: v > 100, "℉", lambda v: (v - 32) * 5 / 9),
        ("진동(mm/s)", lambda v: v < 0.1, "in/s", lambda v: v * 25.4),
        ("압력(bar)", lambda v: v > 1000, "psi", lambda v: v * 0.0689476),
    ]
    log, clean = [], raw.copy()
    for col, cond, unit, conv in rules:
        for i in clean.index[clean[col].apply(cond)]:
            before = clean.at[i, col]
            clean.at[i, col] = round(conv(before), 2)
            log.append({"시간": raw.at[i, "시간"], "설비": raw.at[i, "설비"], "항목": col, "기록값": before,
                        "원래 단위": unit, "변환값": clean.at[i, col], "기록장치": raw.at[i, "기록장치"]})
    log = pd.DataFrame(log)
    log.to_csv(OUT / "unit_fix_log.csv", index=False, encoding="utf-8-sig")
    clean.drop(columns=["기록장치"]).to_csv(OUT / "sensor_clean.csv", index=False, encoding="utf-8-sig")
    # 변환값이 정상 기록(50건 파일)과 얼마나 가까운지 — 상대 오차의 최댓값
    ref = read("Day5_설비센서_50건_가상.csv").set_index(["시간", "설비"])
    gap = max(abs(r["변환값"] - ref.loc[(r["시간"], r["설비"]), r["항목"]]) / ref.loc[(r["시간"], r["설비"]), r["항목"]]
              for r in log.to_dict("records"))
    return log, gap


# ── Block 2: 평상 범위(평균 ± 2σ) ──────────────────────────────────
def normal_range(df):
    rows, ranges = [], {}
    for eq, g in df.groupby("설비", sort=False):
        for c in COLS:
            m, s = g[c].mean(), g[c].std()
            lo, hi = m - 2 * s, m + 2 * s
            ranges[(eq, c)] = (m, s, lo, hi)
            for _, r in g[(g[c] < lo) | (g[c] > hi)].iterrows():
                rows.append({"시간": r["시간"], "설비": eq, "항목": c, "값": r[c],
                             "평상 범위": f"{lo:.2f}~{hi:.2f}"})
    cand = pd.DataFrame(rows)
    cand.to_csv(OUT / "anomaly_candidates.csv", index=False, encoding="utf-8-sig")
    return cand, ranges


# ── Block 3: 노이즈 vs 추세 ─────────────────────────────────────────
def trend(df):
    rows = []
    for eq, g in df.groupby("설비", sort=False):
        g = g.reset_index(drop=True)
        for c in COLS:
            b = g.iloc[:BASE_N][c]
            ul = b.mean() + K_SIGMA * b.std()
            over = (g[c] > ul).tolist()
            start, streak = None, 0
            for i, o in enumerate(over):
                streak = streak + 1 if o else 0
                if streak == RUN:
                    start = i - RUN + 1
                    break
            n_over = sum(over)
            kind = "추세" if start is not None else ("노이즈" if n_over else "정상")
            rows.append({"설비": eq, "항목": c, "기준선 상한": round(ul, 2), "상한 초과 점 수": n_over,
                         "판정": kind, "추세 시작": g.at[start, "시간"] if start is not None else ""})
    t = pd.DataFrame(rows)
    t.to_csv(OUT / "trend_judgement.csv", index=False, encoding="utf-8-sig")
    return t


# ── Block 4: 파일럿 선정 ────────────────────────────────────────────
def pilot():
    p = read("Day5_공정별_파일럿평가_가정값_가상.csv")
    loss = [c for c in p.columns if c.startswith("연간정지손실(")][0]
    p["배수"] = (p[loss] / p["센서·구축 초기투자(만원)"]).round(2)
    p["연간 절감 추정(만원)"] = (p[loss] * CUT_RATE).round(0)
    p["회수 기간(년)"] = (p["센서·구축 초기투자(만원)"] / p["연간 절감 추정(만원)"]).round(1)
    p = p.sort_values("배수", ascending=False).reset_index(drop=True)
    p["순위"] = p.index + 1
    out = p[["순위", "공정", "시간당정지손실(만원)", loss, "센서·구축 초기투자(만원)", "배수", "연간 절감 추정(만원)", "회수 기간(년)"]]
    out.to_csv(OUT / "pilot_ranking.csv", index=False, encoding="utf-8-sig")
    return out, loss


# ── Block 5: 대시보드 ───────────────────────────────────────────────
def dashboard(df, cand, ranges, tr, pil, loss, cases):
    series = {}
    for eq, g in df.groupby("설비", sort=False):
        series[eq] = {"t": [s[11:] for s in g["시간"]], **{c: g[c].tolist() for c in COLS}}
        series[eq]["ul"] = {c: float(tr[(tr["설비"] == eq) & (tr["항목"] == c)]["기준선 상한"].iloc[0]) for c in COLS}
        series[eq]["hi2"] = {c: round(ranges[(eq, c)][3], 2) for c in COLS}
    b_temp = tr[(tr["판정"] == "추세")].sort_values("추세 시작").iloc[0]
    first2 = cand.sort_values("시간")
    first2 = first2[first2["설비"].str.startswith("설비B")].iloc[0]["시간"]
    tr_rows = "".join(f"<tr><td>{r.설비}</td><td>{r.항목}</td><td>{r._3}</td><td>{r._4}</td><td class='{ 'warn' if r.판정 == '추세' else ''}'>{r.판정}</td><td>{r._6[11:] if r._6 else '—'}</td></tr>" for r in tr.itertuples())
    pil_rows = "".join(f"<tr><td>{r.순위}</td><td>{r.공정}</td><td>{r._3:,}</td><td>{r.배수:.2f}배</td><td>{int(r._7):,}</td><td>{r._8}</td></tr>" for r in pil.itertuples())
    case_rows = "".join(f"<tr><td>{r.기업}</td><td>{r._2}</td><td>{r._5}</td><td><a href='{r.출처URL}'>{r.발표연도}</a></td></tr>" for r in cases.itertuples())
    top = pil.iloc[0]
    html = f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>설비 예지보전 대시보드</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
body{{margin:0;font-family:-apple-system,'Malgun Gothic','Apple SD Gothic Neo',sans-serif;color:#1f2937;background:#f6f7fb}}
main{{max-width:980px;margin:0 auto;padding:16px}} h1{{font-size:1.5rem;margin:8px 0}} h2{{font-size:1.15rem;margin:24px 0 8px}}
.sum{{background:#1f2a5a;color:#fff;border-radius:10px;padding:14px 16px;line-height:1.6}}
.card{{background:#fff;border-radius:10px;padding:12px;margin:12px 0;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}}
table{{border-collapse:collapse;width:100%;font-size:.9rem}} th,td{{border-bottom:1px solid #e5e7eb;padding:6px;text-align:left}}
th{{background:#eef1f8}} .warn{{color:#b42318;font-weight:700}} .note{{font-size:.8rem;color:#6b7280}}
.scroll{{overflow-x:auto}} canvas{{max-width:100%}}
</style></head><body><main>
<h1>설비 예지보전 대시보드</h1>
<div class="sum">설비B(차체 용접로봇 감속기)는 <b>{b_temp['항목']}가 {b_temp['추세 시작'][11:]}부터</b> 추세적으로 상승했다 — 평균 ± 2σ로 처음 잡힌 {first2[11:]}보다 먼저다. 설비A의 진동 3.5는 한 번 튄 노이즈다. 파일럿 1순위는 <b>{top['공정']}</b>(연간 정지손실 ÷ 초기 투자 {top['배수']:.2f}배).</div>
<h2>센서 추세 — 설비B (차체 용접로봇 감속기)</h2>
<div class="grid"><div class="card"><canvas id="bv"></canvas></div><div class="card"><canvas id="bt"></canvas></div></div>
<h2>센서 추세 — 설비A (프레스 메인모터)</h2>
<div class="grid"><div class="card"><canvas id="av"></canvas></div><div class="card"><b>한 번의 튐은 노이즈</b><p>12:40에 3.5 mm/s로 튀었다가 13:00에 1.0으로 돌아왔다. 평균 ± 2σ로는 이상 후보지만, 기준선 상한을 연속으로 넘지 않아 정비 신호가 아니다. 측정 순간 외란일 수 있다(추정).</p><p class="note">대비: 설비B 온도는 13:00부터 상한을 10번 넘으며 계속 올랐다.</p></div></div>
<h2>노이즈 vs 추세 판정</h2>
<div class="card scroll"><table><tr><th>설비</th><th>항목</th><th>기준선 상한(평균+3σ)</th><th>상한 초과</th><th>판정</th><th>추세 시작</th></tr>{tr_rows}</table>
<p class="note">기준선 = 처음 12점(08:00~11:40). 상한을 3번 연속 넘으면 추세, 그 첫 점이 추세 시작(정비 권고 시점).</p></div>
<h2>예지보전 파일럿 선정</h2>
<div class="card scroll"><table><tr><th>순위</th><th>공정</th><th>시간당 정지손실(만원)</th><th>연간 정지손실 ÷ 초기 투자</th><th>연간 절감 추정(만원)</th><th>회수(년)</th></tr>{pil_rows}</table>
<p class="note">연간 절감 추정 = 연간 정지손실 × {int(CUT_RATE*100)}%(추정 감축률). 시간당 손실만 보면 조립이 1순위처럼 보이지만, 고장 빈도·정지 시간·투자를 함께 보면 프레스가 1순위다.</p></div>
<h2>국내외 도입 사례 (실데이터)</h2>
<div class="card scroll"><table><tr><th>기업</th><th>설비/공정</th><th>보고된 효과</th><th>출처</th></tr>{case_rows}</table></div>
<p class="note">센서·공정 값은 실습용 가상 데이터, 도입 사례는 기사·보도자료 원문 그대로다. 원본: <a href="https://github.com/keerhee/kma-auto-genai-3-1">kma-auto-genai-3-1</a> Day5 예지보전.</p>
</main>
<script>
const S={json.dumps(series, ensure_ascii=False)};
function line(id,eq,col,title){{
  const s=S[eq], n=s.t.length;
  new Chart(document.getElementById(id),{{type:'line',data:{{labels:s.t,datasets:[
    {{label:col,data:s[col],borderColor:'#1f4e9e',pointRadius:2,tension:0}},
    {{label:'기준선 상한(평균+3σ)',data:Array(n).fill(s.ul[col]),borderColor:'#d97706',borderDash:[6,4],pointRadius:0}},
    {{label:'평상 범위 상한(평균+2σ)',data:Array(n).fill(s.hi2[col]),borderColor:'#9ca3af',borderDash:[2,3],pointRadius:0}}]}},
    options:{{plugins:{{title:{{display:true,text:title}},legend:{{labels:{{boxWidth:12,font:{{size:11}}}}}}}},scales:{{x:{{ticks:{{maxTicksLimit:6}}}}}}}}}});
}}
const B=Object.keys(S)[1], A=Object.keys(S)[0];
line('bv',B,'{COLS[0]}','진동 (mm/s)'); line('bt',B,'{COLS[1]}','온도 (℃)'); line('av',A,'{COLS[0]}','진동 (mm/s) — 한 번의 튐');
</script></body></html>"""
    Path("index.html").write_text(html, encoding="utf-8")


# ── Block 6: 4단 보고서 ─────────────────────────────────────────────
def report(log, cand, tr, pil):
    top = pil.iloc[0]
    trend_rows = tr[tr["판정"] == "추세"]
    lines = [
        "# 설비 예지보전 진단 보고서 (실습용 가상 데이터)", "",
        "## ① 현황 진단",
        f"- 센서 기록 50건(설비 2대 × 25점, 2026-09-15 08:00~16:00). 단위가 다르게 기록된 {len(log)}칸을 ℃·mm/s·bar로 바꾼 뒤 분석했다.",
        f"- 평균 ± 2σ 이상 후보: 설비A {sum(cand['설비'].str.startswith('설비A'))}점, 설비B {sum(cand['설비'].str.startswith('설비B'))}점.", "",
        "## ② 이상 패턴과 원인 추정",
        "- 설비A 진동 3.5 mm/s는 한 번 튀고 정상으로 돌아온 노이즈다. 측정 순간 외란일 수 있다(추정).",
        *[f"- 설비B {r.항목}: {r._6[11:]}부터 기준선 상한을 연속으로 넘는 추세적 상승." for r in trend_rows.itertuples()],
        "- 감속기 온도가 먼저 오르고 진동이 뒤따른 흐름은 윤활 부족·베어링 마모의 전형적 순서다(추정 — 보전팀 확인 필요).", "",
        "## ③ 정비 권고 시점",
        f"- 설비B: 가장 이른 추세 시작 {trend_rows.sort_values('추세 시작').iloc[0]['추세 시작'][11:]} 기준으로 다음 휴무 정비 대신 당일 점검을 권고한다.", "",
        "## ④ 개선안",
        "- 판정 기준을 '한 점이 평상 범위를 벗어나면'에서 '기준선 상한을 3번 연속 넘으면'으로 바꿔 노이즈 경보를 줄이고 추세를 일찍 잡는다.",
        f"- 파일럿은 {top['공정']}부터(정지손실÷투자 {top['배수']:.2f}배, 감축률 {int(CUT_RATE*100)}% 가정 시 회수 {top['회수 기간(년)']}년).",
        "- 기록장치를 교체할 때는 단위 설정을 점검 목록에 넣는다.",
    ]
    (OUT / "pdm_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    OUT.mkdir(exist_ok=True)
    exp = {}
    log, gap = unit_check()
    exp["unit_fixed_cells"] = {"value": len(log), "decimals": 0, "block": 1}
    exp["fahrenheit_cells"] = {"value": int((log["원래 단위"] == "℉").sum()), "decimals": 0, "block": 1}
    exp["unit_fix_max_gap_pct"] = {"value": round(gap * 100, 1), "decimals": 1, "block": 1}

    df = read("Day5_설비센서_50건_가상.csv")
    cand, ranges = normal_range(df)
    exp["a_candidates"] = {"value": int(cand["설비"].str.startswith("설비A").sum()), "decimals": 0, "block": 2}
    exp["b_candidates"] = {"value": int(cand["설비"].str.startswith("설비B").sum()), "decimals": 0, "block": 2}
    a = ranges[(df["설비"].unique()[0], COLS[0])]
    exp["a_vib_upper_2s"] = {"value": round(a[3], 2), "decimals": 2, "block": 2}

    tr = trend(df)
    tb = tr[tr["판정"] == "추세"].sort_values("추세 시작")
    exp["trend_series"] = {"value": len(tb), "decimals": 0, "block": 3}
    exp["b_temp_trend_start"] = {"value": tb[tb["항목"] == COLS[1]]["추세 시작"].iloc[0][11:], "decimals": None, "block": 3}
    exp["b_vib_trend_start"] = {"value": tb[tb["항목"] == COLS[0]]["추세 시작"].iloc[0][11:], "decimals": None, "block": 3}
    first2 = pd.to_datetime(cand[cand["설비"].str.startswith("설비B")]["시간"]).min()
    lead = (first2 - pd.to_datetime(tb["추세 시작"].iloc[0])).total_seconds() / 60
    exp["lead_minutes"] = {"value": int(lead), "decimals": 0, "block": 3}

    pil, loss = pilot()
    exp["press_ratio"] = {"value": float(pil.iloc[0]["배수"]), "decimals": 2, "block": 4}
    exp["assembly_ratio"] = {"value": float(pil[pil["공정"] == "조립"]["배수"].iloc[0]), "decimals": 2, "block": 4}
    exp["press_saving_manwon"] = {"value": int(pil.iloc[0]["연간 절감 추정(만원)"]), "decimals": 0, "block": 4}
    exp["press_payback_years"] = {"value": float(pil.iloc[0]["회수 기간(년)"]), "decimals": 1, "block": 4}

    cases = read("Day5_예지보전_도입사례_실데이터.csv")
    dashboard(df, cand, ranges, tr, pil, loss, cases)
    exp["case_rows"] = {"value": len(cases), "decimals": 0, "block": 5}
    report(log, cand, tr, pil)

    Path("expected.json").write_text(json.dumps({"values": exp}, ensure_ascii=False, indent=1), encoding="utf-8")
    for k, v in exp.items():
        print(f"{k:24s} {v['value']}")


if __name__ == "__main__":
    main()
