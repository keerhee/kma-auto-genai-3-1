# 설비 예지보전 — 센서 신호로 고장을 미리 읽고 공개하기 · learn-auto-pdm

능률협회 「자동차산업과 생성형 AI 3-1」 Day5 예지보전을 course-forge로 옮긴 자율학습 강의다. 설비 센서 데이터의 단위를 점검하고, 평상 범위와 추세로 고장 징후를 읽고, 예지보전 파일럿 공정을 고르고, 결과 대시보드를 GitHub Pages로 공개해 동료와 공유한다. 수업은 Claude Code 스킬 `/learn-auto-pdm`가 진행한다(Skills as Curriculum).

- **결과 대시보드**: 이 저장소의 [index.html](index.html) (GitHub Pages로 공개하면 `https://<아이디>.github.io/learn-auto-pdm/`)
- 처음이면 [GUIDE.md](GUIDE.md)부터. 수업 화면용 매뉴얼은 [docs/PdM_Lab_Manual.pptx](docs/PdM_Lab_Manual.pptx)
- 기본 환경은 Claude 데스크톱 앱(Code 탭). VS Code는 GUIDE 부록 B

## 설치 — 한 줄

Claude Code 입력칸에 붙여 넣는다.

```
npx skills add <owner>/learn-auto-pdm --agent claude-code --global --yes 를 실행해 줘
```

새 세션에서 `/learn-auto-pdm`를 입력하면 수업이 시작된다. zip을 받았다면 GUIDE.md 2단계대로 설치한다.

## 블록 (약 3시간 20분)

| Block | 원본 단계 | 주제 | 끝나면 생기는 것 |
|---|---|---|---|
| 0 | ① 환경 | 준비 — 작업 폴더 · Day5 데이터 4종 · git | env_check.txt · CLAUDE.md |
| 1 | ② 데이터 | 단위 점검 — 기록장치 열이 단서 | 단위 6칸 변환 기록 |
| 2 | ③ 전처리 | 평상 범위 — 설비별 평균 ± 2σ | 이상 후보표 (설비A 1점 · 설비B 3점) |
| 3 | ④ 분석 1 | 노이즈 vs 추세 — 정비 권고 시점 | 판정표 (설비B 온도 13:00 · 진동 15:00 추세) |
| 4 | 보강 실습 B | 파일럿 선정 — 정지손실 ÷ 투자 | 공정 순위 (프레스 2.59배) · 순효과 추정 |
| 5 | ⑤ 분석 2 | 대시보드 공개 — GitHub Pages | 사이트 주소 |
| 6 | ⑥ 평가 | 보고서와 공유 | 4단 보고서 · README · 공유 메시지 · 과제 |

## 수업 방식

| 구분 | 내용 |
|---|---|
| 목표 — AI Native | AI에게 맡기는 것이 기본인 방식으로 일한다 |
| 방법 — Skills as Curriculum | 스킬이 블록마다 설명 → 실습 → 멈춤 → 확인·퀴즈를 진행한다 |
| 형식 — 자율학습 | 강사 없이 자기 속도로, 퀴즈로 스스로 점검한다 |

## 원본 강의와 데이터 출처

| 자료 | 출처 | 구분 |
|---|---|---|
| 강의 흐름 · 용어 · 실습과제 · 모범답안 | [keerhee/kma-auto-genai-3-1](https://github.com/keerhee/kma-auto-genai-3-1) `Day5_예지보전/` 본 강의 · 보강 실습 덱 | 원본 강의 |
| 설비센서 50건 · 단위 혼재 함정 · 공정별 파일럿 가정값 | 같은 저장소 `data/Day5/` | 실습용 가상 데이터 |
| 예지보전 도입 사례 6건 | 같은 저장소 `data/Day5/` — 행마다 기사·보도자료 원문 URL | 실데이터 (기준일 2026-10-07) |
| 정답 수치 대조 | 같은 저장소 `data/_강사용_정답메모.md` Day5 → [forge/qa/source_check.md](forge/qa/source_check.md) | 원본과 일치 |

센서·공정 값은 실제 기업·설비의 자료가 아니다.

## 개정 이력

| 날짜 | 바뀐 점 |
|---|---|
| 2026-10-23 | 첫 판 — course-forge v2로 Day5 예지보전에서 제작 |

## 만든 방법

- `/course-forge Day5 예지보전`으로 만들었다. 원본 요약·커리큘럼·검수 결과는 `forge/`에 있다.
- 원본과 다르게 정한 곳: 원본이 말로 정의한 "추세의 시작점"을 "기준선(처음 12점) 평균 + 3σ를 3번 연속 넘으면 추세"로 규칙화했다(이유는 source_check.md).
