/*
 * 기어리(GEARY) — AX 포트폴리오 공용 AI 안내원 (무료 구성)
 *
 * 답하는 방법 세 가지, 모두 무료:
 *   1) 규칙 답변  : 앱이 등록한 키워드(intents)에 맞으면 바로 답하고 화면을 움직인다. 키 불필요.
 *   2) Claude에게 : 질문 + 앱 화면 요약을 복사하고 claude.ai를 연다. 수강생 Pro 구독으로 답을 받는다.
 *   3) Gemini 키  : (선택) 방문자가 넣은 Gemini 무료 등급 API 키로 기어리가 직접 답한다.
 *                   키는 방문자 브라우저(localStorage)에만 저장되고 저장소에는 절대 들어가지 않는다.
 *
 * 사용법 (앱 HTML 맨 아래):
 *   <script src="../../shared/geary/geary.js"></script>
 *   <script>
 *     Geary.init({
 *       app: '앱 이름',
 *       greeting: '첫 인사',
 *       suggestions: ['이상 시점 보여줘', '설비A만'],
 *       context: () => '지금 화면의 핵심 숫자 요약(문자열)',
 *       intents: [
 *         { keys: ['이상', '경보'], say: '이상 시점을 표시했어요.', run: () => highlightAnomalies() },
 *       ],
 *     });
 *   </script>
 *
 * 규칙: 기어리는 intents에 등록된 함수만 실행한다. 임의 코드 실행은 하지 않는다.
 */
(function () {
  const LS_KEY = 'geary.gemini.key';
  const LS_MODEL = 'geary.gemini.model';
  const LS_VOICE = 'geary.voice';
  const store = {
    get(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } },
    set(k, v) { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} },
  };

  const ICON = `
<svg viewBox="0 0 64 64" width="44" height="44" aria-hidden="true">
  <rect x="12" y="16" width="40" height="32" rx="10" fill="#f2b632"/>
  <rect x="18" y="24" width="28" height="14" rx="7" fill="#13233a"/>
  <circle cx="26" cy="31" r="3.4" fill="#7ee0ff"/><circle cx="38" cy="31" r="3.4" fill="#7ee0ff"/>
  <rect x="29" y="8" width="6" height="8" rx="2" fill="#13233a"/><circle cx="32" cy="7" r="3.5" fill="#d9480f"/>
  <rect x="24" y="41" width="16" height="3" rx="1.5" fill="#13233a" opacity=".55"/>
  <path d="M52 34 l7 -7 a4 4 0 1 0 -4 -4 l-7 7" fill="none" stroke="#13233a" stroke-width="3" stroke-linecap="round"/>
</svg>`;

  const CSS = `
.geary-fab{position:fixed;right:16px;bottom:16px;z-index:9999;width:64px;height:64px;border-radius:50%;border:0;cursor:pointer;
  background:#13233a;box-shadow:0 6px 20px rgba(0,0,0,.25);display:grid;place-items:center}
.geary-fab:hover{transform:translateY(-2px)}
.geary-panel{position:fixed;right:16px;bottom:92px;z-index:9999;width:min(380px,calc(100vw - 32px));max-height:min(560px,calc(100vh - 120px));
  display:none;flex-direction:column;background:var(--surface,#fff);color:var(--ink,#14202e);border:1px solid var(--line,#dde2e8);
  border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.25);overflow:hidden;font-family:var(--font,system-ui)}
.geary-panel.open{display:flex}
.geary-head{display:flex;align-items:center;gap:10px;background:#13233a;color:#fff;padding:10px 12px}
.geary-head b{font-size:15px}.geary-head small{opacity:.75;font-size:12px;display:block}
.geary-head .sp{flex:1}
.geary-head button{background:transparent;border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:8px;padding:3px 8px;font-size:12px;cursor:pointer}
.geary-log{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;font-size:14px}
.geary-msg{padding:8px 11px;border-radius:12px;max-width:88%;white-space:pre-wrap;line-height:1.5}
.geary-msg.bot{background:rgba(242,182,50,.16);align-self:flex-start}
.geary-msg.me{background:#13233a;color:#fff;align-self:flex-end}
.geary-msg .act{margin-top:6px;display:flex;gap:6px;flex-wrap:wrap}
.geary-msg .act button{font:inherit;font-size:12px;border:1px solid var(--line,#dde2e8);background:var(--surface,#fff);color:inherit;border-radius:8px;padding:3px 8px;cursor:pointer}
.geary-sugs{display:flex;gap:6px;flex-wrap:wrap;padding:0 12px 8px}
.geary-sugs button{font:inherit;font-size:12px;border:1px solid var(--line,#dde2e8);background:transparent;color:inherit;border-radius:999px;padding:3px 10px;cursor:pointer}
.geary-in{display:flex;gap:6px;padding:10px;border-top:1px solid var(--line,#dde2e8)}
.geary-in input{flex:1;min-width:0;font:inherit;font-size:14px;padding:8px 10px;border-radius:10px;border:1px solid var(--line,#dde2e8);background:transparent;color:inherit}
.geary-in button{font:inherit;font-weight:700;border:0;border-radius:10px;padding:0 14px;background:#f2b632;color:#13233a;cursor:pointer}
.geary-in .mic{background:transparent;border:1px solid var(--line,#dde2e8);color:inherit;padding:0 10px;font-size:18px}
.geary-in .mic.on{background:#d9480f;color:#fff;border-color:#d9480f}
.geary-set{padding:12px;border-top:1px solid var(--line,#dde2e8);font-size:13px;display:none}
.geary-set.open{display:block}
.geary-set input{width:100%;font:inherit;font-size:13px;padding:6px 8px;margin:4px 0 8px;border-radius:8px;border:1px solid var(--line,#dde2e8);background:transparent;color:inherit}
.geary-set .row{display:flex;gap:6px}
.geary-set button{font:inherit;font-size:12px;border:1px solid var(--line,#dde2e8);background:transparent;color:inherit;border-radius:8px;padding:4px 10px;cursor:pointer}
`;

  const Geary = {
    cfg: null,

    init(cfg) {
      this.cfg = Object.assign({ app: '이 앱', greeting: '', suggestions: [], intents: [], context: () => '' }, cfg);
      const style = document.createElement('style');
      style.textContent = CSS;
      document.head.appendChild(style);

      const fab = document.createElement('button');
      fab.className = 'geary-fab';
      fab.title = '기어리에게 묻기';
      fab.innerHTML = ICON;

      const panel = document.createElement('div');
      panel.className = 'geary-panel';
      panel.innerHTML = `
        <div class="geary-head">${ICON.replace('width="44" height="44"', 'width="30" height="30"')}
          <div><b>기어리</b><small></small></div><span class="sp"></span>
          <button data-k="voice"></button><button data-k="set">설정</button></div>
        <div class="geary-log"></div>
        <div class="geary-sugs"></div>
        <div class="geary-set">
          <b>답변 방식 (모두 무료)</b>
          <p class="small" style="margin:6px 0">① 규칙 답변: 키 없이 동작 ② Claude에게 묻기: 질문을 복사해 claude.ai를 엽니다 ③ Gemini 무료 키: 기어리가 직접 답합니다(선택).</p>
          Gemini API 키 (이 브라우저에만 저장)
          <input type="password" data-k="key" placeholder="AIza… (비워 두면 ①② 방식)">
          모델 이름
          <input type="text" data-k="model" placeholder="gemini-2.5-flash">
          <div class="row"><button data-k="save">저장</button><button data-k="clear">키 삭제</button></div>
        </div>
        <form class="geary-in"><button type="button" class="mic" title="말로 묻기" aria-label="말로 묻기">🎤</button><input placeholder="무엇이든 물어보세요" aria-label="질문"><button>보내기</button></form>`;
      panel.querySelector('.geary-head small').textContent = this.cfg.app;
      document.body.append(fab, panel);

      this.$ = {
        panel, log: panel.querySelector('.geary-log'), sugs: panel.querySelector('.geary-sugs'),
        set: panel.querySelector('.geary-set'), input: panel.querySelector('.geary-in input'),
        voice: panel.querySelector('[data-k=voice]'), key: panel.querySelector('[data-k=key]'),
        model: panel.querySelector('[data-k=model]'),
      };
      this.$.key.value = store.get(LS_KEY);
      this.$.model.value = store.get(LS_MODEL);
      this.voiceOn = store.get(LS_VOICE) === 'on';
      this._voiceLabel();

      fab.onclick = () => {
        panel.classList.toggle('open');
        if (panel.classList.contains('open') && !this.$.log.children.length) {
          this.say(this.cfg.greeting || `안녕하세요, 기어리예요. ${this.cfg.app}에 대해 물어보세요.`);
        }
      };
      panel.querySelector('[data-k=set]').onclick = () => this.$.set.classList.toggle('open');
      this.$.voice.onclick = () => { this.voiceOn = !this.voiceOn; store.set(LS_VOICE, this.voiceOn ? 'on' : ''); this._voiceLabel(); };
      panel.querySelector('[data-k=save]').onclick = () => {
        store.set(LS_KEY, this.$.key.value.trim()); store.set(LS_MODEL, this.$.model.value.trim());
        this.$.set.classList.remove('open');
        this.say(this.$.key.value.trim() ? 'Gemini 키를 이 브라우저에 저장했어요.' : '키 없이 규칙 답변과 Claude 연결로 답할게요.');
      };
      panel.querySelector('[data-k=clear]').onclick = () => {
        store.set(LS_KEY, ''); this.$.key.value = ''; this.say('이 브라우저에서 키를 지웠어요. 공용 PC라면 꼭 지워 주세요.');
      };
      this._setupMic(panel.querySelector('.geary-in .mic'));
      panel.querySelector('.geary-in').onsubmit = e => { e.preventDefault(); this.ask(this.$.input.value); this.$.input.value = ''; };

      this.cfg.suggestions.forEach(s => {
        const b = document.createElement('button');
        b.type = 'button'; b.textContent = s; b.onclick = () => this.ask(s);
        this.$.sugs.appendChild(b);
      });
    },

    // 음성 입력 — 브라우저 기본 음성 인식(Web Speech API). 무료, 키 불필요.
    //   Chrome·Edge에서 동작한다. 지원하지 않는 브라우저에서는 버튼을 숨긴다.
    //   처음 누르면 브라우저가 마이크 사용 허락을 묻는다.
    _setupMic(btn) {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { btn.style.display = 'none'; return; }
      const rec = new SR();
      rec.lang = 'ko-KR'; rec.interimResults = true; rec.maxAlternatives = 1;
      let listening = false, finalText = '';
      rec.onresult = e => {
        let t = '';
        for (const r of e.results) t += r[0].transcript;
        this.$.input.value = t;
        if (e.results[e.results.length - 1].isFinal) finalText = t;
      };
      rec.onend = () => {
        listening = false; btn.classList.remove('on');
        if (finalText.trim()) { this.ask(finalText); this.$.input.value = ''; finalText = ''; }
      };
      rec.onerror = e => {
        const msg = e.error === 'not-allowed' ? '마이크 사용이 막혀 있어요. 주소창 왼쪽 자물쇠에서 마이크를 허용해 주세요.'
                  : e.error === 'no-speech' ? '말소리가 들리지 않았어요. 다시 눌러 말해 주세요.'
                  : '음성 인식 오류(' + e.error + '). 글자로 입력해 주세요.';
        this.say(msg);
      };
      btn.onclick = () => {
        if (listening) { rec.stop(); return; }
        if ('speechSynthesis' in window) speechSynthesis.cancel();
        finalText = ''; listening = true; btn.classList.add('on');
        this.$.input.value = ''; this.$.input.placeholder = '듣고 있어요… 말을 마치면 자동으로 보냅니다';
        try { rec.start(); } catch (err) { listening = false; btn.classList.remove('on'); }
        setTimeout(() => { this.$.input.placeholder = '무엇이든 물어보세요'; }, 6000);
      };
    },

    _voiceLabel() { this.$.voice.textContent = this.voiceOn ? '음성 켜짐' : '음성 꺼짐'; },

    _add(text, who, actions) {
      const el = document.createElement('div');
      el.className = 'geary-msg ' + who;
      el.textContent = text;
      if (actions && actions.length) {
        const row = document.createElement('div');
        row.className = 'act';
        actions.forEach(([label, fn]) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; row.appendChild(b); });
        el.appendChild(row);
      }
      this.$.log.appendChild(el);
      this.$.log.scrollTop = this.$.log.scrollHeight;
      return el;
    },

    say(text, actions) {
      this._add(text, 'bot', actions);
      if (this.voiceOn && 'speechSynthesis' in window) {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'ko-KR';
        speechSynthesis.speak(u);
      }
    },

    async ask(q) {
      q = (q || '').trim();
      if (!q) return;
      this._add(q, 'me');

      // 1) 규칙 답변 — 키워드가 맞는 intent를 등록 순서대로 모두 실행하고 마지막 답을 말한다
      //    (예: "설비A 진동 이상" → 설비A 선택 → 진동 선택 → 이상 표시)
      const norm = q.replace(/\s+/g, '');
      const hits = this.cfg.intents.filter(it => (it.keys || []).some(k => norm.includes(k.replace(/\s+/g, ''))));
      if (hits.length) {
        let msg = '';
        for (const it of hits) {
          let m = typeof it.say === 'function' ? it.say(q) : it.say;
          try { const r = it.run && it.run(q); if (typeof r === 'string') m = r; } catch (e) { m = '화면을 움직이다 오류가 났어요: ' + e.message; }
          if (m) msg = m;
        }
        this.say(msg || '해당 부분을 표시했어요.');
        return;
      }

      // 3) Gemini 무료 키가 있으면 직접 답변
      const key = store.get(LS_KEY);
      if (key) {
        const wait = this._add('생각 중…', 'bot');
        try {
          const text = await this._gemini(key, q);
          wait.remove();
          this.say(text);
        } catch (e) {
          wait.remove();
          this.say('Gemini 호출에 실패했어요(' + e.message + '). 대신 Claude에게 물어볼까요?', [['Claude에게 묻기', () => this._toClaude(q)]]);
        }
        return;
      }

      // 2) 키가 없으면 Claude Pro로 넘기기
      const can = this.cfg.intents.flatMap(i => i.keys.slice(0, 1)).join(', ');
      this.say(`제가 바로 할 수 있는 건 이런 거예요: ${can || '없음'}.\n더 깊은 질문은 Claude에게 화면 요약과 함께 넘길게요.`,
        [['Claude에게 묻기', () => this._toClaude(q)]]);
    },

    _prompt(q) {
      return [
        `너는 자동차 부품사 실무자를 돕는 분석가야. 아래는 내 앱 "${this.cfg.app}" 화면의 요약이야.`,
        '----- 화면 요약 -----',
        String(this.cfg.context() || '(요약 없음)'),
        '---------------------',
        `질문: ${q}`,
        '요약에 있는 숫자만 근거로 답하고, 요약에 없는 건 없다고 말해 줘. 답은 결론부터 5줄 이내로.',
      ].join('\n');
    },

    async _toClaude(q) {
      const text = this._prompt(q);
      try { await navigator.clipboard.writeText(text); this.say('질문과 화면 요약을 복사했어요. 열린 Claude 창에 붙여 넣으세요(Ctrl+V).'); }
      catch (e) { this.say('복사가 막혔어요. 아래 내용을 직접 복사해 Claude에 붙여 넣으세요.\n\n' + text); }
      window.open('https://claude.ai/new', '_blank', 'noopener');
    },

    async _gemini(key, q) {
      const model = store.get(LS_MODEL) || 'gemini-2.5-flash';
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify({ contents: [{ parts: [{ text: this._prompt(q) }] }] }),
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      return (j.candidates?.[0]?.content?.parts || []).map(p => p.text).join('').trim() || '빈 답변이 왔어요.';
    },
  };

  window.Geary = Geary;
})();
