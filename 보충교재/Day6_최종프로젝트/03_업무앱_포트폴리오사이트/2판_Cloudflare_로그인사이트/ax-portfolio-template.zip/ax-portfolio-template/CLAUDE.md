# CLAUDE.md — AX 앱 포트폴리오 작업 규칙

배포 방식: github-pages

이 저장소는 자동차 부품사 실무자의 **AX 앱 포트폴리오**다. 배포 방식은 위 한 줄로 정한다.

- `github-pages` (1판, 기본) — 공개 저장소 + GitHub Pages. 누구나 주소로 본다. 시작 안내는 `START_HERE.md`.
- `cloudflare` (2판) — 비공개 저장소 + Cloudflare Pages + Access 이메일 코드 로그인. 시작 안내는 `START_HERE_Cloudflare.md`, 2판 규칙은 아래 7절.

사용자는 프롬프트를 붙여 넣고 결과만 확인한다. 내려받기·실행·파일 열기·배포·오류 해결은 Claude Code가 한다.

## 1. 공개 사이트 수칙 (push 전에 매번 점검하고 결과를 보고한다 — 2판 비공개 사이트에도 그대로 적용)

1. 회사 이름, 고객사(OEM) 실명, 실제 BOM·단가·클레임 원문을 넣지 않는다. OEM은 `OEM_01`처럼 코드로 쓴다.
2. 화면과 `apps.json`에 데이터마다 **가상** 또는 **실데이터(출처·기준일)** 를 표시한다.
3. API 키·토큰·비밀번호를 어떤 파일에도 넣지 않는다. 기어리의 키는 방문자 브라우저에만 저장된다.
4. 사내 파일은 `private/` 폴더에만 두고 커밋하지 않는다(`.gitignore`에 등록됨).
5. 로그인·결제·개인정보 수집 화면은 만들지 않는다.

점검 결과는 "수칙 1~5 통과" 또는 "수칙 N 위반: 무엇을 어떻게 고쳤는지" 형식으로 보고한다.
배포 워크플로(1판 `.github/workflows/pages.yml`, 2판 `.github/workflows/check.yml`)도 키 패턴과 `private/` 폴더를 자동 점검하며, 걸리면 멈춘다.

## 2. 비용 원칙 — 모두 무료

- 1판은 저장소를 **공개**로 둔다(무료 계정의 GitHub Pages는 공개 저장소에서만 동작). 2판은 **비공개**로 둔다(Cloudflare Pages는 비공개 저장소도 무료로 배포).
- 서버·데이터베이스·유료 API를 쓰지 않는다. 모든 앱은 정적 파일(HTML·CSS·JS·CSV·JSON)이다.
- 외부 라이브러리는 CDN(cdnjs, jsdelivr, unpkg)에서 불러온다.
- 기어리는 ① 규칙 답변 ② Claude에게 묻기(복사 후 claude.ai 열기) ③ Gemini 무료 키(선택) 세 방식만 쓴다.

## 3. 폴더 규칙

```text
index.html            허브 — apps.json을 읽어 카드를 그린다. 직접 고치지 말고 apps.json을 고친다
apps.json             앱 목록(제목·한 줄 소개·직무·상태·기능·데이터·경로)
apps/NN-이름/          앱 하나 = 폴더 하나, 진입 파일은 index.html
shared/ui/style.css   공통 스타일 — 앱은 이 파일을 불러 같은 모양을 쓴다
shared/geary/         AI 안내원 모듈
data/                 공개 가능한 데이터만(가상·공개). 파일명은 영어
private/              사내 파일(커밋 금지, 로컬 실행용)
```

## 4. 새 앱 추가 절차

1. `apps/00-sensor-watch/`를 `apps/NN-이름/`으로 복사해 시작한다.
2. 데이터는 `data/`에 영어 파일명으로 넣는다. 정답열(`gt_*`)이 있으면 앱 결과와 비교한 **일치율을 화면 하단에 표시**한다.
3. 화면에 데이터 구분 배지(가상/실데이터)와 계산 기준을 적는다.
4. 기어리를 붙일 때는 앱이 공개하는 함수만 `intents`에 등록한다. 임의 코드 실행은 금지.
5. `apps.json`에서 해당 항목의 `status`(기획 중 → 운영 중), `version`, `path`, `data`, `geary`를 갱신한다.
6. `README.md`의 앱 표를 갱신한다.
7. 수칙 점검 → 커밋 → `git push` → 배포 완료 확인(1판: Actions 배포 후 주소를 열어 동작 확인 · 2판: 7절의 배포 목록 확인) → 3줄 보고.

## 5. 문체

- 화면 문구는 한국어, 업계 용어는 실무 표기 그대로(CR, BOM, OEM, VOC, HITL 등). 필요하면 영어 병기.
- 결론 먼저, 짧게.

## 6. 로컬 실행 (사내 데이터로 돌려 볼 때)

- `python3 -m http.server 8000`으로 띄우고 `http://localhost:8000`을 연다.
- 사내 파일은 `private/`에 두고 앱의 데이터 경로만 바꿔 확인한 뒤, **경로를 다시 `data/`로 되돌리고** 커밋한다.

## 7. 2판(Cloudflare) 규칙 — `배포 방식: cloudflare`일 때

- 저장소는 **비공개**. 배포는 Cloudflare Pages가 `main` push를 보고 1~2분 안에 한다. GitHub Actions는 `check.yml`(점검만)만 둔다.
- 1판에서 2판으로 바꿀 때: 맨 위 `배포 방식:` 줄을 `cloudflare`로 → `.github/workflows/pages.yml` 삭제 → `cloudflare/check.yml`을 `.github/workflows/check.yml`로 복사 → `README.md`를 `START_HERE_Cloudflare.md`의 "README 2판 문구"로.
- Pages 설정값: Framework preset `None`, Build command `exit 0`, Build output directory `/`. 이 값은 사용자가 Cloudflare 화면에서 넣는다 — 순서를 정확히 알려 준다.
- 사이트 앞에 Access 로그인 문이 있어 주소를 직접 열어 확인할 수 없다. 배포 확인은 `npx wrangler login`(사용자가 브라우저에서 Allow) → `npx wrangler pages deployment list --project-name <프로젝트 이름>`으로 한다. 화면 확인은 사용자에게 시크릿 창 로그인으로 부탁한다.
- Cloudflare API 토큰·계정 ID를 저장소 파일에 넣지 않는다. wrangler 로그인 정보는 사용자 PC에만 남는다.
- 비공개·로그인 사이트여도 1절 수칙은 그대로다. 회사 실데이터는 사용자가 보안 담당 승인을 받았다고 말하기 전에는 올리지 않는다.
- 기어리 Gemini 키의 주소 제한(HTTP 리퍼러)은 `https://<프로젝트 이름>.pages.dev/*`로 안내한다.
- 사용자 도메인을 붙일 때는 Access를 켜기 **전에** Pages → Custom domains로 먼저 연결한다(Access가 켜진 주소에는 붙일 수 없다).

