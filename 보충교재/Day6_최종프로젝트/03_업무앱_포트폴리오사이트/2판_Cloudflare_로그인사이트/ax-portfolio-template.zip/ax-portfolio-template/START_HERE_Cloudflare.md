# 시작하기 2판 — Cloudflare로 "로그인해야 열리는" 사이트 (수강생용)

1판(`START_HERE.md`)은 누구나 보는 공개 사이트를 GitHub Pages로 만든다.
2판은 저장소를 **비공개**로 두고, **Cloudflare Pages**로 배포하고, **이메일 코드 로그인**(Cloudflare Access)으로 허락한 사람만 들어오게 한다.
자세한 화면 순서는 가이드 덱 `AX_App_Portfolio_Guide_Manual_2_Cloudflare`를 본다. 비용은 0원(도메인만 선택·유료).

## STEP 1 — 비공개 저장소 (Claude Code에 붙여 넣기)

`홍길동`, `품질보증팀 대리` 두 곳만 바꾼다.

```text
너는 내 AX 포트폴리오 개발 파트너야. 모두 무료로 진행해.
내 이름은 홍길동, 직무는 품질보증팀 대리야.

1) keerhee/ax-portfolio-template 을 템플릿으로 내 GitHub에 ax-portfolio "비공개" 저장소를 만들고 내 PC에 내려받아 줘.
   (gh repo create ax-portfolio --private --template keerhee/ax-portfolio-template --clone)
2) 이번에는 Cloudflare Pages로 배포할 거야. START_HERE_Cloudflare.md 의 "2판으로 바꾸기" 순서대로 바꿔 줘.
3) apps.json 의 owner·role 을 내 이름·직무로 바꾸고, README 의 사이트 주소는 "(Cloudflare 연결 후 채움)"으로 둬.
4) 수칙 점검 → 커밋 → push 해 줘.
내가 직접 눌러야 하는 것이 있으면 그때만 멈추고 어디를 누를지 정확히 알려 줘.
```

### 2판으로 바꾸기 (Claude Code가 하는 일)

1. `CLAUDE.md` 맨 위 `배포 방식:` 줄을 `cloudflare`로 바꾼다.
2. `.github/workflows/pages.yml`을 지우고 `cloudflare/check.yml`을 `.github/workflows/check.yml`로 복사한다(점검만, 배포 없음).
3. `README.md`의 사이트 줄과 비용 표를 2판 문구로 바꾼다(아래 "README 2판 문구").

## STEP 2 — Cloudflare Pages 연결 (내가 화면에서)

1. dash.cloudflare.com 가입 → 메일 인증 → 도메인 추가 화면은 건너뜀
2. Workers & Pages → Create application → Pages 탭 → Import an existing Git repository
3. Connect GitHub → Only select repositories → `ax-portfolio` → Install → Begin setup
4. 설정 네 칸: Project name `ax-portfolio-내아이디` · Production branch `main` · Framework preset `None` · Build command `exit 0` · Build output directory `/`
5. Save and Deploy → 1~2분 뒤 `https://ax-portfolio-내아이디.pages.dev`

첫 배포가 끝나면 Claude Code에 붙여 넣는다.

```text
Cloudflare Pages 첫 배포가 끝났어. 주소는 https://ax-portfolio-내아이디.pages.dev 야.
1) 이 주소를 열어 허브와 예시 앱(00)이 뜨는지 확인해 줘.
2) README 의 사이트 주소를 이 주소로 바꾸고 push 해 줘.
3) push 뒤 1~2분 안에 사이트에 반영되는지 확인하고 3줄로 보고해 줘.
```

> 이 시점에는 주소를 아는 누구나 열 수 있다. STEP 3을 마치기 전에는 주소를 보내지 않는다.

## STEP 3 — 이메일 코드 로그인 (내가 화면에서)

1. 왼쪽 메뉴 Zero Trust → 팀 이름(영어 소문자) → **Free** 플랜(0원, 50명까지)
2. Workers & Pages → `ax-portfolio-내아이디` → Settings → **Enable access policy** → 생긴 정책의 Manage
3. Configure → Public hostname의 Subdomain 칸에서 `*` 지우기 → Save (이름 오류가 나면 Application name을 바꿔 저장)
4. 다시 Settings → Enable access policy 한 번 더 → 정책 2개(pages.dev · 미리보기)가 보이는지 확인
5. Zero Trust → Access controls → Applications → 내 앱 → Policies → Allow 정책 Edit → Include: **Emails**에 나·팀장·동료 이메일 → Save
6. 시크릿 창에서 주소 열기 → 이메일 입력 → 메일로 온 6자리 코드 → 허브가 보이면 성공. 명단에 없는 이메일은 막혀야 한다.

출처: Cloudflare Pages docs › Known issues › Enable Access on your `*.pages.dev` domain (2026-10 확인).

## 앱 하나를 추가할 때 (1판과 같음)

```text
CLAUDE.md의 "새 앱 추가 절차"대로 apps/{번호-이름}/ 에 앱을 만들어 줘.
- 문제: {직무}의 {반복 업무}를 {몇 분 → 몇 분}으로 줄이는 것
- 입력: data/{파일명}
- 핵심 기능 3개: {기능1}, {기능2}, {기능3}
- 기어리를 붙이고, 앱이 공개하는 함수만 intents에 등록해 줘.
- 다 만들면 push 하고, Cloudflare 배포가 끝났는지 확인한 다음 3줄로 보고해 줘.
```

## 배포가 됐는지 확인할 때

사이트에 로그인 문이 있어서 Claude Code는 주소를 직접 열지 못한다. 배포 목록으로 확인한다.

```text
Cloudflare 배포 상태를 확인해 줘.
1) npx wrangler login 으로 Cloudflare에 연결해 줘. (브라우저가 열리면 내가 Allow를 누를게)
2) npx wrangler pages deployment list --project-name ax-portfolio-내아이디 로 가장 최근 배포가 성공했는지 보고해 줘.
3) 실패했으면 이유를 찾아 고치고 다시 push 해 줘.
```

## 기어리 Gemini 키

키는 1판과 같이 기어리 설정 창에만 넣는다. Google Cloud 콘솔의 키 주소 제한(HTTP 리퍼러)만 `https://ax-portfolio-내아이디.pages.dev/*`로 바꾼다.

## (선택) 내 도메인

도메인을 사서 `hub.내도메인`을 붙이려면 **Access를 켜기 전에** Pages → Custom domains로 먼저 연결하고, 그다음 Zero Trust → Applications → Self-hosted and private → Add public hostname으로 새 주소에도 로그인 문을 단다.

## README 2판 문구

```text
**사이트:** `https://ax-portfolio-아이디.pages.dev` (로그인 필요 — 허락한 이메일만)

| 항목 | 비용 |
|---|---|
| 비공개 저장소 · GitHub Actions 점검 | 무료 |
| Cloudflare Pages 배포 (월 500회) · Access 로그인 (50명까지) | 무료 |
| 기어리 규칙 답변 · Claude에게 묻기 | 무료 (Claude Pro 구독 사용) |
| 기어리 Gemini 직접 답변 | 선택 — Gemini 무료 등급 키 |
| 내 도메인 | 선택 — 유료(연 단위) |
```
