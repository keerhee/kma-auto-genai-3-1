# 시작하기 — 수강생용 (Day0, 30분)

Claude 데스크톱 앱의 Code 탭(Claude Code)을 열고 아래 프롬프트를 그대로 붙여 넣으세요. 당신은 확인만 합니다.

```text
너는 내 AX 포트폴리오 개발 파트너야. 모두 무료로 진행해.
1) keerhee/ax-portfolio-template 을 템플릿으로 내 GitHub에 ax-portfolio 라는 "공개" 저장소를 만들고 내 PC에 내려받아 줘.
   (gh repo create ax-portfolio --public --template keerhee/ax-portfolio-template --clone)
2) GitHub Pages를 켜고 배포 방식을 GitHub Actions로 설정해 줘.
   (gh api -X POST repos/{내아이디}/ax-portfolio/pages -f build_type=workflow)
3) apps.json의 owner와 role을 내 이름과 직무로 바꾸고, README의 사이트 주소와 배포 배지를 실제 값으로 바꿔 줘.
4) CLAUDE.md의 공개 사이트 수칙을 점검한 뒤 커밋하고 push해 줘.
5) Actions 배포가 끝나면 사이트 주소를 열어 허브와 예시 앱(00)이 뜨는지 확인하고, 주소와 함께 3줄로 보고해 줘.
내가 직접 눌러야 하는 것(GitHub 로그인·권한 승인)이 있으면 그때만 멈추고 정확히 어디를 누를지 알려 줘.
```

## 앱 하나를 추가할 때

```text
CLAUDE.md의 "새 앱 추가 절차"대로 apps/{번호-이름}/ 에 앱을 만들어 줘.
- 문제: {직무}의 {반복 업무}를 {몇 분 → 몇 분}으로 줄이는 것
- 입력: data/{파일명}
- 핵심 기능 3개: {기능1}, {기능2}, {기능3}
- 기어리를 붙이고, 앱이 공개하는 함수만 intents에 등록해 줘.
- 배포까지 끝내고 주소를 열어 확인한 뒤 3줄로 보고해 줘.
```

## 사내 데이터로 확인만 하고 싶을 때 (공개하지 않음)

```text
내 사내 파일 {경로}를 private/ 에 복사하고, apps/{번호-이름}을 로컬 서버로 열어 그 파일로 보여 줘.
확인이 끝나면 데이터 경로를 data/로 되돌리고, private/ 가 커밋되지 않았는지 점검해 줘.
```
