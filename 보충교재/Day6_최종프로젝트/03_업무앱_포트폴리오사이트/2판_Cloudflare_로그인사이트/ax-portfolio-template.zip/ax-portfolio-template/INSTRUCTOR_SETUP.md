# 강사용 — 템플릿 저장소 올리기 (1회, 무료)

이 폴더를 내려받아 압축을 푼 뒤, 그 폴더에서 Claude Code를 열고 아래를 붙여 넣습니다.

```text
이 폴더를 keerhee/ax-portfolio-template 공개 저장소로 올려 줘.
1) git init → 전체 커밋 → gh repo create ax-portfolio-template --public --source . --push
2) 템플릿 저장소로 지정: gh api -X PATCH repos/keerhee/ax-portfolio-template -F is_template=true
3) Pages 켜기(배포 방식 GitHub Actions): gh api -X POST repos/keerhee/ax-portfolio-template/pages -f build_type=workflow
4) Actions 배포가 끝나면 https://keerhee.github.io/ax-portfolio-template/ 을 열어 허브와 예시 앱이 뜨는지 확인하고 보고해 줘.
```

수강생은 `START_HERE.md`(1판 · 공개 GitHub Pages) 또는 `START_HERE_Cloudflare.md`(2판 · 비공개 + Cloudflare 로그인)의 프롬프트로 이 템플릿에서 각자 저장소를 만듭니다.
템플릿 저장소 자체는 **공개**로 둡니다 — 2판 수강생도 공개 템플릿에서 `--private`로 복사합니다.
강사 레퍼런스판(앱 9개 완성본)은 같은 방법으로 `keerhee/ax-portfolio`를 만들어 채웁니다.
