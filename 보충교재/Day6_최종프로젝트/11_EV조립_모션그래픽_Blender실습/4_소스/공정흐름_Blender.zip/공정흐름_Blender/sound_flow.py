"""공정 흐름 Blender판(EV_Assembly_Line_Flow_Blender.mp4) 효과음 -> flow_audio.wav (48 kHz 스테레오).

시간표는 flow_scene.py와 같은 식으로 다시 계산하고, 부품 수는 GLB에서 센다(프레임 7 · 배터리 21 · 구동계 380).
음색·필터는 EV_Blender_Scripts.zip 의 sound.py와 같다(scipy 버터워스 필터).
사용: python3 sound_flow.py  → ffmpeg로 영상에 입힌다(아래 맨 끝 주석).
"""
import json, os, struct, wave
import numpy as np
from scipy.signal import butter, sosfilt

HERE = os.path.dirname(os.path.abspath(__file__))
SR, FPS = 48000, 24
rng = np.random.default_rng(11)

# ---------------------------------------------------------------- 시간표 (flow_scene.py와 같음)
PH, t = [], 0.0
def add(kind, st, dur):
    global t
    PH.append({"type": kind, "st": st, "t0": t, "dur": dur}); t += dur
add("enter", 0, 2.5); add("work", 0, 5.5)
for s in range(1, 5):
    add("move", s, 2.6); add("work", s, 6.5 if s == 3 else 5.5)
add("exit", 4, 3.2); add("end", 4, 3.0)
TOTAL = t
F = lambda sec: int(round(sec * FPS)) + 1
sec_of = lambda fr: (fr - 1) / FPS
W = {p["st"]: p for p in PH if p["type"] == "work"}

# 부품 수 (GLB 노드 이름으로 flow_scene.py와 같은 기준)
glb = open(os.path.join(HERE, "../../3_3D모델/EV_Crossover_Education.glb"), "rb").read()
names = [n.get("name", "") for n in json.loads(glb[20:20 + struct.unpack("<I", glb[12:16])[0]])["nodes"] if "mesh" in n]
N_FRAME = sum(not n.startswith(("Body", "Battery_Module", "HV", "Front", "Rear")) for n in names)
N_BATT = sum(n.startswith(("Battery_Module", "HV")) for n in names)
N_DRIVE = sum(n.startswith(("Front", "Rear")) for n in names)

def landings(st, n, span=0.72, each=0.22):
    """stagger()가 부품을 제자리에 놓는 프레임들."""
    w = W[st]; f0 = F(w["t0"] + 0.4); total = (w["dur"] - 1.0) * FPS
    return [f0 + int(total * span * i / max(1, n - 1)) + int(total * each) for i in range(n)]

N = int(SR * (TOTAL + 0.05))
mix = np.zeros((N, 2))

# ---------------------------------------------------------------- 소리 재료
def t_(sec): return np.arange(int(SR * sec)) / SR
def bp(x, lo, hi): return sosfilt(butter(2, [lo, hi], "bandpass", fs=SR, output="sos"), x)
def lp(x, hi): return sosfilt(butter(2, hi, "lowpass", fs=SR, output="sos"), x)

def place(sig, sec, gain=1.0, pan=0.0):
    i = int(sec * SR)
    if i >= N: return
    sig = sig[: N - i]
    l, r = np.sqrt(0.5 * (1 - pan)), np.sqrt(0.5 * (1 + pan))
    mix[i:i + len(sig), 0] += sig * gain * l; mix[i:i + len(sig), 1] += sig * gain * r

def whoosh(sec=0.5):
    tt = t_(sec); n = rng.standard_normal(len(tt)); env = np.sin(np.pi * tt / sec) ** 2
    return bp(n, 400, 3200) * env * 0.5 + bp(n, 150, 600) * env * 0.3
def clank(pitch=1.0):
    tt = t_(0.5)
    thump = np.sin(2 * np.pi * (75 - 30 * tt) * tt) * np.exp(-tt * 14)
    metal = sum(np.sin(2 * np.pi * f * pitch * tt) * np.exp(-tt * d) for f, d in ((920, 22), (1460, 28), (2270, 35), (3110, 45)))
    return thump * 0.9 + metal * 0.12
def click():                      # 배터리 모듈 체결
    tt = t_(0.09)
    return (np.sin(2 * np.pi * 3200 * tt) * np.exp(-tt * 90) * 0.30 + np.sin(2 * np.pi * 180 * tt) * np.exp(-tt * 55) * 0.45
            + bp(rng.standard_normal(len(tt)), 2500, 7000) * np.exp(-tt * 120) * 0.25)
def rattle():                     # 구동계 볼트 체결 한 번
    tt = t_(0.05)
    return bp(rng.standard_normal(len(tt)), 1800, 6500) * np.exp(-tt * 140) * 0.35 + np.sin(2 * np.pi * 1200 * tt) * np.exp(-tt * 110) * 0.12
def servo(sec=0.45):              # 로봇 팔 관절
    tt = t_(sec); f = 520 + 160 * np.sin(np.pi * tt / sec)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.10 + bp(rng.standard_normal(len(tt)), 900, 2600) * 0.05
    return s * np.sin(np.pi * tt / sec) ** 1.5
def motor(sec):                   # 구동계 체결 공구 · 너트러너
    tt = t_(sec); f = 160 + 25 * np.sin(2 * np.pi * 0.7 * tt)
    saw = 2 * ((np.cumsum(f) / SR) % 1) - 1
    env = np.minimum(tt / 0.4, 1) * np.minimum((sec - tt) / 0.5, 1)
    return lp(saw, 1800) * 0.10 * env
def hydraulic(sec):               # 차체가 내려오는 유압
    tt = t_(sec); f = 140 - 60 * tt / sec
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.22
    hiss = bp(rng.standard_normal(len(tt)), 900, 4000) * 0.10
    env = np.minimum(tt / 0.3, 1) * np.minimum((sec - tt) / 0.3, 1)
    return (tone + hiss) * env
def slam():                       # 차체 결합
    tt = t_(1.2)
    boom = np.sin(2 * np.pi * (60 - 25 * tt) * tt) * np.exp(-tt * 6) * 1.0
    metal = sum(np.sin(2 * np.pi * f * tt) * np.exp(-tt * d) for f, d in ((310, 5), (640, 7), (1180, 9), (1990, 12))) * 0.15
    return boom + metal + bp(rng.standard_normal(len(tt)), 200, 2500) * np.exp(-tt * 18) * 0.4
def lamp():                       # 공정 구역 조명이 켜질 때
    tt = t_(0.35)
    return (np.sin(2 * np.pi * 1318.5 * tt) + 0.6 * np.sin(2 * np.pi * 1975.5 * tt)) * np.exp(-tt * 9) * 0.10
def scan(sec):
    tt = t_(sec); f = 380 + 700 * (tt / sec) ** 1.4
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * tt))
    return s * 0.16 * np.sin(np.pi * tt / sec) ** 0.6
def chime():
    tt = t_(2.2)
    return sum(np.sin(2 * np.pi * f * tt) * np.exp(-tt * 2.4) for f in (1046.5, 1318.5, 1568.0, 2093.0)) * 0.14
def shimmer(sec=2.6):
    tt = t_(sec)
    return sum(np.sin(2 * np.pi * f * tt + p) for f, p in ((1760, 0), (1767, 1), (2637, 2), (3520, 3))) * 0.05 * np.sin(np.pi * tt / sec)

# ---------------------------------------------------------------- 바탕: 공장 소음 + 컨베이어
tt = np.arange(N) / SR
hum = (np.sin(2 * np.pi * 60 * tt) * 0.5 + np.sin(2 * np.pi * 120 * tt) * 0.25) * 0.020
air = lp(rng.standard_normal(N), 500) * 0.030
conv = np.zeros(N)                                    # 차가 움직이는 구간에서만 컨베이어 소리를 키운다
for p in PH:
    if p["type"] in ("enter", "move", "exit"):
        a, b = int(p["t0"] * SR), min(N, int((p["t0"] + p["dur"]) * SR))
        seg = np.arange(b - a) / SR; d = p["dur"]
        conv[a:b] = np.sin(np.pi * np.clip(seg / d, 0, 1)) ** 0.7
rumble = bp(rng.standard_normal(N), 60, 400) * 0.10 + (2 * ((np.cumsum(np.full(N, 38.0)) / SR) % 1) - 1) * 0.015
amb = (hum + air + rumble * conv) * np.clip(tt / 1.2, 0, 1) * np.clip((TOTAL - tt) / 2.0, 0, 1)
mix[:, 0] += amb; mix[:, 1] += amb

# ---------------------------------------------------------------- 사건
for i in range(5):                                    # 공정 시작: 조명 + 휙 + 로봇 팔
    w = W[i]
    place(lamp(), w["t0"] + 0.05, 1.0)
    place(whoosh(0.4), max(0, w["t0"] - 0.2), 0.35)
    for k, fr in enumerate(range(F(w["t0"]), F(w["t0"] + w["dur"]), 12)):
        if k % 2 == 0:
            place(servo(), sec_of(fr), 0.8, -0.6 if k % 4 == 0 else 0.6)
for fr in landings(0, N_FRAME):                       # 프레임: 쾅
    place(clank(rng.uniform(0.92, 1.08)), sec_of(fr), 0.75, rng.uniform(-0.4, 0.4))
for fr in landings(1, N_BATT):                        # 배터리 모듈: 찰칵
    place(click(), sec_of(fr), 0.9, rng.uniform(-0.3, 0.3))
dl = landings(2, N_DRIVE, span=0.65, each=0.28)       # 구동계 380개: 촘촘한 체결음 + 공구 모터
for fr in dl[::6]:
    place(rattle(), sec_of(fr) + rng.uniform(-0.02, 0.02), 1.0, rng.uniform(-0.5, 0.5))
place(motor(sec_of(dl[-1]) - sec_of(dl[0]) + 0.4), sec_of(dl[0]) - 0.2, 1.0)
for fr in (dl[0], dl[len(dl) // 2], dl[-1]):
    place(clank(1.15), sec_of(fr), 0.45)
w = W[3]; b0, b1 = w["t0"] + 0.8, w["t0"] + w["dur"] * 0.8   # 차체: 유압으로 내려와 쿵
place(hydraulic(b1 - b0), b0, 0.5)
place(slam(), b1, 0.9)
w = W[4]; g0, gm, g1 = w["t0"] + 0.5, w["t0"] + w["dur"] / 2, w["t0"] + w["dur"] - 0.5   # 검사 게이트 왕복 두 번
place(scan(gm - g0), g0, 1.0); place(scan(g1 - gm), gm, 1.0)
place(chime(), g1 + 0.1, 1.0)                         # 검사 통과
ex = next(p for p in PH if p["type"] == "exit")
place(whoosh(0.9), ex["t0"] + 0.2, 0.45)              # 출하
end = next(p for p in PH if p["type"] == "end")
place(shimmer(), end["t0"] + 0.1, 1.0)

# ---------------------------------------------------------------- 저장
mix /= np.abs(mix).max() / 0.89
pcm = (mix * 32767).astype("<i2")
with wave.open(os.path.join(HERE, "flow_audio.wav"), "wb") as wf:
    wf.setnchannels(2); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())
print(f"ok {TOTAL:.3f}s · frame {N_FRAME} · battery {N_BATT} · drive {N_DRIVE} · rattles {len(dl[::6])}")
# 입히기: ffmpeg -i EV_Assembly_Line_Flow_Blender_무음.mp4 -i flow_audio.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k
#         -af loudnorm=I=-16:TP=-1.5:LRA=11 -shortest -movflags +faststart EV_Assembly_Line_Flow_Blender.mp4
