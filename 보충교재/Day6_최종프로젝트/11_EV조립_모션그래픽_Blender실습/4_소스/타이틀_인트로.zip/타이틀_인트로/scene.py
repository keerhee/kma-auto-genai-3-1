"""Claude + Blender motion graphic — Blender 4.2 Eevee, 1920x1080, 24fps, 240 frames.

Run:  python scene.py            (bpy module)   or   blender -b -P scene.py
Env:  SAMPLES (default 16), FRAME_START / FRAME_END (render range), PREVIEW=1 (one still)
"""
import bpy, math, os, json

OUT = os.path.dirname(os.path.abspath(__file__))
FPS, F_END = 24, 240
TEXT_FRAME = 150          # text starts popping out here (hit sound is synced to this)
SAMPLES = int(os.environ.get("SAMPLES", 16))

# ---------- reset ----------
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, F_END
sc.render.fps = FPS
sc.render.resolution_x, sc.render.resolution_y = 1920, 1080
sc.render.resolution_percentage = 100

# ---------- render settings ----------
sc.render.engine = "BLENDER_EEVEE_NEXT"
ee = sc.eevee
ee.taa_render_samples = SAMPLES
for attr, val in [("use_shadows", True), ("use_raytracing", False), ("use_gtao", True)]:
    if hasattr(ee, attr):
        setattr(ee, attr, val)
if hasattr(ee, "use_bloom"):          # Eevee Legacy (<=4.1) has a bloom switch
    ee.use_bloom = True
    ee.bloom_intensity, ee.bloom_threshold = 0.12, 0.8
sc.view_settings.view_transform = "AgX"
try:
    sc.view_settings.look = "AgX - Medium High Contrast"
except TypeError:
    pass
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_mode = "RGB"
sc.render.filepath = os.path.join(OUT, "renders", "frame_")

# ---------- helpers ----------
def ease_keys(obj, path, frames_vals, interp="BEZIER", easing="AUTO", index=-1):
    for f, v in frames_vals:
        setattr(obj, path, v) if not isinstance(v, tuple) else setattr(obj, path, v)
        obj.keyframe_insert(data_path=path, frame=f, index=index)
    if obj.animation_data and obj.animation_data.action:
        for fc in obj.animation_data.action.fcurves:
            if fc.data_path == path:
                for kp in fc.keyframe_points:
                    kp.interpolation = interp
                    kp.easing = easing

def mat_emission(name, color, strength):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    em = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
    em.inputs["Color"].default_value = (*color, 1); em.inputs["Strength"].default_value = strength
    nt.links.new(em.outputs[0], out.inputs[0])
    return m

def mat_glass(name, tint):
    m = bpy.data.materials.new(name); m.use_nodes = True
    if hasattr(m, "surface_render_method"):
        m.surface_render_method = "BLENDED"
    else:
        m.blend_method = "BLEND"
    m.use_backface_culling = False
    p = m.node_tree.nodes["Principled BSDF"]
    p.inputs["Base Color"].default_value = (*tint, 1)
    p.inputs["Roughness"].default_value = 0.08
    p.inputs["Alpha"].default_value = 0.22
    p.inputs["Coat Weight"].default_value = 1.0
    p.inputs["Emission Color"].default_value = (*tint, 1)
    p.inputs["Emission Strength"].default_value = 0.35
    return m

# ---------- world ----------
w = bpy.data.worlds.new("World"); sc.world = w; w.use_nodes = True
w.node_tree.nodes["Background"].inputs["Color"].default_value = (0.004, 0.005, 0.012, 1)
w.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.0

# backdrop: large plane with soft radial glow, gives the glass something to refract over
bpy.ops.mesh.primitive_plane_add(size=60, location=(0, 9, 0), rotation=(math.radians(90), 0, 0))
bd = bpy.context.object; bd.name = "Backdrop"
m = bpy.data.materials.new("BackdropMat"); m.use_nodes = True
nt = m.node_tree; nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord"); grad = nt.nodes.new("ShaderNodeTexGradient")
grad.gradient_type = "SPHERICAL"
mp = nt.nodes.new("ShaderNodeMapping"); mp.inputs["Scale"].default_value = (0.09, 0.14, 1)
ramp = nt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color = (0.002, 0.002, 0.006, 1)
ramp.color_ramp.elements[1].position = 0.9
ramp.color_ramp.elements[1].color = (0.018, 0.012, 0.04, 1)
em = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], mp.inputs[0]); nt.links.new(mp.outputs[0], grad.inputs[0])
nt.links.new(grad.outputs["Fac"], ramp.inputs[0]); nt.links.new(ramp.outputs[0], em.inputs[0])
nt.links.new(em.outputs[0], out.inputs[0])
bd.data.materials.append(m)

# dark glossy floor for grounding
bpy.ops.mesh.primitive_plane_add(size=80, location=(0, 0, -2.2))
fl = bpy.context.object; fl.name = "Floor"
fl.visible_shadow = False
fm = bpy.data.materials.new("FloorMat"); fm.use_nodes = True
fp = fm.node_tree.nodes["Principled BSDF"]
fp.inputs["Base Color"].default_value = (0.004, 0.004, 0.006, 1)
fp.inputs["Roughness"].default_value = 0.35
fl.data.materials.append(fm)

# ---------- glass panels ----------
PANELS = [  # x, tint, edge color, entry start frame
    (-2.7, (0.30, 0.75, 1.00), (0.25, 0.75, 1.00), 8),
    ( 0.0, (0.70, 0.45, 1.00), (0.75, 0.40, 1.00), 28),
    ( 2.7, (1.00, 0.55, 0.30), (1.00, 0.55, 0.25), 48),
]
panels = []
for i, (x, tint, edge, f0) in enumerate(PANELS):
    root = bpy.data.objects.new(f"PanelRoot{i}", None); sc.collection.objects.link(root)

    bpy.ops.mesh.primitive_plane_add(size=1)
    g = bpy.context.object; g.name = f"Glass{i}"
    g.scale = (1.8, 2.6, 1); bpy.ops.object.transform_apply(scale=True)
    g.rotation_euler = (math.radians(90), 0, 0); bpy.ops.object.transform_apply(rotation=True)
    sol = g.modifiers.new("Solid", "SOLIDIFY"); sol.thickness = 0.06
    bev = g.modifiers.new("Bevel", "BEVEL"); bev.width = 0.03; bev.segments = 3
    g.data.materials.append(mat_glass(f"GlassMat{i}", tint))
    g.parent = root

    # emissive frame = wireframe of the same plane (drives the bloom)
    bpy.ops.mesh.primitive_plane_add(size=1)
    fr = bpy.context.object; fr.name = f"Frame{i}"
    fr.scale = (1.8, 2.6, 1); bpy.ops.object.transform_apply(scale=True)
    fr.rotation_euler = (math.radians(90), 0, 0); bpy.ops.object.transform_apply(rotation=True)
    wf = fr.modifiers.new("Wire", "WIREFRAME"); wf.thickness = 0.025
    fr.data.materials.append(mat_emission(f"EdgeMat{i}", edge, 9.0))
    fr.parent = root

    # entry: fly up from below/behind, spin 1.5 turns, scale 0 -> 1
    f1 = f0 + 44
    root.location = (x, 3.0, -5.0); root.keyframe_insert("location", frame=f0)
    root.location = (x, 0.0, 0.25); root.keyframe_insert("location", frame=f1)
    root.rotation_euler = (math.radians(-40), 0, math.radians(540 + 25 * (1 - i))); root.keyframe_insert("rotation_euler", frame=f0)
    root.rotation_euler = (0, 0, math.radians(18 * (1 - i))); root.keyframe_insert("rotation_euler", frame=f1)
    root.scale = (0.001,) * 3; root.keyframe_insert("scale", frame=f0)
    root.scale = (1, 1, 1); root.keyframe_insert("scale", frame=f1)
    # make room for the text: drift back and fan out
    root.location = (x * 1.08, 0.0, 0.25); root.keyframe_insert("location", frame=TEXT_FRAME - 12)
    root.location = (x * 1.25, 2.2, 0.45); root.keyframe_insert("location", frame=TEXT_FRAME + 14)
    root.location = (x * 1.28, 2.4, 0.55); root.keyframe_insert("location", frame=F_END)
    root.rotation_euler = (0, 0, math.radians(18 * (1 - i))); root.keyframe_insert("rotation_euler", frame=TEXT_FRAME - 12)
    root.rotation_euler = (0, 0, math.radians(30 * (1 - i)) + math.radians(6)); root.keyframe_insert("rotation_euler", frame=F_END)
    for fc in root.animation_data.action.fcurves:
        for kp in fc.keyframe_points:
            kp.interpolation = "BEZIER"; kp.handle_left_type = kp.handle_right_type = "AUTO_CLAMPED"
    # gentle idle bob after entry
    for fc in root.animation_data.action.fcurves:
        if fc.data_path == "location" and fc.array_index == 2:
            n = fc.modifiers.new("NOISE"); n.scale = 40; n.strength = 0.08; n.phase = i * 3.7
            n.use_restricted_range = True; n.frame_start = f1; n.frame_end = F_END; n.blend_in = 12
    panels.append(root)

# ---------- 3D text ----------
bpy.ops.object.text_add(location=(0, -1.2, 0.2), rotation=(math.radians(90), 0, 0))
t = bpy.context.object; t.name = "Title"
t.data.body = "Claude + Blender"
t.data.align_x = "CENTER"; t.data.align_y = "CENTER"
t.data.size = 0.78; t.data.extrude = 0.14
t.data.bevel_depth = 0.025; t.data.bevel_resolution = 3
tm = bpy.data.materials.new("TitleMat"); tm.use_nodes = True
tp = tm.node_tree.nodes["Principled BSDF"]
tp.inputs["Base Color"].default_value = (0.95, 0.93, 0.9, 1)
tp.inputs["Metallic"].default_value = 0.35
tp.inputs["Roughness"].default_value = 0.22
tp.inputs["Emission Color"].default_value = (1.0, 0.62, 0.35, 1)
tp.inputs["Emission Strength"].default_value = 0.0
t.data.materials.append(tm)

# pop: hidden -> overshoot -> settle, flying toward camera
t.scale = (0.001,) * 3; t.keyframe_insert("scale", frame=TEXT_FRAME - 1)
t.scale = (1.22,) * 3;  t.keyframe_insert("scale", frame=TEXT_FRAME + 5)
t.scale = (0.94,) * 3;  t.keyframe_insert("scale", frame=TEXT_FRAME + 10)
t.scale = (1.0,) * 3;   t.keyframe_insert("scale", frame=TEXT_FRAME + 16)
t.location = (0, 2.5, 0.2);  t.keyframe_insert("location", frame=TEXT_FRAME - 1)
t.location = (0, -1.2, 0.2); t.keyframe_insert("location", frame=TEXT_FRAME + 6)
t.rotation_euler = (math.radians(90 - 25), 0, 0); t.keyframe_insert("rotation_euler", frame=TEXT_FRAME - 1)
t.rotation_euler = (math.radians(90), 0, 0);      t.keyframe_insert("rotation_euler", frame=TEXT_FRAME + 10)
t.rotation_euler = (math.radians(90), 0, math.radians(-4)); t.keyframe_insert("rotation_euler", frame=F_END)
# emission flash on impact
es = tp.inputs["Emission Strength"]
for f, v in [(TEXT_FRAME - 1, 0.0), (TEXT_FRAME + 2, 6.0), (TEXT_FRAME + 20, 0.6), (F_END, 0.4)]:
    es.default_value = v; es.keyframe_insert("default_value", frame=f)

# ---------- lights ----------
def area(name, loc, rot, energy, color, size):
    d = bpy.data.lights.new(name, "AREA"); d.energy = energy; d.color = color; d.size = size
    o = bpy.data.objects.new(name, d); sc.collection.objects.link(o)
    o.location = loc; o.rotation_euler = [math.radians(a) for a in rot]
    return o
area("Key", (-4, -8, 7), (50, 0, -25), 500, (1.0, 0.95, 0.9), 4)
area("RimL", (-6, 4, 7), (45, 0, -130), 450, (0.3, 0.6, 1.0), 2)
area("RimR", (6, 4, 7), (45, 0, 130), 450, (1.0, 0.45, 0.25), 2)

# ---------- camera: slow dolly-in ----------
cd = bpy.data.cameras.new("Cam"); cd.lens = 40
cd.dof.use_dof = True; cd.dof.aperture_fstop = 4.0
cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam); sc.camera = cam
target = bpy.data.objects.new("CamTarget", None); sc.collection.objects.link(target)
target.location = (0, 0, 0.2)
cd.dof.focus_object = target
c = cam.constraints.new("TRACK_TO"); c.target = target; c.track_axis = "TRACK_NEGATIVE_Z"; c.up_axis = "UP_Y"
cam.location = (0.9, -17.0, 2.2); cam.keyframe_insert("location", frame=1)
cam.location = (0.0, -10.5, 1.0); cam.keyframe_insert("location", frame=F_END)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points:
        kp.interpolation = "SINE"; kp.easing = "EASE_IN_OUT"
# focus follows the text once it arrives
target.location = (0, 0, 0.2); target.keyframe_insert("location", frame=TEXT_FRAME - 1)
target.location = (0, -1.2, 0.2); target.keyframe_insert("location", frame=TEXT_FRAME + 6)

# ---------- compositor bloom (Eevee Next removed the render bloom toggle) ----------
sc.use_nodes = True
cn = sc.node_tree; cn.nodes.clear()
rl = cn.nodes.new("CompositorNodeRLayers")
gl = cn.nodes.new("CompositorNodeGlare")
try:
    gl.glare_type = "BLOOM"
except TypeError:
    gl.glare_type = "FOG_GLOW"
gl.quality = "HIGH"; gl.threshold = 0.85; gl.size = 8; gl.mix = 0.0
lens = cn.nodes.new("CompositorNodeLensdist"); lens.inputs["Dispersion"].default_value = 0.012
comp = cn.nodes.new("CompositorNodeComposite")
cn.links.new(rl.outputs["Image"], gl.inputs["Image"])
cn.links.new(gl.outputs["Image"], lens.inputs["Image"])
cn.links.new(lens.outputs["Image"], comp.inputs["Image"])

# timing info for the audio step
with open(os.path.join(OUT, "timing.json"), "w") as f:
    json.dump({"fps": FPS, "frames": F_END, "text_frame": TEXT_FRAME,
               "hit_seconds": (TEXT_FRAME - 1) / FPS}, f)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))

# ---------- render ----------
if os.environ.get("PREVIEW"):
    fr = int(os.environ["PREVIEW"])
    sc.frame_set(fr)
    sc.render.filepath = os.path.join(OUT, "scratch", f"preview_{fr:04d}.png")
    bpy.ops.render.render(write_still=True)
else:
    sc.frame_start = int(os.environ.get("FRAME_START", 1))
    sc.frame_end = int(os.environ.get("FRAME_END", F_END))
    bpy.ops.render.render(animation=True)
