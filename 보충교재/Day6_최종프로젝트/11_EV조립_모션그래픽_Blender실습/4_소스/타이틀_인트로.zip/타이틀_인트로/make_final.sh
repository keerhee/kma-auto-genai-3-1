#!/usr/bin/env bash
# renders/frame_####.png + sfx/hit.wav -> final.mp4 (hit synced to text_frame in timing.json)
set -euo pipefail
cd "$(dirname "$0")"
FPS=$(python3 -c "import json;print(json.load(open('timing.json'))['fps'])")
HIT_MS=$(python3 -c "import json;print(round(json.load(open('timing.json'))['hit_seconds']*1000))")
DUR=$(python3 -c "import json;d=json.load(open('timing.json'));print(d['frames']/d['fps'])")

ffmpeg -y -loglevel error \
  -framerate "$FPS" -start_number 1 -i renders/frame_%04d.png \
  -i sfx/hit.wav \
  -filter_complex "[1:a]adelay=${HIT_MS}|${HIT_MS},apad,atrim=0:${DUR}[a]" \
  -map 0:v -map "[a]" \
  -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -movflags +faststart \
  -c:a aac -b:a 192k -t "$DUR" final.mp4
echo "final.mp4 written (hit at ${HIT_MS} ms)"
