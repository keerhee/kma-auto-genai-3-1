# IC Roast Room (투자위원회 에디션)

![IC Roast Room](docs/room.png)

연기금·국부펀드·공제회·보험사 같은 기관투자가의 투자위원회(IC) 안건을 가상 위원 7명이 토론하고, 점수가 붙은 판정과 PDF 보고서를 돌려주는 Claude Code 스킬입니다. [nateherkai/roast-room](https://github.com/nateherkai/roast-room)(MIT)을 기관투자가용으로 개작했습니다.

| 위원 | 담당 영역 | 위원이 붙드는 질문 |
|---|---|---|
| David Swensen | 정책 포트폴리오·대체투자 | 정책 포트폴리오에 들어갈 자산인가, 운용사 선별 역량이 실제로 있는가? |
| Ray Dalio | 매크로 국면·리스크 균형 | 성장·물가 국면별로 어떻게 움직이며, 정말 분산이 되는가? |
| Howard Marks | 사이클·신용·위험의 가격 | 지금 사이클의 어디에 있고, 감수하는 위험만큼 보상받는가? |
| John Bogle | 비용·수수료·실행 | 보수·거래비용·마찰이 총수익에서 얼마를 가져가는가? |
| Cliff Asness | 증거·팩터 프리미엄 | 프리미엄이 비용과 쏠림을 넘어 실재한다는 견고한 증거가 있는가? |
| Keith Ambachtsheer | 거버넌스·수탁자 책임 | 부진한 구간을 거버넌스가 버틸 수 있고, 수익자에게 도움이 되는가? |
| Nassim Taleb | 꼬리위험·유동성 | 꼬리 국면에서 무슨 일이 생기며, 강제 매도 없이 살아남는가? |

## 필요한 것

- [Claude Code](https://claude.com/claude-code) (구독 플랜으로 동작, API 키 불필요)
- [Node.js](https://nodejs.org) 20 이상 (회의실 화면용, 별도 설치 패키지 없음)

## 실행

```bash
cd ic-roast-room
npm start            # 브라우저에서 http://localhost:4730
claude               # 다른 터미널에서
/roast-room <안건>
```

1. 의장(Claude Code)이 빠진 정보를 묻습니다.
2. 위원 7명이 3라운드(첫 발언 → 토론 → 표결)로 논쟁하고, 화면에서는 캐릭터가 입을 움직이며 발언합니다.
3. 판정(GO, GO WITH CONDITIONS, RESHAPE, WAIT, DON'T DO IT)이 나오면 "PDF 내려받기"를 누릅니다. 전체 보고서는 `sessions/<날짜>-<안건>/verdict.md`에 저장됩니다.

옵션:

- `/roast-room --quick ...` 위원 4명, 2라운드. 사용량이 크게 줄어듭니다.
- `/roast-room --seats marks,taleb ...` 지정한 위원만 참석.
- `/roast-room ask dalio ...` 위원 한 명에게만 질문.

## 안건 작성 요령

결정 사항 한 줄, 선택지 2~3개("현 정책 유지" 포함), 기관 숫자(AUM, 현재 SAA와 해당 자산 비중, 부채·지급 의무, 해외 비중), 제약(IPS 한도, 유동성 예산, 승인 절차), 성공 기준과 벤치마크, 팀의 의견과 이유.

```
/roast-room 운용자산 200조 원 공적연금입니다. 사모신용 비중을 3%에서 6%로 2년 안에 늘릴지,
3개 빈티지로 4.5%까지 나눠 갈지, 현 3%를 유지할지 결정해야 합니다. 대체투자 미집행 약정이
총자산의 4%, 연간 급여 지급은 3%입니다. 목표는 10년 기준 정책 벤치마크 대비 연 30bp 초과이고,
팀은 즉시 확대 쪽입니다.
```

## 원본과 달라진 점

- **좌석 7개 교체.** 창업자 자문단(Bezos, Hormozi 등)을 기관투자 위원으로 바꿨습니다. 각 위원의 brain(`.claude/skills/roast-room/brains/<slug>/`)은 책·서한·메모·논문·증언·인터뷰를 출처 번호와 함께 요약한 것입니다. 저작권과 정확성을 위해 **직접 인용은 넣지 않았고**, 위원은 실제 인물의 말을 따옴표로 지어내지 않습니다. 출처 목록과 검증하지 못한 항목은 각 `sources.md`에 있습니다.
- **채점 규칙.** RUIN RISK를 "강제 매도, 유동성·자금 조달 위기, IPS·수탁자 책임 위반, 회복 불가능한 손실"로 재정의했습니다. 간이 위원회의 하방 점검석은 Taleb 또는 Ambachtsheer입니다.
- **한국어.** 안건을 한국어로 쓰면 카드·판정·보고서가 한국어로 나옵니다(필드 이름과 판정 라벨은 화면 파싱용으로 영어 유지). 화면 UI를 한국어로 옮겼고, PDF에는 한글 글꼴(Noto Sans KR)을 넣었습니다.
- **캐릭터와 입모양.** 위원 캐릭터를 새로 그렸습니다(`app/scripts/portraits.py`로 다시 생성). 실제 얼굴을 닮게 그리지 않고 머리 모양·안경·수염·옷으로 구분합니다. 다문 입·벌린 입·오므린 입·깜빡임 4종이 있어, 발언 자막의 모음에 맞춰 입이 움직입니다. 한글은 음절의 모음(ㅏ·ㅓ·ㅣ 계열은 벌린 입, ㅗ·ㅜ·ㅡ 계열은 오므린 입)과 받침 ㅁ·ㅂ·ㅍ(입 다묾)을 읽어 맞춥니다. 발언 중인 위원에게는 좌석 색 후광과 말풍선이 붙습니다.
- 원본의 로고와 브랜드 표기는 뺐습니다.

## 위원 추가·교체

`.claude/skills/roast-room/references/brain-spec.md`의 규격대로 brain 폴더와 `.claude/agents/council-<key>.md`를 만들고, `app/lib/seats.mjs`의 `SEATS`, `references/seats.md`, `references/scoring.md`의 표, `app/scripts/portraits.py`의 `SEATS`를 함께 고칩니다.

## 음성과 위원 지정

- **음성으로 듣기.** 로컬 [Voicebox](http://127.0.0.1:17493)가 켜져 있으면 오른쪽 위 "음성 끔" 버튼이 살아납니다. 누르면 위원 발언과 의장의 의결안·판정을 복제 음성으로 읽고, 자막과 입모양이 음성에 맞춰 움직입니다. Voicebox는 실제 음성 길이보다 3~4배 오래 걸리므로 발언 카드가 도착하는 즉시 미리 만들고, 만든 음성은 `.tts-cache/`에 저장해 다시 보기 때 바로 재생합니다. 위원별 음성은 `.env`의 `VOICEBOX_VOICES`로 바꿉니다(형식: `위원:Voicebox 프로필 이름:높낮이`, 예: `swensen:매튜리:1,taleb:JW Choi:0.93`). 기본 배정은 의장 Kay Rhee, Swensen·Asness·Marks 매튜리, Dalio·Ambachtsheer 빌조쉬, Bogle·Taleb JW Choi이며, 같은 목소리를 쓰는 위원은 높낮이를 달리합니다.
- **말로 입력.** 안건 입력창의 "말로 입력" 버튼(Chrome·Edge)을 누르고 말하면 글로 받아 적습니다. 브라우저의 음성 인식 서비스를 쓰므로 음성이 Google(Edge는 Microsoft) 서버로 전송됩니다.
- **위원 지정.** 입력창 아래에서 "위원 지정"을 고르고 참석할 위원을 2명 이상 선택합니다. API 키가 없으면 버튼이 "Claude Code 명령 복사"로 바뀌어 `/roast-room --seats ... <안건>` 명령을 복사해 주고, Claude Code에 붙여넣으면 회의가 이 화면에서 재생됩니다.

## 선택: 화면에서 직접 회의 열기

`.env.example`을 `.env`로 복사하고 `ANTHROPIC_API_KEY`와 `COUNCIL_RUNNER=api`를 넣은 뒤 `npm start`를 다시 실행하면 화면에서 안건을 바로 입력할 수 있습니다. 이 방식은 Anthropic API 계정에 과금됩니다(전체 위원회 1회에 약 25회 호출).

## 위원에 대해

위원은 각 인물의 공개 저작을 요약해 만든 시뮬레이션입니다. 실제 인물이 아니며, 그들의 견해를 대변하지 않고, 이 프로젝트와 관련이 없습니다. 결과는 투자 권유가 아닙니다.

코드는 MIT 라이선스(`LICENSE`)입니다. PDF 빌더는 [jsPDF](https://github.com/parallax/jsPDF)(MIT), Montserrat와 Noto Sans CJK(SIL Open Font License)를 포함하며 라이선스 파일은 `app/public/` 아래에 있습니다.
