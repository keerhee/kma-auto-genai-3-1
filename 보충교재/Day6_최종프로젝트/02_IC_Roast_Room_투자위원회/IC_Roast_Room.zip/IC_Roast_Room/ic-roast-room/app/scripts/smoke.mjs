// Smoke test: one Chair setup call and one seat card, no full council.
import { SEATS, systemFor, parseCard, checkQuotes } from "../lib/seats.mjs";
import * as ai from "../lib/anthropic.mjs";
import { MODELS } from "../lib/council.mjs";

const sys = systemFor("marks");
console.log("marks system chars:", sys[0].text.length);

const t0 = Date.now();
const card = await ai.stream({
  model: MODELS.seat, system: sys, maxTokens: 900,
  messages: [{ role: "user", content: `ROAST ROOM COUNCIL, ROUND 1 OF 3: OPENING POSITION
You hold the MARKS seat. THE BRIEF: A KRW 200tn public pension fund holds 3% in private credit and the team proposes raising it to 6% over two years. Options: (A) go to 6% now, (B) phase to 4.5% over three vintages, (C) keep 3%.
Answer under 200 words in this shape:
SEAT: MARKS
STANCE: ...
OPTION SCORES: A n/10 · B n/10 · C n/10
PILLAR SCORE: n/10
CONFIDENCE: n/5
RUIN RISK: none | possible | likely
DOOR: one-way | two-way
THE CALL: one sentence.
WHY: 1. with a framework and source id, e.g. (Pendulum, S014)` }],
});
console.log(`seat card in ${((Date.now() - t0) / 1000).toFixed(1)}s\n`, card);
console.log(parseCard(card, ["A", "B", "C"]));
console.log(checkQuotes("marks", card));
console.log(ai.usage);
