"""Draw the seat portraits: stylized cartoon busts, four mouth/eye states each.

Run: python3 app/scripts/portraits.py   (needs: pip install cairosvg pillow)
Writes app/public/portraits/<key>-{base,open,mid,blink}.webp (560x560, transparent).

The characters are generic archetypes told apart by hair, glasses, beard and clothes.
They are not likenesses of the real people.
"""
import io
from pathlib import Path

import cairosvg
from PIL import Image

OUT = Path(__file__).resolve().parents[1] / "public" / "portraits"

SEATS = {
    # skin, hair colour, hair style, glasses, beard, outfit, suit, shirt, tie, age lines, brow
    "swensen": dict(skin="#f2c9a5", hair="#b9b4ad", style="side", glasses="rect", beard=None, outfit="suit", suit="#24324f", shirt="#eef3fb", tie="#2f6fd6", lines=1),
    "dalio": dict(skin="#efc39d", hair="#c9c4bd", style="receding", glasses=None, beard=None, outfit="open", suit="#2b2b30", shirt="#dfe6ee", tie=None, lines=2),
    "marks": dict(skin="#f0c4a0", hair="#a8a29a", style="bald", glasses="round", beard=None, outfit="suit", suit="#5a6170", shirt="#ffffff", tie="#c0392b", lines=1),
    "bogle": dict(skin="#f3cdb0", hair="#eeeeee", style="full", glasses=None, beard=None, outfit="bow", suit="#3a4458", shirt="#ffffff", tie="#7d3c98", lines=3),
    "asness": dict(skin="#efc29b", hair="#4a3b33", style="short", glasses="rect_dark", beard="stubble", outfit="tee", suit="#3c4a5c", shirt="#1f2a36", tie=None, lines=0),
    "ambachtsheer": dict(skin="#f2c8a8", hair="#e6e3df", style="side_white", glasses="round", beard="full", outfit="tweed", suit="#7a6248", shirt="#e8efe8", tie="#1f8a5e", lines=2),
    "taleb": dict(skin="#d9a87c", hair="#8c8681", style="shaved", glasses=None, beard="short", outfit="tee", suit="#1b1d22", shirt="#0f1013", tie=None, lines=1),
}

INK = "#2a1a14"


def darker(hex_, f=0.82):
    h = hex_.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return "#%02x%02x%02x" % (int(r * f), int(g * f), int(b * f))


def hair_paths(style, c):
    d = darker(c, 0.85)
    if style == "side":
        return f'''<path d="M163 232 C150 140 215 88 288 86 C365 86 412 140 398 232 C392 200 380 176 360 160 C320 172 270 150 236 128 C222 150 196 170 176 196 Z" fill="{c}"/>
<path d="M236 128 C262 146 300 158 360 160" stroke="{d}" stroke-width="5" fill="none" stroke-linecap="round"/>'''
    if style == "side_white":
        return f'''<path d="M162 236 C146 140 212 84 286 82 C366 84 414 140 400 236 C394 196 378 170 352 156 C316 150 280 146 248 132 C220 150 190 176 172 206 Z" fill="{c}"/>
<path d="M248 132 C270 120 320 118 352 156" stroke="{d}" stroke-width="4" fill="none" stroke-linecap="round"/>'''
    if style == "receding":
        return f'''<path d="M162 236 C152 186 166 150 196 128 C206 160 196 200 186 236 Z" fill="{c}"/>
<path d="M398 236 C408 186 394 150 364 128 C354 160 364 200 374 236 Z" fill="{c}"/>
<path d="M220 112 C250 100 310 100 340 112 C320 118 300 120 280 119 C260 120 240 118 220 112 Z" fill="{c}" opacity="0.9"/>'''
    if style == "bald":
        return f'''<path d="M160 250 C152 210 160 180 178 160 C186 190 186 222 180 256 Z" fill="{c}"/>
<path d="M400 250 C408 210 400 180 382 160 C374 190 374 222 380 256 Z" fill="{c}"/>
<ellipse cx="248" cy="128" rx="34" ry="14" fill="#ffffff" opacity="0.28"/>'''
    if style == "full":
        return f'''<path d="M156 250 C134 150 200 78 284 76 C372 76 432 150 404 250 C398 214 392 190 380 172 C350 150 330 132 300 122 C268 138 232 140 206 132 C186 156 172 190 164 230 Z" fill="{c}"/>
<path d="M150 236 C140 210 146 186 160 170" stroke="{d}" stroke-width="10" fill="none" stroke-linecap="round"/>
<path d="M410 236 C420 210 414 186 400 170" stroke="{d}" stroke-width="10" fill="none" stroke-linecap="round"/>'''
    if style == "short":
        return f'''<path d="M164 220 C156 140 214 92 286 92 C360 92 408 140 398 220 C390 186 376 160 350 146 C310 136 254 136 214 148 C190 162 172 186 164 220 Z" fill="{c}"/>
<path d="M214 148 C250 122 314 124 350 146" stroke="#8a7a70" stroke-width="3" fill="none" opacity="0.6"/>'''
    if style == "shaved":
        return f'''<path d="M166 214 C166 134 222 92 282 92 C346 92 398 134 396 214 C384 160 340 120 282 118 C222 120 178 160 166 214 Z" fill="{c}" opacity="0.35"/>
<ellipse cx="252" cy="122" rx="36" ry="13" fill="#ffffff" opacity="0.25"/>'''
    return ""


def glasses(kind):
    if not kind:
        return ""
    stroke = "#1d1d1f" if kind == "rect_dark" else "#5b5f66"
    w = 7 if kind == "rect_dark" else 5
    if kind == "round":
        lens = f'''<circle cx="236" cy="226" r="31" fill="#ffffff" fill-opacity="0.12" stroke="{stroke}" stroke-width="{w}"/>
<circle cx="324" cy="226" r="31" fill="#ffffff" fill-opacity="0.12" stroke="{stroke}" stroke-width="{w}"/>'''
    else:
        lens = f'''<rect x="200" y="200" width="70" height="52" rx="14" fill="#ffffff" fill-opacity="0.12" stroke="{stroke}" stroke-width="{w}"/>
<rect x="290" y="200" width="70" height="52" rx="14" fill="#ffffff" fill-opacity="0.12" stroke="{stroke}" stroke-width="{w}"/>'''
    return lens + f'''<path d="M270 222 Q280 214 290 222" stroke="{stroke}" stroke-width="{w}" fill="none"/>
<path d="M200 220 L168 214 M360 220 L392 214" stroke="{stroke}" stroke-width="{w}" stroke-linecap="round"/>'''


def beard(kind, c, skin):
    if kind == "stubble":
        return f'<path d="M180 270 C190 340 236 372 280 374 C324 372 370 340 380 270 C360 320 330 340 280 342 C230 340 200 320 180 270 Z" fill="{c}" opacity="0.28"/>'
    if kind == "short":
        return f'''<path d="M176 262 C184 344 230 382 280 384 C330 382 376 344 384 262 C368 312 336 328 280 330 C224 328 192 312 176 262 Z" fill="{c}"/>
<path d="M244 286 C258 278 302 278 316 286 C304 292 256 292 244 286 Z" fill="{c}"/>'''
    if kind == "full":
        return f'''<path d="M170 252 C172 350 222 398 280 400 C338 398 388 350 390 252 C372 306 340 326 280 328 C220 326 188 306 170 252 Z" fill="{c}"/>
<path d="M236 290 C254 274 306 274 324 290 C306 298 254 298 236 290 Z" fill="{c}"/>'''
    return ""


def mouth(state, has_beard):
    lip = "#8f3b2e"
    if state == "open":
        return f'''<path d="M246 296 Q280 290 314 296 Q312 340 280 344 Q248 340 246 296 Z" fill="#4a1714" stroke="{lip}" stroke-width="4" stroke-linejoin="round"/>
<path d="M252 298 Q280 294 308 298 L306 308 Q280 304 254 308 Z" fill="#ffffff"/>
<ellipse cx="280" cy="332" rx="20" ry="9" fill="#e06a6a"/>'''
    if state == "mid":
        return f'''<ellipse cx="280" cy="310" rx="14" ry="17" fill="#4a1714" stroke="{lip}" stroke-width="4"/>
<ellipse cx="280" cy="320" rx="8" ry="5" fill="#e06a6a"/>'''
    # base and blink: closed, gentle smile
    return f'<path d="M250 302 Q280 322 310 302" stroke="{lip}" stroke-width="6" fill="none" stroke-linecap="round"/>'


def eyes(state):
    if state == "blink":
        return f'''<path d="M220 228 Q236 238 252 228" stroke="{INK}" stroke-width="5" fill="none" stroke-linecap="round"/>
<path d="M308 228 Q324 238 340 228" stroke="{INK}" stroke-width="5" fill="none" stroke-linecap="round"/>'''
    return f'''<ellipse cx="236" cy="226" rx="17" ry="14" fill="#ffffff"/>
<ellipse cx="324" cy="226" rx="17" ry="14" fill="#ffffff"/>
<circle cx="238" cy="227" r="9" fill="#3b2a22"/><circle cx="326" cy="227" r="9" fill="#3b2a22"/>
<circle cx="241" cy="223" r="3" fill="#ffffff"/><circle cx="329" cy="223" r="3" fill="#ffffff"/>'''


def outfit(o, suit, shirt, tie):
    lap = darker(suit, 0.78)
    body = f'<path d="M48 560 C58 450 140 404 280 400 C420 404 502 450 512 560 Z" fill="{suit}"/>'
    if o in ("suit", "bow", "tweed"):
        s = body + f'<path d="M226 404 L280 496 L334 404 Z" fill="{shirt}"/>'
        if o == "tweed":
            s += "".join(f'<path d="M{x} 430 L{x+20} 560" stroke="{darker(suit,0.9)}" stroke-width="3" opacity="0.5"/>' for x in range(70, 500, 34))
        if o == "bow":
            s += f'<path d="M280 420 L246 404 L246 438 Z M280 420 L314 404 L314 438 Z" fill="{tie}"/><circle cx="280" cy="420" r="9" fill="{darker(tie)}"/>'
        else:
            s += f'<path d="M268 410 L292 410 L288 430 L272 430 Z" fill="{darker(tie)}"/><path d="M272 430 L288 430 L298 500 L280 520 L262 500 Z" fill="{tie}"/>'
        s += f'<path d="M226 404 L280 500 L238 560 L196 430 Z" fill="{lap}"/><path d="M334 404 L280 500 L322 560 L364 430 Z" fill="{lap}"/>'
        return s
    if o == "open":
        return body + f'''<path d="M228 404 L280 474 L332 404 Z" fill="{shirt}"/>
<path d="M228 404 L262 452 L248 470 L214 420 Z M332 404 L298 452 L312 470 L346 420 Z" fill="#ffffff"/>
<path d="M228 404 L280 500 L238 560 L196 430 Z" fill="{lap}"/><path d="M332 404 L280 500 L322 560 L364 430 Z" fill="{lap}"/>'''
    # tee under blazer
    return body + f'''<path d="M220 404 C240 440 320 440 340 404 L364 560 L196 560 Z" fill="{shirt}"/>
<path d="M230 408 C250 430 310 430 330 408" stroke="{darker(shirt,0.7)}" stroke-width="4" fill="none"/>
<path d="M220 404 L250 560 L190 560 L180 440 Z" fill="{lap}"/><path d="M340 404 L310 560 L370 560 L380 440 Z" fill="{lap}"/>'''


def svg(p, state):
    skin = p["skin"]
    sk2 = darker(skin, 0.88)
    lines = "".join(
        f'<path d="M{236 - i*4} {158 + i*12} Q280 {150 + i*12} {324 + i*4} {158 + i*12}" stroke="{sk2}" stroke-width="3" fill="none" stroke-linecap="round"/>'
        for i in range(p["lines"])
    )
    brow_c = darker(p["hair"], 0.7) if p["hair"] not in ("#eeeeee", "#e6e3df") else "#b8b2aa"
    brows = f'''<path d="M212 196 Q236 184 260 194" stroke="{brow_c}" stroke-width="9" fill="none" stroke-linecap="round"/>
<path d="M300 194 Q324 184 348 196" stroke="{brow_c}" stroke-width="9" fill="none" stroke-linecap="round"/>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="560" height="560" viewBox="0 0 560 560">
<defs><radialGradient id="g" cx="0.45" cy="0.38" r="0.7"><stop offset="0" stop-color="{skin}"/><stop offset="1" stop-color="{sk2}"/></radialGradient></defs>
<g transform="translate(280 560) scale(1.14) translate(-280 -560)">
{outfit(p["outfit"], p["suit"], p["shirt"], p["tie"])}
<path d="M246 320 L314 320 L320 412 C300 424 260 424 240 412 Z" fill="{sk2}"/>
<ellipse cx="166" cy="244" rx="20" ry="28" fill="{sk2}"/><ellipse cx="394" cy="244" rx="20" ry="28" fill="{sk2}"/>
<ellipse cx="280" cy="232" rx="118" ry="140" fill="url(#g)"/>
{hair_paths(p["style"], p["hair"])}
{lines}
{beard(p["beard"], p["hair"], skin)}
<ellipse cx="214" cy="272" rx="18" ry="10" fill="#e88a7a" opacity="0.28"/><ellipse cx="346" cy="272" rx="18" ry="10" fill="#e88a7a" opacity="0.28"/>
{eyes(state)}
{brows}
<path d="M280 236 Q270 268 264 276 Q280 284 296 276" stroke="{darker(skin,0.72)}" stroke-width="4" fill="none" stroke-linecap="round"/>
{mouth(state, bool(p["beard"]))}
{glasses(p["glasses"])}
</g>
</svg>'''


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for key, p in SEATS.items():
        for state in ("base", "open", "mid", "blink"):
            png = cairosvg.svg2png(bytestring=svg(p, state).encode(), output_width=560, output_height=560)
            Image.open(io.BytesIO(png)).save(OUT / f"{key}-{state}.webp", "WEBP", quality=92, method=6)
    print("wrote", len(SEATS) * 4, "portraits to", OUT)


if __name__ == "__main__":
    main()
