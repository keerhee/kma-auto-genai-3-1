import { downloadVerdictPdf } from "./pdf.js";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const SAMPLES = [
  ["사모신용 비중 확대?", "운용자산 200조 원 규모 공적연금입니다. 사모신용 비중이 3%인데 운용팀은 2년 안에 6%로 늘리자고 합니다. 선택지: 6%로 즉시 확대(2년 내 약정), 3개 빈티지에 걸쳐 4.5%까지 분할, 현 3% 유지. 대체투자 미집행 약정이 이미 총자산의 4%이고 해외자산 비중은 60%입니다. 목표는 10년 기준 정책 벤치마크 대비 연 30bp 초과. 팀은 즉시 확대 쪽으로 기울어 있습니다."],
  ["환헤지 비율 조정?", "해외자산 비중 55%인 국부펀드입니다. 현재 해외주식은 무헤지, 해외채권은 100% 헤지입니다. 원화 강세 전망 보고서가 나오면서 해외주식 헤지 비율을 0%에서 30%로 올리자는 안이 올라왔습니다. 선택지: 30% 헤지, 10% 시범 헤지 후 재검토, 현 정책 유지. 헤지 비용은 연 1.5%p 수준이고 유동성 버퍼는 총자산의 3%입니다."],
  ["팩터 틸트 도입?", "국내외 상장주식 80조 원을 대부분 패시브로 운용하는 연기금입니다. 밸류·퀄리티·모멘텀 멀티팩터로 20%를 전환하자는 안건입니다. 선택지: 20% 전환, 외부위탁 5% 시범 운용, 현행 패시브 유지. 추적오차 한도는 1%이고, 위원회는 3년 이상 부진하면 철회 압박을 받아 왔습니다."],
  ["꼬리위험 헤지?", "적립금 50조 원 공제회입니다. 2022년 주식·채권 동반 하락 이후 상시 테일 헤지 프로그램(풋옵션, 연 비용 0.5%) 도입이 논의됩니다. 선택지: 상시 프로그램 도입, 위기 신호 시에만 가동하는 조건부 헤지, 리밸런싱 규칙과 유동성 버퍼 강화만 하기. 연간 지급 의무는 총자산의 4%입니다."],
];

const EXAMPLE = "운용자산 200조 원 공적연금입니다. 사모신용 비중을 3%에서 6%로 2년 안에 늘릴지, 3개 빈티지로 4.5%까지 나눠 갈지, 현 3%를 유지할지 결정해야 합니다. 대체투자 미집행 약정이 총자산의 4%, 연간 급여 지급은 3%입니다. 목표는 10년 기준 정책 벤치마크 대비 연 30bp 초과이고, 팀은 즉시 확대 쪽입니다.";

// The how-to, shown in the side panel while the room is empty and in "How it works".
const GUIDE = `
  <div class="guide">
    <div class="guide-sec">
      <h4>IC Roast Room 사용법</h4>
      <ol>
        <li><span>이 폴더에서 Claude Code를 엽니다.</span></li>
        <li><span><code>/roast-room</code> 뒤에 안건을 입력합니다.</span></li>
        <li><span>의장의 질문에 답하면, 위원회가 이 화면에서 토론을 벌입니다.</span></li>
        <li><span>판정이 나오면 PDF로 내려받습니다.</span></li>
      </ol>
    </div>
    <div class="guide-sec">
      <h4>안건에 넣을 내용</h4>
      <ul>
        <li><span><b>결정 사항</b> 한 줄.</span></li>
        <li><span><b>선택지</b> 2~3개. "현 정책 유지"도 선택지입니다.</span></li>
        <li><span><b>기관 숫자</b>: AUM, 현재 SAA와 해당 자산 비중, 부채·지급 의무, 해외 비중.</span></li>
        <li><span><b>제약</b>: IPS 한도, 유동성 예산, 승인 절차, 일정.</span></li>
        <li><span><b>성공 기준</b>과 평가 기간, 비교 벤치마크.</span></li>
        <li><span><b>팀의 의견</b>과 그 이유. 위원회는 이것을 검증합니다.</span></li>
      </ul>
      <p class="note" style="margin-top:8px">빠진 내용은 의장이 회의 전에 물어봅니다.</p>
    </div>
    <div class="guide-sec">
      <h4>예시</h4>
      <div class="example">
        <p><code>/roast-room</code> ${EXAMPLE.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</p>
        <button class="ghost" type="button" data-copy-example>예시 복사</button>
      </div>
    </div>
    <div class="guide-sec">
      <h4>알아둘 점</h4>
      <ul>
        <li><span><b>전체 위원회:</b> 위원 7명, 3라운드. SAA·IPS 변경, 다년 약정처럼 되돌리기 어려운 결정용.</span></li>
        <li><span><b>간이 위원회:</b> <code>--quick</code>을 붙이면 4명, 2라운드. 사용량이 훨씬 적습니다.</span></li>
        <li><span><b>모든 회의는 저장됩니다.</b> 지난 회의에서 다시 보거나 PDF를 받을 수 있습니다.</span></li>
        <li><span>위원은 공개 저작을 요약해 만든 가상 인물이며, 결과는 투자 권유가 아닙니다.</span></li>
      </ul>
    </div>
  </div>`;

const SHAPES = ["base", "open", "mid", "blink"];
const portrait = (key, shape = "base") => `/portraits/${key}-${shape}.webp`;
const ROUND_NAME = ["", "첫 발언", "토론", "표결"];

const state = {
  seats: [], byKey: {}, session: null, options: [], weights: {}, active: [], round: 0,
  cards: { 1: {}, 2: {}, 3: {} }, replaying: false, verdict: null, links: [], geo: {}, setup: null, wait: null,
};

// ------------------------------------------------------------- boot
async function boot() {
  const r = await fetch("/api/seats").then((x) => x.json());
  state.seats = r.seats;
  state.byKey = Object.fromEntries(r.seats.map((s) => [s.key, s]));
  state.runner = r.runner;
  if (r.runner === "api" && !r.hasKey) toast("No ANTHROPIC_API_KEY found in .env. Add it and restart the server.");
  renderSeats();
  renderSamples();
  renderSeatPick();
  bindUI();
  setupMic();
  voice.init();
  new ResizeObserver(() => { layoutStage(); drawLinks(); }).observe($("#stage"));
  startBlinking();
  reset();
  typeIn($("#composer h2"));
  typeIn($("#waiting h2"));
  const ss = await fetch("/api/sessions").then((x) => x.json());
  if (ss.running) attach(ss.running);
  else if (ss.live) attach(ss.live);
  refreshUsage();
  setInterval(watchForLive, 2500);
  setInterval(tickWait, 1000);
}

// a council started in Claude Code shows up here on its own
const seenLive = new Set();
async function watchForLive() {
  const ss = await fetch("/api/sessions").then((x) => x.json()).catch(() => null);
  const id = ss?.live || ss?.running;
  if (!id || seenLive.has(id) || id === state.session) return;
  seenLive.add(id);
  attach(id);
}

// AIS arrival: a heading types in a character at a time, blur to sharp
function typeIn(el) {
  if (!el) return;
  const text = el.textContent;
  el.classList.add("typein");
  // characters sit inside a nowrap span per word, so lines only break between words
  let i = 0;
  el.innerHTML = text.split(" ").map((word) => `<span class="wd">${[...word].map((c) => `<span class="ch" style="animation-delay:${i++ * 22}ms">${esc(c)}</span>`).join("")}</span>`).join(" ");
  el.setAttribute("aria-label", text);
}

function renderSamples() {
  $("#samples").innerHTML = SAMPLES.map(([t], i) => `<button type="button" data-i="${i}">${esc(t)}</button>`).join("");
  $("#samples").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    $("#prompt").value = SAMPLES[b.dataset.i][1];
    $("#prompt").focus();
  });
}

function renderSeats() {
  $("#seats").innerHTML = state.seats.map((s, i) => `
    <div class="seat" id="seat-${s.key}" data-seat="${s.key}" style="--d:-${(i * 1.7) % 6}s;--c:${s.color}" tabindex="0" role="button" aria-label="${esc(s.name)}, ${esc(s.pillarKo || s.pillar)}. 카드 열기">
      <div class="think" aria-hidden="true"><i></i><i></i><i></i></div>
      <div class="say" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
      <div class="bust" data-shape="base">${SHAPES.map((sh) => `<img class="${sh}" src="${portrait(s.key, sh)}" alt="" draggable="false">`).join("")}</div>
    </div>`).join("");
  $("#plates").innerHTML = state.seats.map((s) => `
    <div class="nameplate" id="plate-${s.key}" data-seat="${s.key}" style="--c:${s.color}">
      <b>${esc(s.short === "Gary V" ? "Gary V" : s.name)}</b>
      <small>${esc(s.pillarKo || s.pillar)}</small>
      <div class="meta"><span class="pips" title="이 안건에서의 가중치"></span><span class="chip" hidden></span><span class="score" hidden></span></div>
    </div>`).join("");
  layoutStage();
}

// The table is an ellipse seen from the front. Seats sit along its far edge: the
// middle seat is farthest (higher, smaller), the end seats nearest (lower, bigger).
function layoutStage() {
  const stage = $("#stage");
  const W = stage.clientWidth;
  const narrow = matchMedia("(max-width: 820px)").matches;
  const H = narrow ? Math.round(W * 0.62) : stage.clientHeight;
  const cx = W / 2, cy = H * (narrow ? 0.98 : 0.9), rx = W * 0.48, ry = H * (narrow ? 0.46 : 0.42);
  const t = $("#table");
  Object.assign(t.style, { left: `${cx - rx}px`, top: `${cy - ry}px`, width: `${rx * 2}px`, height: `${ry * 2}px` });
  const edge = (x) => cy - ry * Math.sqrt(Math.max(0, 1 - ((x - cx) / rx) ** 2));
  const xs = [0.085, 0.222, 0.361, 0.5, 0.639, 0.778, 0.915];
  state.seats.forEach((s, i) => {
    const x = W * xs[i];
    const d = ((x - cx) / rx) ** 2;
    const size = H * (narrow ? 0.5 + 0.08 * d : 0.37 + 0.07 * d);
    const bottom = edge(x) + size * 0.2;
    const el = $(`#seat-${s.key}`);
    Object.assign(el.style, { left: `${x - size / 2}px`, top: `${bottom - size}px`, width: `${size}px`, height: `${size}px`, zIndex: 10 + Math.round(d * 10) });
    const pl = $(`#plate-${s.key}`);
    pl.style.left = `${x}px`;
    pl.style.top = `${edge(x) + H * 0.01}px`; // straddles the table edge, over the chest
    state.geo[s.key] = { x, head: bottom - size * 0.72, top: bottom - size * 0.9, size };
  });
  const c = $("#center");
  if (narrow) {
    stage.style.paddingTop = `${H}px`; // the scene sits on top; captions flow below it
  } else {
    stage.style.paddingTop = "";
    // the captions start below the lowest nameplate they could collide with
    const inner = [1, 2, 3, 4, 5].map((i) => $(`#plate-${state.seats[i].key}`));
    const top = Math.max(...inner.map((p) => p.offsetTop + p.offsetHeight / 2)) + H * 0.035;
    Object.assign(c.style, { left: `${W * 0.2}px`, width: `${W * 0.6}px`, top: `${top}px`, height: `${H - top - H * 0.09}px` });
  }
  const sp = state.speaking ? state.geo[state.speaking] : null;
  if (sp) moveSpot(state.speaking);
}

function moveSpot(key) {
  const g = state.geo[key]; const spot = $("#spot");
  if (!g) { spot.classList.remove("on"); return; }
  spot.style.left = `${g.x}px`;
  spot.style.top = `${g.head}px`;
  spot.style.width = spot.style.height = `${g.size * 1.9}px`;
  spot.classList.add("on");
}

function bindUI() {
  $("#composer").addEventListener("submit", async (e) => {
    e.preventDefault();
    mic.stop();
    const prompt = $("#prompt").value.trim();
    if (prompt.length < 10) return toast("안건을 한 문장 이상 입력해 주세요.");
    const mode = $('input[name="mode"]:checked').value;
    const seats = $$("#seatPick input:checked").map((x) => x.value);
    if (mode === "seats" && seats.length < 2) return toast("위원을 2명 이상 골라 주세요.");
    if (state.runner !== "api") {
      // no API key: hand the agenda to Claude Code instead
      const flag = mode === "quick" ? "--quick " : mode === "seats" ? `--seats ${seats.join(",")} ` : "";
      const cmd = `/roast-room ${flag}${prompt.replace(/\s+/g, " ")}`;
      try { await navigator.clipboard.writeText(cmd); toast("명령을 복사했습니다. Claude Code에 붙여넣으면 이 화면에서 회의가 시작됩니다."); }
      catch { toast("복사가 되지 않습니다. 브라우저의 클립보드 권한을 확인하세요."); }
      return;
    }
    $("#convene").disabled = true;
    const r = await fetch("/api/council", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ prompt, mode, seats }) });
    const j = await r.json();
    $("#convene").disabled = false;
    if (!r.ok) return toast(j.error || "위원회를 시작하지 못했습니다.");
    attach(j.id);
  });
  const openFrom = (e) => { const b = e.target.closest("[data-seat]"); if (b) openCard(b.dataset.seat); };
  $("#seats").addEventListener("click", openFrom);
  $("#plates").addEventListener("click", openFrom);
  $("#seats").addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openFrom(e); } });
  $("#feed").addEventListener("click", (e) => { const c = e.target.closest(".feed-card"); if (c) openCard(c.dataset.seat, Number(c.dataset.round)); });
  $("#waitHistory").addEventListener("click", openHistory);
  $("#waitGuide").addEventListener("click", openGuide);
  $("#guideBtn").addEventListener("click", openGuide);
  document.addEventListener("click", async (e) => {
    if (e.target.closest("[data-copy-example]")) {
      try { await navigator.clipboard.writeText("/roast-room " + EXAMPLE); toast("복사했습니다. Claude Code에 붙여넣으세요."); }
      catch { toast("복사가 되지 않습니다. 텍스트를 직접 선택해 복사하세요."); }
    }
    if (e.target.closest("[data-pdf]")) savePdf(e.target.closest("[data-pdf]"));
  });
  $("#historyBtn").addEventListener("click", openHistory);
  $("#newBtn").addEventListener("click", reset);
  $("#verdictSheet").addEventListener("click", (e) => { if (e.target.id === "verdictSheet" || e.target.closest("[data-close]")) $("#verdictSheet").hidden = true; });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("#verdictSheet").hidden = true; });
  // picking seats takes the samples' row, so the composer keeps its height
  $$('input[name="mode"]').forEach((r) => r.addEventListener("change", () => {
    const pick = $('input[name="mode"]:checked').value === "seats";
    $("#seatPick").hidden = !pick;
    $("#samples").hidden = pick;
    dimUnpicked();
  }));
  $("#seatPick").addEventListener("change", dimUnpicked);
  $("#voiceBtn").addEventListener("click", () => voice.toggle());
  $$(".speed button").forEach((b) => b.addEventListener("click", () => {
    player.speed = Number(b.dataset.speed);
    voice.rate();
    $$(".speed button").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
  }));
  $("#skipBtn").addEventListener("click", () => player.skip());
}

// ------------------------------------------------------------- the player
// Every event goes through one ordered queue. Seats speak one at a time, at a
// readable pace, even though the API answers them in parallel. Skip ahead drains
// whatever is queued instantly; new events after that animate again.
const player = {
  q: [], busy: false, epoch: 0, speed: 1, fast: false, timers: new Set(),
  push(ev) { this.q.push(ev); this.info(); this.pump(); },
  async pump() {
    if (this.busy) return;
    this.busy = true;
    const my = this.epoch;
    while (this.q.length && my === this.epoch) {
      const ev = this.q.shift();
      this.info();
      hideWait();
      try { await handle(ev); } catch (e) { console.error(e); }
    }
    if (my === this.epoch) { this.busy = false; this.fast = false; this.info(); }
  },
  sleep(ms) {
    if (this.fast || ms <= 0) return Promise.resolve();
    return new Promise((res) => { const t = setTimeout(() => { this.timers.delete(o); res(); }, ms / this.speed); const o = { t, res }; this.timers.add(o); });
  },
  flushTimers() { for (const o of this.timers) { clearTimeout(o.t); o.res(); } this.timers.clear(); },
  skip() { this.fast = true; this.flushTimers(); voice.stop(); },
  reset() { voice.stop(); this.epoch++; this.q.length = 0; this.fast = true; this.flushTimers(); this.busy = false; this.fast = false; this.info(); },
  info() {
    const waiting = this.q.filter((e) => e.type === "seat_done").length;
    $("#queueInfo").textContent = waiting ? `다음 발언 ${waiting}개` : "";
  },
};

// ------------------------------------------------------------- session wiring
function reset() {
  state.es?.close();
  player.reset();
  Object.assign(state, { session: null, options: [], weights: {}, active: [], round: 0, cards: { 1: {}, 2: {}, 3: {} }, replaying: false, verdict: null, links: [], speaking: null, setup: null, wait: null });
  hideWait();
  $("#stage").classList.remove("live");
  $("#topic").hidden = true;
  // the composer shows either way: with an API key it convenes here, without one it
  // builds the /roast-room command for Claude Code
  $("#composer").hidden = false;
  $("#waiting").hidden = true;
  $("#convene").textContent = state.runner === "api" ? "위원회 소집" : "Claude Code 명령 복사";
  $("#convene").title = state.runner === "api" ? "" : "API 키 없이 열린 화면입니다. 복사한 명령을 Claude Code에 붙여넣으면 회의가 여기서 재생됩니다.";
  $("#caption").hidden = true;
  $("#cruxes").hidden = true;
  $("#plate").hidden = true;
  $("#playbar").hidden = true;
  $("#newBtn").hidden = true;
  $("#verdictSheet").hidden = true;
  $("#panelHead").textContent = "시작하기";
  $("#feed").innerHTML = GUIDE;
  $$(".vote").forEach((b) => b.remove());
  $$(".seat").forEach((el) => { el.classList.remove("absent", "speaking", "thinking", "addressed"); $(".bust", el).dataset.shape = "base"; });
  $$(".nameplate").forEach((el) => { el.classList.remove("absent", "speaking"); $(".chip", el).hidden = true; $(".score", el).hidden = true; $(".pips", el).innerHTML = ""; });
  $("#spot").classList.remove("on");
  $$(".stepper li").forEach((li) => li.classList.remove("active", "done"));
  drawLinks();
  dimUnpicked();
}

function begin(id) {
  reset();
  state.session = id;
  $("#composer").hidden = true;
  $("#waiting").hidden = true;
  $("#newBtn").hidden = false;
  $("#playbar").hidden = false;
  $("#panelHead").textContent = "발언 요약";
  $("#feed").innerHTML = '<div class="empty">One line per seat as the council talks. Click a seat to read its full card.</div>';
  $("#stage").classList.add("live");
  chairSays("위원들이 자리에 앉고 있습니다", { dots: true });
}

function attach(id) {
  begin(id);
  const es = new EventSource(`/api/stream/${id}`);
  state.es = es;
  es.onmessage = (m) => {
    const ev = JSON.parse(m.data);
    if (ev.type === "end") { es.close(); refreshUsage(); return; }
    if (ev.type === "delta") return; // seats speak from their finished cards
    if (ev.type === "usage") return refreshUsage();
    if (ev.type === "seat_error") return toast(`${state.byKey[ev.seat].short} hit an error: ${ev.error}`);
    voice.prefetch(ev);
    player.push(ev);
  };
  es.onerror = () => { /* the browser retries; the server replays from the start */ };
}

// ------------------------------------------------------------- event handling
const STEP_OF = { setup: "setup", round1: "round1", cruxes: "cruxes", round2: "round2", draft: "round3", round3: "round3", skip3: "round3", verdict: "verdict" };
const ORDER = ["setup", "round1", "cruxes", "round2", "round3", "verdict"];

function setStep(step) {
  const idx = ORDER.indexOf(step);
  $$(".stepper li").forEach((li) => {
    const i = ORDER.indexOf(li.dataset.step);
    li.classList.toggle("done", i < idx);
    li.classList.toggle("active", i === idx);
  });
}

async function handle(ev) {
  switch (ev.type) {
    case "phase": {
      state.wait = { phase: ev.phase, at: ev.at || Date.now() };
      setStep(STEP_OF[ev.phase] || "setup");
      feedPhase(ev.label);
      const thinking = ["setup", "cruxes", "draft", "verdict"].includes(ev.phase);
      if (thinking || ev.phase === "skip3") {
        chairSays(ev.label, { dots: thinking });
        await player.sleep(1400);
      }
      break;
    }
    case "setup": state.setup = ev; onSetup(ev); await player.sleep(1800); break;
    case "round_start": onRoundStart(ev.round); break;
    case "seat_start": $(`#seat-${ev.seat}`)?.classList.add("thinking"); break;
    case "seat_done": await onSeatDone(ev); break;
    case "round_done": state.wait = null; updateOptions(ev.scores); break;
    case "cruxes": await onCruxes(ev); break;
    case "draft": await onDraft(ev.draft); break;
    case "verdict": state.wait = null; onVerdict(ev); break;
    case "error": state.wait = null; toast(`위원회가 중단되었습니다: ${ev.error}`); chairSays(`위원회가 중단되었습니다: ${ev.error}`); break;
  }
}

function onSetup(ev) {
  state.options = ev.options;
  state.weights = ev.weights;
  state.active = ev.seats;
  $("#topic").hidden = false;
  $("#topicTitle").textContent = ev.title;
  typeIn($("#topicTitle"));
  $("#options").innerHTML = ev.options.map((o) => `
    <div class="opt" data-opt="${o.id}"><span class="id">${o.id}</span><span class="label">${esc(o.label)}</span><span class="val">-</span><span class="bar"><i></i></span></div>`).join("");
  for (const s of state.seats) {
    const absent = !ev.seats.includes(s.key);
    $(`#seat-${s.key}`).classList.toggle("absent", absent);
    const pl = $(`#plate-${s.key}`);
    pl.classList.toggle("absent", absent);
    const w = ev.weights[s.key]?.weight || 1;
    pl.title = `Weight ${w} of 3: ${ev.weights[s.key]?.reason || ""}`;
  }
  chairSays(ev.title, { tag: ev.mode === "quick" ? "간이 위원회" : ev.mode === "seats" || ev.seats.length < state.seats.length ? `위원 ${ev.seats.length}명` : "전체 위원회" });
}

function updateOptions(scores) {
  const best = Object.entries(scores).sort((a, b) => (b[1].score ?? 0) - (a[1].score ?? 0))[0]?.[0];
  for (const [id, v] of Object.entries(scores)) {
    const el = $(`.opt[data-opt="${id}"]`); if (!el) continue;
    $(".val", el).textContent = v.score ?? "-";
    $(".bar i", el).style.width = `${(v.score || 0) * 10}%`;
    el.classList.toggle("lead", id === best);
    el.title = v.math;
  }
}

function onRoundStart(round) {
  state.round = round;
  state.links = [];
  drawLinks();
  $("#cruxes").hidden = true;
  chairSays(`${["", "1라운드: 첫 발언", "2라운드: 토론", "3라운드: 표결"][round]}`, { dots: true, tag: "발언을 시작합니다" });
}

// ------------------------------------------------------------- talking
const clean = (t) => String(t || "").replace(/\s*\((?:S\d+|source[^)]*)[^)]*\)/gi, "").replace(/\*\*/g, "").replace(/\s+/g, " ").trim();

function firstSentences(t, max) {
  const parts = t.match(/[^.!?]+[.!?]+["”)]?\s*|[^.!?]+$/g) || [t];
  let out = "";
  for (const p of parts) { if (out && (out + p).length > max) break; out += p; }
  return shorten(out.trim(), max + 40);
}

/** The line a seat says out loud: the headline of its card, not the whole card. */
function lineFor(round, p, max = 170) {
  if (round === 1) return firstSentences(clean(p.call || p.stance), max);
  if (round === 2) {
    let t = clean(p.disagreeLine || p.stance);
    // "Graham. His argument..." reads as talking to him: "Graham, his argument..."
    t = t.replace(/^([A-Za-z][\w.' ]{0,24})[.:,]\s+(\S+)/, (m, name, next) => !seatKey(name) ? m : `${state.byKey[seatKey(name)].short}, ${/^I('|$)/.test(next) ? next : next[0].toLowerCase() + next.slice(1)}`);
    return firstSentences(t, max);
  }
  return firstSentences(clean(p.oneLine || p.amendment), max);
}

// Mouth shapes for a word. Latin letters by vowel; Hangul syllables by their medial vowel
// (ㅏㅐㅑㅓㅔㅕㅣ open, ㅗㅛㅜㅠㅡ rounded) and a closing ㅁ/ㅂ/ㅍ final shuts the lips.
const OPEN_V = new Set([0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 14, 15, 20]);
const LIPS_F = new Set([16, 17, 18, 26]);
function shapesFor(word) {
  const out = [];
  const add = (s) => { if (s && s !== out[out.length - 1]) out.push(s); };
  for (const ch of word.toLowerCase()) {
    const c = ch.codePointAt(0);
    if (c >= 0xac00 && c <= 0xd7a3) {
      const n = c - 0xac00, v = Math.floor((n % 588) / 28), f = n % 28;
      add(OPEN_V.has(v) ? "open" : "mid");
      if (LIPS_F.has(f)) add("base");
      continue;
    }
    add("aei".includes(ch) ? "open" : "ouwy".includes(ch) ? "mid" : "mbpf".includes(ch) ? "base" : null);
  }
  return out.length ? out : ["mid"];
}
const syllables = (w) => (w.match(/[\uac00-\ud7a3]/g) || []).length;

function setShape(key, shape) { const b = $(`#seat-${key} .bust`); if (b) b.dataset.shape = shape; }

function setSpeaker(key, target) {
  state.speaking = key;
  $$(".seat").forEach((el) => { el.classList.toggle("speaking", el.dataset.seat === key); el.classList.toggle("addressed", el.dataset.seat === target); });
  $$(".nameplate").forEach((el) => el.classList.toggle("speaking", el.dataset.seat === key));
  const el = key && $(`#seat-${key}`);
  if (el) {
    el.classList.remove("thinking");
    // lean toward whoever they're answering
    const g = state.geo[key], tg = target && state.geo[target];
    el.style.transform = tg ? `translateX(${Math.sign(tg.x - g.x) * g.size * 0.04}px) rotate(${Math.sign(tg.x - g.x) * 2.5}deg) scale(1.05)` : "scale(1.05)";
    moveSpot(key);
  } else $("#spot").classList.remove("on");
  $$(".seat").forEach((s) => { if (s.dataset.seat !== key) s.style.transform = ""; });
}

function captionFor(who) {
  $("#cruxes").hidden = true;
  $("#plate").hidden = true;
  const c = $("#caption");
  c.hidden = false;
  c.style.animation = "none"; void c.offsetWidth; c.style.animation = "";
  const s = state.byKey[who];
  $("#capAv").className = `cap-av${s ? "" : " chair"}`;
  $("#capAv").innerHTML = `<img src="${s ? portrait(who) : "/brand/ic-mark.svg"}" alt="">`;
  $("#capWho").textContent = s ? s.name : "의장";
}

function chairSays(text, { dots = false, tag = "" } = {}) {
  setSpeaker(null);
  captionFor(null);
  $("#capTag").textContent = tag;
  const p = $("#capText");
  p.className = "cap-text chair";
  p.innerHTML = esc(text) + (dots ? '<span class="dots"><i></i><i></i><i></i></span>' : "");
  $("#capSub").textContent = "";
}

async function speak(key, text, { tag = "", target = null, sub = "" } = {}) {
  setSpeaker(key, target);
  captionFor(key);
  $("#capTag").textContent = tag;
  $("#capSub").textContent = "";
  const p = $("#capText");
  p.className = "cap-text";
  const words = text.split(" ").filter(Boolean);
  p.innerHTML = words.map((w) => `<span class="w">${esc(w)}</span> `).join("");
  const spans = $$(".w", p);
  const audio = await voice.start(key, text);
  if (audio) {
    await speakWithAudio(key, audio, words, spans);
    spans.forEach((s) => s.classList.add("on"));
    setShape(key, "base");
    $("#capSub").innerHTML = sub;
    await player.sleep(700);
    return;
  }
  for (let i = 0; i < words.length; i++) {
    if (player.fast) break;
    const w = words[i];
    spans[i].classList.add("on");
    const shapes = shapesFor(w.replace(/[^a-z\uac00-\ud7a3]/gi, ""));
    const hs = syllables(w);
    const dur = Math.max(170, (w.length - hs) * 52 + hs * 135);
    const per = dur / (shapes.length + 1);
    for (const sh of shapes) { setShape(key, sh); await player.sleep(per); }
    setShape(key, "base");
    await player.sleep(per + (/[.!?]["”)]?$/.test(w) ? 340 : /[,;:]$/.test(w) ? 170 : 25));
  }
  spans.forEach((s) => s.classList.add("on"));
  setShape(key, "base");
  $("#capSub").innerHTML = sub;
  await player.sleep(1300);
}

// Word timing for a line: the same weights the silent captions use, stretched to the clip.
function wordWeights(words) {
  return words.map((w) => {
    const hs = syllables(w);
    return Math.max(170, (w.length - hs) * 52 + hs * 135) + (/[.!?]["”)]?$/.test(w) ? 340 : /[,;:]$/.test(w) ? 170 : 25);
  });
}

// Captions and mouth follow the audio clock, so they stay in sync at any speed.
async function speakWithAudio(key, audio, words, spans) {
  const until = (t) => new Promise((res) => {
    const tick = () => (player.fast || audio.ended || audio.error || audio.paused || audio.currentTime >= t ? res() : setTimeout(tick, 30));
    tick();
  });
  const dur = Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : 0;
  const wts = wordWeights(words);
  const total = wts.reduce((a, b) => a + b, 0) || 1;
  let at = 0;
  for (let i = 0; i < words.length; i++) {
    if (player.fast) break;
    spans[i].classList.add("on");
    const len = dur ? (wts[i] / total) * dur : 0;
    const shapes = shapesFor(words[i].replace(/[^a-z\uac00-\ud7a3]/gi, ""));
    for (let j = 0; j < shapes.length; j++) { setShape(key, shapes[j]); await until(at + (len * (j + 1)) / (shapes.length + 1)); }
    setShape(key, "base");
    at += len;
    await until(at);
  }
  await until(Infinity);
}

// ------------------------------------------------------------- voice out (Voicebox)
// Lines are requested as soon as their event arrives, so the next seat's audio is being
// made while the current one talks. Voicebox runs slower than real time; the room waits
// for a line rather than talk over it, and falls back to silent captions on an error.
const KO_LABEL = { "GO": "추진", "GO WITH CONDITIONS": "조건부 추진", "RESHAPE": "재설계", "WAIT": "보류", "DON'T DO IT": "추진 불가" };
const seatLine = (ev) => lineFor(ev.round, ev.parsed) || "I'll put it in my card.";
const draftLine = (d) => `의결안은 ${d.option}안, ${KO_LABEL[d.label] || d.label}입니다. ${firstSentences(clean(d.recommendation), 140)}`;
const verdictLine = (v) => `판정은 ${KO_LABEL[v.label] || v.label}입니다. ${firstSentences(clean(v.call), 150)}`;

const voice = {
  on: false, info: null, clips: new Map(), audio: null, warned: false,
  async init() {
    try { this.on = localStorage.getItem("rr-voice") === "on"; } catch { /* private window */ }
    this.info = await fetch("/api/voices").then((x) => x.json()).catch(() => ({ available: false }));
    if (!this.info.available) this.on = false;
    this.paint();
  },
  paint() {
    const b = $("#voiceBtn");
    b.disabled = !this.info?.available;
    b.setAttribute("aria-pressed", String(this.on));
    b.textContent = this.on ? "음성 켬" : "음성 끔";
    b.title = this.info?.available ? "위원 발언을 Voicebox 음성으로 듣기" : `Voicebox(${this.info?.api || "127.0.0.1:17493"})에 연결되지 않았습니다. Voicebox 앱을 켜고 새로고침하세요.`;
  },
  toggle() {
    this.on = !this.on;
    try { localStorage.setItem("rr-voice", this.on ? "on" : "off"); } catch { /* ignore */ }
    this.paint();
    if (this.on) { player.q.forEach((ev) => this.prefetch(ev)); toast("음성을 켰습니다. 처음 듣는 발언은 Voicebox가 만드는 동안 잠시 기다릴 수 있습니다."); }
    else this.stop();
  },
  clip(seat, text) {
    const k = `${seat}\n${text}`;
    if (!this.clips.has(k)) {
      const p = fetch("/api/tts", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ seat, text }) })
        .then(async (r) => { if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || `TTS ${r.status}`); return URL.createObjectURL(await r.blob()); });
      p.catch(() => this.clips.delete(k));
      this.clips.set(k, p);
    }
    return this.clips.get(k);
  },
  prefetch(ev) {
    if (!this.on) return;
    if (ev.type === "seat_done") this.clip(ev.seat, seatLine(ev));
    else if (ev.type === "draft") this.clip("chair", draftLine(ev.draft));
    else if (ev.type === "verdict") this.clip("chair", verdictLine(ev.verdict));
  },
  seatRate(seat) { return this.info?.seats?.[seat]?.rate || 1; },
  rate() {
    const a = this.audio; if (!a) return;
    // at 1x the seat's pitch shift gives two seats on one cloned voice their own sound;
    // faster playback keeps the pitch natural
    a.preservesPitch = player.speed !== 1;
    a.playbackRate = player.speed === 1 ? this.seatRate(a.dataset.seat) : player.speed;
  },
  /** Start the clip for a line and return the playing <audio>, or null to stay silent. */
  async start(seat, text) {
    if (!this.on || !this.info?.available || player.fast) return null;
    const sub = $("#capSub");
    const t = setTimeout(() => { if (sub.textContent === "") sub.textContent = "음성 준비 중..."; }, 400);
    let url = null;
    try {
      const skipped = new Promise((res) => { const iv = setInterval(() => { if (player.fast || !this.on) { clearInterval(iv); res(null); } }, 100); this.clip(seat, text).catch(() => {}).finally(() => clearInterval(iv)); });
      url = await Promise.race([this.clip(seat, text), skipped, new Promise((res) => setTimeout(() => res(null), 240000))]);
    } catch (e) {
      if (!this.warned) { this.warned = true; toast(`음성을 만들지 못해 자막으로만 진행합니다: ${e.message || e}`); }
    } finally { clearTimeout(t); if (sub.textContent === "음성 준비 중...") sub.textContent = ""; }
    if (!url || player.fast || !this.on) return null;
    const a = new Audio(url);
    a.dataset.seat = seat;
    this.stop();
    this.audio = a;
    this.rate();
    for (;;) {
      try {
        await a.play();
        if (!Number.isFinite(a.duration)) await new Promise((res) => { a.onloadedmetadata = res; setTimeout(res, 500); });
        return a;
      } catch (e) {
        if (e.name !== "NotAllowedError") { this.audio = null; return null; }
        // The browser blocks sound until the page gets a click (after a reload, say).
        // Hold this line until the viewer clicks anywhere, then play it.
        sub.textContent = "화면을 한 번 클릭하면 음성이 나옵니다";
        const clicked = await new Promise((res) => {
          const go = () => { clearInterval(iv); document.removeEventListener("pointerdown", go, true); res(true); };
          const iv = setInterval(() => { if (player.fast || !this.on) { clearInterval(iv); document.removeEventListener("pointerdown", go, true); res(false); } }, 150);
          document.addEventListener("pointerdown", go, true);
        });
        if (sub.textContent === "화면을 한 번 클릭하면 음성이 나옵니다") sub.textContent = "";
        if (!clicked || this.audio !== a) { if (this.audio === a) this.audio = null; return null; }
      }
    }
  },
  /** Play a Chair line and wait for it to end. Resolves false when there is no audio. */
  async say(text) {
    const a = await this.start("chair", text);
    if (!a) return false;
    await new Promise((res) => { const tick = () => (player.fast || a.ended || a.error || a.paused ? res() : setTimeout(tick, 60)); tick(); });
    return true;
  },
  stop() { if (this.audio) { this.audio.pause(); this.audio = null; } },
};

// ------------------------------------------------------------- voice in (browser speech recognition)
// Chrome and Edge send the audio to their speech service; Safari and Firefox mostly lack it.
const mic = {
  rec: null,
  stop() { this.rec?.stop(); },
};
function setupMic() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const btn = $("#micBtn");
  if (!SR) { btn.hidden = true; return; }
  btn.addEventListener("click", () => {
    if (mic.rec) return mic.stop();
    const ta = $("#prompt");
    const base = ta.value.trim() ? ta.value.trim() + " " : "";
    let said = "";
    const rec = new SR();
    rec.lang = "ko-KR";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) said += t.trim() + " ";
        else interim += t;
      }
      ta.value = (base + said + interim).trimEnd();
      ta.scrollTop = ta.scrollHeight;
    };
    rec.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") toast("마이크 권한이 없습니다. 주소창의 마이크 아이콘에서 허용해 주세요.");
      else if (e.error !== "no-speech" && e.error !== "aborted") toast(`음성 입력 오류: ${e.error}`);
    };
    rec.onend = () => { mic.rec = null; btn.setAttribute("aria-pressed", "false"); $("span", btn).textContent = "말로 입력"; };
    mic.rec = rec;
    rec.start();
    btn.setAttribute("aria-pressed", "true");
    $("span", btn).textContent = "듣는 중 · 누르면 멈춤";
  });
}

// before a council, seats left out of the pick fade at the table
function dimUnpicked() {
  if (state.session) return;
  const pick = $('input[name="mode"]:checked')?.value === "seats";
  const on = new Set($$("#seatPick input:checked").map((x) => x.value));
  for (const s of state.seats) {
    const out = pick && !on.has(s.key);
    $(`#seat-${s.key}`).classList.toggle("absent", out);
    $(`#plate-${s.key}`).classList.toggle("absent", out);
  }
}

function renderSeatPick() {
  $("#seatPick").innerHTML = state.seats.map((s) => `
    <label style="--c:${s.color}" title="${esc(s.pillarKo || s.pillar)}"><input type="checkbox" value="${s.key}" checked><span>${esc(s.short)}</span></label>`).join("");
}

// idle blinking for everyone, so the room feels alive between lines
function startBlinking() {
  const blink = (key) => {
    const b = $(`#seat-${key} .bust`);
    if (b && b.dataset.shape === "base") {
      b.dataset.shape = "blink";
      setTimeout(() => { if (b.dataset.shape === "blink") b.dataset.shape = "base"; }, 130);
    }
    setTimeout(() => blink(key), 2400 + Math.random() * 4200);
  };
  state.seats.forEach((s, i) => setTimeout(() => blink(s.key), 600 + i * 530));
}

async function onSeatDone(ev) {
  const { round, seat, text, parsed, quotes } = ev;
  state.cards[round][seat] = { text, parsed, quotes };
  const s = state.byKey[seat];
  const top = topOption(parsed.optionScores);
  const line = lineFor(round, parsed);
  let tag = ROUND_NAME[round], sub = "", target = null;
  if (round === 1) {
    tag = `${stanceWord(parsed.stance)}${top ? ` · ${top.id}안 지지 (${top.v}/10)` : ""}`;
  } else if (round === 2) {
    const tgt = parsed.disagreeWith ? state.byKey[parsed.disagreeWith] : null;
    if (tgt) {
      target = tgt.key;
      tag = `${tgt.short}에게 반박`;
      state.links = state.links.filter((l) => l.from !== seat);
      state.links.push({ from: seat, to: tgt.key });
      drawLinks();
    }
    sub = /^yes/i.test(parsed.moved) ? "입장 변경" : "";
  } else {
    const v = parsed.vote || "endorse";
    tag = `Votes ${v}`;

  }
  feedCard(round, seat, parsed);
  await speak(seat, line || "I'll put it in my card.", { tag, target, sub });

  const pl = $(`#plate-${seat}`);
  const chip = $(".chip", pl);
  chip.hidden = round === 3; // the vote stamp says it
  chip.className = "chip";
  if (round === 3) {
    const v = parsed.vote || "endorse";
    chip.textContent = v;
    chip.classList.add(v);
    $(`#seat-${seat} .vote`)?.remove();
    const stamp = document.createElement("div");
    stamp.className = `vote ${v}`;
    stamp.textContent = v.toUpperCase();
    $(`#seat-${seat}`).appendChild(stamp);
  } else chip.textContent = stanceWord(parsed.stance);
  if (top) { const sc = $(".score", pl); sc.hidden = false; sc.textContent = `${top.id} ${top.v}`; sc.title = `최고 점수: ${top.id}안`; }
  setSpeaker(null);
  void s;
}

function stanceWord(t = "") {
  const m = t.match(/strong yes|conditional yes|strong no|yes|no/i);
  if (!m) return "발언";
  return { "strong yes": "강한 찬성", "conditional yes": "조건부 찬성", "strong no": "강한 반대", yes: "찬성", no: "반대" }[m[0].toLowerCase()];
}

function topOption(scores = {}) {
  const e = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  return e ? { id: e[0], v: e[1] } : null;
}
const shorten = (t, n) => (t.length > n ? t.slice(0, n - 1).replace(/\s+\S*$/, "") + "…" : t);
const face = (k) => `<img src="${portrait(k)}" alt="${esc(state.byKey[k]?.short || k)}" title="${esc(state.byKey[k]?.short || k)}">`;

async function onCruxes(ev) {
  setSpeaker(null);
  $("#caption").hidden = true;
  const c = $("#cruxes");
  c.hidden = false;
  c.innerHTML = `<div class="head">${ev.unanimous ? "의견이 너무 일치합니다. 의장이 반론을 요구합니다." : "쟁점"}</div>` +
    ev.cruxes.map((x, i) => `<div class="crux" style="animation-delay:${i * 0.18}s"><b>${esc(x.question)}</b><div class="sides">${x.sides.map((sd) => `<span class="side"><span class="faces">${sd.seats.filter((k) => state.byKey[k]).map(face).join("")}</span>${esc(shorten(sd.position, 48))}</span>`).join("")}</div></div>`).join("");
  const f = document.createElement("div");
  f.className = "feed-note";
  f.innerHTML = `<b>쟁점:</b> ${ev.cruxes.map((x) => esc(x.question)).join(" ")}`;
  feedAppend(f);
  await player.sleep(3500 + 1800 * ev.cruxes.length);
}

async function onDraft(d) {
  chairSays(`의결안: ${d.option}안 ${d.label}. ${firstSentences(clean(d.recommendation), 140)}`, { tag: "표결 부의" });
  const f = document.createElement("div");
  f.className = "feed-note";
  f.innerHTML = `<b>표결 부의:</b> ${esc(d.option)}안 ${esc(d.label)}.`;
  feedAppend(f);
  if (!(await voice.say(draftLine(d)))) await player.sleep(4200);
}

// ------------------------------------------------------------- rebuttal arcs
function drawLinks() {
  const svg = $("#links");
  const stage = $("#stage");
  const w = stage.clientWidth, h = stage.clientHeight;
  svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
  const links = state.links || [];
  const col = "#38bdf8";
  svg.innerHTML = `<defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${col}"/></marker></defs>` +
    links.map(({ from, to }, i) => {
      const a = state.geo[from], b = state.geo[to];
      if (!a || !b) return "";
      const y1 = a.top - 6, y2 = b.top - 6;
      const mx = (a.x + b.x) / 2, my = Math.min(y1, y2) - Math.min(90, Math.abs(a.x - b.x) * 0.22) - 10;
      return `<path class="${i < links.length - 1 ? "old" : ""}" d="M${a.x},${y1} Q${mx},${my} ${b.x},${y2}" stroke="${col}" marker-end="url(#arrow)"/>`;
    }).join("");
}

// ------------------------------------------------------------- feed + cards
function feedAppend(node) {
  const feed = $("#feed");
  $(".empty", feed)?.remove();
  feed.appendChild(node);
  feed.scrollTop = feed.scrollHeight;
}
function feedPhase(label) {
  const d = document.createElement("div");
  d.className = "feed-phase";
  d.textContent = label;
  feedAppend(d);
}
function feedCard(round, seat, parsed) {
  const s = state.byKey[seat];
  const d = document.createElement("div");
  d.className = "feed-card";
  d.dataset.seat = seat;
  d.dataset.round = round;
  const top = topOption(parsed.optionScores);
  const tgt = parsed.disagreeWith ? state.byKey[parsed.disagreeWith]?.short : "";
  const what = round === 1 ? `${stanceWord(parsed.stance)}${top ? ` · ${top.id}안` : ""}` : round === 2 ? (tgt ? `vs ${tgt}` : "토론") : ({ endorse: "찬성", amend: "수정 찬성", dissent: "반대" })[parsed.vote || "endorse"];
  d.innerHTML = `<img class="av" src="${portrait(seat)}" alt=""><div><div class="h">${esc(s.short)}<span class="r">${esc(what)}</span></div><p>${esc(lineFor(round, parsed, 105))}</p></div>`;
  feedAppend(d);
}

function openCard(seat, round) {
  const s = state.byKey[seat];
  const rounds = [3, 2, 1].filter((r) => state.cards[r][seat]);
  const r = round || rounds[0];
  const c = state.cards[r]?.[seat];
  $("#cardBody").innerHTML = `
    <div class="card-head"><img src="${portrait(seat)}" alt=""><div><div class="label">${esc(s.pillarKo || s.pillar)}</div><h3>${esc(s.name)}</h3><p class="muted" style="margin:0">핵심 질문: ${esc(s.questionKo || s.question)}</p></div></div>
    ${rounds.length > 1 ? `<p style="margin:0 0 6px">${rounds.slice().reverse().map((x) => `<button class="ghost" data-r="${x}" style="margin-right:6px">${ROUND_NAME[x]}</button>`).join("")}</p>` : ""}
    ${c ? `<pre>${esc(c.text)}</pre>${c.quotes.length ? `<ul class="qcheck">${c.quotes.map((q) => `<li class="${q.verified ? "" : "bad"}">"${esc(shorten(q.quote, 110))}" (${q.source}) ${q.verified ? "brain에서 확인" : "brain에 없음"}</li>`).join("")}</ul>` : ""}` : `<p class="muted">아직 발언하지 않았습니다.</p>`}
    <p class="muted" style="font-size:12px">${esc(s.name)}의 공개 저작을 요약해 만든 가상 위원입니다. 실제 인물이 아닙니다.</p>`;
  $$("#cardBody [data-r]").forEach((b) => b.addEventListener("click", () => openCard(seat, Number(b.dataset.r))));
  const dlg = $("#cardDialog");
  if (!dlg.open) dlg.showModal();
}

// ------------------------------------------------------------- verdict
// the Chair should write display names; map any raw seat key just in case
const seatKey = (x) => { const k = String(x).toLowerCase().replace(/\s+/g, ""); return state.byKey[k] ? k : state.seats.find((s) => s.short.toLowerCase() === String(x).toLowerCase() || s.name.toLowerCase() === String(x).toLowerCase())?.key; };
const seatName = (x) => state.byKey[seatKey(x)]?.short || x;

function labelClass(l) { return /DON'T/.test(l) ? "dont" : /RESHAPE/.test(l) ? "reshape" : /WAIT/.test(l) ? "wait" : "go"; }

function onVerdict(ev) {
  const v = ev.verdict;
  state.verdict = ev;
  setStep("verdict");
  voice.say(verdictLine(v));
  setSpeaker(null);
  $("#caption").hidden = true;
  $("#cruxes").hidden = true;
  state.links = [];
  drawLinks();
  $("#stage").classList.remove("live");
  updateOptions(v.scores);
  const opt = (id) => state.options.find((o) => o.id === id)?.label || id;
  const seats = ev.seats;
  const mk = seatKey(v.minority.seat);
  const short = (t, n) => esc(shorten(clean(t || ""), n));
  const html = `
    <div class="v-top">
      <div><div class="label">위원회 판정</div><span class="v-label ${labelClass(v.label)}">${esc(v.label)}</span></div>
      <div class="actions"><button class="pill" type="button" data-pdf>PDF 내려받기</button><button class="ghost" data-close>회의실로 돌아가기</button></div>
    </div>
    <p class="v-call">${esc(v.call)}</p>
    <div class="v-grid">
      <div class="v-sec"><h3>점수</h3><div class="v-opts">${state.options.map((o) => `
        <div class="opt ${o.id === v.recommended ? "lead" : ""}"><span class="id">${o.id}</span><span class="label">${esc(o.label)}</span><span class="val">${v.scores[o.id]?.score ?? "-"}</span><span class="bar"><i style="width:${(v.scores[o.id]?.score || 0) * 10}%"></i></span></div>`).join("")}</div>
        <p class="v-meta">확신도 ${v.confidence ?? "-"}/10${v.votes ? ` · 찬성 ${v.votes.endorse || 0} · 수정 찬성 ${v.votes.amend || 0} · 반대 ${v.votes.dissent || 0}` : ""}</p>
      </div>
      <div class="v-sec"><h3>근거</h3><ul class="v-why">${v.why.slice(0, 3).map((w) => { const k = seatKey(w.seat); return `<li>${k ? `<img class="av" src="${portrait(k)}" alt="">` : ""}<span>${short(w.point, 150)}</span></li>`; }).join("")}</ul></div>
      <div class="v-sec"><h3>소수 의견</h3><div class="minority"><div class="who">${mk ? `<img class="av" src="${portrait(mk)}" alt="">` : ""}${esc(seatName(v.minority.seat))}</div><q>${short(v.minority.quote, 170)}</q></div></div>
      <div class="v-sec"><h3>다음 단계</h3><ul class="v-steps">${v.next_steps.slice(0, 3).map((n) => `<li><b>${esc(n.when)}</b> ${short(n.action, 120)}</li>`).join("")}</ul>
        <p class="v-meta"><b>중단 기준:</b> ${short(v.kill_criteria, 140)}</p></div>
    </div>
    <details class="v-more"><summary>전체 내용</summary>
      <div class="v-grid">
        <div class="v-sec"><h3>쟁점</h3><ul>${v.fights.map((f) => `<li><b>${esc(f.crux)}</b> ${esc(f.story)}</li>`).join("")}</ul></div>
        <div class="v-sec"><h3>조건</h3><ol>${v.conditions.map((c) => `<li>${esc(c)}</li>`).join("")}</ol></div>
        <div class="v-sec v-wide"><h3>채점표</h3>
          <table class="scorecard"><thead><tr><th>위원</th><th>가중치</th>${state.options.map((o) => `<th>${o.id}</th>`).join("")}<th>한 줄 당부</th></tr></thead><tbody>
          ${seats.map((x) => { const s = state.byKey[x.key]; return `<tr><td><span class="who"><img class="av" src="${portrait(x.key)}" alt="">${esc(s.short)}</span></td><td class="n">${x.weight}</td>${state.options.map((o) => `<td class="n">${x.optionScores?.[o.id] ?? "-"}</td>`).join("")}<td class="line">${short(x.oneLine, 150)}</td></tr>`; }).join("")}
          </tbody></table>
          <p class="muted" style="font-size:11.5px;margin-top:8px">안건과의 관련도로 가중 평균했습니다. ${state.options.map((o) => `${o.id}: ${esc(v.scores[o.id]?.math || "")}`).join(" · ")}</p></div>
        <div class="v-sec"><h3>가장 싼 검증</h3><p>${esc(v.cheapest_test)}</p><h3>재검토</h3><p>${esc(v.revisit)}</p></div>
        <div class="v-sec"><h3>가장 강한 반론 전문</h3><p>${esc(v.minority.quote)}</p><p class="muted">이 의견이 맞으려면: ${esc(v.minority.would_have_to_be_true)}</p></div>
        ${v.amendments?.length ? `<div class="v-sec v-wide"><h3>수정안</h3><ul>${v.amendments.map((a) => `<li><b>${esc(seatName(a.seat))}:</b> ${esc(a.amendment)} <span class="tag">${a.adopted ? "채택" : "미채택"}: ${esc(a.reason)}</span></li>`).join("")}</ul></div>` : ""}
      </div>
    </details>
    <div class="v-foot"><span class="muted">${esc(v.disclaimer)}</span><button class="ghost" data-close>회의실로 돌아가기</button></div>`;
  $("#verdictBody").innerHTML = html;
  const plate = $("#plate");
  plate.hidden = false;
  plate.innerHTML = `<div class="label">위원회 판정</div><span class="v-label ${labelClass(v.label)}">${esc(v.label)}</span><p>${esc(firstSentences(clean(v.call), 150))}</p><div class="row"><button type="button" id="plateOpen">판정 보기</button><button type="button" data-pdf>PDF 내려받기</button><button type="button" class="alt" id="plateReplay">이 회의 다시 보기</button></div>`;
  $("#plateOpen").addEventListener("click", () => ($("#verdictSheet").hidden = false));
  $("#plateReplay").addEventListener("click", () => replay(state.session));
  $("#playbar").hidden = true;
  const f = document.createElement("div");
  f.className = "feed-note";
  f.innerHTML = `<b>판정: ${esc(v.label)}.</b> ${esc(firstSentences(clean(v.call), 160))}`;
  feedAppend(f);
  setTimeout(() => { if (state.verdict === ev) $("#verdictSheet").hidden = false; }, 1600);
}

// ------------------------------------------------------------- history + replay
async function openHistory() {
  const { sessions } = await fetch("/api/sessions").then((x) => x.json());
  $("#historyList").innerHTML = sessions.length
    ? sessions.map((s) => `<li><button data-id="${esc(s.id)}"><b>${esc(s.title)}</b><small>${esc(s.id.slice(0, 10))} · ${esc(s.mode)} · ${esc(s.status)}</small></button>${s.status === "done" ? `<button class="pdf" type="button" data-pdf="${esc(s.id)}" title="판정을 PDF로 내려받기">PDF</button>` : ""}</li>`).join("")
    : '<li class="muted">아직 회의가 없습니다. 위원회를 한 번 열면 여기에 표시됩니다.</li>';
  $$("#historyList button[data-id]").forEach((b) => b.addEventListener("click", () => { $("#historyDialog").close(); replay(b.dataset.id); }));
  $("#historyDialog").showModal();
}

async function replay(id) {
  const j = await fetch(`/api/sessions/${encodeURIComponent(id)}`).then((x) => x.json());
  begin(id);
  state.replaying = true;
  for (const ev of j.events) {
    if (["delta", "usage", "seat_error", "end"].includes(ev.type)) continue;
    voice.prefetch(ev);
    player.push(ev);
  }
}

// ------------------------------------------------------------- waiting on Claude Code
// A live council goes quiet for minutes while the seats write in parallel. Instead of a
// frozen table, say what is happening, how long it has been, and what each seat is weighing.
const SAME_TIME = "위원들은 Claude Code에서 동시에 의견을 작성합니다. 라운드가 끝나는 대로 여기서 발언이 재생됩니다.";
function waitCopy(phase) {
  const n = state.setup?.mode === "quick" ? 2 : 3;
  return {
    setup: ["회의 준비", "의장이 위원들을 착석시키고 있습니다.", ""],
    round1: [`1라운드 / ${n}`, "위원들이 첫 의견을 작성하고 있습니다.", SAME_TIME],
    round2: [`2라운드 / ${n}`, "위원들이 서로의 의견을 읽고 반박하고 있습니다.", SAME_TIME],
    round3: [`3라운드 / ${n}`, "위원들이 의장의 의결안에 표결하고 있습니다.", SAME_TIME],
    cruxes: ["라운드 사이", "의장이 첫 의견을 읽고 쟁점을 정리하고 있습니다.", "다음에 쟁점이 표시되고 토론이 시작됩니다."],
    draft: ["라운드 사이", "의장이 토론 내용을 의결안으로 정리하고 있습니다.", "다음에 모든 위원이 표결합니다."],
    skip3: ["마지막 단계", "의장이 점수를 집계하고 판정문을 쓰고 있습니다.", "판정이 나오면 PDF로 내려받을 수 있습니다."],
    verdict: ["마지막 단계", "의장이 점수를 집계하고 판정문을 쓰고 있습니다.", "판정이 나오면 PDF로 내려받을 수 있습니다."],
  }[phase] || ["진행 중", "위원회가 작업 중입니다.", ""];
}
const clock = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };

function hideWait() {
  const w = $("#waitcard");
  if (w.hidden) return;
  w.hidden = true;
  $$(".seat.musing").forEach((e) => e.classList.remove("musing"));
  if (state.capWasShown) $("#caption").hidden = false;
  if (state.playbarWasShown) $("#playbar").hidden = false;
}

function tickWait() {
  const w = state.wait;
  const idle = !player.busy && !player.q.length;
  if (!w || !idle || state.replaying || !state.session || state.verdict) return hideWait();
  const card = $("#waitcard");
  if (card.hidden) {
    state.capWasShown = !$("#caption").hidden;
    $("#caption").hidden = true;
    $("#cruxes").hidden = true;
    // speed controls do nothing while the room waits, and they would cover the card
    state.playbarWasShown = !$("#playbar").hidden;
    $("#playbar").hidden = true;
    card.hidden = false;
    state.museAt = 0;
  }
  const [step, head, sub] = waitCopy(w.phase);
  const elapsed = Date.now() - w.at;
  $("#wcStep").textContent = step;
  $("#wcTime").textContent = clock(elapsed);
  $("#wcHead").textContent = head;
  $("#wcSub").textContent = sub;
  $("#wcNudge").hidden = elapsed < 4 * 60 * 1000;
  const round = Number((w.phase.match(/^round(\d)$/) || [])[1]) || 0;
  const bar = $("#wcBar").parentElement;
  const muse = $("#wcMuse");
  if (round) {
    const seats = state.active.length ? state.active : state.seats.map((s) => s.key);
    const done = seats.filter((k) => state.cards[round][k]).length;
    bar.classList.toggle("indeterminate", done === 0);
    $("#wcBar").style.width = done ? Math.round((done / seats.length) * 100) + "%" : "";
    // every few seconds, show what one of the still-thinking seats is weighing
    const pending = seats.filter((k) => !state.cards[round][k]);
    if (pending.length && Date.now() - (state.museAt || 0) > 5200) {
      state.museAt = Date.now();
      state.museIdx = ((state.museIdx ?? -1) + 1) % pending.length;
      const s = state.byKey[pending[state.museIdx]];
      muse.classList.add("fade");
      setTimeout(() => {
        muse.innerHTML = "<b>" + esc(s.short) + "</b> 고민 중: " + esc(s.questionKo || s.question) + (done ? " · " + done + "/" + seats.length + " 완료" : "");
        muse.classList.remove("fade");
        $$(".seat").forEach((el) => el.classList.toggle("musing", el.dataset.seat === s.key));
      }, 300);
    }
  } else {
    bar.classList.add("indeterminate");
    $("#wcBar").style.width = "";
    muse.textContent = "";
    $$(".seat.musing").forEach((e) => e.classList.remove("musing"));
  }
}

function openGuide() {
  $("#guideBody").innerHTML = GUIDE;
  const d = $("#guideDialog");
  if (!d.open) d.showModal();
}

// ------------------------------------------------------------- PDF
async function savePdf(btn) {
  const id = btn.dataset.pdf;
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = "PDF 만드는 중...";
  try {
    let setup = state.setup, verdict = state.verdict;
    if (id) { // a past session from the history list
      const j = await fetch("/api/sessions/" + encodeURIComponent(id)).then((x) => x.json());
      setup = j.events.find((e) => e.type === "setup");
      verdict = [...j.events].reverse().find((e) => e.type === "verdict");
    }
    if (!setup || !verdict) throw new Error("이 회의에는 아직 판정이 없습니다.");
    await downloadVerdictPdf({ setup, verdict, byKey: state.byKey, id: id || state.session });
  } catch (e) {
    console.error(e);
    toast("PDF를 만들지 못했습니다: " + (e.message || e));
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
}

// ------------------------------------------------------------- misc
let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 6000);
}
async function refreshUsage() {
  const u = await fetch("/api/usage").then((x) => x.json()).catch(() => null);
  if (!u || !u.calls) { $("#usage").textContent = ""; return; }
  const k = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : `${Math.round(n / 1000)}k`);
  $("#usage").textContent = `${u.calls} calls · ${k(u.input + u.cacheRead + u.cacheWrite)} in · ${k(u.output)} out`;
}

boot();
