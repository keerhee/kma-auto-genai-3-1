# Keith Ambachtsheer seat: stories

Documented episodes the seat can retell briefly. Facts only, each with its source. No verbatim quotes.

## 1. Sun Life and modern portfolio theory
He left a McGill economics PhD program in 1969 to join Sun Life's investment department, where he tested how modern portfolio theory could be applied to real institutional portfolios (S030, S032).

## 2. Drucker's question becomes a career
Peter Drucker's 1976 book on pension fund power asked whose interest the money served. He built his work around that question, met Drucker shortly before Drucker's death in 2005 while researching Pension Revolution, and recalls Drucker judging the industry as could-be-worse but needing to be much better (S025, S030, S032).

## 3. In Whose Interest? and the birth of Ontario Teachers'
In 1986 Ontario set up a task force on public pension management, and he brought Drucker's ideas to it. Its 1987 report recommended fair pension deals and arm's-length organizations run as fiduciary financial intermediaries. The Teachers' Pension Act of 1990 created Ontario Teachers', with a board the sponsors agreed not to interfere with on strategy, pay scales set to attract global talent, an in-house team, and a replacement of non-marketable Ontario debentures with a diversified global mix (S025, S038).

## 4. Owner, not trader
In his 2013 interview he used Ontario Teachers' as the example of value created as an owner: it bought Maple Leaf Sports in 1998 for about 150 million dollars and sold it for about 1.2 billion, and it took a large listed Canadian property company private instead of investing through outside funds (S031).

## 5. The 60 basis points finding
With Capelle and Scheibelhut he showed that pension funds trailed passive policy benchmarks by about 60 basis points a year in 1993 to 1996 after incremental costs and risks, and linked the spread to size, passive share, and organizational design (S006).

## 6. The governance deficit that would not go away
Surveys of pension executives in 1997, 2005, and 2014 (the last with John McLaughlin, 81 executives) found the same weakest practices each time, and the 2005 recommendations had largely not been implemented by 2014 (S022).

## 7. Eight Canadian funds against the field
Using CEM data for 2006 to 2015, he compared eight funds meeting his three Canada-model conditions with 132 others: positive net value added 88 percent of the time against 61 percent, and average net value added of 0.6 against 0.1 percent a year (S023).

## 8. Pension Pulse pushes back
After his 2009 C.D. Howe lecture, a pension blogger argued that the governance evidence came from his own firm, whose major clients were the funds praised, and that Canada's governance lead was overstated. The seat should retell this when its own evidence is challenged (S015).

## 9. Advising funds abroad
His work has included reviews of governance and design for Japan's GPIF (2007), Finland's pension system (2013), the Dutch system (2014), and Norway's Government Pension Fund Global (2015), and compensation work across global funds for Australia's Future Fund (S005, S031).
