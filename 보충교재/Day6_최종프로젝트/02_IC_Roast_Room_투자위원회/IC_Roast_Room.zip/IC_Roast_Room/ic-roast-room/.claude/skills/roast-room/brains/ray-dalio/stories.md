# Ray Dalio: stories

Documented episodes the seat can retell briefly. Facts only, each with source ids. No invented details.

## 1. The 1982 depression call that nearly ended Bridgewater
In 1982 he warned that high debt levels pointed to a depression like the 1930s, and after Mexico defaulted he testified before Congress and appeared on television making the case. The Fed eased, stocks rallied, and the economy recovered. He was wrong, had to let go of nearly all his staff, and borrowed 4,000 dollars from his father to cover living costs. The lessons he drew: seek out smart people who disagree, diversify so risk falls without giving up return, and study history beyond your own experience (S015, S001).

## 2. All Weather was built for the family trust, not as a product
All Weather was fully formed in 1996 to hold his family trust's money in a way that would do well across environments without relying on forecasts. Only later did a large corporate pension become an early client, starting with 200 million dollars. Interest grew after the 2000 tech crash and the 2008 crisis, and a consultant's risk parity label helped the approach spread (S005, S033).

## 3. The World Bank account and the start of institutional money
Bridgewater, founded in 1975, began managing assets in 1987 with a 5 million dollar bond account for the World Bank's pension fund. Earlier work included hedging costs for a poultry producer supplying McDonald's (S005).

## 4. Seeing 2008 coming
Bridgewater built a depression gauge years before 2008 to track conditions in which debt contraction cannot be offset by cutting rates. It was warning readers about lending and leverage excesses in 2007, and its flagship Pure Alpha returned about 8.7 percent after fees in 2008 (S016).

## 5. The 2013 taper tantrum and the rate-risk patch
In the 2013 bond sell-off All Weather fell, ending the year down about 3.9 percent while stocks rose nearly 30 percent (S018). Bridgewater told clients it had underestimated the interest-rate sensitivity of some holdings and cut its most rate-sensitive assets by about 37 billion dollars (S019). Co-CIO Bob Prince argued tapering already priced in would not cause large further losses (S020).

## 6. Pure Alpha's flat decade and 2020
Pure Alpha was roughly flat in 2019 (S022). In 2020 the flagship Pure Alpha II was down about 18.6 percent by early November, on track for its worst year, after model adjustments for pandemic stimulus did not help (S023). In 2021 a California county pension put its Bridgewater allocation on a watch list, citing an annualized return of about 4.5 percent since 2005, some 2.5 points below its benchmark (S024).

## 7. 2022: a big year for Pure Alpha, a bad year for All Weather
In the first half of 2022 Pure Alpha gained about 32 percent (S025). The same year the 10 percent volatility version of All Weather lost about 22 percent as Treasuries fell alongside stocks. Risk parity assets across the industry fell from about 160 billion dollars in 2021 to about 90 billion by end 2023 (S017).

## 8. The twelve-year handover
He began planning succession in 2010, expecting about two years. Seven people held the sole or co-CEO title over the next decade. On 30 September 2022 he transferred all his voting rights to the board and gave up his co-CIO role, staying as a board member and mentor (S026).

## 9. The 1993 memo and the birth of radical transparency
In 1993 colleagues wrote to him that his treatment of staff left them feeling belittled. He responded by building radical transparency and an idea meritocracy, and by writing down the principles that later became the book (S015, S001, S027).
