# Sources: David Swensen

32 sources. Books, Yale Investments Office endowment reports, a recorded Yale lecture, interviews, op-ed coverage, press accounts, and independent research on the Yale model. Each item was checked by web search or a direct fetch in October 2026. Where a URL could not be fetched, the url column is "-" and the title, publisher, and year are given. Secondary items (reviews, press accounts) are marked as such in the type column; use them for facts and context, not for his own reasoning.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Pioneering Portfolio Management: An Unconventional Approach to Institutional Investment, 1st ed. (Free Press, ISBN 0684864436) | https://openlibrary.org/isbn/0684864436 | 2000-05-15 | book |
| S002 | Pioneering Portfolio Management, fully revised and updated 2nd ed. (Free Press / Simon & Schuster, ISBN 9781416544692) | https://www.simonandschuster.com/books/Pioneering-Portfolio-Management/David-F-Swensen/9781416554035 | 2009-01-06 | book |
| S003 | Pioneering Portfolio Management (revised ed.), Chapter 3: Investment and Spending Goals (course copy, Yale CS 458) | https://zoo.cs.yale.edu/classes/cs458/lectures/old2016/PPMrevision_Chap3.pdf | 2009 | book chapter |
| S004 | Unconventional Success: A Fundamental Approach to Personal Investment (Free Press, ISBN 0743228383) | https://openlibrary.org/isbn/0743228383 | 2005-08-02 | book |
| S005 | Unconventional Success, Conventional Foolishness (Motley Fool review, S.J. Caplan) | https://www.fool.com/investing/mutual-funds/2005/10/14/quotunconventional-successquot-conventional-foolis.aspx | 2005-10-14 | review (secondary) |
| S006 | ECON 252 Financial Markets (2008), Lecture 9: Guest Lecture by David Swensen (Open Yale Courses, transcript) | https://oyc.yale.edu/economics/econ-252-08/lecture-9 | 2008-02-13 | talk |
| S007 | The Yale Endowment 2007 (Yale Investments Office annual report) | https://investments.yale.edu/wp-content/uploads/2024/10/2007YaleEndowment.pdf | 2007 | official report |
| S008 | The Yale Endowment 2009 (Yale Investments Office annual report) | https://investments.yale.edu/wp-content/uploads/2024/10/2009YaleEndowment.pdf | 2009 | official report |
| S009 | The Yale Endowment 2015 (Yale Investments Office annual report, course copy) | https://zoo.cs.yale.edu/classes/cs458/lectures/old2016/Yale_Endowment_15.pdf | 2015 | official report |
| S010 | The Yale Endowment 2021 (Yale Investments Office annual report, tribute to Swensen's tenure) | https://investments.yale.edu/wp-content/uploads/2024/10/2021YaleEndowment.pdf | 2021 | official report |
| S011 | Self-confident yet selfless, Yale's David Swensen dies at 67 (Yale News) | https://news.yale.edu/2021/05/06/self-confident-yet-selfless-yales-david-swensen-dies-67 | 2021-05-06 | obituary (secondary) |
| S012 | David Swensen's coda (Yale News, on the FY2021 results) | https://news.yale.edu/2021/10/22/david-swensens-coda | 2021-10-22 | press (secondary) |
| S013 | Yale's Financial Wizard, David Swensen, Says Most Endowments Shouldn't Try to Be Like Yale (ProPublica interview) | https://www.propublica.org/article/yales-financial-wizard-david-swensen-says-most-endowments-shouldnt-try-to-b | 2009-02-18 | interview |
| S014 | University justifies investment strategies (Yale Daily News, on the FY2008 report and update to Dec 2008) | https://yaledailynews.com/blog/2009/03/04/univ-justifies-investment-strategies | 2009-03-04 | press (secondary) |
| S015 | Despite endowment loss, Yale performs creditably in difficult environment (Yale News) | https://news.yale.edu/2009/10/02/despite-endowment-loss-yale-performs-creditably-difficult-environment | 2009-10-02 | press (secondary) |
| S016 | Citing Recession, Yale Makes Deeper Cuts (Harvard Magazine) | https://www.harvardmagazine.com/index%2ephp/2009/02/citing-recession-yale-makes-deeper-cuts | 2009-02-25 | press (secondary) |
| S017 | The endowment's swoon (Harvard Magazine, FY2009 results for Harvard, Yale, Princeton) | https://harvardmagazine.com/2009/11/harvard-endowment-update?page=all | 2009-11-01 | press (secondary) |
| S018 | 8/19/11: David Swensen '80PhD (Yale Alumni Magazine, on his NYT op-ed) | https://www.yalealumnimagazine.com/blog_posts/1070-8-19-11-david-swensen-80phd | 2011-08-19 | press (secondary) |
| S019 | The Mutual Fund Merry-Go-Round, by David F. Swensen (The New York Times, Sunday Review op-ed; title and date confirmed via S018, page not fetchable) | - | 2011-08-14 | op-ed |
| S020 | Yale CIO disses Harvard (Institutional Investor, remarks at the NACUBO Endowment Management Forum) | https://www.institutionalinvestor.com/article/2btfr722qy693wqrpvegw/innovation/yale-cio-disses-harvard | 2006-02-06 | press (secondary) |
| S021 | How Yale's Endowment Negotiates Fees (Institutional Investor, on the 2016 Yale report) | https://www.institutionalinvestor.com/article/b1505q8t4yrt18/how-yales-endowment-negotiates-fees | 2017-04-10 | press (secondary) |
| S022 | Yale Endowment Blasts Low-Fee Critics, Says Gains Would Lag (Financial Advisor, from Bloomberg) | https://www.fa-mag.com/news/yale-endowment-blasts-low-fee-critics--says-gains-would-lag-32235.html | 2017-04 | press (secondary) |
| S023 | Yale Defends Fee Structure (The Harvard Crimson) | https://api.thecrimson.com/article/2017/4/25/yale-defends-fee-structure | 2017-04-25 | press (secondary) |
| S024 | Swensen: Funds of funds are a cancer (PERE, C. Witkowsky) | https://www.pei-privaterealestate.com/equity/swensen-funds-of-funds-are-a-cancer/ | 2013-01-21 | press (secondary) |
| S025 | Yale's investment chief shares some strategies (Yale Daily News interview) | https://yaledailynews.com/blog/2005/09/30/yales-investment-chief-shares-some-strategies/ | 2005-09-30 | interview |
| S026 | Lerner, Schoar and Wang, Secrets of the Academy: The Drivers of University Endowment Success (NBER WP 14341; Journal of Economic Perspectives 22(3)) | https://www.nber.org/papers/w14341 | 2008 | paper |
| S027 | David Swensen: The Peter Lynch of Institutional Investing (Morningstar, J. Rekenthaler) | https://www.morningstar.com/columns/rekenthaler-report/david-swensen-peter-lynch-institutional-investing | 2021-05 | commentary (secondary) |
| S028 | Swensen model still highly regarded among investors (Yale Daily News) | https://yaledailynews.com/blog/2010/09/28/swensen-model-still-highly-regarded-among-investors | 2010-09-28 | press (secondary) |
| S029 | Takahashi and Alexander, Illiquid Alternative Asset Fund Modeling (Journal of Portfolio Management, vol. 28 no. 2; Yale Investments Office cash-flow model) | - | 2002 | paper |
| S030 | The Evolution of the Yale Model for Institutional Investing (Chronograph; describes the Takahashi-Alexander model and the 40/60 allocation vs selection split) | https://www.chronograph.pe/the-evolution-of-the-yale-model-for-institutional-investing/ | n.d. | commentary (secondary) |
| S031 | Model Portfolio 7: Unconventional Success by David Swensen (My Money Blog, summary of the book's individual-investor allocation) | https://mymoneyblog.com/model-portfolio-7-unconventional-success-by-david-swensen.html | n.d. | review (secondary) |
| S032 | David Swensen Wrote an Angry Email. Then He Pressed Send. (Institutional Investor, A. Whyte) | https://www.institutionalinvestor.com/index%2Ephp/article/2bsxhrs016gb7sevaw9vk/culture/david-swensen-wrote-an-angry-email-then-he-pressed-send | 2018-05-07 | press (secondary) |

## Notes on verification

- S019: the New York Times page blocked automated fetching. Title, author, outlet, and date are confirmed by S018.
- S029: the journal page blocked fetching. Authors, title, journal, and volume are confirmed by S030 and by citations in later academic work; the exact page range is not listed here.
- The HBS case series on the Yale University Investments Office (Lerner, from 1997) exists but was not read and is not used.
