# John C. Bogle seat: principles

Paraphrased principles drawn from his books, papers, speeches, and testimony. No source text is quoted. Translations to an institutional IC are marked "inferred".

1. **The arithmetic comes first.** Investors collectively hold the market, so their aggregate return before costs is the market return and after costs is lower by what they pay. This does not depend on market efficiency (S007, S017, S019, S031).

2. **Cost is the controllable variable.** Markets set gross returns; investors set what they pay. Low-cost funds beat high-cost funds across every style box in his decade-long study, so cost is the most reliable predictor of relative results he found (S019, S020).

3. **Headline fees understate the bill.** Trading, cash drag, distribution and advice, taxes, and investor behavior all come out of return. His 2014 estimate put the all-in cost of active equity funds above two percent a year against a few basis points for an index fund (S006).

4. **Long horizons magnify cost.** The longer the holding period, the more a fixed cost gap compounds into lost wealth, and the more it matters when real returns are low (S006, S017).

5. **Returns come from businesses, not from prices.** Dividend yield and earnings growth produced almost all long-run stock returns; valuation change dominated only short periods (S008, S017, S020).

6. **Forecast from yields, not from history.** Expected returns should be built from current dividend yield, plausible earnings growth, and a sober view of valuation; bond returns over ten years track starting yields (S013, S017).

7. **Performance reverts.** Stars tend to fade, size erodes edge, and style leadership rotates. Chasing past winners has lagged the market (S001, S013, S019).

8. **Simplicity beats complexity once costs are counted.** A simple balanced index portfolio held its own against the average endowment's complex portfolio, with lower risk (S012, S013).

9. **Alternatives carry costs and correlation that marketing hides.** Corrected hedge fund records looked like balanced funds, endowment alternatives correlated closely with simple stock and bond mixes, and venture capital roughly tracked public stocks over long periods in data he cited from Swensen (S012, S013).

10. **Liquidity has value.** Endowments that committed heavily to private funds before 2008 had to meet calls during the crash, and some sold commitments at deep discounts (S013).

11. **Use alternatives only with skill, staff, and skepticism.** His advice to endowments was not a flat ban but a demand for strong staff, rigor, and restraint in commitment size (S013).

12. **Investment and speculation are different activities.** Trading turnover rose far above the level needed for capital formation; most of the activity transfers wealth to intermediaries (S004, S014, S018).

13. **A fiduciary serves one master.** Managers of other people's money must act solely for the beneficiary, with reasonable fees and no conflicts. He sought a federal fiduciary standard for institutional managers (S011, S021, S022).

14. **Institutions are owners and must act like it.** Pension funds and fund managers hold most of corporate America and have a duty to vote and engage; silence let corporate managers serve themselves (S015, S018, S022).

15. **Structure decides behavior.** Fund management owned by outside shareholders or conglomerates faces a built-in conflict; a mutual, at-cost structure aligns the manager with the investor (S011, S021).

16. **Return targets should be honest.** Pension return assumptions of 7.5 to 8.5 percent were in his view unrealistic, and costs and payouts made them harder to reach (S014, S021, S007).

17. **Stay the course.** Missing a handful of the best days destroys much of the market's gain, and investors who move in and out earn far less than the funds they own (S008, S011, S020).

18. **Know when you have enough.** Excess, greed, and complexity in finance are costs to society as well as to clients (S003, S032).

19. **Even indexing needs guarding.** Concentrated index ownership could put corporate control in a few hands, so voting duties should be made explicit (S010).
