# John C. Bogle seat: books and influences

## His books
- **Bogle on Mutual Funds** (McGraw-Hill, 1993): his first book on fund costs and choosing funds (S030).
- **Common Sense on Mutual Funds** (Wiley, 1999; updated 10th anniversary edition 2009): the full case for indexing, simplicity, reversion to the mean, the cost of size, and fund structure (S001).
- **John Bogle on Investing: The First 50 Years** (McGraw-Hill, 2000): collected speeches and essays (S030).
- **Character Counts** (McGraw-Hill, 2002): the Vanguard culture and stewardship (S030).
- **The Battle for the Soul of Capitalism** (Yale University Press, 2005): owners' capitalism displaced by managers' capitalism in corporations and funds (S005, S015).
- **The Little Book of Common Sense Investing** (Wiley, 2007; 10th anniversary edition 2017): own the whole market at minimal cost and hold it (S002).
- **Enough.** (Wiley, 2008): the costs of excess, greed, and complexity in finance and life (S003, S032).
- **Don't Count on It!** (Wiley, 2010): essays on illusions in investing (S030).
- **The Clash of the Cultures: Investment vs. Speculation** (Wiley, 2012): short-term speculation crowding out long-term investment, fiduciary duty, the retirement system (S004).
- **Stay the Course: The Story of Vanguard and the Index Revolution** (Wiley, 2018): the history of Vanguard and indexing (S030).

## Thinkers and works he credits
- **William F. Sharpe, The Arithmetic of Active Management (1991):** active and passive are equal before costs, so active must trail after costs (S031, S017).
- **Paul Samuelson:** the Nobel economist who in 2000 ranked the creation of the index fund alongside the invention of the wheel and the alphabet (paraphrased) (S029).
- **Benjamin Graham:** the average institutional manager cannot beat the market over time; large holders should act against poor management (S014, S018, S019).
- **John Maynard Keynes:** the enterprise versus speculation distinction behind his split of return sources (S017).
- **Warren Buffett:** expenses and emotions as investors' enemies; the innovator, imitator, fool sequence; long-term ownership (S013, S014, S018).
- **David Swensen:** data showing venture capital roughly tracked public stocks, and the view that low-cost passive funds run at cost best serve individuals (S012, S013, S014).
- **Burton Malkiel:** corrected hedge fund return studies (S013).
- **Benoit Mandelbrot, Frank Knight, Hyman Minsky, Karl Popper:** fat tails, risk versus uncertainty, finance overwhelming the productive economy, and seeking evidence that would disprove one's beliefs (S008).
- **Charlie Munger:** the size of total investment costs for foundations and the overconfidence of professional processes (S012).
- **Harlan Fiske Stone and Benjamin Cardozo:** the fiduciary standard as stricter than the morals of the marketplace (paraphrased) (S021).
