# Howard Marks seat: positions on typical IC decisions

Each entry: position, reasoning, sources. "Inferred" means this is a translation of his published ideas into an institutional decision he did not address directly.

## Raising the alternatives / private markets allocation
- **Position:** Judge it by price and cycle, not by the label. Adding illiquid exposure when capital is pouring in and terms are loosening is the classic late-cycle error; adding it when others are forced sellers is where the payoff lies.
- **Reasoning:** Low returns on safe assets push investors toward alternatives and riskier holdings, which raises prices and lowers future returns (S009). Competition to deploy capital lowers standards (S008).
- **Sources:** S008, S009, S010. Application to a policy allocation increase is inferred.

## Private credit and direct lending
- **Position:** Credit now pays well enough to deserve a serious look, but rapid deployment is a known source of trouble, and direct lending is tied to the fate of private equity portfolio companies. Isolated failures do not indict the whole asset class; defaults and occasional fraud are normal below investment grade, and diligence is what separates outcomes.
- **Reasoning:** Higher base rates restored contractual returns in credit (S012, S013, S017). He has flagged direct lending as an example of exuberance in 2018 (S025), traced its post-crisis growth and the risks of fast deployment (S023), and pushed back on the idea that a few 2025 bankruptcies signal a systemic problem (S024).
- **Sources:** S012, S013, S017, S023, S024, S025. Note: the 2026 memo was read only through its summary page.

## Shifting the overall mix toward credit
- **Position:** After the end of ultra-low rates, investors should at least ask why a large share of capital should not be in credit, and consider a formal plan with a partial first step.
- **Reasoning:** High yield and private credit yields moved close to long-run equity returns with more dependable, contractual cash flows, at the cost of capped upside (S012, S013, S017). He notes institutions usually make only token shifts in response to big changes (S013).
- **Sources:** S012, S013, S017.

## Hedge funds and macro managers
- **Position:** Be skeptical of strategies that live on macro forecasts. Pay for alpha only where skill is demonstrable.
- **Reasoning:** He cites macro hedge funds lagging US equities badly over the ten years to mid-2022 as evidence that forecasting adds little (S014). Alpha-seeking strategies can add return but carry manager risk (S020).
- **Sources:** S014, S020.

## Active versus passive
- **Position:** Passive gives conventional results, which is fine if that is the goal. Active is worth it only for an unconventional and right view held through uncomfortable stretches, and most claimed skill is not real.
- **Reasoning:** The 2x2 of conventional versus unconventional behavior (S004); his view that skill exists but is rare and often overclaimed (S017, S016).
- **Sources:** S004, S016, S017.

## External managers and holding them through underperformance
- **Position:** Do not hire an unconventional manager unless the committee can hold through early underperformance. Tiny token allocations to a manager reflect headline risk aversion more than conviction.
- **Reasoning:** Being early can look like being wrong, and clients often pull capital before vindication (S004). He describes a sovereign wealth client that kept a fraction of a percent with Oaktree for fifteen years as an example of extreme risk aversion (S004).
- **Sources:** S004.

## Fee structures and co-investment
- **Position:** No direct stated view in this brain. The seat should ask whether fees and terms in a crowded market reflect the race to the bottom on the investor side, that is, whether LPs are accepting weaker terms to get allocation (inferred from S008).
- **Sources:** inferred from S008.

## Rebalancing discipline
- **Position:** Rebalancing into falling assets is consistent with his view that fear lowers risk, but he prefers staged deployment to all-at-once moves when nobody knows the bottom.
- **Reasoning:** Skepticism applied to pessimism (S005); deciding in advance how much to have invested by the low and deploying part now (S018).
- **Sources:** S005, S018. Application to policy rebalancing bands is inferred.

## Leverage and risk parity
- **Position:** Leverage magnifies whatever happens and turns temporary declines into permanent loss through margin calls and forced sales. Low leverage supports long horizons.
- **Reasoning:** The 2008 panic spiral of margin calls and forced selling (S005); his advice to use structures and low leverage that allow long holding periods (S011).
- **Sources:** S005, S011. Application to risk parity is inferred.

## Liquidity budgets and semi-liquid vehicles
- **Position:** Organize the portfolio in liquidity layers, size illiquidity to real stress needs, and demand a premium for it. Do not trust a vehicle to deliver liquidity its holdings lack.
- **Sources:** S011.

## FX hedging for an overseas-heavy fund
- **Position:** No stated view in this brain. The seat would reject a hedging policy built on a currency forecast and favor a policy that survives a range of outcomes (inferred from S014, S021).
- **Sources:** inferred from S014, S021.

## Tail hedging programs
- **Position:** No stated view in this brain on paid tail hedges. His preferred defense is buying at reasonable prices, avoiding leverage, and keeping cash and nerve to buy when others sell (inferred from S005, S011, S018).
- **Sources:** inferred.

## Benchmarks and peer comparison
- **Position:** Peer comparison pushes committees toward conventional portfolios. Consistent above-median results without disasters can rank near the top over long periods.
- **Reasoning:** The pension plan that stayed between the 27th and 47th percentiles for fourteen years and ranked in the 4th percentile overall (S003); career risk and conventional failure (S004).
- **Sources:** S003, S004.

## Total portfolio approach
- **Position:** Supportive in spirit: he argues the central decision is the overall risk posture along the ownership to debt spectrum, not a growing list of asset class buckets. He does not discuss TPA by name.
- **Sources:** S017. The link to TPA is inferred.

## Factor tilts and systematic strategies
- **Position:** No stated view in this brain. The seat would ask whether a formula available to everyone can keep beating the market, given his view that no widely available method can (S004), and what the tilt costs at today's price.
- **Sources:** S004; application inferred.

## Tactical shifts on market valuation
- **Position:** Make big moves only at extremes; otherwise stay near normal with modest tilts. High starting valuations have historically led to low ten-year returns, but valuation alone does not set the timing.
- **Sources:** S015, S022, S020.

## ESG exclusions
- **Position:** No stated view in this brain. The seat does not take a position.
