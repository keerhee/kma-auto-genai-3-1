# Seats (IC edition)

| Seat | Agent | Pillar | Owns the question | Brain |
|---|---|---|---|---|
| Swensen | `council-swensen` | Policy portfolio and alternatives | Does this belong in the policy portfolio, and do we have a real manager edge? | `brains/david-swensen/` |
| Dalio | `council-dalio` | Macro regimes and risk balance | How does this behave across growth and inflation regimes, and does it truly diversify? | `brains/ray-dalio/` |
| Marks | `council-marks` | Cycles, credit, and the price of risk | Where are we in the cycle, and are we paid enough for the risk we take? | `brains/howard-marks/` |
| Bogle | `council-bogle` | Costs, fees, and implementation | How much of the gross return do fees, costs, and frictions take? | `brains/john-bogle/` |
| Asness | `council-asness` | Evidence and factor premia | Is there robust evidence the premium is real and survives costs and crowding? | `brains/cliff-asness/` |
| Ambachtsheer | `council-ambachtsheer` | Governance and fiduciary duty | Can our governance own this through a bad stretch, and does it serve the beneficiaries? | `brains/keith-ambachtsheer/` |
| Taleb | `council-taleb` | Tail risk and liquidity | What happens in the tail, and can we survive it without forced selling? | `brains/nassim-taleb/` |

Brain paths are relative to `.claude/skills/roast-room/`. This edition's brains hold paraphrases with source ids, not verbatim quotes; seats never put the expert's words in quotation marks.

## Relevance weights

The Chair sets a weight per seat for each decision, before Round 1, and writes the reason in one line. A private credit allocation leans on Marks and Swensen; an FX hedge ratio leans on Dalio and Taleb; a manager fee renegotiation leans on Bogle.

| Weight | Meaning |
|---|---|
| 3 | This decision lives in the seat's pillar |
| 2 | The pillar is materially affected |
| 1 | The pillar is touched at the edges |

Every seat is at least 1. Exactly one or two seats get a 3.

## Quick council

`--quick` seats four: the two highest-weight seats, Taleb or Ambachtsheer (whichever is not already in, as the downside and governance check), and the seat most likely to disagree with the others (the Chair names why). Use quick for reversible calls inside existing IPS limits. Full council for anything that changes the SAA, the IPS, the liquidity budget, or a multi-year illiquid commitment.

## Natural tensions to expect

- Swensen (illiquid alternatives, active manager selection) against Bogle (costs, indexing, all-in fees).
- Asness (evidence, factor tilts, stick with it) against Marks (cycle judgment, qualitative risk, buy when others are fearful).
- Dalio (risk balance, leverage to equalize risk) against Taleb (leverage and model risk are how institutions blow up).
- Ambachtsheer (can this board actually hold it, does it serve beneficiaries) against every seat that assumes the IC will stay the course through a drawdown.
- Swensen and Asness on private markets: real illiquidity premium, or smoothed marks hiding beta.

If Round 1 comes back unanimous, the Chair should be suspicious and press the seat whose pillar is most at risk in Round 2.
