# Live room files

The Roast Room (a local web app on http://localhost:4730) watches the sessions folder and plays a council as its files appear: portraits talk one at a time, rebuttal arrows fly, votes land, and the verdict comes up. It reads the round files you already write, plus four small JSON files. Write each one at the moment listed, as plain JSON (no comments, no trailing commas). Seat names can be keys (`ambachtsheer`) or display names (`Ambachtsheer`).

The room is optional. Write these files anyway; they cost a few lines and the council runs the same without the room.

## Order

| When | File |
|---|---|
| Step 2, with `brief.md` | `council.json` |
| Round 1 cards back | `round-1.md` (one `## <Seat>` heading per card, cards verbatim, `## Chair notes` last) |
| After the Round 1 Chair notes | `cruxes.json` |
| Round 2 cards back | `round-2.md` |
| With `draft-resolution.md` | `draft.json` (skip in quick mode when Round 3 is skipped) |
| Round 3 cards back | `round-3.md` |
| Last, after `verdict.md` | `verdict.json` |

## council.json

```json
{
  "title": "사모신용 비중 3%에서 6%로 확대",
  "decision": "사모신용 전략 배분을 늘릴지, 얼마나, 어떤 속도로.",
  "mode": "full",
  "options": [
    { "id": "A", "label": "6%로 즉시 확대 (2년 커밋)" },
    { "id": "B", "label": "4.5%까지 3빈티지 분할" },
    { "id": "C", "label": "현 3% 유지" }
  ],
  "weights": {
    "marks": { "weight": 3, "reason": "신용 사이클과 위험 보상이 핵심" },
    "taleb": { "weight": 2, "reason": "유동성 예산과 강제 매도 위험" }
  },
  "seats": ["swensen", "dalio", "marks", "bogle", "asness", "ambachtsheer", "taleb"],
  "brief": "Two or three sentences.",
  "assumptions": ["미집행 약정 비율 40% (assumed)"]
}
```

`mode` is `full` or `quick`. `seats` lists only the seats at the table. Give every seat at the table a weight (1 to 3). Option labels stay short: under 50 characters.

## cruxes.json

```json
{
  "cruxes": [
    {
      "question": "Is the private credit spread still paying for the risk?",
      "sides": [
        { "position": "Yes, senior direct lending still pays", "seats": ["Swensen", "Marks"] },
        { "position": "No, smoothed marks hide beta", "seats": ["Asness", "Taleb"] }
      ]
    }
  ],
  "unanimous": false,
  "note": "One plain sentence on what the room is fighting about."
}
```

One to three cruxes. Questions under 90 characters, positions under 50.

## draft.json

```json
{
  "option": "B",
  "label": "GO WITH CONDITIONS",
  "recommendation": "One or two sentences.",
  "conditions": ["Checkable condition"],
  "next_steps": ["Step with a date"],
  "cheapest_test": "One line.",
  "kill_criteria": "One line."
}
```

## verdict.json

```json
{
  "label": "GO WITH CONDITIONS",
  "call": "One or two sentences the IC can act on, naming the option.",
  "recommended": "B",
  "why": [
    { "point": "One line.", "seat": "Marks", "framework": "Pendulum" }
  ],
  "minority": { "seat": "Taleb", "quote": "The seat's own words, copied from a card.", "would_have_to_be_true": "One line." },
  "next_steps": [ { "when": "This week", "action": "One line." } ],
  "kill_criteria": "One line.",
  "conditions": ["Checkable condition"],
  "fights": [ { "crux": "The question", "story": "Who was on each side, who moved, how it resolved." } ],
  "amendments": [ { "seat": "Bogle", "amendment": "One line.", "adopted": true, "reason": "One line." } ],
  "cheapest_test": "One line.",
  "revisit": "When and with what numbers.",
  "override_note": ""
}
```

`label` is one of GO, GO WITH CONDITIONS, RESHAPE, WAIT, DON'T DO IT. Put the three strongest arguments first in `why` and at most three `next_steps`; the room shows those up front and folds the rest under "Full detail". The room computes the option scores, confidence, and votes itself from the cards, so they are not in this file.
