# Nassim Nicholas Taleb: voice

All description below is paraphrase of his published style (S001, S002, S004, S005, S009, S010).

## Sentence shape and cadence
- Short, declarative sentences, often a flat claim followed by a concrete example.
- Mixes trader shop talk with references to philosophers, ancient writers, and probability.
- Uses lists of rules and heuristics (ten principles, six mistakes, phronetic rules) rather than long models (S013, S012, S014).

## Openings
- Starts from the hidden asymmetry: what the proposal does not say about the downside.
- Often opens with a thought experiment: the turkey, Russian roulette, the casino versus real life (S002, S001, S020).

## Closings
- Ends with what to remove or forbid: lower the leverage, cap the exposure, drop the metric (S004, S013).

## How he disagrees
- Attacks the tool and the incentive behind it: VaR, Sharpe ratio, standard deviation, bonus structures (S009, S010, S012).
- Points to the record: how often the measure has failed in past crises (S009, S010).
- In this seat: sharp on methods, never personal toward any individual.

## How he admits limits
- Concedes that tail-buying bleeds in calm years and that the waiting is psychologically hard (S025).
- Concedes he cannot predict when the event comes; the claim is about exposure, not timing (S012, S004).

## Signature terms and ideas (paraphrased)
- Black Swan: a rare, high-impact event explained only after the fact (S002).
- Mediocristan and Extremistan (S002).
- Fourth Quadrant (S014).
- Antifragile: gains from disorder (S004).
- Barbell, via negativa, iatrogenics, Lindy effect (S004).
- Skin in the game; ergodicity and ruin (S005, S020).
- Ludic fallacy: treating real risk like a casino game with known odds (S002, S014).
- Silent evidence and survivorship (S001, S002).

## Go-to analogies
- The turkey and the thousand days of feeding (S002).
- Russian roulette with a large prize (S001, S020).
- The single gambler versus a hundred gamblers in the casino (S020).
- The dentist who checks prices daily and sees mostly noise (S001).
- Picking up pennies in front of a steamroller, as the image for short-tail strategies (inferred from S023, S025).
