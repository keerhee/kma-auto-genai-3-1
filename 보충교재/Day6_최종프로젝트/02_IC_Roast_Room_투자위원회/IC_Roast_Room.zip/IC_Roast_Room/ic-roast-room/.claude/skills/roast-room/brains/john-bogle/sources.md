# John C. Bogle seat: sources

Every source below was checked with a web search or a fetch of the listed URL during compilation (October 2026). Book entries point to a publisher, catalog, or reference page that confirms title, publisher, and year. Speech PDFs are hosted on johncbogle.com, the archive of the Bogle Financial Markets Research Center. Content summaries in the other brain files are paraphrases of these sources; no source text is quoted.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Common Sense on Mutual Funds, Updated 10th Anniversary Edition (Wiley; first edition 1999). Table of contents used for chapter themes | https://gov.wiley.com/WileyCDA/WileyTitle/productCd-0470138130,descCd-tableOfContents.html | 2009 (orig. 1999) | book |
| S002 | The Little Book of Common Sense Investing (Wiley; 10th Anniversary Edition 2017, ISBN 978-1-119-40450-7) | https://en.wikipedia.org/wiki/The_Little_Book_of_Common_Sense_Investing | 2007, 2017 | book (reference page) |
| S003 | Enough. True Measures of Money, Business, and Life (Wiley) | https://gov.wiley.com/WileyCDA/WileyTitle/productCd-0470398515,descCd-reviews.html | 2008 | book |
| S004 | The Clash of the Cultures: Investment vs. Speculation (Wiley, ISBN 9781118238219). Contents include the double-agency society, fund managers as fiduciaries, the index fund, the retirement system | https://oreilly.com/library/view/the-clash-of/9781118238219 | 2012 | book |
| S005 | The Battle for the Soul of Capitalism (Yale University Press, ISBN 0300109903). Review in Journal of Pension Economics and Finance | https://core-cms.cambridgecore.org/core/journals/journal-of-pension-economics-and-finance/article/battle-for-the-soul-of-capitalism-john-c-bogle-yale-university-press-2005-isbn-0300109903-288-pages/5B4394CD67D8DBD94E5B2D59F6215E56 | 2005 | book |
| S006 | The Arithmetic of All-In Investment Expenses, Financial Analysts Journal 70(1), 13-21 | https://rpc.cfainstitute.org/research/financial-analysts-journal/2014/the-arithmetic-of-all-in-investment-expenses | 2014-01 | paper |
| S007 | The Relentless Rules of Humble Arithmetic, Financial Analysts Journal 61(6), 22-35 | https://ideas.repec.org/a/taf/ufajxx/v61y2005i6p22-35.html | 2005-11 | paper |
| S008 | Black Monday and Black Swans, Financial Analysts Journal 64(2), 30-40 (text at Bogle Center) | https://boglecenter.net/wp-content/uploads/risk_mgmt.pdf | 2008-03 | paper |
| S009 | The Index Mutual Fund: 40 Years of Growth, Change, and Challenge, Financial Analysts Journal 72(1), 9-13 | https://ideas.repec.org/a/taf/ufajxx/v72y2016i1p9-13.html | 2016-01 | paper |
| S010 | Bogle Sounds a Warning on Index Funds, Wall Street Journal commentary (reprint) | https://shareholderforum.com/ACCESS/Library/20181129_WSJ.htm | 2018-11-29 | op-ed |
| S011 | Testimony before the Senate Governmental Affairs Subcommittee on Financial Management, the Budget, and International Security | https://www.hsgac.senate.gov/imo/media/doc/110303bogle.pdf | 2003-11-03 | testimony |
| S012 | The Investment Dilemma of the Philanthropic Investor, Philanthropy Roundtable | http://johncbogle.com/speeches/JCB_Philanthropy_10-02.pdf | 2002-10-31 | speech |
| S013 | The Lessons of History: Endowment and Foundation Investing Today, NMS Investment Management Forum | https://johncbogle.com/wordpress/wp-content/uploads/2011/09/NMS-9-12-12.pdf | 2011-09-12 | speech |
| S014 | Putting Investors First, CFA Society of Philadelphia endowment and foundation event | https://johncbogle.com/wordpress/wp-content/uploads/2015/07/CFA-Phila-6-4-15.pdf | 2015-06-04 | speech |
| S015 | The Ownership of Corporate America: Rights and Responsibilities, Council of Institutional Investors 20th Anniversary Meeting | http://johncbogle.com/speeches/JCB_CII0405.pdf | 2005-04-11 | speech |
| S016 | Risk and Risk Control in an Era of Confidence, New England Pension Consultants client conference | http://johncbogle.com/speeches/JCB_NE_Pension_4-00.pdf | 2000-04-06 | speech |
| S017 | The (Non) Lessons of History and the (Real) Lessons of Return Sources and Investment Costs, American Philosophical Society | https://johncbogle.com/wordpress/wp-content/uploads/2019/10/APS-11-10-12.pdf | 2012-11-10 | speech |
| S018 | Long Horizon Investing and Corporate Governance (slides), International Centre for Pension Management, Toronto | http://johncbogle.com/speeches/JCB_Toronto_June06.pdf | 2006-06-07 | talk |
| S019 | Three Challenges of Investing: Active Management, Market Efficiency, and Selecting Managers, AXA Rosenberg client conference | http://johncbogle.com/speeches/JCB_AXA_10-01.pdf | 2001-10-21 | speech |
| S020 | In Investing, You Get What You Don't Pay For, World Money Show, Orlando | http://johncbogle.com/speeches/JCB_MS0205.pdf | 2005-02-02 | speech |
| S021 | The Fiduciary Principle: No Man Can Serve Two Masters, Columbia Business School | https://johncbogle.com/wordpress/wp-content/uploads/2006/02/columbia-bus-4-1-09.pdf | 2009-04-01 | speech |
| S022 | Gretchen Morgenson, He Doesn't Let Money Managers Off the Hook, New York Times (reprint) | https://www.shareholderforum.com/sop/Library/20090412_NYT.htm | 2009-04-12 | interview article |
| S023 | Bogle: Smart Beta ETFs Do Not Work, Morningstar interview with Christine Benz | https://morningstar.co.uk/uk/news/152958/bogle-smart-beta-etfs-do-not-work.aspx | 2016-10-05 | interview |
| S024 | Vanguard's Jack Bogle Warns Smart Beta May Be Over-Promising, Bloomberg | https://www.bloomberg.com/news/articles/2017-04-27/vanguard-s-jack-bogle-warns-smart-beta-may-be-over-promising | 2017-04-27 | interview article |
| S025 | Bogle: Indexing Has Its Flaws, Financial Advisor magazine (remarks at CFA Institute annual conference, Philadelphia) | https://www.fa-mag.com/news/bogle--indexing-has-its--flaws-32882.html?print | 2017 | talk report |
| S026 | John Bogle Says Investors Don't Need to Own International Stocks, InvestmentNews | https://investmentnews.com/emerging-markets/john-bogle-says-investors-dont-need-to-own-international-stocks/71216 | 2017-04-29 | interview article |
| S027 | Be Wary of Stocks Outside the US: Bogle, CNBC Closing Bell | https://www.cnbc.com/amp/2015/01/26/be-wary-of-stocks-outside-the-us-bogle.html | 2015-01-26 | interview |
| S028 | John Bogle: ETF Speculation Insane for Longer-Term Investors, InvestmentNews | https://investmentnews.com/etfs/john-bogle-etf-speculation-insane-for-longer-term-investors/29753 | 2010-09-17 | interview article |
| S029 | 50 Years, 50 Facts: Indexing Since 1976, Vanguard | https://corporate.vanguard.com/content/corporatesite/us/en/corp/articles/50-years-50-facts-indexing-since-1976.html | 2026 | official history |
| S030 | John C. Bogle (biography and bibliography) | https://en.wikipedia.org/wiki/John_C._Bogle | accessed 2026-10 | reference |
| S031 | William F. Sharpe, The Arithmetic of Active Management, Financial Analysts Journal 47(1), 7-9 | https://marottaonmoney.com/wp-content/uploads/2021/07/The-Arithmetic-of-Active-Management.pdf | 1991-01 | paper (credited thinker) |
| S032 | Knowing When to Stop (review of Enough), Spokesman-Review | https://www.spokesman.com/stories/2008/oct/09/knowing-when-to-stop/ | 2008-10-09 | review |
| S033 | Jack Bogle Never Liked ETFs: Here's Why, ETF Stream | https://etfstream.com/articles/jack-bogle-never-liked-etfs-heres-why | 2019 (approx.) | article |
| S034 | Bogle speeches archive (index of titles, dates, venues) | https://johncbogle.com/wordpress/bogle-speeches/ | accessed 2026-10 | archive |

## Notes on verification

- S005: the book's existence, publisher, year, and ISBN were confirmed through the review listing and library catalogs; the book text itself was not read, so the brain uses it only for its broad theme (owners' capitalism displaced by managers' capitalism), which S015 previews.
- S024: the Bloomberg page returned only a short summary; the brain uses it only for the claim that he saw smart beta as over-promising and untested by a severe crash.
- S025: the article gives no exact day; internal references place it in 2017.
- S033: the article date is not stated on the page; the Nathan Most episode it reports is attributed there to The Little Book of Common Sense Investing (S002).
- The 1966 Wellington merger date and the January 1974 firing date are common in secondary accounts but were not confirmed in a fetched source, so the brain states only that he was fired after a merger he approved (S030).
