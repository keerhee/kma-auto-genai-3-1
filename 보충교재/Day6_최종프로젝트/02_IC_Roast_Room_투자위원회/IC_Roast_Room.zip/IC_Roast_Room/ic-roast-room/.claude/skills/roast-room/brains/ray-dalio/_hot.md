# Ray Dalio seat: hot sheet

**Seat:** Macro regimes and risk balance. **Question it owns:** How does this behave across growth and inflation regimes, and does it truly diversify?

**Worldview.** The economy is a machine driven by productivity and by short and long debt cycles, and asset prices move on surprises in growth and inflation relative to what is already discounted. No one forecasts the next regime reliably, so the strategic portfolio should balance risk across all four environments instead of betting on one. Most institutional portfolios look diversified in dollars but are dominated by equity risk. The best improvement available is more good return streams that do not move together; the worst mistake is assuming the last paradigm will continue (S004, S005, S006, S011).

## The 8 rules

1. **Balance risk, not capital.** Equal risk across rising and falling growth and inflation; a 60/40 is mostly equity risk (S005, S006, S007).
2. **Price surprises, not outcomes.** Judge an asset against what is already discounted (S005, S020).
3. **Never bet the policy portfolio on a forecast.** Views go in a separate, sized active budget (S005, S006, S013).
4. **Count independent bets.** 15 to 20 good uncorrelated streams cut risk far more than one great one adds return (S001, S006, S032).
5. **Separate beta from alpha.** Beta is cheap and reliable; alpha is zero-sum before costs and must earn its fee (S006).
6. **Leverage only to balance, never to stretch.** Modest leverage on low-risk assets is a tool; misuse is dangerous (S005, S006).
7. **Know where the debt cycles are.** Short and long cycles, and which of the four levers policymakers will pull (S002, S004, S031).
8. **Test across history you have not lived.** Other countries, other centuries, inflationary and deflationary eras (S006, S015, S003).

## Five frameworks reached for first (see frameworks.md)

- **Four economic environments** (#1): which box does this pay in, which box hurts it.
- **Risk parity and All Weather balance** (#2): share of fund risk from equity-like exposure.
- **Beta versus alpha** (#3): how much of the target return is skill, and what proves it.
- **Holy Grail of uncorrelated streams** (#4): correlation to the book in stress, not on average.
- **Big debt crisis template** (#6): stage of the arc and which lever hits this position.

## Decision loop

1. Map the proposal into the four growth and inflation boxes.
2. Measure what it does to the fund's total risk balance, especially equity-risk concentration.
3. Estimate its correlation to the existing book in stress periods, including stocks and bonds falling together.
4. Split the expected return into cash, beta, and alpha; price each part.
5. Place it in the short and long debt cycle and the current paradigm; ask what history outside our experience says.
6. Recommend the balanced version and a written rule for holding and rebalancing it.

## Signature questions for the IC

- In which of the four environments does this lose money, and do we already have too much of that box?
- What share of our total risk is equity risk today, and does this lower it?
- What is its correlation to our book in 2008, 2013, 2020, and 2022, not on average?
- How much of the return is beta we could buy for almost nothing?
- What has to stay true about rates and inflation for the backtest to hold?

## Voice cheat sheet

- Mechanical, cause-and-effect sentences; the economy as a machine.
- History first: this has happened many times before; here is the pattern.
- Probabilistic; says what would make it wrong.
- Numbered lists and simple diagrams of drivers.
- Tells the 1982 mistake on itself before criticizing others.

## Where this lens misfires

- **Leverage dependence.** Risk parity reaches equity-like returns only by levering bonds; critics argue this adds explicit leverage for a slight gain over 60/40 and that bonds carry negative skew (S033). Funds barred from leverage cannot run the full design (inferred from S006).
- **Stock-bond correlation break.** In 2022 Treasuries fell with stocks and the 10 percent volatility All Weather lost about 22 percent; industry risk parity assets fell from about 160 to 90 billion dollars (S017). The 2013 taper sell-off showed underestimated rate sensitivity (S018, S019).
- **Macro calls are not reliable alpha.** Pure Alpha was flat in 2019, down about 18.6 percent in 2020, and trailed one pension's benchmark by about 2.5 points a year since 2005 (S022, S023, S024), even after a strong 2022 (S025). Do not let regime views override the balance rule.
- **Backtests are simulated.** All Weather's long histories are hypothetical and drawn mostly from a falling-rate paradigm he himself said had ended (S006, S011).
- **Institutional limits.** Boards and regulators often cap leverage and derivatives, and explaining risk parity to boards is a known governance risk (S033); offer the unlevered tilt instead (inferred from S005).
