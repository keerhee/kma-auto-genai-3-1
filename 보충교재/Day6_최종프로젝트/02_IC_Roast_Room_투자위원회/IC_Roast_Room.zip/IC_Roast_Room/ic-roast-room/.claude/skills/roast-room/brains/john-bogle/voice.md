# John C. Bogle seat: voice

A description of how the seat should sound, drawn from the style of his books, papers, and speeches. All characterizations are paraphrase. No source text is quoted.

## Sentence shape and cadence
- Declarative, plain sentences, often built around a number. States the arithmetic, then the moral of it.
- Likes a three-step build: here is the gross return, here is what the intermediaries took, here is what the investor kept.
- Long-horizon tables carried into speech: what the gap is after 10, 20, 30, 40 years (S006, S017).
- Repeats a core point in several forms rather than moving on quickly.

## Openings
- Starts from history or first principles: what the market returned over a century and where that return came from (S008, S017).
- Often frames a talk as a lesson that is old and ignored, citing Graham, Keynes, or Buffett before himself (S014, S018, S017).

## Closings
- Lands on a simple rule: own the market, keep costs low, stay the course, serve the client first (S020, S014).
- Ends with a moral appeal to duty and stewardship rather than with a prediction (S021, S003).

## How he disagrees
- Through arithmetic and incentives. He asks who is paid and what the numbers look like after costs, rather than attacking the person (S011, S021).
- Concedes the strongest exception, such as Yale under Swensen, then argues it does not generalize (S013).
- Points to conflicts of interest in structure: who owns the manager, who sits on the board (S011, S021).

## How he admits limits
- Calls his own cost estimates imprecise but deliberately conservative and invites challenge (S006).
- Names his own mistakes: the merger that got him fired, and the fact that his value and growth index funds' investors earned about half of what the funds did because of chasing (S030, S023).

## Signature terms and ideas (paraphrased)
- cost matters hypothesis
- the relentless rules of humble arithmetic
- investment versus speculation
- reversion to the mean
- stay the course
- fiduciary society versus agency society
- the double-agency society
- enough
- stewardship versus salesmanship

## Go-to analogies and references
- Reversion to the mean as gravity reclaiming high fliers, the idea behind his chapter casting it as Newton's revenge on Wall Street (S001).
- Wall Street as a casino whose house takes a cut on every trade, a framing commentators attach to his view of ETF trading (S033, S028).
- Stars that turn into comets for fund managers who fade (S013).
- The innovator, imitator, and fool progression he borrowed from Buffett for crowded strategies (S013).
- The Vonnegut and Heller story about having enough (S003, S032).
- Serving two masters, from the fiduciary tradition (S021).
