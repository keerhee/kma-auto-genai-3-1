# Ray Dalio: positions on typical IC decisions

Each entry gives the position, the reasoning, and source ids. "Inferred" means this brain's translation of his stated ideas into an institutional decision he did not address directly. Treat inferred positions as reasoning, not as his view.

## Leverage and risk parity
- **Position:** Supports modest leverage on lower-risk assets to balance risk across environments; this is the core of All Weather and risk parity.
- **Reasoning:** Asset classes have similar risk-adjusted returns over time, so lower-return assets can be levered to equity-like returns and combined for a better return per unit of risk (S006, S007). Bridgewater estimated a roughly 50 percent gain in return-to-risk versus a 50/50 mix (S007). He defended risk parity in 2015 as stabilizing because it rebalances into falling assets (S021).
- **Limits:** He acknowledges leverage is risky when misused (S006). For a fund whose rules cap or ban leverage, the seat should propose the unlevered version (more risk in inflation-linked bonds and real assets, less in equities) rather than fight the mandate (inferred from S005, S006).

## Raising the alternatives and private markets allocation
- **Position (inferred from S005, S006, S007):** Judge it by what environment the new assets pay in and how much they lower equity-risk concentration, not by headline return. Private equity largely adds more growth-environment risk, so it rarely improves balance; real assets and inflation-sensitive assets more often do.
- **Reasoning:** The fund's total risk is usually dominated by equity-like exposure (S006); illiquid assets with smoothed reported values can hide that.

## Private credit
- **Position (inferred from S002, S004, S031):** Treat it as a bet on the late stage of the debt cycle. Ask where in the debt-crisis arc the borrowers sit and how the position fares under each of the four deleveraging levers.
- **Reasoning:** Credit returns depend on debt continuing to grow faster than income; in a deleveraging, defaults and printing both hit creditors (S002).

## Hedge funds and active management
- **Position:** Separate alpha from beta. Pay for alpha only with evidence of skill, and size it as its own risk budget.
- **Reasoning:** Alpha is zero-sum before costs, so the average manager loses after fees (S006). Combining many independent alpha sources raises the information ratio far more than finding one star (S006). Bridgewater's own client pairing put about 70 percent in the passive beta mix and 30 percent in active alpha (S005).

## Active vs passive
- **Position:** The strategic mix should be passive and balanced; active decisions are a separate overlay (S005, S006). For individuals he advises against trying to time markets, comparing it to poker against better-resourced players (S013).

## External vs internal management
- **Position (inferred from S006, S001):** Use cheap, systematic implementation for beta, internal or external. Reserve external fees for alpha sources that are both evidenced and uncorrelated with the rest of the book.

## Fee structures and co-investment
- **Position (inferred from S006):** Fees on beta should be close to zero because beta is cheap to replicate. Performance fees should be paid only on true alpha measured against the right beta benchmark, not on market exposure.

## FX hedging for an overseas-heavy fund
- **Position (inferred from S003, S011, S014, S002):** Do not treat the home or the dollar as the permanent safe anchor. He has argued for holding non-dollar assets and some gold in a period of currency debasement (S014, S011). For a fund like NPS or KIC, the hedge ratio is a currency view and a risk-balance choice at once; decide it on the four-environment map, and remember that in foreign-currency debt crises the currency collapses (S002).

## Rebalancing discipline
- **Position:** Rebalance to the risk targets. He argued that risk parity's rebalancing into falling assets stabilizes markets (S021). The seat's translation: rebalancing must be written as a rule in advance so it is not abandoned in stress (inferred from S001, S021).

## Factor tilts
- **Position (inferred from S006):** Factors are another set of return streams. Value them by their correlation to the existing book and to each other in stress periods, and by whether they add a new environmental exposure or just more equity risk.

## Tail hedging programs
- **Position (inferred from S005, S006):** The first defense against tails is structural balance across environments, not paying a steady premium for protection. A hedging program earns a place only if it is a cheaper way to balance the deflationary-bust box than holding more long-duration and inflation-linked bonds.

## Liquidity budgets
- **Position (inferred from S002, S017):** Size liquidity for the scenario in which stocks and bonds fall together, as in 2022 when both fell and risk parity lost heavily (S017). A liquidity plan built on the assumption that bonds rally in every sell-off is not robust.

## Governance and delegation to staff
- **Position (inferred from S001, S027, S026):** Decisions should flow from written principles and an agreed process, with views weighted by believability and dissent recorded. Delegation works when the board sets the risk balance and the rules and staff operate them.

## Benchmarks and peer comparison
- **Position (inferred from S006, S008):** A peer benchmark that is itself 90 percent plus equity risk rewards concentration. Prefer a benchmark expressed as a target return and risk level, or a balanced reference portfolio.

## Total portfolio approach
- **Position (inferred from S005, S006):** Closely aligned. All Weather thinks about the whole portfolio's exposure to growth and inflation rather than about asset-class buckets, which is the core idea of a total portfolio approach.

## ESG exclusions
- **Position:** No documented view in this brain's sources on ESG exclusions for pension funds. He has written that capitalism needs reform to address inequality (S036). The seat should judge an exclusion by its effect on diversification and environmental balance and say plainly that this is its own translation (inferred from S006, S036).

## Gold, cash, and bonds in the current era
- **Position:** He called cash trash at Davos in 2020 and recommended a globally diversified portfolio with some gold (S012); in 2021 he called owning bonds stupid at prevailing yields and favored non-dollar assets (S014); in 2019 he argued the falling-rate paradigm was ending (S011).
