# David Swensen: principles

Paraphrased principles from his books, Yale endowment reports, lecture, and interviews. No verbatim quotes. "Inferred" marks a translation to a non-endowment institution.

1. **Asset allocation is the dominant decision.** Following Tobin and the Ibbotson studies, he treated the long-term policy mix as the source of most variation in institutional results, and argued that, across all investors together, active management subtracts rather than adds because of its costs (S006, S010).

2. **Equity bias for long horizons.** Over long periods stocks have compounded far ahead of bonds and bills, so an investor with a perpetual horizon should aim most of the portfolio at equity-like returns. Yale's targets put roughly 96 percent of the portfolio in equity-like assets (S006, S007, S008).

3. **Diversification is the free lunch.** Spreading exposure across many independent drivers improves the return per unit of risk. He defended this after the 2009 losses by pointing to investors concentrated in a single market, such as Japanese equities from 1989, who suffered far worse (S006, S008).

4. **Size equity risk so you can hold it.** Stocks can fall by most of their value, as small stocks did from 1929 to 1932. Investors who sell near the bottom miss the recovery, so risk must be sized to what the institution can live through without abandoning the plan (S006).

5. **Market timing destroys value.** Investors and even endowments tend to buy after gains and sell after losses. He cited investors in top Internet funds losing most of the money they put in while the funds themselves posted small positive returns, and endowments taking years to rebuild equity after 1987 (S006).

6. **Rebalance into weakness.** Holding targets means buying what has fallen. Yale bought equities after the 1987 crash and kept rebalancing to policy in late 2008 (S010, S014).

7. **Security selection is a loser's game for most.** Before costs it is zero-sum; after fees, trading costs, and market impact it is negative-sum. Individuals and under-resourced institutions should use low-cost index funds (S004, S006, S013).

8. **Seek active returns where markets are inefficient.** Manager dispersion is narrow in high-grade bonds and wide in venture capital and other private markets, so selection effort belongs where the spread is wide (S006, S009).

9. **Reported active returns overstate reality.** Survivorship and backfill biases inflate manager databases, especially for hedge funds. Adjusted returns look much weaker (S006).

10. **The principal-agent problem is the central risk of delegation.** Managers' interest in fees and asset growth conflicts with the client's interest in returns. Seek co-investment, hurdles, clawbacks, and independent firms; avoid managers inside financial conglomerates with conflicts (S007, S010, S018, S019).

11. **People first in manager selection.** Integrity and a focus on performance over wealth matter more than any single statistic. Managers who keep assets modest are preferred (S006, S007).

12. **Buyouts should create value, not just leverage it.** Yale favored partners who improve operations over those relying mainly on financial engineering (S007, S009).

13. **Liquidity is a budget, not an afterthought.** Prudent investors can meet spending and commitments without becoming forced sellers, drawing on non-disruptive sources before disruptive ones (S008, S013).

14. **Spending policy is fiscal discipline.** A target rate plus a smoothing rule balances present and future beneficiaries. Payouts should not be raised after good years or slashed after bad ones without a fundamental reason (S003, S009, S025).

15. **Intergenerational equity sets the target rate.** Too high a rate favors today's beneficiaries; too low favors tomorrow's. The sustainable rate keeps the same level of activity supported indefinitely (S003).

16. **Build an internal team, and keep it small and expert.** Once assets are large enough, a dedicated staff beats consultants and funds of funds. Yale ran on about 30 professionals, hired for integrity and potential (S011, S013, S024).

17. **Do not overpay internal managers.** He called Harvard's internal management structure unstable because very high pay for in-house managers erodes institutional cohesion (S020).

18. **Judge results over long periods.** One year, good or bad, says little; the test is decades of net returns relative to peers and to a simple stock and bond mix (S010, S012, S014).
