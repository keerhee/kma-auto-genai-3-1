# Nassim Nicholas Taleb: positions applied to IC decisions

He has written about markets, banks, regulation, and risk measurement, not about pension IC agendas as such. Most entries below are translations and are marked inferred. Direct positions carry the source id only.

## Leverage and risk parity
- **Position:** Against leverage justified by model-based risk measures. Leverage turns an underestimated extreme move into ruin; hard limits beat VaR-based limits; do not cure excess leverage with more leverage (S010, S009, S013).
- **Applied:** A risk parity program that levers bonds to equalize volatility contributions relies on volatility and correlation estimates that fail in the tail. Expect strong opposition unless leverage is capped by a simple notional rule and the financing can survive a joint stock-bond selloff (inferred from S010, S014).

## Tail hedging programs
- **Position:** He has long advocated being long the tail and is the documented scientific adviser to Universa, a tail-hedging firm founded in 2007 by Mark Spitznagel; he and Spitznagel started Empirica in 1999 (S027, S029). He criticized the view that buying insurance is a losing proposition (S024, S023).
- **Applied:** Supports a small convex sleeve sized so its carry is tolerable and governed so it is not cancelled after a calm stretch. Acknowledges the bleed: the CalPERS case shows the program is only valuable if the board holds it (inferred from S028, S004).

## Liquidity budgets
- **Position:** Redundancy and slack are not inefficiency; over-optimization makes organizations fragile (S012, S014).
- **Applied:** Wants a liquidity budget stress-tested against simultaneous capital calls, collateral calls on FX hedges, and benefit outflows, with a reserve that needs no forced sale (inferred from S012, S020).

## Raising the alternatives and private markets allocation
- **Position:** No direct position on endowment-style allocations in the sources.
- **Applied:** Skeptical of illiquid assets whose smooth appraisal returns understate risk; low reported volatility is not low risk (inferred from S014, S023). The question is whether the fund can meet obligations without selling liquid assets at the bottom while the illiquid sleeve is locked (inferred from S020).

## Private credit
- **Position:** Debt bubbles are more dangerous than equity bubbles (S013, S010).
- **Applied:** A fast-growing private credit book with short loss history and covenant-lite terms sits in the fourth quadrant: open-ended loss in a cycle the data do not contain (inferred from S014, S018, S013).

## Hedge funds
- **Position:** Steady-return strategies are often short the tail; the visible winners are a survivor sample (S023, S025, S001).
- **Applied:** Demand payoff-shape analysis before Sharpe ratios; reject managers whose record is too short relative to the tail they sell (inferred from S014, S018).

## Fee structures and co-investment
- **Position:** Agents should bear their downside; bonuses should be subject to clawback (S010, S017, S005).
- **Applied:** Favors significant GP commitment, clawbacks, and fees that do not reward steady short-volatility income (inferred from S017).

## Active versus passive, factor tilts
- **Position:** Distrusts thin-tailed statistics and backtests drawn from calm samples (S006, S018, S014).
- **Applied:** Will not oppose a tilt on cost grounds, but will ask whether its historical premium survives once fat-tailed estimation error is admitted and whether the tilt carries hidden crash exposure (inferred from S018, S023).

## FX hedging policy for an overseas-heavy fund
- **Position:** No direct position.
- **Applied:** Focuses on the liquidity path: rolling forwards create cash settlement needs exactly when a home-currency shock hits. Prefers hedge ratios and tenors that cannot trigger forced selling of assets (inferred from S020, S012).

## Rebalancing discipline
- **Position:** No direct position.
- **Applied:** Supports rebalancing only if the fund has liquidity to do it in a crash without breaching other obligations; a rule that requires selling illiquid assets is not a rule (inferred from S020).

## Governance and delegation
- **Position:** Do not let people with asymmetric bonuses oversee high-stakes risks; those who failed should not be put in charge of the fix (S013).
- **Applied:** Wants the risk function independent of return-based pay and clear authority to cut exposures in stress (inferred from S013, S017).

## Benchmarks and peer comparison
- **Position:** Survivorship and short windows mislead; long observation windows are needed in the fourth quadrant (S001, S014).
- **Applied:** Peer rankings over three to five years are weak evidence of skill or safety (inferred from S014, S001).

## Total portfolio approach
- **Position:** No direct position.
- **Applied:** Welcomes looking at total exposure rather than asset-class boxes, but warns that a TPA built on a covariance matrix inherits that matrix's tail blindness (inferred from S009, S006).

## ESG exclusions
- **Position:** No investment position in the sources. His precautionary work argues for precaution only for systemic, fat-tailed harms (S008).
- **Applied:** Would judge an exclusion by whether it removes a systemic tail exposure, not on general grounds (inferred from S008).
