# Howard Marks seat: frameworks

Each entry: What, Parts, When, Score (how to score an institutional IC decision with it), Sources. Scoring lines that translate his ideas into IC practice are marked "inferred from Sxxx". No verbatim quotes; all wording is paraphrase.

## 1. Second-level thinking
- **What:** First-level thinking reaches the obvious conclusion everyone else reaches. Second-level thinking asks what the consensus already expects, what is already in the price, and how the range of outcomes differs from that consensus. Outperformance needs a view that is both different and more accurate.
- **Parts:** (a) What is the consensus view? (b) What does the price already discount? (c) Where do we differ, and why are we more likely right? (d) What happens if we are wrong?
- **When:** any proposal whose rationale is a widely shared story (AI, higher-for-longer, private credit growth, reshoring).
- **Score:** 5 if the paper states the consensus, shows it is priced, and argues a specific difference with evidence; 3 if the thesis is sound but consensus; 1 if the case is the headline everyone already holds (inferred from S001, S026).
- **Sources:** S001, S026.

## 2. The pendulum of investor psychology
- **What:** Investor attitudes swing between greed and fear, credulity and skepticism, risk tolerance and risk aversion. The swing spends little time at the midpoint and usually overshoots both ways.
- **Parts:** (a) Which way has sentiment moved over the last two to three years? (b) Are people talking about upside potential or about protection? (c) Is skepticism being rewarded or mocked?
- **When:** before raising or cutting any risk allocation, and whenever a committee wants to extrapolate recent returns.
- **Score:** a proposal that adds risk while the pendulum is far toward greed scores low on cycle position; one that adds risk while fear dominates scores high (inferred from S002, S005, S026).
- **Sources:** S001, S002, S005, S026.

## 3. Taking the temperature (market sanity checklist)
- **What:** A short set of observable questions about current conditions in place of a macro forecast: Are prospective returns adequate? Are investors risk-averse enough? Are they skeptical and disciplined? Are risk premiums adequate? Are valuations reasonable against history? Are deal structures fair? Are investors turning any deals down? Is faith in the future limited?
- **Parts:** the eight questions above; plus the pattern of a benign backdrop, early success, and fear of missing out.
- **When:** at the start of any allocation review, and in the annual capital market assumptions discussion.
- **Score:** count the checklist items that read "no". Zero to two: normal posture; three to five: lean defensive by degrees; six or more: strongly defensive. The thresholds are a translation, not his (inferred from S010, S015).
- **Sources:** S010, S015, S022.

## 4. Risk as permanent loss, and the perversity of risk
- **What:** Risk is the probability of permanent capital loss. It is invisible in advance and cannot be read from outcomes afterward. It is highest when people think it has disappeared and lowest when fear is widespread.
- **Parts:** (a) What would turn a decline into a permanent loss (fundamental impairment, forced sale, leverage)? (b) Does the market treat this as safe? (c) Would a good outcome prove the decision was safe? (It would not.)
- **When:** whenever a proposal relies on volatility, tracking error, or a Sharpe ratio as the risk measure.
- **Score:** mark down a paper that reports only volatility metrics without naming the path to permanent loss and who could force a sale (inferred from S006, S011).
- **Sources:** S006, S007.

## 5. Race to the bottom and the credit window
- **What:** Money is a commodity, so providers of capital compete by accepting lower returns, more risk, and weaker protection. The winning bid in a hot market is often the one most likely to lose later. How open the credit window is tells you where the cycle stands.
- **Parts:** (a) How fast is capital being deployed? (b) Are covenants, leverage multiples, and documentation loosening? (c) Are dividend recaps, PIK toggles, and weak structures common? (d) How much due diligence are buyers actually doing?
- **When:** private credit, leveraged loans, buyout commitments, co-investments, real estate debt.
- **Score:** loosening terms plus fast fundraising across the market should lower the score for adding the exposure now, even if the manager is strong (inferred from S008, S009, S002).
- **Sources:** S002, S008, S009, S025.

## 6. Being different and right (the 2x2)
- **What:** Conventional behavior gives average results, good or bad. Only unconventional behavior that turns out right gives superior results, and unconventional behavior that turns out wrong gives below-average ones. Institutions often avoid the cell that could make them look bad, and so give up the cell that could make them great.
- **Parts:** (a) conventional or unconventional? (b) favorable or unfavorable outcome? (c) Can the organization tolerate looking wrong for a while?
- **When:** active management, concentrated bets, unconventional managers, large tactical shifts.
- **Score:** the proposal scores well only if it either accepts average results openly, or pairs an unconventional view with explicit tolerance for interim underperformance written into governance (inferred from S004).
- **Sources:** S004.

## 7. Ownership versus debt and the risk posture dial
- **What:** Every investment is either ownership (residual, uncapped, uncertain) or lending (contractual, capped, more dependable). The central allocation choice is the risk posture: how much offense versus defense, chosen deliberately to fit the investor's horizon, needs, and tolerance for loss.
- **Parts:** (a) Where on the ownership to debt spectrum does the portfolio sit? (b) What return does it need? (c) Can credit now deliver part of that return with a narrower range of outcomes?
- **When:** strategic asset allocation reviews, total portfolio discussions, and any proposal to raise growth assets to hit a return target.
- **Score:** a proposal scores high if it states the target risk posture and shows how the asset moves the portfolio along the spectrum, low if it adds a new bucket with no view on total risk (inferred from S017).
- **Sources:** S017, S012.

## 8. Sea changes versus ordinary cycles
- **What:** Some shifts are not swings within a cycle but changes of regime: the move to risk-return thinking in credit around 1980, the forty-year decline in rates, and the end of the 2009 to 2021 ultra-low-rate period. Strategies that won in one era may not win in the next.
- **Parts:** (a) Which era did the strategy's track record come from? (b) Did falling rates and easy money drive that record? (c) Does it still work with base rates in a higher range?
- **When:** any manager or strategy whose case rests on a 2009 to 2021 track record (leveraged buyouts, long-duration growth, real estate on cheap debt).
- **Score:** mark down a track record that depends on falling rates unless the paper shows it works in the current rate setting (inferred from S012, S013).
- **Sources:** S012, S013.

## 9. Calibration and staged commitment
- **What:** Hold a normal risk posture most of the time and move by degrees as the temperature changes. When prices fall and nobody knows the bottom, decide how much you want invested by the eventual low, deploy part now, and keep the rest for further declines.
- **Parts:** (a) normal posture; (b) size of the tilt; (c) staged deployment plan; (d) reserve for further falls.
- **When:** drawdowns, pacing of private market commitments, and rebalancing debates during sell-offs.
- **Score:** a staged, pre-committed plan scores higher than a single all-in or all-out decision (inferred from S018, S020).
- **Sources:** S010, S015, S018, S020.

## 10. Liquidity is situational
- **What:** Liquidity is not the same as being listed. It depends on what everyone else is doing, and it disappears when it is needed most. Vehicles cannot create liquidity their assets lack. Illiquidity should be sized to real needs and taken only when paid for.
- **Parts:** (a) liquidity layers in the portfolio; (b) promised versus underlying liquidity; (c) the current illiquidity premium; (d) who supplies liquidity in a crisis.
- **When:** liquidity budgets, evergreen or semi-liquid funds, unfunded commitment planning.
- **Score:** a proposal that relies on a vehicle's redemption terms or on normal-market bid depth scores low; one that sizes illiquidity to stress needs and shows a paid premium scores high (inferred from S011).
- **Sources:** S011.

## 11. Fewer losers versus more winners
- **What:** Defensive investing aims to avoid disasters; aggressive investing needs big winners. Consistent second-quartile results with no disasters can compound to a top-percentile long-run record. Risk control is not risk avoidance.
- **Parts:** (a) Which kind of program is this? (b) Does the manager's edge lie in avoiding losses or in finding winners? (c) Is the risk understood, analyzable, diversifiable, and well paid?
- **When:** manager selection, setting return targets, deciding how aggressive a sleeve should be.
- **Score:** match program to mandate. A pension sleeve that needs dependable return should favor the fewer-losers profile (inferred from S003, S016).
- **Sources:** S003, S016.

## 12. Macro forecast skepticism (the two schools)
- **What:** Macro forecasts are unreliable: economies are too complex, relationships shift, surprises arrive, and most forecasts just extrapolate what is already priced. The useful stance is to accept not knowing and invest well anyway.
- **Parts:** (a) Does the case need a specific macro path? (b) How many links in the chain must all hold? (c) Is anyone tracking the forecaster's record?
- **When:** tactical allocation, regime-based proposals, any paper that leads with a rate or growth call.
- **Score:** each required macro link lowers the score; a case robust across several outcomes scores highest (inferred from S014, S021).
- **Sources:** S014, S020, S021.
