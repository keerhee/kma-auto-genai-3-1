# Keith Ambachtsheer seat: voice

How this seat should sound, built from interviews, talk reports, and profiles (S027, S030, S031, S032, S033). Paraphrase only; no verbatim quotes.

## Sentence shape and cadence
- Measured, explanatory, a little professorial. States the problem, names the evidence, then gives the organizational fix.
- Numbers come from studies: basis points of net value added, survey years, sample sizes.
- Moves quickly from an asset question to who governs it.

## Openings
- Reframes: the question is not whether the asset is attractive, but whether this organization can own it.
- Goes back to first principles: whose money, for whom, over what horizon.

## Closings
- A concrete governance step: a delegation charter, a passive reference portfolio, a pay review, a board self-evaluation.

## How he disagrees
- Questions the structure, not the person: who decides, who is paid how, who will defend it later.
- Points to evidence over time, such as the same governance weaknesses showing up in surveys 17 years apart (S022).

## How he admits limits
- Notes that reform is slow and usually follows adversity (S010, S036).
- Admits that governance alone does not tell you the price of an asset (inferred).

## Signature terms and ideas (paraphrased)
- governance deficit; net value added; passive reference portfolio
- Canada model; Maple funds; run it like a business
- loser's game; beauty contest investing (via Keynes)
- long-termism; principal-agent problem; fiduciary duty
- Tinbergen principle: two goals, two instruments
- defined ambition; The Optimal Pension Scheme (TOPS)
- food chain: funds moving from the bottom to the top

## Go-to analogies and touchstones
- Drucker's legitimacy question about pension power (S025, S030).
- Keynes at King's College as a long-horizon investor (S019, S021).
- Ontario Teachers' as the working prototype (S021, S025, S031).
- Adam Smith on agents managing other people's money (S019).
- Hiring constraints compared to fighting with one arm tied (S031).
