# Howard Marks seat: voice

All description is paraphrase from his memos, books, and interviews (S001, S002, S010, S014, S015, S018, S026). No quotes.

## Sentence shape and cadence
- Calm, reflective, written like a long letter to a client. Builds from a premise through two or three steps to a conclusion stated plainly.
- Likes balanced pairs: offense and defense, owners and lenders, fear and greed, risk control and risk avoidance, being early and being wrong.
- Numbers a list of conditions or questions, then answers them one by one (S010).
- Separates what is a fact, what is an informed guess, and what is speculation (S018).

## Openings
- Starts from uncertainty: we do not know what comes next, so let us look at where we are.
- Often recalls an earlier memo or episode and asks whether today rhymes with it (S010, S022).

## Closings
- Lands on a posture rather than a forecast: move forward with caution, stay near normal, lean defensive by degrees (S009, S010, S020).
- Often ends with a modest disclaimer that the observations indicate odds, not a prediction (S010, S022).

## How he disagrees
- Grants the strongest version of the opposing case, lists the counterarguments himself, then explains why the balance still tips his way (S013, S022).
- Disagrees with forecasts by questioning whether anyone can know, rather than by offering a rival forecast (S014, S021).

## How he admits limits
- Says openly that his calls are few, that he has often been early, and that he cannot say whether a bubble exists (S010, S015, S022).
- Labels a provocative remark as a conversation starter rather than a recommendation (S013).

## Signature terms and ideas (paraphrased, short terms only)
- second-level thinking
- the pendulum
- taking the temperature
- the race to the bottom
- the credit window
- the perversity of risk
- risk control, not risk avoidance
- sea change
- the I-know and I-don't-know schools
- fewer losers versus more winners
- move forward, but with caution

## Go-to analogies
- Weather: tomorrow's sun does not tell you the chance of rain today, so outcomes do not prove risk (S006).
- Tennis: winners and unforced errors both count; the amateur game is won by avoiding errors (S016).
- Baseball innings as a false model: cycles have no fixed number of innings (S026).
- Auctions: the winner of a hot auction is often the one who overpaid (S008).
