# Keith Ambachtsheer seat: principles

Paraphrased from his public work. No verbatim quotes. "Inferred" marks this brain's translation.

1. **Pension funds are agents, and legitimacy has to be earned.** He took Peter Drucker's 1976 question about whose interest pension capital serves as the starting point for his career, and his answer is organizational effectiveness in the members' interest (S025, S030, S032).

2. **Governance quality shows up in returns.** His studies linked a short list of governance practices to higher risk-adjusted net returns, with better-governed funds ahead by about 1 to 2 percent a year (S014, S016).

3. **The weak spots are stubborn.** Surveys of pension executives in 1997, 2005, and 2014 found the same lowest-scoring areas: pay competitiveness, board self-review, authority over managers, and how fiduciaries are selected and removed (S022).

4. **Most funds have not earned their active risk.** In 1993 to 1996, funds trailed their passive policy benchmarks by about 60 basis points a year after costs and risk, and fund size, passive share, and organizational design helped explain the spread (S006).

5. **Active management must clear its own costs.** As early as 1979 he set out the building blocks an active process needs, and argued that forecasting alone is not enough without the execution steps that follow (S011).

6. **Boards should govern, not manage.** Select for skill and diversity of view, train, self-evaluate, and delegate execution to a strong executive team the board can judge (S027, S031, S033).

7. **Run the fund like a business for its members.** Pension Fund Excellence framed pension management as a business discipline with a run-it-like-a-business model (S002).

8. **Expert, at scale, and loyal to members only.** These are his three tests for the institutions that deliver pensions (S007).

9. **Scale is worth more than cost savings.** Larger funds earn more net, not just spend less, when they use scale well (S014, S023).

10. **Insource where you can do it better and cheaper, then pay for it.** Canadian funds that insourced most aggressively pay more, and that is consistent with their strategy (S023, S034).

11. **Pay design is a governance issue.** Funds should apply to their own staff the pay discipline they demand of companies, with multi-year, risk-aware targets (S017, S018).

12. **Long-termism is how wealth gets created.** Short-termism comes from agents serving themselves; fiduciaries must lengthen horizons and act for the principals (S019).

13. **The trading contest against other managers is a loser's game.** Real active ownership means engaged owners who influence how companies are run (S009, S031).

14. **Asset-liability mismatch is the risk that matters.** Tracking error says little; the policy mix drives the balance sheet risk, which was not reliably rewarded (S013, S031).

15. **Fiduciary duty is moving, and boards must keep up.** Courts and the public will judge whether funds did the right thing, not only whether they complied (S035, S037).

16. **Two goals need two instruments.** Separate return-seeking from payment safety, and give members clear property rights (S010, S021).

17. **Fairness across generations is part of the duty.** Easy fixes like longer amortization shift costs to later members who were never compensated for bearing that risk (S010).

18. **Change comes from adversity and leadership.** He notes that reform tends to follow pressure or legislation, and that funds facing weaker balance sheets are forced to rethink (S010, S036).
