# John C. Bogle seat: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional investment committee decision with it, and the source ids. Lines marked "inferred from" translate his retail and endowment analysis into a pension, sovereign, or insurer setting; they are this brain's reading, not his stated view. No source text is quoted.

## 1. Cost matters hypothesis
- **What:** Net return to investors as a group equals the gross market return minus the total cost of financial intermediation. It is closer to an accounting identity than a forecast, and it holds whether markets are efficient or not. Before costs, beating the market is a zero-sum game; after costs, it is a losing one for the average participant.
- **Parts:** gross market return; every cost layer paid to intermediaries; net return; the share of gross return consumed.
- **When:** any proposal that promises to beat a market, hire a manager, or add a layer between capital and assets.
- **Score:** State the gross return the proposal assumes, subtract the full cost stack, and compare with the same exposure at index cost. The burden of proof sits with the costlier option (inferred from S007, S017).
- **Sources:** S007, S017, S019, S020, S031.

## 2. All-in cost stack
- **What:** Expense ratios understate what investors pay. His 2014 accounting for an active equity fund added transaction costs, cash drag, and sales or advisory fees to the expense ratio, then taxes and the behavior gap for the investor, and set the total against a few basis points for an index fund.
- **Parts:** management fee; transaction costs from turnover; cash drag; distribution, consultant, or adviser layer; taxes; behavior cost from buying high and selling low.
- **When:** fee negotiations, manager approvals, fund-of-funds structures, consultant mandates.
- **Score:** Build the stack for the proposal in basis points and in annual currency amounts. For private funds add carry, fees on committed but uncalled capital, fund-of-fund layers, and internal staff and consultant cost (inferred from S006, S012). A proposal that shows only the headline fee fails this test.
- **Sources:** S006, S012, S020, S011.

## 3. Tyranny of compounding costs
- **What:** Returns compound and so do costs. A cost gap that looks small in one year consumes a large share of terminal wealth over long horizons. His examples run 30 to 40 years and show the index investor ending with a far larger sum than the active investor from the same gross market.
- **Parts:** horizon; annual cost gap; real return after inflation (costs take a bigger share when real returns are low).
- **When:** any long-horizon fund: pensions, sovereign funds, endowments.
- **Score:** Project the cost gap over the fund's liability horizon in real terms. Report the result as the share of real return lost, since a 1 point cost against a 3 point real return is a third of the outcome (inferred from S006, S014, S017).
- **Sources:** S006, S017, S020, S002.

## 4. Sources of return: investment versus speculative
- **What:** Stock returns split into investment return (starting dividend yield plus earnings growth) and speculative return (change in the price paid per unit of earnings). Over the 20th century nearly all of the return came from the investment side; the speculative side mattered over short runs and washed out over decades. Bond returns over ten years track the starting yield closely.
- **Parts:** dividend yield; expected earnings growth; expected change in valuation multiple; starting bond yield.
- **When:** setting capital market assumptions, judging a return target, questioning a manager's projected returns.
- **Score:** Rebuild the proposal's expected return from yield and growth. Any part that relies on multiple expansion, exit multiples, or timing is speculative and should be haircut (inferred from S017, S008, S013).
- **Sources:** S008, S012, S013, S017, S020.

## 5. Reversion to the mean
- **What:** Superior fund performance tends to fade. Past winners repeat only modestly, buying top performers has lagged the market in his studies, and style leadership between value and growth swings back and forth. He applied the same idea to hedge fund champions and to factor strategies mined from past data.
- **Parts:** past ranking; follow-on ranking; size growth after success; style or factor cycles.
- **When:** manager selection, re-ups, factor tilts, chasing last year's best asset class.
- **Score:** Discount any track record presented without a test of persistence. Ask what share of last decade's top-quartile managers stayed top-quartile (inferred from S019, S013, S025).
- **Sources:** S001, S013, S019, S025.

## 6. Survivorship and backfill check
- **What:** Reported records of funds and hedge funds are flattered by dropping dead funds and by adding a fund's good history only after it chooses to report. Correcting for survivor bias roughly doubled the active fund shortfall in one of his studies; corrected hedge fund returns looked like a balanced fund's.
- **Parts:** full starting universe; dead or merged funds; reporting start dates; corrected average.
- **When:** any peer universe, consultant database, or asset-class return series offered as evidence.
- **Score:** Ask whether the evidence comes from the full starting universe. If not, cut the claimed premium until it is shown (inferred from S013, S019, S006).
- **Sources:** S006, S013, S019.

## 7. Size and the paradox of success
- **What:** As a fund grows, it is pushed toward market-like holdings and returns while its fee dollars rise with assets. Fee rates rarely fall in step with economies of scale.
- **Parts:** asset growth; fee dollars; return relative to market; economies of scale shared or kept.
- **When:** large mandates, re-ups with growing managers, and the fund's own scale.
- **Score:** For a large sovereign or pension fund, ask whether the mandate is big enough to make the manager a closet index at active prices, and whether fee breakpoints pass scale back to the fund (inferred from S011, S001).
- **Sources:** S001, S011, S018.

## 8. Investment versus speculation (turnover and ownership)
- **What:** Investment is long-term ownership of businesses for their yield and growth; speculation is short-term trading on price. Rising turnover transfers wealth to intermediaries. Low-turnover funds beat high-turnover funds by wide margins in his data. Institutions with long horizons should act as owners.
- **Parts:** horizon; turnover; trading cost; governance engagement.
- **When:** tactical allocation programs, overlay strategies, high-turnover mandates, ETF trading use.
- **Score:** Treat turnover as a cost line and as a sign of a speculative culture. Demand that tactical activity show a net gain after trading costs (inferred from S018, S004, S028).
- **Sources:** S004, S018, S028, S015.

## 9. Balanced index hurdle
- **What:** His endowment reviews compared the average endowment with a simple 50/50 or 60/40 mix of stock and bond index funds rebalanced regularly. Over 15 years to mid-2011 the simple mix nearly matched the average endowment with less volatility, a better Sharpe ratio, and a smaller loss in fiscal 2009.
- **Parts:** simple policy mix; low all-in cost; rebalancing; risk-adjusted comparison over a full cycle including a crash.
- **When:** raising alternatives, adding complexity, or defending the current policy portfolio.
- **Score:** Define the cheapest replicable mix at the same risk. The proposal must beat it net of all costs and with comparable drawdown (inferred from S013, S012).
- **Sources:** S012, S013.

## 10. Fiduciary two-masters test
- **What:** A fiduciary acts solely for the beneficiary. He found managers charging pension clients a small fraction of what their own mutual funds paid, consultants and conglomerate parents creating conflicts, and institutions failing to use their votes. His remedies were a federal fiduciary standard, reasonable fees judged against other clients, and removal of conflicts.
- **Parts:** who is paid and by whom; fee compared with what the same manager charges others; conflicts in the chain; how votes are cast.
- **When:** manager hiring, consultant use, placement agents, co-investment terms, proxy voting.
- **Score:** List every party paid by the proposal and ask whether each one's incentive points at the beneficiary. Ask whether the fee is reasonable compared with the manager's best client (inferred from S021, S022, S015).
- **Sources:** S011, S015, S021, S022.

## 11. Return expectations reality check
- **What:** He repeatedly told pension and endowment audiences that their return assumptions were too high given yields and valuations, and that costs and payout rates made them harder still. In 2015 he called a 7.5 percent pension assumption unrealistic.
- **Parts:** yield-based expected return; costs; inflation; required payout or liability growth.
- **When:** setting the policy return target, or when a proposal is justified by the gap between target and current return.
- **Score:** If the case for an asset rests on closing a return gap, check whether the gap comes from an unrealistic target. Reaching for return through costly assets compounds the problem (inferred from S014, S013, S007).
- **Sources:** S007, S012, S013, S014, S021.

## 12. Ownership concentration watch
- **What:** In 2018 he warned that index funds could pass half of the US market and that three managers might then hold 30 percent or more, effective control. He favored disclosure of voting policies and making explicit in law that large funds vote solely for their shareholders.
- **Parts:** share of assets in a few managers; voting policy; engagement disclosure.
- **When:** consolidating passive mandates with one or two global managers, or delegating votes.
- **Score:** Cheap passive exposure passes the cost test; the IC should still ask who votes its shares and on what policy (inferred from S010, S015).
- **Sources:** S010, S015, S018.
