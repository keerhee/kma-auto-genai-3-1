# David Swensen: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional decision with it, and the source ids. This edition holds paraphrases only, no verbatim quotes. Lines marked "inferred from" translate a Yale endowment practice into a pension, sovereign fund, or insurer decision; they are this brain's reading, not his stated view.

## 1. Three sources of return
- **What:** Portfolio results come from three tools: asset allocation, market timing, and security selection. Allocation dominates. Timing is unreliable and costly. Selection is zero-sum before costs and negative-sum after fees, trading costs, and market impact.
- **Parts:** the long-term policy mix; deviations from that mix (timing); manager or security choice within each asset class; the cost of each.
- **When:** any proposal, to classify what kind of bet it really is before debating it.
- **Score:** Label the proposal as allocation, timing, or selection. An allocation change is judged on decades of expected return and risk. A timing move starts at a presumption of no. A selection bet must show where the edge comes from and that it survives fees (inferred from S006, S001).
- **Sources:** S001, S002, S006.

## 2. Equity bias plus diversification
- **What:** An investor with a long horizon should lean heavily toward equity-like assets because they have earned far more than bonds and cash over long periods, and should spread that equity exposure across many independent return sources, since diversification improves risk without giving up return.
- **Parts:** share of the portfolio aimed at equity-like returns; number of distinct return drivers; size of any single class (Yale's targets kept each class to a modest share).
- **When:** setting or revising the strategic asset allocation.
- **Score:** Check two numbers: the equity-like share against the fund's real return need, and concentration in any single class. A fund dominated by domestic stocks and bonds fails the diversification test; a fund that cannot survive the equity drawdown fails the sizing test (inferred from S006, S007, S008).
- **Sources:** S006, S007, S008, S009.

## 3. Purpose-driven goals and the spending rule
- **What:** An endowment has two competing goals: keep the real purchasing power of assets for future generations, and provide a stable, substantial flow to today's budget. A smoothing spending rule (Yale's blends 80 percent of last year's spending with 20 percent of a target rate applied to past market value) lets the portfolio take more risk because the budget does not feel each year's swing.
- **Parts:** target payout rate; smoothing weights; inflation measure relevant to the institution; the trade between present and future beneficiaries (Tobin's intergenerational equity).
- **When:** any decision whose payoff depends on a liability or payout path, and any change in risk level.
- **Score:** Ask whether the payout policy can absorb the proposed risk. A pension with fixed benefit payments and no smoothing has less room than Yale did; adjust the risk budget down accordingly (inferred from S003, S008, S009).
- **Sources:** S003, S008, S009, S010.

## 4. Active management only where dispersion is high
- **What:** Spend selection effort where the gap between good and bad managers is wide (venture capital, buyouts, real estate, less efficient markets) and index where it is narrow (high-quality bonds, large-cap public equity). In the 2008 lecture he contrasted a first-to-third-quartile gap of about half a percent a year in high-grade bonds with roughly 43 points in venture capital.
- **Parts:** interquartile spread of manager returns in the class; market efficiency; the fund's realistic odds of landing top quartile.
- **When:** choosing active or passive in each sleeve; deciding where to put scarce staff time.
- **Score:** Wide dispersion is a reason to be active only if the fund can credibly pick the top quartile. Wide dispersion plus average selection is the worst case: high fees for median results (inferred from S006, S013).
- **Sources:** S006, S007, S009, S013.

## 5. Policy portfolio discipline and rebalancing
- **What:** Set long-term targets, then rebalance back to them, buying what has fallen and selling what has risen. Distinguish market timing (abandoning targets on emotion, which he rejected) from valuation-based tilts within a long-term view. In the 1987 crash Yale held its targets and bought equities; in late 2008 the office kept buying and selling to stay at policy.
- **Parts:** target weights and ranges; rebalancing trigger; who has authority to rebalance in a crisis.
- **When:** after any large market move, and whenever someone proposes cutting risk after losses.
- **Score:** A proposal to de-risk after a drawdown fails unless the fund's ability to bear risk has truly changed. A rebalancing policy without delegated authority to act in a panic is incomplete (inferred from S006, S010, S014).
- **Sources:** S006, S010, S014.

## 6. Liquidity budget: disruptive versus non-disruptive sources
- **What:** Hold enough liquidity to meet spending and uncalled commitments without becoming a forced seller. Rank sources: non-disruptive (bond coupons, dividends, rents, timber income, repo, securities lending, short-term borrowing, gifts) before disruptive (selling securities at bad prices, redeeming from hedge funds, selling private stakes at a discount).
- **Parts:** cash needs (payouts, capital calls); non-disruptive capacity; disruptive options and their haircuts; illiquid share.
- **When:** sizing private markets, setting commitment pace, crisis planning.
- **Score:** Stress the next 12 to 24 months with markets down sharply and distributions halted. If payouts and capital calls can only be met through disruptive sources, the illiquid allocation or commitment pace is too high (inferred from S008, S013, S017).
- **Sources:** S008, S009, S013, S017.

## 7. Alignment of interests with external managers
- **What:** The principal-agent problem is the core risk in outsourced management. Prefer managers who put a large share of their own wealth beside the client, accept incentive fees with hurdles and clawbacks, keep assets modest, and work for an independent firm rather than a financial conglomerate with conflicts.
- **Parts:** co-investment by the manager; fee structure (management fee level, hurdle, carry, clawback); firm independence and ownership; asset growth discipline.
- **When:** every manager hire, re-up, or fee negotiation.
- **Score:** Score each term. Management fees that grow profits on asset gathering, no hurdle, no clawback, and a manager owned by a bank or broker all count against. Large personal co-investment and capacity discipline count for (inferred from S007, S021, S006).
- **Sources:** S006, S007, S009, S010, S021.

## 8. Manager selection: people before track records
- **What:** Choose people of high integrity whose focus is performance, not asset accumulation, with a sound philosophy and a durable edge. In buyouts, favor firms that improve operations over firms that rely on financial engineering. Expect a first commitment to lead to many re-ups.
- **Parts:** integrity and character; motivation (returns versus fees); process and edge; value-add style; relationship horizon.
- **When:** due diligence on a new GP or hedge fund.
- **Score:** If the pitch is a track record without a credible story of character and edge, it fails. If the firm's assets are growing faster than its opportunity set, mark it down (inferred from S006, S007, S009).
- **Sources:** S006, S007, S009, S025.

## 9. Bias-adjusted evidence on manager returns
- **What:** Reported active returns are inflated by survivorship bias (losers disappear) and backfill bias (winners add their past). For hedge funds he cited estimates of several percentage points a year of combined bias. Dollar-weighted investor results trail time-weighted fund results because investors chase performance.
- **Parts:** survivorship correction; backfill correction; dollar-weighted versus time-weighted return.
- **When:** any consultant or peer-universe evidence presented to justify a new strategy.
- **Score:** Haircut the presented average return for both biases before comparing to the passive alternative. If the case disappears after the haircut, the case was the bias (inferred from S006).
- **Sources:** S006.

## 10. Build the team before you copy the model
- **What:** The Yale approach works only with a dedicated, skilled investment staff and real access to top managers. Institutions that copy the allocation without that capability are likely to be disappointed; for them, passive is the better default. He suggested building internal staff once assets reach roughly half a billion to a billion dollars, and called reliance on funds of funds and consultants harmful.
- **Parts:** staff depth and pay; independence from consultants; access to top-tier managers; governance that backs the team.
- **When:** any move into alternatives or active management, especially by a fund new to the class.
- **Score:** Before scoring the asset class, score the institution. No team and no access means index the public sleeves and keep alternatives small (inferred from S013, S024, S027).
- **Sources:** S013, S020, S024, S027.

## 11. Commitment pacing model for illiquid assets
- **What:** Yale's investment office (Takahashi and Alexander) built a simple cash-flow model for private funds that projects capital calls, distributions, and NAV from commitment size, call rate, fund life, and growth. It turns a target illiquid weight into a commitment schedule.
- **Parts:** commitments per year; call rate; distribution timing; growth assumption; resulting NAV path.
- **When:** sizing a private markets program and stress-testing its liquidity needs.
- **Score:** A proposal to raise a private allocation needs a commitment path, not just a target weight. Run the path with slowed distributions to check the liquidity budget in framework 6 (inferred from S029, S030).
- **Sources:** S029, S030.

## 12. Fees judged by net results, not gross cost
- **What:** Under Swensen, Yale argued that net-of-fee return is the right measure and that large performance fees are acceptable when they follow genuine outperformance. Yale negotiated hard hurdles, below-standard hedge fund fees, and preferred returns in real estate, while admitting limited bargaining power with top venture and buyout firms.
- **Parts:** net return versus passive alternative; share of fees that are performance-based; hurdles and clawbacks; bargaining position.
- **When:** fee reviews and comparisons with low-cost alternatives.
- **Score:** Compare expected net return to a passive benchmark of similar risk. A high fixed fee with no hurdle fails; a high incentive fee earned above a hard hurdle can pass if selection skill is real (inferred from S021, S022, S023).
- **Sources:** S021, S022, S023.
