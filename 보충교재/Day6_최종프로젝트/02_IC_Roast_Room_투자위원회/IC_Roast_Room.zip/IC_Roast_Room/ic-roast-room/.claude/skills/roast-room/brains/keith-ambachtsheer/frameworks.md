# Keith Ambachtsheer seat: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional decision with it, and the sources. Lines marked "inferred from" translate his work into an IC decision he did not address directly; they are this brain's reading, not his stated view. No verbatim quotes.

## 1. Governance quality scorecard
- **What:** A set of governance practices that his CEM-based studies linked to higher risk-adjusted net returns across 88 funds, with good-practice funds ahead of weaker ones by 1 to 2 percent a year in analyses almost a decade apart.
- **Parts:** (a) board selection that weighs skills, not only representation; (b) regular board self-evaluation; (c) clear split of board and management roles; (d) a high-performance culture with competitive, transparent pay; (e) insourcing or outsourcing decided on cost-effectiveness.
- **When:** any decision that adds complexity, illiquidity, or a long payoff horizon.
- **Score:** Rate the fund 0 to 2 on each of the five parts for this specific mandate. Below 6 of 10, the fund should either fix the gap first or take a simpler version of the decision (inferred from S014, S016).
- **Sources:** S014, S015, S016, S022.

## 2. Canada model three conditions
- **What:** His definition of the Canadian pension model: a clear mission, a strong independent governance function, and the ability to attract and retain talent. Eight funds meeting all three for ten years insourced about 75 percent of assets, held about 23 percent in private markets, kept costs near the average, and produced positive net value added 88 percent of the time against 61 percent for the wider CEM universe (2006 to 2015).
- **Parts:** mission; arm's-length board; talent and pay; scale large enough to insource.
- **When:** proposals to copy Maple fund moves, such as direct private deals, co-investment platforms, or large internal teams.
- **Score:** Pass only if all three conditions hold for the team that will run the program. If one fails, prefer external or simpler implementation (inferred from S023, S025).
- **Sources:** S023, S024, S025, S026.

## 3. Net value added test
- **What:** Measure what management actually contributes: gross return minus investment costs minus the return of a passive reference portfolio of the same policy mix. His 1998 study found funds trailed their passive policy benchmarks by about 60 basis points a year after incremental costs and risk.
- **Parts:** passive reference portfolio; full cost accounting; risk adjustment; long enough window.
- **When:** any active, alternative, or fee-heavy proposal.
- **Score:** Require the proposal to state expected net value added versus a named passive reference, and the cost line in basis points. No stated reference, no approval (inferred from S006, S023).
- **Sources:** S006, S023, S026.

## 4. Principal-agent audit
- **What:** He treats the pension problem as a chain of agents (boards, staff, consultants, managers) with information gaps and their own short-term interests. Adam Smith named the problem; fiduciaries must push agents toward long-term value for principals.
- **Parts:** list each layer; state its pay and horizon; find where its interest diverges from the beneficiary's; fix with structure, disclosure, or pay.
- **When:** fund-of-funds structures, outsourced CIO, consultant-led searches, any new intermediary.
- **Score:** Count layers between beneficiary and asset and the fees each takes. Every layer must show what it adds that the fund cannot do itself (inferred from S008, S019).
- **Sources:** S008, S019, S029.

## 5. Board oversees, management manages
- **What:** Following Drucker, he sees weak board selection, micromanagement, and poor organization design and incentives as the main obstacles. Boards should mix lay and expert members, educate themselves, evaluate themselves, and delegate execution to a skilled executive team they can judge.
- **Parts:** board composition; education; self-evaluation; delegation charter; the board's ability to judge strategy.
- **When:** any decision where the IC is choosing individual managers or deals rather than policy.
- **Score:** If the board is selecting deals, flag it as a governance failure and recommend a delegation framework with limits and reporting (inferred from S027, S031).
- **Sources:** S027, S029, S031, S033.

## 6. Beliefs-to-organization fit
- **What:** Funds demand culture and organizational strength from the external managers they hire but rarely apply the same test to themselves. Investment beliefs often do not match organizational design, or the culture does not support it.
- **Parts:** stated belief; capabilities it requires; current capabilities; gap and cost to close.
- **When:** new asset classes, factor programs, total portfolio approach, internal management.
- **Score:** Write the belief in one sentence, then list the people, systems, and pay it needs. If the gap is large, the decision is an organization-building decision first (inferred from S028).
- **Sources:** S003, S028.

## 7. Long-termism threads
- **What:** His case for long-horizon investing draws on Keynes at King's College, Buffett at Berkshire, MFS, and Ontario Teachers'. The common threads are autonomy to act without breaking long-term strategy, strong governance and management quality, and human capital with long-term incentives.
- **Parts:** autonomy; governance and management quality; human capital.
- **When:** contrarian or illiquid decisions that need years to pay off.
- **Score:** Check each thread for this decision. Missing autonomy (for example, political pressure to sell after a bad year) makes the long-horizon thesis unusable (inferred from S019).
- **Sources:** S019, S021, S031.

## 8. Asset-liability risk, not tracking error
- **What:** The policy portfolio largely sets the mismatch between assets and liabilities, and in the decade to 2002 that mismatch risk went unrewarded on average. He calls tracking error a poor risk measure; exposure relative to liabilities matters more. His 1987 work defended a 60/40 mix on a going-concern view of liabilities.
- **Parts:** liability view (termination or going concern); mismatch risk; whether it is rewarded; time-varying return expectations.
- **When:** strategic asset allocation, FX hedging policy, risk budget setting.
- **Score:** Ask what the decision does to the funded position or to the fund's long-run obligation, not only to its relative return (inferred from S012, S013, S031).
- **Sources:** S012, S013, S031.

## 9. Pay follows strategy
- **What:** Pension funds scrutinize corporate pay but rarely their own. Strategy should drive pay: insourcing private markets raises pay needs. Incentives should be multi-year, mostly market-relative with some absolute component, and risk-aware, which few funds manage well.
- **Parts:** six questions on whether the fund invests productively, administers effectively, advises wisely, governs well, uses scale, and attracts the right people; bonus design; risk adjustment.
- **When:** any plan that requires new specialist staff.
- **Score:** If the plan needs talent the pay scale cannot buy or keep, the plan's expected value should be marked down or the plan routed to external managers (inferred from S017, S018, S034).
- **Sources:** S017, S018, S034.

## 10. Scale economics
- **What:** In his CEM work, each tenfold increase in fund size lifted risk-adjusted net returns by about 27 basis points while unit costs fell about 17, so large funds win by more than cost alone. He also advises small plans to outsource administration.
- **Parts:** fund size; mandate size; internal versus external cost; minimum efficient scale.
- **When:** insourcing, co-investment, direct deals, consolidation of small funds.
- **Score:** Size the mandate, not the fund. A small sleeve inside a large fund may not carry an internal team (inferred from S014, S029).
- **Sources:** S014, S023, S029.

## 11. Fiduciary duty: doing the right thing
- **What:** He argues pension boards lag the courts in what fiduciary duty now means. Governance has focused on technical compliance rather than on doing the right thing, and reliance on simple theories such as the efficient market hypothesis weakens prudence, loyalty, and impartiality.
- **Parts:** loyalty; prudence; impartiality across member groups and generations; how a court or the public will judge it later.
- **When:** ESG exclusions, politically targeted investing, intergenerational trade-offs.
- **Score:** Write how the decision would be explained to members ten years from now. If the only defense is that it was legal, it is weak (inferred from S035, S037).
- **Sources:** S035, S037, S010.

## 12. Tinbergen pension design
- **What:** Two goals (affordability and payment safety) need two instruments. He proposes a long-horizon return-seeking pool plus a liability-matching safety instrument, with clear property rights and a default glide path.
- **Parts:** growth instrument; safety instrument; transition rule; fair, clear ownership.
- **When:** liability-driven sleeves, reserve-fund design, separating return-seeking and hedging portfolios.
- **Score:** Check whether the decision mixes two goals into one portfolio. If so, separate the objective and the measure for each (inferred from S010, S021, S028).
- **Sources:** S010, S021, S028.
