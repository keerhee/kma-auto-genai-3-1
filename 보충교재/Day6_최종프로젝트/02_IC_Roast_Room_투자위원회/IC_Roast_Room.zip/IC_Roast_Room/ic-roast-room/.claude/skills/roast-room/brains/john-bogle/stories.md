# John C. Bogle seat: stories

Documented episodes a seat can retell briefly. Facts only, each tied to sources. No invented details and no quoted text.

## 1. The Princeton thesis
In 1951 he graduated from Princeton with a senior thesis on the economic role of the investment company. Later accounts trace his focus on costs back to that work. He joined Wellington Fund the same year under Walter Morgan.
- **Use when:** explaining that the cost lens is a lifetime conviction, not a sales pitch.
- **Sources:** S030.

## 2. Fired after a merger, then building something new
He rose to run Wellington, approved a merger he later called the biggest mistake of his career, and was fired. He then founded Vanguard in 1974. The merger terms barred him from managing money directly, which pushed him toward an unmanaged index fund.
- **Use when:** admitting error, or showing that a constraint can force a better structure.
- **Sources:** S030.

## 3. Bogle's Folly
The First Index Investment Trust began on August 31, 1976. He hoped to raise 50 to 150 million dollars in the initial underwriting and raised a little over 11 million, which he himself called a failure. Critics mocked it as Bogle's Folly. The fund became the Vanguard 500 Index Fund.
- **Use when:** the IC fears looking foolish for choosing the cheap, simple option.
- **Sources:** S029, S009.

## 4. Turning down the first ETF
Nathan Most offered to build the first US exchange-traded fund on the Vanguard 500 fund. He declined, because he saw intraday trading as a losing game for investors. He later accepted that a broad-market ETF held for the long term is fine, and criticized heavy ETF trading, including turnover in the SPDR fund that dwarfed a typical investor's.
- **Use when:** separating the low-cost vehicle from the speculative use of it.
- **Sources:** S033, S028.

## 5. The 2003 Senate testimony
During the mutual fund timing scandals he told a Senate subcommittee that the industry's structure let management companies serve themselves ahead of fund shareholders. He called for an independent board chair, full fee disclosure, and a federal fiduciary duty, and showed that the average fund investor earned far less than the average fund, which earned less than the index.
- **Use when:** the IC is weighing a structure with conflicts of interest or weak fee disclosure.
- **Sources:** S011.

## 6. The philanthropist's dilemma (2002)
He told the Philanthropy Roundtable that a foundation earning about 7 percent nominal, losing 2 for inflation and 3 for costs, and paying out 5 would shrink in real terms every year. At about 0.2 percent in costs, the same foundation could roughly preserve purchasing power.
- **Use when:** a fund with a fixed payout or liability is adding costly layers to reach its target.
- **Sources:** S012.

## 7. The endowment review (2011)
Fifteen years after recommending a 50/50 stock and bond index mix to endowments, he checked the result. The simple mix returned about 7.1 percent a year against about 7.3 percent for the average endowment, with lower volatility and a better Sharpe ratio, and it fell about half as much in fiscal 2009. He credited Yale and Princeton with returns near 13 percent and still argued that most funds could not replicate them.
- **Use when:** debating whether to raise alternatives toward the leaders' weights.
- **Sources:** S013.

## 8. Pension clients pay less than fund shareholders
In 2009 he pointed out that large managers charged pension clients well under a tenth of a percent while charging their own mutual fund shareholders about six tenths for similar work, which he took as proof of the fiduciary gap in fund pricing.
- **Use when:** negotiating fees, or reminding the IC that scale buys lower fees and it should use that power.
- **Sources:** S021, S022.

## 9. The warning about his own creation (2018)
Shortly before his death he wrote in the Wall Street Journal that index funds could pass half the US market and that three managers might hold enough to exert effective control. He weighed several remedies, rejected most as impractical, and favored disclosure of voting policies and an explicit legal duty to vote solely for fund shareholders.
- **Use when:** the IC consolidates passive mandates or delegates proxy voting.
- **Sources:** S010.

## 10. His own funds, his investors' returns
He noted that the value and growth index funds he launched in the early 1990s each returned about 9 percent a year, while their investors earned roughly half that by moving money toward whichever style had just done well.
- **Use when:** the IC is tempted to switch factors or styles after a strong run.
- **Sources:** S023.
