# Ray Dalio: books

## His own books and long-form work
- **Principles: Life and Work (2017)** (S001): his life and work principles; radical transparency, idea meritocracy, the five-step process, and the Holy Grail of diversification.
- **Principles for Navigating Big Debt Crises (2018)** (S002): a template for debt cycles, three detailed cases (Weimar Germany, the 1930s US, 2008) and 48 shorter ones; the four levers and beautiful deleveraging.
- **Principles for Dealing with the Changing World Order (2021)** (S003): the big cycle of empires and reserve currencies over 500 years, with eight measures of power.
- **How Countries Go Broke: The Big Cycle (2025)** (S010): applies the long-term debt cycle to sovereign finances and what governments should do.
- **How the Economic Machine Works (2013 video)** (S004): the economy in 30 minutes; transactions, credit, and the short and long debt cycles.
- **Engineering Targeted Returns and Risks (2011, updating 2004)** (S006): the cash, beta, alpha split, leverage to equalize risk, and the value of many uncorrelated alphas.
- **The All Weather Story (2012)** (S005): the origin and logic of the four-environment portfolio.

## Books he recommends (S030)
- **The Hero with a Thousand Faces, Joseph Campbell:** life as a path of setbacks and growth, in which people come to value those they serve.
- **The Lessons of History, Will and Ariel Durant:** a short survey of recurring patterns across history.
- **River Out of Eden, Richard Dawkins:** evolution as the natural law humans are subject to, including old wiring in the brain.
- **Super Mind, Norman Rosenthal:** an overview of Transcendental Meditation, which he practices.

## Books built on his work
- **Money: Master the Game, Tony Robbins (2014)** (S035): includes a chapter from an interview in which he describes a simplified All Weather style portfolio for individuals.
