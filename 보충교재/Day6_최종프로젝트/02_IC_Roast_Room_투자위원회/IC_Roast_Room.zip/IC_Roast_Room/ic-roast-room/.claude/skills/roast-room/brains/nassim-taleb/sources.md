# Sources: Nassim Nicholas Taleb

31 sources. Books, technical papers, testimony, essays, and documented press accounts of the tail-hedging business he advises. Each item was checked by web search or fetch during compilation, except where the url is "-": those are standard book editions listed by title, publisher, and year. Secondary press items (S026 to S029) are used only for documented facts about Universa and CalPERS, not for his views.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Fooled by Randomness: The Hidden Role of Chance in Life and in the Markets (Texere; later Random House editions) | - | 2001 | book |
| S002 | The Black Swan: The Impact of the Highly Improbable (Random House) | - | 2007 | book |
| S003 | The Black Swan, Second Edition, with the added essay On Robustness and Fragility (Random House Trade Paperbacks, ISBN 9780812973815) | https://www.abebooks.com/9780812973815/Black-Swan-Second-Edition-Taleb-081297381X/plp | 2010 | book |
| S004 | Antifragile: Things That Gain from Disorder (Random House, ISBN 9781400067824) | https://en.wikipedia.org/wiki/Antifragile_(book) | 2012-11-27 | book |
| S005 | Skin in the Game: Hidden Asymmetries in Daily Life (Random House) | - | 2018 | book |
| S006 | Statistical Consequences of Fat Tails: Real World Preasymptotics, Epistemology, and Applications (STEM Academic Press, ISBN 9781544508054; arXiv 2001.10488) | https://arxiv.org/abs/2001.10488 | 2020 | book |
| S007 | Dynamic Hedging: Managing Vanilla and Exotic Options (Wiley, ISBN 978-0-471-15280-4) | https://gov.wiley.com/WileyCDA/WileyTitle/productCd-0471152803.html | 1997-01 | book |
| S008 | The Precautionary Principle (with Application to the Genetic Modification of Organisms), Taleb, Read, Douady, Norman, Bar-Yam | https://arxiv.org/abs/1410.5787 | 2014-10-17 | paper |
| S009 | Against Value-at-Risk: Nassim Taleb Replies to Philippe Jorion | https://www.fooledbyrandomness.com/jorion.html | 1997 | essay |
| S010 | Written testimony of Nassim N. Taleb, House Subcommittee on Investigations and Oversight hearing, The Risks of Financial Modeling: VaR and the Economic Meltdown | https://republicans-science.house.gov/sites/republicans.science.house.gov/files/documents/hearings/091009_Taleb.pdf | 2009-09-10 | testimony |
| S011 | Hearing record, The Risks of Financial Modeling: VaR and the Economic Meltdown (Serial No. 111-48; lists Taleb as Distinguished Professor of Risk Engineering, NYU Poly, and Principal, Universa Investments) | https://www.govinfo.gov/content/pkg/CHRG-111hhrg51925/html/CHRG-111hhrg51925.htm | 2009-09-10 | official record |
| S012 | The Six Mistakes Executives Make in Risk Management, Taleb, Goldstein, Spitznagel, Harvard Business Review (R0910G) | https://store.hbr.org/product/the-six-mistakes-executives-make-in-risk-management/R0910G | 2009-10 | article |
| S013 | Ten Principles for a Black Swan-Proof World, Financial Times (reposted at Edge) | https://www.edge.org/node/21297 | 2009-04-07 | essay |
| S014 | The Fourth Quadrant: A Map of the Limits of Statistics, Edge | https://www.edge.org/node/21304 | 2008-09-14 | essay |
| S015 | Errors, Robustness, and the Fourth Quadrant, International Journal of Forecasting 25(4) | https://ideas.repec.org/a/eee/intfor/v25y2009i4p744-759.html | 2009 | paper |
| S016 | Mathematical Definition, Mapping, and Detection of (Anti)Fragility, Taleb and Douady | https://arxiv.org/abs/1208.1189 | 2012-08-06 | paper |
| S017 | The Skin In The Game Heuristic for Protection Against Tail Events, Taleb and Sandis, Review of Behavioral Economics 1(1-2) | https://nowpublishers.com/article/Details/RBE-0006 | 2014 | paper |
| S018 | How Much Data Do You Need? An Operational, Pre-Asymptotic Metric for Fat-tailedness, International Journal of Forecasting 35(2) | https://ideas.repec.org/a/eee/intfor/v35y2019i2p677-686.html | 2019 | paper |
| S019 | On the Statistical Differences between Binary Forecasts and Real-World Payoffs, Taleb and Tetlock (as listed), International Journal of Forecasting 36(4) | https://ideas.repec.org/a/eee/intfor/v36y2020i4p1228-1240.html | 2020 | paper |
| S020 | The Logic of Risk Taking, Incerto (Medium); chapter material for Skin in the Game | https://medium.com/incerto/107bf41029d3 | 2017-08-25 | essay |
| S021 | A Focus on the Exceptions That Prove the Rule, Mandelbrot and Taleb, Financial Times | https://fooledbyrandomness.com/FT-MandelbrotTaleb.pdf | 2006 | essay |
| S022 | The Black Swan of Cairo, Taleb and Blyth, Foreign Affairs | https://www.mauldineconomics.com/overmyshoulder/article/the-black-swan-of-cairo | 2011-05 | essay |
| S023 | Bleed or Blowup? Why Do We Prefer Asymmetric Payoffs?, Journal of Behavioral Finance 5(1) | - | 2004 | paper |
| S024 | Ilmanen, Do Financial Markets Reward Buying or Selling Insurance and Lottery Tickets? Author Response (to a Taleb letter), Financial Analysts Journal | https://www.aqr.com/Insights/Research/Journal-Article/Do-Financial-Markets-Reward-Buying-or-Selling-Insurance-and-Lottery-Tickets-Author-Response | 2013-03 | journal exchange |
| S025 | Gladwell, Blowing Up, The New Yorker, April 22 and 29 issue | https://www.TrendFollowing.com/pdfs/niederhoffer_taleb_gladwell.pdf | 2002-04-22 | profile |
| S026 | Bloomberg, Nassim Taleb-Advised Universa Tail Fund Returned 3,600% in March | https://www.bloomberg.com/news/articles/2020-04-08/taleb-advised-universa-tail-risk-fund-returned-3-600-in-march | 2020-04-08 | press |
| S027 | Bloomberg, Why One Firm's 3,612% Return Is Drawing the Ire of Hedge Funds | https://www.bloomberg.com/news/articles/2023-04-03/black-swans-angry-hedge-funds-and-how-to-make-a-3-612-return | 2023-04-03 | press |
| S028 | Bloomberg via Advisor Perspectives, Calpers Missed a $1 Billion Payday by Scrapping Market Hedge | https://www.advisorperspectives.com/articles/2020/04/13/calpers-missed-a-1-billion-payday-by-scrapping-market-hedge | 2020-04-13 | press |
| S029 | Universa Investments (encyclopedia entry summarizing WSJ and Bloomberg reporting) | https://en.wikipedia.org/wiki/Universa_Investments | accessed 2026-10 | reference |
| S030 | Spitznagel, Safe Haven: Investing for Financial Storms (Wiley), foreword by Taleb | https://lehmanns.de/shop/recht-steuern/57238891-9781119402527-safe-haven | 2021 | book |
| S031 | Israelov, Pathetic Protection: The Elusive Benefits of Protective Puts, Journal of Alternative Investments (AQR) | https://www.aqr.com/Insights/Research/White-Papers/Pathetic-Protection-The-Elusive-Benefits-of-Protective-Puts | 2018-12-31 | paper (counterview) |
