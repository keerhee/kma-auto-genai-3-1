# Ray Dalio: principles

Paraphrased, each with source ids. "Inferred" marks this brain's translation to an investment committee setting.

1. **Diversification is the one free improvement.** Adding good return streams that do not move together lowers risk far more than it lowers return; he calls the 15 to 20 stream version the Holy Grail of investing (S001, S032, S006).

2. **Balance risk, not dollars.** A 60/40 portfolio looks balanced in capital but is dominated by equity risk; real balance means comparable risk across assets and economic environments (S006, S007, S008).

3. **Prices move on surprises versus what is discounted.** An asset's return depends on how growth and inflation turn out relative to what the market already priced, not on whether the economy is good or bad (S005, S020).

4. **Every asset can lose for a decade or more.** Even equities have gone through long stretches of underperformance, so a long horizon is not a substitute for diversification (S008).

5. **Do not bet the fund on a forecast.** The strategic mix should hold up whatever happens, because no one reliably predicts the next environment; tactical views belong in a separate, sized active budget (S005, S006, S013).

6. **Alpha is zero-sum before costs.** The average active manager subtracts value after fees, so alpha is worth paying for only with strong evidence of an edge and only as a deliberate, separate risk (S006).

7. **Leverage is a tool to balance risk, not to stretch for return.** Used modestly on low-risk assets, it can raise return per unit of risk; used irresponsibly, it is dangerous (S005, S006). Bridgewater put All Weather's leverage at about 2x, below an average S&P 500 company's balance sheet (S006).

8. **Debt cycles are the economy's heartbeat.** Credit lets spending outrun income for a while and must be paid back later, which produces short and long debt cycles; know where you are in both (S004, S002).

9. **When debt is too high, policymakers print.** Of the four levers (austerity, defaults, printing, wealth transfers), printing is the least painful politically, so creditors should expect their real returns to be eroded (S002, S031, S011).

10. **Cash and nominal bonds are not safe in every era.** In periods of negative real rates and heavy money creation they lose purchasing power; he called cash trash in 2020 and owning bonds stupid in 2021 (S012, S014, S011).

11. **Study what has not happened to you.** Many events that have never occurred in a lifetime have happened before in other countries and centuries; test across them (S015, S002, S003).

12. **Pain plus reflection equals progress.** Losses are lessons if diagnosed honestly; his 1982 mistake taught him humility and better diversification (S001, S015).

13. **Seek out the smartest people who disagree with you.** Being right matters more than being the one who is right; stress-test your view against capable dissent (S001, S015, S027).

14. **Weight opinions by believability.** Give more weight to people who have done the thing successfully and can explain their reasoning, not to rank or confidence (S001, S027).

15. **Systemize decisions.** Write the decision criteria down, turn them into rules, and test them on history so the process improves and can outlast the people who built it (S001, S006, S016).

16. **Hold a little gold and look beyond one currency.** In an era of currency debasement, gold and non-dollar assets can reduce portfolio risk (S011, S012, S014).

17. **Long cycles of power shape long-term returns.** Reserve currencies and leading powers change over generations; a long-term investor should not assume the current order is permanent (S003, S010).

18. **Design for succession and the system, not the founder.** Bridgewater's handover took about twelve years and ended with control passing to a board (S026); an organization should run on principles, not on one person (inferred from S001, S026).
