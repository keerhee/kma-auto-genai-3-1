# Sources: Ray Dalio

36 sources. Primary works (books, Bridgewater research, talks, essays) come first, then press coverage used for dated facts and performance figures. All entries were checked by web search or fetch in October 2026. Where a primary URL could not be fetched, the listed URL is a stable page that hosts or describes the item. Paraphrase only; this edition stores no verbatim quotes.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Principles: Life and Work (Simon & Schuster, ISBN 9781501124020) | https://mitpressbookstore.mit.edu/book/9781501124020 | 2017 | book |
| S002 | Principles for Navigating Big Debt Crises (Bridgewater, three parts, 48 case studies) | https://www.bridgewater.com/big-debt-crises/Principles-For-Navigating-Big-Debt-Crises-By-Ray-Dalio.pdf | 2018 | book |
| S003 | Principles for Dealing with the Changing World Order: Why Nations Succeed and Fail (Simon & Schuster, ISBN 9781471196690 UK edition) | https://www.simonandschuster.co.uk/books/Principles-for-Dealing-with-the-Changing-World-Order/Ray-Dalio/9781471196690 | 2021 | book |
| S004 | How the Economic Machine Works (animated video, about 30 minutes) | https://economicprinciples.org/how-the-economic-machine-works | 2013 | video |
| S005 | The All Weather Story (Bridgewater; Podolsky, Johnson, Jennings, from interviews with the strategy's creators) | https://www.bridgewater.com/resources/all-weather-story.pdf | 2012-01 | research |
| S006 | Engineering Targeted Returns and Risks (Dalio; 2011 update of a 2004 piece) | https://bridgewater.brightspotcdn.com/fa/e3/d09e72bd401a8414c5c0bdaf88bb/bridgewater-associates-engineering-targeted-returns-and-risks-aug-2011.pdf | 2011-08 | research |
| S007 | Our Thoughts about Risk Parity and All Weather (Dalio and Prince, Bridgewater) | https://theideafarm.com/portfolio-management/our-thoughts-about-risk-parity-and-all-weather/ | 2015-09 | research |
| S008 | Risk Parity: Achieving targeted returns with an All Weather asset allocation (Prince and Ross, Bridgewater, in IPE) | https://www.ipe.com/risk-parity-achieving-targeted-returns-with-an-all-weather-asset-allocation/40031.article | c. 2011 | research |
| S009 | An In-Depth Look at Deleveragings (Dalio, Bridgewater), as described by Market Folly | https://www.marketfolly.com/2012/03/bridgewaters-ray-dalio-on-deleveragings.html | 2012-03 | research |
| S010 | How Countries Go Broke: The Big Cycle (Avid Reader Press / Simon & Schuster) | https://www.simonandschuster.ca/books/How-Countries-Go-Broke/Ray-Dalio/9781501124068 | 2025 | book |
| S011 | Paradigm Shifts (Dalio essay, first posted on LinkedIn), reprint | https://www.heartsandmindsinvestments.com.au/insights/ray-dalio--paradigm-shifts | 2019-07 | essay |
| S012 | Ray Dalio at Davos: cash is trash (CNBC) | https://www.cnbc.com/2020/01/21/ray-dalio-at-davos-cash-is-trash-as-everybody-wants-in-on-the-2020-market.html | 2020-01-21 | interview |
| S013 | Dalio advice on a four-environment portfolio and on not timing markets (CNBC Davos coverage) | https://www.cnbc.com/id/100403678 | n.d. (Davos) | interview |
| S014 | Owning Bonds Is Stupid, and They're in a Bubble, Says Ray Dalio (aiCIO) | https://www.ai-cio.com/news/owning-bonds-stupid-theyre-bubble-says-ray-dalio/ | 2021-03-17 | press |
| S015 | The Education of Ray Dalio (Kip McDaniel, Institutional Investor) | https://www.institutionalinvestor.com/article/b15130nxhjtqqq/the-education-of-ray-dalio | 2017-09-18 | interview |
| S016 | Culture and Anticipation Helped Ray Dalio Survive the Financial Crisis (Michael Peltz, Institutional Investor) | https://www.institutionalinvestor.com/article/2bsu6zgxx8hrj5koy3uo0/portfolio/culture-and-anticipation-helped-ray-dalio-survive-the-financial-crisis | 2013-09-20 | press |
| S017 | Lackluster returns: investors pull billions from Dalio's investing strategy (Justina Lee, Bloomberg via Fortune) | https://fortune.com/2024/04/23/lackluster-returns-ray-dalio-investing-strategy-investors-pull-billions/ | 2024-04-23 | press |
| S018 | Ray Dalio's All Weather fund goes cold (Stephen Gandel, Fortune) | https://fortune.com/2014/01/09/ray-dalios-all-weather-fund-goes-cold | 2014-01-09 | press |
| S019 | Dalio Patched All Weather's Rate Risk as U.S. Bonds Fell (Bloomberg) | https://www.bloomberg.com/news/articles/2013-08-14/dalio-patched-all-weather-s-rate-risk-as-u-s-bonds-fell | 2013-08-14 | press |
| S020 | UBS Calls Time on Risk Parity: Bridgewater's Bob Prince Responds (aiCIO) | https://www.ai-cio.com/news/ubs-calls-time-on-risk-parity-bridgewaters-bob-prince-responds/ | 2013-08-09 | press |
| S021 | Dalio Defends Risk-Parity Strategy (HedgeCo News) | https://www.hedgeco.net/news/?p=49977 | 2015-09-17 | press |
| S022 | In Disappointing Year, Bridgewater's Flagship Fund Returns 0.5% (Institutional Investor) | https://www.institutionalinvestor.com/article/b1jsw5lw26ncfq/In-Disappointing-Year-Bridgewater-s-Flagship-Fund-Returns-0-5 | 2020-01-07 | press |
| S023 | Bridgewater Loss Stuck at 18.6% in Main Fund After Model Tweaks (Bloomberg) | https://www.bloomberg.com/news/articles/2020-11-06/bridgewater-loss-stuck-at-18-6-in-main-fund-after-model-tweaks | 2020-11-06 | press |
| S024 | Dalio's Hedge Fund Risks Being Dumped by Pension on Weak Returns (Bloomberg via Advisor Perspectives) | https://www.advisorperspectives.com/articles/2021/09/03/dalios-hedge-fund-risks-being-dumped-by-pension-on-weak-returns | 2021-09-03 | press |
| S025 | Bridgewater Flagship Fund Gains 32% Through First Half of 2022 (Bloomberg) | https://www.bloomberg.com/news/articles/2022-07-05/bridgewater-flagship-fund-gains-32-through-first-half-of-2022 | 2022-07-05 | press |
| S026 | Ray Dalio Gives Up Control of Bridgewater (Bloomberg via Fortune) | https://fortune.com/2022/10/04/ray-dalio-gives-up-control-bridgewater-capital | 2022-10-04 | press |
| S027 | How to build a company where the best ideas win (TED2017 talk) | https://www.ted.com/talks/ray_dalio_how_to_build_a_company_where_the_best_ideas_win | 2017-04 | talk |
| S028 | Ray Dalio: Principles, the Economic Machine, AI and the Arc of Life (Lex Fridman Podcast) | https://lexfridman.com/ray-dalio/ | 2019-12-02 | interview |
| S029 | Ray Dalio on Failure, Meaningful Work and Relationships (Masters in Business, Bloomberg) | https://www.bloomberg.com/news/audio/2017-12-07/ray-dalio-on-failure-meaningful-work-and-relationships | 2017-12-07 | interview |
| S030 | 4 books that billionaire Ray Dalio thinks everyone should read (CNBC, Davos) | https://www.cnbc.com/2018/01/24/4-books-that-billionaire-ray-dalio-thinks-everyone-should-read.html | 2018-01-24 | interview |
| S031 | Book Review: Principles for Navigating Big Debt Crises (Robert Farago, CFA Institute Enterprising Investor) | https://rpc.cfainstitute.org/blogs/enterprising-investor/2019/book-review-principles-for-navigating-big-debt-crises | 2019-08-09 | review |
| S032 | 7 learnings from Ray Dalio (Morningstar India; summary of Principles incl. the Holy Grail of investing) | https://www.morningstar.in/posts/50327/equity-8.aspx | 2019-01-07 | review |
| S033 | Risk parity (Wikipedia: history, Qian 2005 term, criticisms) | https://en.wikipedia.org/wiki/Risk_parity | accessed 2026-10 | reference |
| S034 | Ray Dalio: Changing World Order concept map (Heuristica summary) | https://www.heuristi.ca/concept-maps/ray-dalio-changing-world-order | n.d. | review |
| S035 | Money: Master the Game (Tony Robbins, Simon & Schuster; chapter built on a Dalio interview about All Weather) | - | 2014 | book |
| S036 | Ray Dalio Says Capitalism Is Not Working. Here's How He Thinks the U.S. Should Fix It (Institutional Investor, on his LinkedIn essay Why and How Capitalism Needs to Be Reformed) | https://www.institutionalinvestor.com/article/2bswfn59rzcjojfgim41s/culture/ray-dalio-says-capitalism-is-not-working-heres-how-he-thinks-the-u-s-should-fix-it | 2019-04 | essay |

Notes on verification:
- S013: the CNBC page carries no visible date; it is part of CNBC's Davos coverage.
- S019, S023, S025: Bloomberg pages are paywalled; titles and dates come from the URL and the search listing, and the fetched text confirmed the core figures for S019 and S023.
- S035: the book is real and widely catalogued; the exact All Seasons weights it prints could not be confirmed from an accessible page, so this brain does not cite them.
- S010: verified as published; its content is not used beyond its title and thesis line.
