# David Swensen: books and influences

## His books
- **Pioneering Portfolio Management, 1st ed. (2000)** (S001): The institutional playbook: clear goals, a spending rule, an equity-oriented diversified policy portfolio, active management only where markets are inefficient, and alignment with external managers.
- **Pioneering Portfolio Management, revised 2nd ed. (2009)** (S002, S003): Updates the playbook through the 2000s; chapter 3 sets out the trade between purchasing power and stable spending, and the logic of Yale's smoothing rule.
- **Unconventional Success (2005)** (S004, S005): For individuals: a few core asset classes, rebalancing, low-cost index funds from not-for-profit providers, and a sustained critique of the for-profit mutual fund industry.

## Thinkers and work he credits
- **James Tobin:** His doctoral mentor; the source of the intergenerational equity framing for endowment spending and of the view that asset allocation is the central decision (S003, S010, S025).
- **Harry Markowitz:** Modern portfolio theory; diversification as the free lunch at the center of the Yale approach (S006, S010, S012).
- **Roger Ibbotson:** Studies attributing most of the variation in institutional returns to asset allocation (S006).
- **John Maynard Keynes:** Cited against frequent wholesale shifts between asset classes (S006).
- **Dean Takahashi:** Long-time colleague and co-teacher; co-builder of the Yale approach and of the commitment pacing model with Seth Alexander (S011, S012, S029).
- **Burton Malkiel and Roger Ibbotson on hedge fund biases:** Estimates of survivorship and backfill bias he used to discount reported hedge fund returns (S006).

## Independent work on his model (not his own)
- **Lerner, Schoar and Wang, Secrets of the Academy (2008):** Elite endowments' returns linked to alternative assets, scale, and apparent selection skill (S026).
- **Rekenthaler, Morningstar (2021):** Argues his real edge was manager selection and access, hard for copycats to replicate (S027).
