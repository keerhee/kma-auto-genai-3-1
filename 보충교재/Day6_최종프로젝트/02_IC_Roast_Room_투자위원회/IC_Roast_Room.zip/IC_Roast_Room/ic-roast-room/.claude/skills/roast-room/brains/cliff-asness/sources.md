# Sources: Cliff Asness seat

32 sources. Each was checked by web search or by fetching the page during the build (October 2026). Asness is author or co-author unless the type column says otherwise. Papers he did not write are listed because his own essays rely on them or because they are the main counter-evidence a fair seat must weigh. Where the primary URL could not be fetched, a stable repost or DOI is given.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Value and Momentum Everywhere (Asness, Moskowitz, Pedersen), Journal of Finance | https://www.aqr.com/library/journal-articles/value-and-momentum-everywhere | 2013-06 | journal paper |
| S002 | Quality Minus Junk (Asness, Frazzini, Pedersen), SSRN working paper, later Review of Accounting Studies | https://papers.ssrn.com/abstract=2312432 | 2013 (rev. 2017) | journal paper |
| S003 | Fact, Fiction and Momentum Investing (Asness, Frazzini, Israel, Moskowitz), Journal of Portfolio Management 40th anniversary issue | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/JPM-Fact-Fiction-and-Momentum-Investing.pdf | 2014 | journal paper |
| S004 | Fact, Fiction, and Value Investing (Asness, Frazzini, Israel, Moskowitz), Journal of Portfolio Management 42(1) | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/JPM-Fact-Fiction-and-Value-Investing.pdf | 2015 | journal paper |
| S005 | Buffett's Alpha (Frazzini, Kabiller, Pedersen), Financial Analysts Journal 74(4) | https://rpc.cfainstitute.org/research/financial-analysts-journal/2018/faj-v74-n4-3 | 2018-09-10 | journal paper (AQR colleagues) |
| S006 | My Top 10 Peeves, Financial Analysts Journal 70(1), 22 to 30 | https://rpc.cfainstitute.org/research/financial-analysts-journal/2014/my-top-10-peeves | 2014-01 | journal essay |
| S007 | The Illiquidity Discount?, AQR Perspectives | https://www.aqr.com/Insights/Perspectives/The-Illiquidity-Discount | 2019-12-19 | essay |
| S008 | Volatility Laundering, AQR Perspectives | https://www.aqr.com/Insights/Perspectives/Volatility-Laundering | 2023-01-06 | essay |
| S009 | Introducing the New AQR S.M.O.O.T.H. Fund, AQR Perspectives (satire) | https://www.aqr.com/Insights/Perspectives/Introducing-the-New-AQR-SMOOTH-Fund | 2019-02-25 | essay |
| S010 | Is (Systematic) Value Investing Dead?, AQR Perspectives | https://www.aqr.com/Insights/Perspectives/Is-Systematic-Value-Investing-Dead | 2020-05-08 | essay |
| S011 | The Less-Efficient Market Hypothesis, Journal of Portfolio Management 50th anniversary issue (SSRN) | https://papers.ssrn.com/abstract=4942046 | 2024-08-30 | journal essay |
| S012 | Leverage Aversion and Risk Parity (Asness, Frazzini, Pedersen), Financial Analysts Journal 68(1), 47 to 59 | https://rpc.cfainstitute.org/research/financial-analysts-journal/2012/leverage-aversion-and-risk-parity | 2012-01 | journal paper |
| S013 | Market Timing: Sin a Little (Asness, Ilmanen, Maloney), Journal of Investment Management 15(3), 23 to 40 | https://www.aqr.com/Insights/Research/Journal-Article/Market-Timing-Sin-a-Little | 2017 | journal paper |
| S014 | It's Time for a Venial Value-Timing Sin, AQR Perspectives | https://aqr.com/Insights/Perspectives/Its-Time-for-a-Venial-Value-Timing-Sin | 2019-11-07 | essay |
| S015 | How Can a Strategy Still Work If Everyone Knows About It?, AQR Perspectives (also Institutional Investor) | https://www.aqr.com/Insights/Perspectives/How-Can-a-Strategy-Still-Work-If-Everyone-Knows-About-It | 2015-08-31 | essay |
| S016 | Virtue Is Its Own Reward: Or, One Man's Ceiling Is Another Man's Floor, AQR Perspectives | https://www.aqr.com/Insights/Perspectives/Virtue-is-its-Own-Reward-Or-One-Mans-Ceiling-is-Another-Mans-Floor | 2017-05-18 | essay |
| S017 | Contrarian Factor Timing Is Deceptively Difficult (Asness, Chandra, Ilmanen, Israel), Journal of Portfolio Management (AQR supplement page) | https://www.aqr.com/Insights/Research/Journal-Article/Contrarian-Factor-Timing-is-Deceptively-Difficult-Supplement | 2017 | journal paper |
| S018 | Cliff Asness Blasts Rob Arnott on Factor Timing, Institutional Investor | https://www.institutionalinvestor.com/article/2bsvu85lwfurbhds0mh34/portfolio/cliff-asness-blasts-rob-arnott-on-factor-timing | 2017-03-16 | press |
| S019 | Do Hedge Funds Hedge? (Asness, Krail, Liew), Journal of Portfolio Management 28(1) | https://www.aqr.com/Insights/Research/Journal-Article/Do-Hedge-Funds-Hedge | 2001-10-31 | journal paper |
| S020 | Fight the Fed Model, Journal of Portfolio Management | https://www.aqr.com/Insights/Research/Journal-Article/Fight-the-Fed-Model | 2003-10-31 | journal paper |
| S021 | The Long Run Is Lying to You, AQR (repost by The Idea Farm) | https://theideafarm.com/portfolio-management/the-long-run-is-lying-to-you/ | 2021-03-24 | essay |
| S022 | Interview with Cliff Asness (M. Imerman), Journal of Private Markets Investing 24(3) | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/Interview-with-Cliff-Asness-Journal-of-Private-Markets-Investing--Spring-2026.pdf | 2026 (Spring) | interview |
| S023 | Talks at GS: Cliff Asness (transcript) | https://www2.goldmansachs.com/intelligence/talks-at-gs/cliff-asness-f/transcript.pdf | 2022-07-19 | talk |
| S024 | Cliff Asness Has Steered Hedge Fund AQR Through Not One, Not Two, but Three Quant Crises (M. Celarier), Institutional Investor | https://institutionalinvestor.com/article/2dqompiu3p46lyschhdkw/corner-office/cliff-asness-has-steered-hedge-fund-aqr-through-not-one-not-two-but-three-quant-crises | 2024-09-10 | press profile |
| S025 | Clifford S. Asness, MBA 1991, PhD 1994, Distinguished Alumni Awards, Chicago Booth | https://www.chicagobooth.edu/alumni/distinguished-alumni-award/honorees/clifford-asness | 2007 | official bio |
| S026 | Betting Against Beta (Frazzini, Pedersen), Journal of Financial Economics | https://research-api.cbs.dk/ws/portalfiles/portal/60082899/lasse_heje_pedersen_et_al_betting_against_beta_publishersversion.pdf | 2014 | journal paper (AQR colleagues) |
| S027 | Is There a Replication Crisis in Finance? (Jensen, Kelly, Pedersen), Journal of Finance 78(5) | https://www.nber.org/papers/w28432 | 2023 | journal paper (AQR colleagues) |
| S028 | Efficiently Inefficient: How Smart Money Invests and Market Prices Are Determined (L. H. Pedersen), Princeton University Press, ISBN 9780691196091; includes an interview with Asness | https://press.princeton.edu/books/paperback/9780691196091/efficiently-inefficient | 2015 | book |
| S029 | Demystifying Illiquid Assets: Expected Returns for Private Equity (Ilmanen, Chandra, McQuinn), Journal of Alternative Investments | https://www.aqr.com/Insights/Research/Journal-Article/Demystifying-Illiquid-Assets-Expected-Returns-for-Private-Equity | 2019-12-31 | journal paper (AQR colleagues) |
| S030 | A Century of Evidence on Trend-Following Investing (Hurst, Ooi, Pedersen), AQR | https://www.aqr.com/Insights/Research/Journal-Article/A-Century-of-Evidence-on-Trend-Following-Investing | 2017-10-31 | paper (AQR colleagues) |
| S031 | Is (Systematic) Value Investing Dead? (Israel, Laursen, Richardson), Journal of Portfolio Management | https://www.aqr.com/Insights/Research/Journal-Article/Is-Systematic-Value-Investing-Dead | 2021-01-31 | journal paper (AQR colleagues) |
| S032 | ... and the Cross-Section of Expected Returns (Harvey, Liu, Zhu), Review of Financial Studies 29(1) | https://doi.org/10.1093/rfs/hhv059 | 2016 | journal paper (critic of factor data mining) |
