# Howard Marks seat: books

## His books
- **The Most Important Thing: Uncommon Sense for the Thoughtful Investor** (Columbia Business School Publishing, 2011). Distils his memos into a set of things that each matter most: second-level thinking, price versus value, understanding and controlling risk, the pendulum, contrarianism, and the role of luck (S001).
- **Mastering the Market Cycle: Getting the Odds on Your Side** (Houghton Mifflin Harcourt, 2018). Explains economic, profit, psychological, and credit cycles, why the credit cycle is the most powerful, and how to set a risk posture from where we stand rather than from forecasts (S002).
- **The memos** (Oaktree, 1990 onward). The primary record of his thinking, written for clients and published on oaktreecapital.com; most entries in this brain cite them (S003 to S023).

## Thinkers he credits or draws on (as recorded in this brain's sources)
- **Warren Buffett.** Cited for focusing on companies and securities rather than macro forecasts (S014), and for an often-repeated idea about corporate profit growth that Marks says Buffett told him he never actually said (S022).
- **Nassim Taleb, The Black Swan.** Cited in the 2008 panic to make the point that unlikely events are not impossible and that one must survive the low points (S005).
- **John Maynard Keynes.** His observation that failing conventionally is better for one's reputation than succeeding unconventionally underpins the career-risk argument (S004).
- **David Swensen.** Cited for the point that active management requires institutions to behave in ways that are uncomfortable for institutions (S004).
- **Amos Tversky.** Cited on the danger of not knowing what you do not know (S014).
- **Graham and Dodd.** Cited for describing fixed-income investing as a negative art, where returns come from avoiding defaults (S016).
- **Mujo (impermanence).** A concept he met in Japanese studies at Wharton and connects to his view of cycles (S026).
