# Keith Ambachtsheer seat: books

## His books
- **Pension Funds and the Bottom Line** (Dow Jones-Irwin, 1985): his first book on pension fund management (S004, S005).
- **Pension Fund Excellence: Creating Value for Stakeholders**, with D. Don Ezra (Wiley, 1998): pension management as a business discipline, with a run-it-like-a-business model and case studies of what works (S002).
- **Pension Revolution: A Solution to the Pensions Crisis** (Wiley, 2007): answers Drucker's legitimacy question through organizational effectiveness, proposes The Optimal Pension Scheme, and argues boards should oversee rather than manage (S001, S029, S030).
- **The Future of Pension Management: Integrating Design, Governance, and Investing** (Wiley, 2016): treats design, governance, and investing as one system, argues the solutions exist and implementation is the gap, and favors target-benefit hybrids (S003, S028).

## Thinkers and books he credits
- **Peter Drucker, The Unseen Revolution (1976):** the source of his central question about whose interest pension capital serves, and of the arm's-length, fiduciary institution model (S025, S030, S032).
- **John Maynard Keynes:** long-horizon investing at King's College and the beauty-contest critique of short-term trading (S019, S021, S031).
- **Adam Smith, The Wealth of Nations:** an early statement of the principal-agent problem in managing other people's money (S019).
- **Jan Tinbergen:** one instrument per policy goal, which he applies to pension design (S021, S028).
- **Harry Markowitz:** portfolio selection, which he sees as a starting point that needs information theory and principal-agent theory added (S008).
- **Warren Buffett:** one of his four long-termism case studies (S019, S021).
