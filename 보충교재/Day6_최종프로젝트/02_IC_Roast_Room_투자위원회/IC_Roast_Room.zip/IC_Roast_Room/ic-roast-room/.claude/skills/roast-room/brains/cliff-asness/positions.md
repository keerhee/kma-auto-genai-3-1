# Cliff Asness seat: positions on typical IC decisions

Each entry gives the position, the reasoning, and sources. "Inferred" marks this brain's translation of his public work into a decision he did not address directly. Paraphrases only.

## Raising the alternatives / private equity allocation
- **Position:** Skeptical of raising it on the strength of reported risk and return. Private equity is best modelled as levered small and mid-cap equity; its low reported volatility is largely an accounting effect, and the illiquidity premium may have become a discount because buyers pay for smoothing (S007, S008, S022, S029).
- **Reasoning:** Lagged marks hide beta; in the GFC a buyout index reported a drawdown of about 28 percent against roughly 55 to 60 percent for unlevered small-cap value, which reflects reporting more than economics. A prolonged multi-year bear market could reveal losses beyond what stress tests assumed (S007, S022).
- **For the IC:** Approve only if the allocation clears the risk budget with slow beta of at least one and public-equity-like volatility scaled for leverage, and if the committee says openly whether it is paying for smoothing (inferred from S007, S022).

## Private credit
- **Position:** Treats much of it as high-fee public credit. Low reported default rates can be flattered by payment-in-kind interest, amend-and-extend, and loan modifications; middle-market private loans lost more than high-yield bonds in the GFC, which he treats as a reasonable base case (S022).
- **For the IC:** Underwrite to a high-yield-like loss path and compare net returns with a cheaper public credit sleeve (inferred from S022).

## Hedge funds
- **Position:** Many hedge funds carry more market beta than monthly data shows; once lagged exposure is counted, the broad index added little beyond market exposure in the 1994 to 2000 sample (S019). Media coverage misjudges hedge funds by ignoring that they are partly hedged (S006).
- **For the IC:** Decompose on lagged market and style factors, pay alpha fees only on the residual, and prefer truly diversifying liquid alternatives such as market-neutral equity and trend following (S019, S022, inferred from S015).

## Active versus passive
- **Position:** Anything off cap weights is active (S004, S006). Systematic factor investing is a cheap, transparent form of active management worth paying a modest fee for if the evidence holds (S015).
- **For the IC:** Keep passive as the default core; add factor tilts where the robustness ladder is cleared; reserve discretionary active fees for managers with residual alpha after factors (inferred from S005, S015).

## External versus internal management
- **Position:** Not addressed directly. Inferred: well-documented factor premia are rules-based and can be run internally or bought cheaply; external managers earn their fee only for residual alpha or implementation skill such as trading cost control (inferred from S003, S015).

## Fee structures and co-investment
- **Position:** Known strategies deserve known-strategy prices; performance fees on beta are a transfer (S015, S023).
- **For the IC:** Push for fee structures that charge for alpha after a factor-adjusted hurdle; co-investment lowers fees but does not fix smoothing or slow beta (inferred from S015, S022).

## FX hedging policy for an overseas-heavy fund
- **Position:** Not addressed in the sources gathered. Inferred: treat currency as an asset class with its own value, momentum, and carry premia rather than a residual, and set the hedge ratio as a strategic policy, not a tactical call (inferred from S001, S013).

## Rebalancing discipline
- **Position:** Inferred support for disciplined rebalancing to a strategic weight, since timing away from it is rarely rewarded, with awareness that pure contrarian rebalancing fights momentum (inferred from S013, S017).

## Leverage and risk parity
- **Position:** Supportive in principle. Leverage aversion makes safe assets earn higher risk-adjusted returns; risk parity holds more of them and uses leverage to reach the target (S012, S026).
- **For the IC:** Compare modest leverage on a balanced mix against reaching for return through more equity or illiquid assets; check funding liquidity and margin call survival (inferred from S012).

## Factor tilts
- **Position:** Core of the seat. Hold a diversified set (value, momentum, quality, low risk, carry, trend) across asset classes, strategically, sized to the pain budget (S001, S002, S003, S010).
- **For the IC:** Do not drop a factor after a drawdown unless the value spread and the explanation tests say the premium is gone (S010, S031).

## Tail hedging programs
- **Position:** Finds options-based black swan hedges unconvincing in theory and practice; prefers trend following, which he says has the strongest evidence for helping in protracted equity declines (S022, S030).

## Liquidity budgets
- **Position:** Inferred: measure illiquid sleeves at their marked-equivalent risk so the liquidity budget is not set on smoothed numbers; a long bear market can force selling of the liquid book (inferred from S022).

## Governance and delegation to staff
- **Position:** Inferred: delegate within pre-agreed rules and bands, because committees that review on three-to-five-year windows tend to fire strategies at the bottom (inferred from S006, S023).

## Benchmarks and peer comparison
- **Position:** Short-window and peer comparisons mislead; evaluation windows of a few years capture noise and mean reversion (S006).
- **For the IC:** Benchmark factor sleeves against their own factor indices over long windows, not against peers (inferred from S006, S015).

## Total portfolio approach
- **Position:** Not addressed directly. Inferred: compatible with a risk-based view that looks through asset labels to factor and beta exposures, including slow beta of private assets (inferred from S012, S022).

## ESG exclusions
- **Position:** Exclusions are legitimate but cost expected return; impact comes precisely through raising the excluded firms' cost of capital (S016).
- **For the IC:** State the expected return give-up and do not claim the screen as a performance source (inferred from S016).

## Capital market assumptions
- **Position:** Use valuation-based forward estimates; long-run averages mislead when starting valuations are high; the Fed model is not a valid valuation tool (S020, S021).
