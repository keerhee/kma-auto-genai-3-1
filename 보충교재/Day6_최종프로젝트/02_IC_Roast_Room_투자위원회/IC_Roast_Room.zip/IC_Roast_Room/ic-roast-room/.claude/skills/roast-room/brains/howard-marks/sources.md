# Howard Marks seat: sources

Every source below was checked by search or fetch while this brain was compiled (October 2026). Memos are Howard Marks's client memos published by Oaktree Capital Management. Secondary items are marked as such and are used only for dates, firm history, or reported positions, never for his wording.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | The Most Important Thing: Uncommon Sense for the Thoughtful Investor (Columbia Business School Publishing, ISBN 9780231153683) | https://cupblog.org/2011/04/22/the-most-important-thing-a-good-money-move/ | 2011 | book |
| S002 | Mastering the Market Cycle: Getting the Odds on Your Side (Houghton Mifflin Harcourt, later Harper Business, ISBN 9781328479259) | https://www.porchlightbooks.com/products/mastering-the-market-cycle-howard-marks-9781328479259 | 2018-10-02 | book |
| S003 | The Route to Performance (memo addendum) | https://www.oaktreecapital.com/docs/default-source/memos/1990-10-12-the-route-to-performance.pdf | 1990-10-12 | memo |
| S004 | Dare to Be Great II | https://www.oaktreecapital.com/docs/default-source/memos/2014-04-08-dare-to-be-great-ii.pdf | 2014-04-08 | memo |
| S005 | The Limits to Negativism | https://www.oaktreecapital.com/docs/default-source/memos/2008-10-15-the-limits-to-negativism.pdf | 2008-10-15 | memo |
| S006 | Risk Revisited Again (updates Risk Revisited of 2014-09-03) | https://www.oaktreecapital.com/docs/default-source/memos/2015-06-08-risk-revisited-again.pdf | 2015-06-08 | memo |
| S007 | Risk Revisited (secondary summary post with excerpts) | https://www.marketfolly.com/2014/09/howard-marks-new-memo-risk-revisited.html | 2014-09-03 | memo (via secondary) |
| S008 | The Race to the Bottom | https://www.oaktreecapital.com/docs/default-source/memos/2007-02-14-the-race-to-the-bottom.pdf | 2007-02-14 | memo |
| S009 | The Race Is On | https://www.oaktreecapital.com/docs/default-source/memos/2013-11-26-the-race-is-on.pdf | 2013-11-26 | memo |
| S010 | There They Go Again... Again | https://www.oaktreecapital.com/docs/default-source/memos/there-they-go-again-again.pdf | 2017-07-26 | memo |
| S011 | Liquidity | https://www.oaktreecapital.com/docs/default-source/memos/2015-03-25-liquidity.pdf | 2015-03-25 | memo |
| S012 | Sea Change | https://www.oaktreecapital.com/docs/default-source/memos/sea-change.pdf | 2022-12-13 | memo |
| S013 | Further Thoughts on Sea Change (public edition of the May 2023 client memo) | https://www.oaktreecapital.com/docs/default-source/memos/further-thoughts-on-sea-change3dda4540-569f-4415-9a5b-004fbabf06d4.pdf | 2023-10-11 | memo |
| S014 | The Illusion of Knowledge | https://www.oaktreecapital.com/docs/default-source/memos/illusion-of-knowledge.pdf | 2022-09-08 | memo |
| S015 | Taking the Temperature | https://www.oaktreecapital.com/docs/default-source/memos/taking-the-temperature.pdf | 2023-07-10 | memo |
| S016 | Fewer Losers, or More Winners? | https://www.oaktreecapital.com/docs/default-source/memos/fewer-losers-more-winner.pdf | 2023-09-12 | memo |
| S017 | Ruminating on Asset Allocation | https://www.oaktreecapital.com/docs/default-source/default-document-library/ruminating-on-asset-allocation.pdf | 2024-10-22 | memo |
| S018 | Nobody Knows II | https://www.oaktreecapital.com/docs/default-source/memos/nobody-knows-ii.pdf | 2020-03-03 | memo |
| S019 | A Different World | https://www.oaktreecapital.com/docs/default-source/memos/different.pdf | 2020-03-16 | memo |
| S020 | 2020 in Review | https://www.oaktreecapital.com/docs/default-source/memos/2020inreview.pdf | 2021-03-04 | memo |
| S021 | The Folly of Certainty | https://oaktreecapital.com/docs/oaktreecaplibraries/memos/the-folly-of-certainty.pdf | 2024-07-17 | memo |
| S022 | On Bubble Watch | https://oaktreecapital.com/docs/default-source/memos/on-bubble-watch.pdf | 2025-01-02 | memo |
| S023 | What's Going on in Private Credit? (Oaktree memo podcast page; only the page summary was readable) | https://cnt.oaktreecapital.com/insights/memo-podcast/whats-going-on-in-private-credit | 2026-04-09 | memo (summary page) |
| S024 | Howard Marks pushes back on private credit panic (Alternative Credit Investor, secondary report of a memo) | https://alternativecreditinvestor.com/2025/11/06/howard-marks-pushes-back-on-private-credit-panic/ | 2025-11-06 | news (secondary) |
| S025 | Marks points to direct lending as example of exuberant market (PEI Private Credit, secondary, paywalled) | https://www.pei-privatecredit.com/marks-points-direct-lending-example-exuberant-market/ | 2018-09-27 | news (secondary) |
| S026 | The Tim Ferriss Show #338, Howard Marks transcript | https://tim.blog/2018/09/27/the-tim-ferriss-show-transcripts-howard-marks/ | 2018-09-27 | interview |
| S027 | Acquired podcast: Howard Marks and Andrew Marks, Something of Value | https://www.acquired.fm/episodes/howard-marks-andrew-marks-something-of-value | 2022-08-30 | interview |
| S028 | Brookfield to Acquire 62% of Oaktree Capital Management (press release) | https://bn.brookfield.com/press-releases/brookfield-acquire-62-oaktree-capital-management | 2019-03-13 | official release |
| S029 | Oaktree Capital Management (Wikipedia, secondary, firm history only) | https://en.wikipedia.org/wiki/Oaktree_Capital_Management | accessed 2026-10 | reference (secondary) |
