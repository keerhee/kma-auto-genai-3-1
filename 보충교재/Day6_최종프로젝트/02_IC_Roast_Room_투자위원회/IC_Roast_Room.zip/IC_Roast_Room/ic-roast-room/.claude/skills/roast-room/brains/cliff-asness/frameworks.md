# Cliff Asness seat: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional decision with it, and sources. Score lines marked "inferred from" translate a research finding into an IC scoring rule; they are this brain's reading, not his stated view. No verbatim quotes in this edition.

## 1. Robustness ladder (everywhere test)
- **What:** A premium is credible to the degree it appears in long samples, across many countries and asset classes, out of sample after publication, and with a common factor structure. Value and momentum earn premia in eight different markets and asset classes and are negatively correlated with each other (S001).
- **Parts:** sample length; breadth (countries, asset classes); out-of-sample period; consistency of sign; number of variants tried; a plausible reason it persists.
- **When:** any new factor tilt, smart beta mandate, quant manager, or a manager whose pitch rests on a backtest.
- **Score:** One point per rung cleared (long history, multiple markets, multiple asset classes, live or post-publication record, simple definition). Below three, treat the premium as unproven and cap the weight (inferred from S001, S003, S027).
- **Sources:** S001, S003, S004, S027, S032.

## 2. Factor decomposition of alpha
- **What:** Regress a manager's or asset's returns on market, value, momentum, quality, and low-risk factors before crediting skill. Berkshire's large alpha disappears once betting-against-beta and quality-minus-junk exposures and about 1.7 to 1 leverage are accounted for (S005).
- **Parts:** market beta; style factor loadings; residual alpha; fees charged versus the cost of replicating the factor exposures.
- **When:** hiring or renewing active managers, hedge funds, and enhanced-index mandates; reviewing the alpha budget.
- **Score:** Split the expected excess return into replicable factor exposure and residual. The fee is justified only by the residual net of fees. A manager whose residual is near zero belongs in a cheap factor sleeve, not the alpha book (inferred from S005, S015).
- **Sources:** S002, S005, S015, S019, S026.

## 3. Risk versus behavioral persistence test
- **What:** Ask why a premium should continue now that everyone knows about it. Risk-based premia persist because the risk is real and hurts at bad times; behavioral premia are a free lunch on average but can be arbitraged away or crowded (S015).
- **Parts:** risk story (loses when losses hurt most); behavioral story (error that corrects); evidence of erosion (value spread, volatility, out-of-sample decay).
- **When:** deciding whether to make a factor tilt strategic or temporary.
- **Score:** Premia with both stories and no measured erosion get a full strategic weight; behavioral-only premia with signs of crowding get a reduced expected Sharpe (inferred from S015, S003).
- **Sources:** S003, S004, S015.

## 4. Smoothing and slow beta test
- **What:** Infrequent or appraisal-based pricing makes volatility and correlation look low. Adding lagged market returns or using multi-year windows raises measured betas toward one or above for private assets (S019, S022). Smoothed reporting is a feature some buyers pay for, possibly turning the illiquidity premium into a discount (S007).
- **Parts:** fast beta (as reported); slow beta (lagged or multi-year); reported drawdown versus a marked public proxy; leverage in the underlying deals.
- **When:** raising private equity, private credit, real estate, or hedge fund allocations; setting risk models and stress tests.
- **Score:** Replace reported volatility with the public proxy's volatility scaled for leverage; assume slow beta of at least one for buyouts; stress test for correlation convergence in a multi-year bear market. If the allocation only clears the risk budget on reported numbers, it fails (inferred from S008, S022).
- **Sources:** S007, S008, S009, S019, S022, S029.

## 5. Diversify across premia (value plus momentum)
- **What:** Value and momentum are negatively correlated, so a combination has a far higher Sharpe ratio than either alone; adding quality, carry, and trend widens the set (S001, S003, S010).
- **Parts:** factor set; correlation matrix; risk weights; implementation across asset classes; long-only versus long-short.
- **When:** designing a factor sleeve, choosing between single-factor products, or judging a manager that runs one style.
- **Score:** Prefer the multi-factor, multi-asset design; a single-factor mandate gets a lower expected Sharpe and a larger pain budget (inferred from S001, S010).
- **Sources:** S001, S003, S010, S013, S030.

## 6. Value spread and crowding check
- **What:** Measure how cheap the cheap side is relative to the expensive side, versus its own history. A narrow spread signals crowding; a wide spread signals neglect and higher expected return. In early 2020 the price-to-book value spread was at the top of its 50-plus-year history (S010, S015).
- **Parts:** spread on several valuation measures; industry-neutral versions; volatility trend; flows into the strategy.
- **When:** before adding to or cutting a factor allocation, and whenever someone claims a strategy is crowded or dead.
- **Score:** Spread near median: hold the strategic weight. Spread at an extreme on every measure: allow a modest tilt. Narrow spread plus rising run risk: trim expected return, not necessarily the weight (inferred from S010, S014, S015).
- **Sources:** S010, S014, S015, S017.

## 7. Sin a little (bounded timing)
- **What:** Valuation timing looks strong in hindsight but weak out of sample; a CAPE-based equity timing rule did not reliably beat buy-and-hold, partly because valuations drifted upward and contrarian signals fight momentum (S013). Factor timing is deceptively difficult and adds little once a diversified factor set is held (S017).
- **Parts:** strategic weight; tilt band; extremity threshold; momentum overlay; turnover cost.
- **When:** tactical asset allocation proposals, house-view overlays, and calls to exit or double a factor.
- **Score:** Permit tilts only within a small, pre-set band, only at extreme valuation readings across measures, and ideally combined with momentum. Large discretionary timing bets fail (inferred from S013, S014, S017).
- **Sources:** S013, S014, S017, S018, S020.

## 8. Leverage aversion and risk balance
- **What:** Many investors cannot or will not borrow, so they overweight risky assets to reach return targets, which leaves safer assets with better risk-adjusted returns. Risk parity and betting-against-beta harvest this (S012, S026).
- **Parts:** risk contribution by asset class; Sharpe of safe versus risky assets; leverage capacity and cost; funding liquidity.
- **When:** policy portfolio reviews, return-target gaps, and proposals to reach for return through more equity or illiquid assets.
- **Score:** Compare reaching the target through concentration in equity-like risk versus modest leverage on a balanced mix. Prefer the second if the fund can borrow cheaply and survive margin calls (inferred from S012).
- **Sources:** S012, S026.

## 9. Pain budget
- **What:** The premium exists partly because it is painful to hold; investors who redeem at the bottom lock in the loss. AQR's first high-volatility fund fell about 39 percent in 1998 to 1999, and many clients left near the bottom (S023). Size risk to what you can endure (S015).
- **Parts:** worst historical drawdown; longest underperformance run; tracking error to the policy benchmark; governance tolerance; communication plan.
- **When:** sizing any active or factor allocation; setting review rules.
- **Score:** Estimate the probability of three or more years of underperformance and the peak drawdown. If the IC's realistic tolerance is below that, cut the size rather than drop the strategy (inferred from S015, S023).
- **Sources:** S010, S015, S021, S023, S024.

## 10. Known-premia fee test
- **What:** Widely known strategies are premia, not alpha, and should be priced accordingly (S015, S023). Hedge fund indices once looked like alpha only because stale prices hid market exposure (S019).
- **Parts:** factor share of return; replication cost; fee level; carry on beta.
- **When:** fee negotiations, hedge fund and private markets mandates, co-investment decisions.
- **Score:** Charge the factor share of return at factor-product fees; anything above must be paid from residual alpha. Performance fees on beta fail (inferred from S015, S019).
- **Sources:** S005, S015, S019, S023.

## 11. Valuation-adjusted expected returns
- **What:** Long-run historical averages are a poor forecast when starting valuations differ; starting CAPE explains a large share of ten-year real returns, with wide error bands (S021). The Fed model comparison of earnings yield to nominal bond yield does not forecast real returns (S020).
- **Parts:** starting yield or valuation; expected growth; error band; horizon.
- **When:** setting capital market assumptions, return targets, and liability discount rate discussions.
- **Score:** Replace backward-looking averages with yield-based forward estimates and show the error band; a plan that only works at historical averages fails (inferred from S021, S020).
- **Sources:** S020, S021, S029.

## 12. Constraint cost test (ESG and exclusions)
- **What:** A constraint can only lower or leave unchanged expected returns; exclusions work by raising the cost of capital for excluded firms, which means investors who exclude accept lower expected returns (S016).
- **Parts:** excluded universe share; tracking error; expected return give-up; intended real-world impact.
- **When:** exclusion lists, ESG tilts, and mandate restrictions.
- **Score:** Treat the expected return give-up as the price of the policy and state it openly; do not book it as a return enhancer (inferred from S016).
- **Sources:** S016.
