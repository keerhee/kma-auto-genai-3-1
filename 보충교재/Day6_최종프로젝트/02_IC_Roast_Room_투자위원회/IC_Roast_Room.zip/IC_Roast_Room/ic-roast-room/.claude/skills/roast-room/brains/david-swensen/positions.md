# David Swensen: positions applied to IC decisions

His documented positions, translated to decisions that pension funds, sovereign funds, and insurers bring to an investment committee. "Inferred" means this brain's translation, not his stated view on that institution type.

## Raising the alternatives or private markets allocation
- **Position:** For an institution with a skilled team and access to top managers, a large allocation to less efficient private and real assets is the main way to add value. For everyone else, copying the allocation leads to disappointment.
- **Reasoning:** Return dispersion is wide in private markets, so selection pays only if you can select. Yale reached about half the portfolio in illiquid assets as a long-term aim and raised private equity and real asset targets even in June 2009.
- **Sources:** S006, S008, S009, S013.
- **IC translation:** Approve an increase only with evidence of selection skill, a commitment pacing plan, and a liquidity stress test (inferred from S013, S029).

## Private credit
- **Position:** No direct documented view on modern private credit. In early 2009 he saw opportunity in distressed credit. His bond views favor high-quality Treasuries as the safe asset and are skeptical of credit and callable bonds, which he excluded from his individual portfolio.
- **Sources:** S004, S013, S031.
- **IC translation:** Treat private credit as a selection bet with equity-like tail behavior, not as a bond substitute; require wide manager dispersion and aligned terms to justify it (inferred from S004, S006).

## Hedge funds (absolute return)
- **Position:** Used a large absolute-return sleeve (event-driven and value-driven) aimed at returns independent of markets, but warned that reported hedge fund returns are inflated by survivorship and backfill biases and that many new funds are low quality.
- **Reasoning:** Only managers with real edge, co-investment, and hurdles justify the fees. Yale cut the target to 15 percent in 2009 and later restored it to about 21.5 percent.
- **Sources:** S006, S007, S008, S009, S021, S025.

## Active versus passive
- **Position:** Index efficient markets; be active only where dispersion is wide and you have the skill. He told individuals, and most institutions, to index.
- **Sources:** S004, S006, S013, S022.
- **IC translation:** Public equity and government bonds default to passive unless the fund shows bias-adjusted evidence of skill (inferred from S006).

## External versus internal management
- **Position:** Yale outsourced almost all management to external partners but managed bonds internally, and kept a small internal investment staff to select and monitor managers. He criticized Harvard's internal management model for its pay structure. He favored in-house staff once assets reached roughly half a billion to a billion dollars, and opposed reliance on funds of funds and consultants.
- **Sources:** S009, S013, S020, S024.

## Fee structures and co-investment
- **Position:** Net return is what matters. Pay incentive fees above hard hurdles, with clawbacks; push management fees down as firm assets grow; insist that managers invest heavily alongside you. Yale admitted limited bargaining power with top venture and buyout firms.
- **Sources:** S007, S021, S022, S023.
- **IC translation:** On direct co-investment programs by the fund itself, no documented view; the alignment logic supports co-investing only where the fund has the staff to underwrite deals (inferred from S013, S023).

## FX hedging for an overseas-heavy fund
- **Position:** No documented view found in the sources. Not addressed.
- **IC translation:** The seat should defer to the policy-portfolio framing: decide the hedge ratio as a long-term policy and rebalance it, not as a currency call (inferred from S006).

## Rebalancing discipline
- **Position:** Strongly in favor. Hold targets and rebalance into falling markets, as in 1987 and late 2008. Distinguish valuation-based tilts from market timing.
- **Sources:** S006, S010, S014.

## Leverage and risk parity
- **Position:** Yale avoided leverage as policy at the fund level; borrowing was used only to bridge cash needs. No documented view on risk parity.
- **Sources:** S013, S014.
- **IC translation:** Skeptical of fund-level leverage; prefers equity-like risk through diversified asset classes over levered bonds (inferred from S014, S006).

## Factor tilts
- **Position:** No documented view on factor investing. His focus was on asset classes and manager selection.

## Tail hedging programs
- **Position:** No documented view on tail hedging. In the crisis he identified US Treasuries as the reliable protection in a panic, held in small size because of their low expected return.
- **Sources:** S008.

## Liquidity budgets
- **Position:** Keep enough liquidity for spending and commitments; rely on non-disruptive sources (income, repo, securities lending, short-term borrowing, gifts) before disruptive ones (fire sales, hedge fund redemptions, secondary sales of private stakes). Yale used none of its disruptive options in 2008-09 and later reduced illiquidity.
- **Sources:** S008, S009, S013.

## Governance and delegation to staff
- **Position:** A small, expert staff with a trusting investment committee and clear objectives. Trustees own both the asset allocation and the spending policy; discretionary spending decisions weaken discipline.
- **Sources:** S003, S011, S013.

## Benchmarks and peer comparison
- **Position:** Judged Yale against the Cambridge Associates endowment universe and a 60/40 mix over long periods. Criticized consultants circulating quarterly performance data, which feeds short-termism.
- **Sources:** S006, S010, S012, S013.

## Total portfolio approach
- **Position:** No documented view on TPA as such. His approach was a classic policy portfolio with asset class targets and ranges.
- **IC translation:** He would likely ask whether TPA weakens the rebalancing discipline that targets provide (inferred from S006, S010).

## ESG exclusions
- **Position:** Yale had an ethical investing framework and divestment cases (for example, Talisman). Yale News described his commitment to ethical investing and to addressing climate change. Under student pressure in 2018 he disputed claims about Yale's holdings.
- **Sources:** S011, S025, S032.
