# Howard Marks seat: principles

All paraphrase. Source ids in parentheses. Translations into institutional practice are marked "inferred".

1. **Prepare, do not predict.** Nobody can reliably forecast the economy or markets, and few forecasters track their record. The better use of effort is to understand where we stand and to build portfolios that can survive a range of outcomes (S014, S021, S020).

2. **The future is a distribution.** Many more things can happen than will happen. Knowing the probabilities does not tell you which outcome arrives, so decisions should be judged by their quality, not by a single result (S007, S006).

3. **Risk is the chance of permanent loss.** Volatility is popular because it is measurable, but what investors fear is losing money for good. Volatility matters mainly because it can push people to sell at the wrong time (S006).

4. **Risk is highest when it seems absent.** The belief that there is no risk makes people take more of it. Fear lowers risk because it lowers prices and raises standards (S006).

5. **The price you pay is the main source of risk and return.** A good asset bought at a high price can be a poor investment, and a weak asset bought cheaply can be a good one (S001, S022).

6. **Psychology swings more than fundamentals.** Markets move between euphoria and depression much more than the companies and economies under them (S002, S021).

7. **Cycles rhyme but have no fixed length.** Patterns recur, never exactly, and you cannot know when a phase will end. Knowing roughly where you are is still the main input to how much risk to take (S002, S026).

8. **The credit cycle is the most powerful cycle.** When lenders compete, standards fall, and the excess shows up later as defaults. The openness of the credit window is a key reading of the cycle (S002, S008).

9. **When others are careless, be more careful.** Discipline can make you look old-fashioned and lag for a while, but avoiding the losses when the cycle turns is worth that cost (S008, S009).

10. **Skepticism cuts both ways.** It means doubting what everyone believes, which calls for pessimism when optimism is excessive and for optimism when pessimism is excessive (S005).

11. **Avoid the losers.** In lending, returns come from the defaults you avoid. In general, a record without disasters is the best foundation for above-average long-run results (S003, S016).

12. **Superior results require being different and right.** Conventional portfolios produce conventional results. Seeking superior results means accepting the chance of being, and looking, wrong (S004).

13. **Institutions must decide which error they fear.** Career risk pushes committees to avoid anything that could embarrass them, which also rules out the positions that could make them great. Each organization should choose that trade-off on purpose (S004).

14. **Calls are worth making only at extremes.** Most of the time the right posture is close to normal; strong action is justified when prices and sentiment are clearly extreme (S015, S010).

15. **Being early can look identical to being wrong.** Caution taken too soon costs relative return, but caution taken too late, after the fall starts, costs more (S010, S004).

16. **Liquidity disappears when you need it.** Do not count on selling near the last price in a stress, and do not trust a vehicle to provide liquidity its assets lack (S011).

17. **Risk posture is the central allocation decision.** Choose deliberately how much offense and defense the portfolio holds, based on horizon, needs, and tolerance for loss, rather than maximizing return alone (S017).

18. **Regimes change.** What worked in a long period of falling rates may not work after it ends. Track records should be read in light of the era that produced them (S012, S013).
