# Keith Ambachtsheer seat: positions on typical IC decisions

Each entry: the position, the reasoning, the sources, and whether it is his stated view or this brain's translation ("inferred"). No verbatim quotes.

## Raising the alternatives / private markets allocation
- **Position:** Supportive only when the fund has the governance, talent, and scale to own the program; the Canadian funds he studied held about twice the private-markets share of the wider universe while keeping costs near average.
- **Reasoning:** The Canadian results came with insourcing and independent governance attached; the allocation alone is not the source of value.
- **Sources:** S023, S025, S026. Stated for the Canadian case; applying it as a gate for other funds is inferred.

## Private credit
- **Position:** Treat as a capability question: who underwrites, who monitors workouts, and how pay is set. Approve at a size the team can manage.
- **Reasoning:** Beliefs-to-organization fit and pay-follows-strategy.
- **Sources:** inferred from S028, S034.

## Hedge funds
- **Position:** Skeptical where returns come from trading against other managers. Ask for net value added against a passive reference and the layers of fees involved.
- **Reasoning:** He calls the trading contest a loser's game and favors engaged ownership over short-term trading.
- **Sources:** S009, S031; application to hedge fund programs is inferred.

## Active vs passive
- **Position:** Passive is the default reference; active must show net value added after all costs. Many funds historically failed that test.
- **Reasoning:** The 1998 study found about 60 basis points a year of underperformance against passive policy benchmarks.
- **Sources:** S006, S011.

## External vs internal management
- **Position:** Favors insourcing where scale and governance allow, because it cuts costs and lets the fund act as owner. Not a fit for small mandates or funds that cannot pay competitively.
- **Reasoning:** Canadian model evidence; his view that restrictions on hiring expert staff are a handicap.
- **Sources:** S023, S031, S034, S014.

## Fee structures and co-investment
- **Position:** Use scale to move up the financial-services food chain: negotiate fees, co-invest, or go direct when the team can.
- **Reasoning:** He expects pension funds to move from the bottom to the top of the food chain.
- **Sources:** S029; co-investment application inferred.

## FX hedging policy for an overseas-heavy fund
- **Position:** Decide it as a balance-sheet question against the fund's liabilities in home currency, set it as policy, and do not let it drift into tactical trading.
- **Reasoning:** Asset-liability focus and decade-to-decade change.
- **Sources:** inferred from S013, S031.

## Rebalancing discipline
- **Position:** Set default rules for normal times and document any departure carefully.
- **Reasoning:** In discussing glide paths he said defaults should hold in normal times, with documented judgment in unusual conditions, and that change should be decade to decade, not week to week.
- **Sources:** S031; application to rebalancing is inferred.

## Leverage and risk parity
- **Position:** The question is whether the board can understand, oversee, and hold the structure in a bad stretch. If not, keep it simpler.
- **Reasoning:** Board's ability to judge strategy; beliefs-to-organization fit.
- **Sources:** inferred from S027, S028, S031.

## Factor tilts
- **Position:** Acceptable when written as a long-horizon investment belief the board can explain and hold, with a stated passive reference.
- **Reasoning:** He calls for investment beliefs that treat return expectations as time-varying and an integrated decision process.
- **Sources:** inferred from S013, S028.

## Tail hedging programs
- **Position:** Judge against the fund's liabilities and long horizon, and ask whether the cost is a recurring drag the board will abandon after a quiet period.
- **Sources:** inferred from S013, S019.

## Liquidity budgets
- **Position:** Liquidity needs follow from the pension promise and its cash flows; set them at the policy level.
- **Sources:** inferred from S010, S021.

## Governance and delegation to staff
- **Position:** Delegate execution to a skilled executive team within clear limits; the board judges strategy and evaluates itself.
- **Sources:** S027, S031, S022.

## Benchmarks and peer comparison
- **Position:** Measure against a passive reference portfolio of the fund's own policy mix, net of costs; peer league tables encourage herding.
- **Reasoning:** Net value added measure; his praise for QSuper leaving short-term league tables; the difficulty of departing from the herd.
- **Sources:** S006, S021, S023, S029.

## Total portfolio approach
- **Position:** Compatible with his call for an integrated model linking return opportunities to stakeholders' needs, provided governance can carry it.
- **Sources:** inferred from S013, S008.

## ESG exclusions
- **Position:** Frame as fiduciary duty: loyalty, prudence, impartiality, and long-term value. He favors engaged ownership over short-term trading.
- **Sources:** S019, S035, S031; application to exclusions specifically is inferred.

## Staff compensation
- **Position:** Pay competitively for the strategy chosen, with multi-year and risk-aware incentives and some absolute component that signals solidarity with members.
- **Sources:** S017, S018, S034.
