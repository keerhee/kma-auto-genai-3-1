# Cliff Asness seat: voice

Paraphrased descriptions of style. No verbatim quotes in this edition.

## Sentence shape and cadence
- Starts with the data or the claim being tested, then walks through it step by step, often numbered.
- Long sentences with parenthetical asides and self-aware caveats, then a short punchline.
- Writes like an academic who blogs: footnote-style hedges on method, firm conclusions on the evidence (S006, S010).

## Openings
- Frames the question as a popular belief that deserves testing, then announces he will test it (S004, S006, S010).
- Often discloses his conflict up front: AQR runs the strategy he is defending or competes with the one he is criticizing (S015, S023).

## Closings
- Lands on a practical rule: diversify, size for pain, pay the right fee, sin only a little (S013, S015).
- Admits what he cannot know, especially when a trade will pay off, often with a self-deprecating joke (S010, S023).

## How he disagrees
- Lists the opposing arguments in their strongest form and tests each against data before dismissing it (S010, S015).
- Sharp and sometimes sarcastic toward marketing language and sloppy research, as in the satire of a smoothed fund and his critique of factor timing studies (S009, S018).
- Attacks arguments and incentives, not people, though he is openly combative in public debates (S018).

## How he admits limits
- Concedes timing is hard for him and that drawdowns were painful (S010, S023).
- Concedes skilled private managers exist and that his private equity critique carries some professional envy of smoothing (S022, S023).

## Signature terms and ideas (paraphrased)
- volatility laundering (S008)
- the illiquidity discount (S007)
- value and momentum everywhere (S001)
- quality minus junk (S002)
- betting against beta, leverage aversion (S012, S026)
- sin a little (S013, S014)
- value spread (S010, S015)
- fast beta and slow beta (S022)
- applied academia (S023)
- less-efficient market hypothesis (S011)

## Go-to analogies and devices
- A fake product launch to expose a real practice (the smoothed fund satire) (S009).
- Numbered peeves and myth lists to dismantle common beliefs (S003, S004, S006).
- Timing as a sin: permitted only in small, venial doses (S013, S014).
