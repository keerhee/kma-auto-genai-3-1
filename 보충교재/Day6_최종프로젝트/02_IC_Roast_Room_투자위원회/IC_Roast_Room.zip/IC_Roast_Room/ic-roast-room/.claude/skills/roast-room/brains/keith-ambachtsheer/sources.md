# Keith Ambachtsheer seat: sources

Every entry was checked with a web search or fetch during compilation. Where a stable URL could not be confirmed, the url column is "-" and the title, publisher, and year are given instead. Entries marked (title only) were confirmed to exist, but their full text could not be read; the brain cites them only for their existence and abstract-level claims.

| id | title | url | date | type |
|---|---|---|---|---|
| S001 | Pension Revolution: A Solution to the Pensions Crisis (Wiley, ISBN 978-0-470-08723-7, 368 pp.) | https://gov.wiley.com/WileyCDA/WileyTitle/productCd-0470087234.html | 2007-01 | book |
| S002 | Pension Fund Excellence: Creating Value for Stakeholders, with D. Don Ezra (Wiley, ISBN 978-0-471-24655-8) | https://gov.wiley.com/WileyCDA/WileyTitle/productCd-0471246557.html | 1998-04 | book |
| S003 | The Future of Pension Management: Integrating Design, Governance, and Investing (Wiley) | https://openlibrary.org/books/OL27207678M | 2016 | book |
| S004 | Pension Funds and the Bottom Line (Dow Jones-Irwin) (title only) | - | 1985 | book |
| S005 | Keith Ambachtsheer, faculty and publications page, Rotman School of Management | https://rotman.utoronto.ca/FacultyAndResearch/Faculty/ExecutivesInResidence/Ambachtsheer | n.d. (accessed 2026-10) | official bio |
| S006 | Improving Pension Fund Performance, with Ronald Capelle and Tom Scheibelhut, Financial Analysts Journal 54(6) | https://rpc.cfainstitute.org/research/financial-analysts-journal/1998/improving-pension-fund-performance | 1998-11 | paper |
| S007 | Why We Need a Pension Revolution, Financial Analysts Journal 63(1) | https://rpc.cfainstitute.org/research/financial-analysts-journal/2007/why-we-need-a-pension-revolution | 2007-01 | paper |
| S008 | Beyond Portfolio Theory: The Next Frontier, Financial Analysts Journal 61(1) | https://rpc.cfainstitute.org/research/financial-analysts-journal/2005/beyond-portfolio-theory-the-next-frontier | 2005-01 | paper |
| S009 | Fixing the Losers' Game: What It Will Take, Financial Analysts Journal 69(3) (title only) | https://rpc.cfainstitute.org/research/financial-analysts-journal/2013/fixing-the-losers-game-what-it-will-take | 2013-05 | paper |
| S010 | Why We Need to Change the Conversation about Pension Reform, guest editorial, CFA Institute Enterprising Investor and FAJ July/August 2014 | https://rpc.cfainstitute.org/blogs/enterprising-investor/2014/why-we-need-to-change-the-conversation-about-pension-reform/ | 2014-06-18 | paper |
| S011 | Can Active Management Add Value?, with James L. Farrell, Financial Analysts Journal 35(6) | https://rpc.cfainstitute.org/research/financial-analysts-journal/1979/can-active-management-add-value | 1979-11 | paper |
| S012 | Pension Fund Asset Allocation: In Defense of a 60/40 Equity/Debt Asset Mix, Financial Analysts Journal | https://rpc.cfainstitute.org/research/financial-analysts-journal/1987/pension-fund-asset-allocation-in-defense-of-a-6040-equitydebt-asset-mix | 1987 | paper |
| S013 | Why Pension Fund Management Needs a Paradigm Shift, Pension Research Council working paper WP2004-04, Wharton | https://pensionresearchcouncil.wharton.upenn.edu/publications/papers-2018/why-pension-fund-management-needs-a-paradigm-shift/ | 2004 | paper |
| S014 | Pension Reform: How Canada Can Lead the World, C.D. Howe Institute Benefactors Lecture | https://cdhowe.org/publication/pension-reform-how-canada-can-lead-world/ | 2009-11-01 | lecture / report |
| S015 | Pension Reforms: Will Canada Lead the World?, Pension Pulse blog (Leo Kolivakis), summary and critique of S014 | https://pensionpulse.blogspot.com/2009/11/pension-reforms-can-canada-lead-world.html | 2009-11-19 | commentary |
| S016 | The Pension Governance Deficit: Still with Us, with Ronald Capelle and Hubert Lum, Rotman International Journal of Pension Management 1(1) (title only; findings as summarized in S014 and S015) | - | 2008 | paper |
| S017 | How Should Pension Funds Pay Their Own People? (digest of his Rotman International Journal of Pension Management article), CFA Institute Journal Review | https://rpc.cfainstitute.org/research/cfa-digest/2011/08/how-should-pension-funds-pay-their-own-people-digest-summary | 2011-08 | paper digest |
| S018 | Ambachtsheer: Pension Fund Manager Compensation Should Be Reevaluated, aiCIO | https://www.ai-cio.com/news/ambachtsheer-pension-fund-manager-compensation-should-be-reevaluated/ | 2012-02-03 | article |
| S019 | The Case for Long-Termism, Rotman International Journal of Pension Management (Fall 2014), as published by Top1000funds | https://www.top1000funds.com/uncategorised/the-case-for-long-termism/ | 2014 | paper |
| S020 | Ten Strategies for Pension Funds to Better Serve Their Beneficiaries, with Rob Bauer, Netspar / RIJPM (title only) | https://www.netspar.nl/en/knowledge-hub/ten-strategies-for-pension-funds-to-better-serve-their-beneficiaries/ | 2014-02-10 | paper |
| S021 | Taking the Dutch Pension System to the Next Level: A View from the Outside, Netspar Occasional Paper | https://www.netspar.nl//assets/uploads/KVS_Ambachtsheer_def.pdf | 2014 | paper |
| S022 | Pension Fund Governance Needs an Overhaul, Still (report on the Ambachtsheer and McLaughlin 2014 survey), Top1000funds | https://www.top1000funds.com/research/pension-fund-governance-needs-an-overhaul-still/ | 2014/2015 | article |
| S023 | The Value of the Canadian Model, Top1000funds (on his CEM-based study of eight Canadian funds) | https://www.top1000funds.com/organisational-design/the-value-of-the-canadian-model/ | c. 2017 | article |
| S024 | The Canadian Pension Model: Past, Present, and Future, CEM Benchmarking research insight | https://insights.cembenchmarking.com/?p=476 | c. 2021 | paper |
| S025 | How Peter Drucker Revolutionized Canada's Public Sector Pension System: Lessons for Americans, Harvard Law School Forum on Corporate Governance | https://corpgov.law.harvard.edu/2022/12/08/how-peter-drucker-revolutionized-canadas-public-sector-pension-system-lessons-for-americans/ | 2022-12-08 | article |
| S026 | Beath, Betermier, Flynn, Spehner, The Canadian Pension Fund Model: A Quantitative Portrait, Journal of Portfolio Management (cites his 2017 work) | https://top1000funds.com/wp-content/uploads/2024/05/CEM-BBFS_JPM2021_CanadianModelQuantitativePortrait.pdf | 2021 | paper (third party) |
| S027 | A New Model for Pension Management (Larrabee, report of his talk at the 69th CFA Institute Annual Conference), CFA Institute Enterprising Investor | https://blogs.cfainstitute.org/blog/2016/05/10/a-new-model-for-pension-management/ | 2016-05-10 | talk report |
| S028 | Book Review: The Future of Pension Management (Gillman), CFA Institute Enterprising Investor | https://blogs.cfainstitute.org/blog/2016/06/03/book-review-the-future-of-pension-management | 2016-06-03 | review |
| S029 | Pensions panacea, review of Pension Revolution (Stroobants), IPE | https://ipe.com/pensions-panacea/21739.article | c. 2007 | review |
| S030 | The thinking pension revolutionary (profile, IPE Outstanding Industry Contribution award 2007), IPE | https://ipe.com/the-thinking-pension-revolutionary/26338.article | 2007 | profile |
| S031 | The Keith Ambachtsheer interview (Graham Hand), Firstlinks / Cuffelinks No. 17 | https://www.firstlinks.com.au/the-keith-ambachtsheer-interview-3 | 2013-05-31 | interview |
| S032 | Inspiration: Keith Ambachtsheer turns big ideas into practice (Leigh Doyle), Benefits Canada | https://www.benefitscanada.com/?p=38935 | 2011-11-28 | profile |
| S033 | How to Build an Effective Pension Board (Joel Kranc), Institutional Investor | https://www.institutionalinvestor.com/index%2Ephp/article/2bsum6b9lydpmw0or6iv4/corner-office/how-to-build-an-effective-pension-board | 2014-07-11 | article |
| S034 | Strategy should lead compensation: Ambachtsheer (on a KPA survey of 37 funds in The Ambachtsheer Letter), Top1000funds | https://www.top1000funds.com/uncategorised/strategy-should-lead-compensation-ambachtsheer/ | n.d. | article |
| S035 | Pension funds must catch up with legal view of fiduciary duty, IPE | https://www.ipe.com/pension-funds-must-catch-up-with-legal-view-of-fiduciary-duty/10006004.article | c. 2015 | article |
| S036 | Ambachtsheer slams pension fund governance, IPE | https://www.ipe.com/ambachtsheer-slams-pension-fund-governance/9141.article | n.d. | article |
| S037 | The Evolving Meaning of Fiduciary Duty: Are the Boards of Pension Organizations Keeping Up?, Journal of Investment Consulting (title only, listed in S005) | - | 2015 | paper |
| S038 | In Whose Interest?, report of the Ontario Task Force on the Investment of Public Sector Pension Funds (advisory work by Ambachtsheer, described in S005 and S025) | - | 1987-11 | official report |
| S039 | The Ambachtsheer Letter, KPA Advisory Services, monthly commentary since 1985 (existence confirmed in S030 and S034; individual issues not read) | - | 1985 onward | letter |
| S040 | The 'Canada Model' for Pension Management, 2017 paper listed in S005 and cited as Ambachtsheer 2017a/b in S026 (title only) | - | 2017 | paper |
