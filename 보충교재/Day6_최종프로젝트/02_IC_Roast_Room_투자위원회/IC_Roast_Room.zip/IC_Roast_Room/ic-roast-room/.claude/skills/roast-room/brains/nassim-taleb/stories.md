# Nassim Nicholas Taleb: stories

Facts only, as documented in the listed sources. Retell briefly and paraphrase.

## 1. Two traders, two payoff shapes (2002 profile)
Malcolm Gladwell's New Yorker profile contrasted Taleb's Empirica, which bought out-of-the-money options, held reserves in Treasury bills, and lost small amounts most days, with Victor Niederhoffer, who sold uncovered S&P 500 puts. When the market fell sharply on 27 October 1997, Niederhoffer's firm lost about 130 million dollars and was wiped out. The profile also described the written protocols Empirica used to endure the daily bleed (S025).
**Use:** any proposal earning steady income by selling insurance or liquidity.

## 2. Against VaR (1997)
In a published reply to Philippe Jorion, Taleb argued that VaR gives misplaced precision, rests on unreliable tail estimates, and serves as an alibi after losses, and that the real causes of famous blowups were leverage that simple checks would have caught (S009).
**Use:** any risk budget expressed mainly as VaR or tracking error.

## 3. Testimony to Congress (2009)
At a September 2009 House subcommittee hearing on VaR and the crisis, Taleb testified that VaR understates tail losses, can encourage more risk-taking through anchoring, and should face a do-no-harm standard. He urged robust measures such as leverage limits, smaller institutions, clawbacks, and converting debt to equity (S010, S011).
**Use:** when an IC treats a model output as a safety certificate.

## 4. The turkey problem
In The Black Swan, a turkey fed daily for a thousand days grows more confident in the farmer's goodwill each day, until the day before the holiday. The point: a long, calm record can increase confidence exactly as risk peaks (S002).
**Use:** strategies with long smooth track records and no crisis in sample.

## 5. Universa in March 2020
Universa, founded in 2007 by Mark Spitznagel with Taleb as adviser, reported a 3,612 percent March 2020 return in an investor letter (S026, S029). Later reporting explained the figure was a return on the capital required for the positions, not on assets, drew criticism from other managers including Cliff Asness over the long-run cost of rolling options, and estimated the program's cost near 1.7 percent a year of a protected portfolio (S027).
**Use:** both sides of a tail-hedge debate: payoff in a crash, carry and measurement questions in between.

## 6. CalPERS and the cancelled hedge
CalPERS hired Universa and LongTail Alpha in 2017 for equity tail protection. The hedges cost about 140 million dollars in the year to June 2019. The fund gave notice to Universa in October 2019 and exited by January 2020, before a sell-off in which the position would have paid over 1 billion dollars; the LongTail hedge, kept until 31 March, paid several hundred million (S028). This is a documented episode about the client, not about Taleb's own actions.
**Use:** governance must be able to hold a hedge through the bleed.

## 7. The insurance debate in the FAJ
Antti Ilmanen of AQR published research finding that selling financial catastrophe insurance earned positive long-run returns with sharp losses in bad times. Taleb wrote a letter disputing it, and Ilmanen's reply addressed points including the limits of rare-event data and the treatment of the 1987 crash (S024).
**Use:** the Taleb versus Asness-camp disagreement on whether long volatility is underpriced.

## 8. Ten principles after the crisis (2009)
In the Financial Times, Taleb set out ten principles for a sturdier financial system: let fragile things fail small, no socialized losses, no bonus-driven risk overseers, simple products, no curing leverage with leverage, and no retirement savings that depend on expert forecasts (S013).
**Use:** leverage and governance debates.

## 9. Six mistakes executives make (2009)
With Daniel Goldstein and Mark Spitznagel, Taleb argued in HBR that managers wrongly try to predict extreme events, trust the past, ignore advice about what to avoid, rely on standard deviation, overlook framing, and strip out redundancy in the name of efficiency (S012).
**Use:** when a risk plan is a forecast rather than an exposure map.
