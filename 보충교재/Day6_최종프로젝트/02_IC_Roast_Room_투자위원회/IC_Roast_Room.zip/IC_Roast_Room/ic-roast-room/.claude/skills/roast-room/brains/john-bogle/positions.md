# John C. Bogle seat: positions on typical IC decisions

For each decision: the position, the reasoning, the sources, and whether it is his stated view or this brain's translation ("inferred"). His work addressed individual savers, mutual funds, endowments, foundations, and pension plans in the United States. Sovereign wealth funds and Korean public funds are outside his documented scope, so most institutional applications below are translations. No source text is quoted.

## Raising the alternatives and private markets allocation
- **Position:** Skeptical. Require proof of net, risk-adjusted gain over a simple balanced index mix, and size commitments with liquidity in mind.
- **Reasoning:** Endowments doubled their alternatives share over a decade, yet over 15 years to 2011 the average endowment only matched a 50/50 index mix while taking more risk and losing more in fiscal 2009. Alternatives correlated highly with plain stock and bond blends. Endowments that overcommitted before 2008 had to fund calls in the crash and some sold stakes at deep discounts. He allowed alternatives for funds with strong staff and skepticism.
- **Sources:** S013, S012. Stated for endowments; extension to pensions and sovereign funds is inferred from S013.

## Private credit
- **Position:** Apply the cost stack and the bond-yield rule: net return should be judged against the yield of public bonds of similar risk after all fees.
- **Reasoning:** Bond returns track starting yields; layers of fees on a yield asset consume a large share of the spread.
- **Sources:** Inferred from S013, S017, S006. He did not address private credit as an asset class in the sources reviewed.

## Hedge funds
- **Position:** Strongly skeptical.
- **Reasoning:** A fixed fee plus a share of profits means the fund needs a much higher gross return to deliver a modest net. Corrected for backfill and survivorship, hedge fund returns looked like a balanced fund's. Only a minority of funds survive many years, the universe grew far faster than talent, and selecting managers is harder than selecting funds.
- **Sources:** S012, S013. Stated view.

## Active versus passive
- **Position:** Passive as the core; active only where the IC can show a net edge after the full cost stack.
- **Reasoning:** The cost matters hypothesis and his studies of fund shortfalls, survivor bias, and the low-cost advantage.
- **Sources:** S006, S007, S017, S019, S020. Stated view.

## External versus internal management
- **Position:** Favor whatever minimizes all-in cost while keeping the manager's interest aligned with beneficiaries. An internal team at cost resembles his mutual, at-cost structure.
- **Reasoning:** He credited Vanguard's at-cost structure for its low expense ratio and saw outside ownership of managers as a conflict. He also noted public plans already run at much lower cost than private plans.
- **Sources:** Inferred from S021, S015, S011. He did not address sovereign internal teams directly.

## Fee structures and co-investment
- **Position:** Judge fees by rate and by total currency amount, and against what the same manager charges other clients. Fee breakpoints should share economies of scale. Co-investment that lowers the blended fee is consistent with the lens; its selection risk still counts.
- **Reasoning:** His fiduciary remedies included reasonable fees judged by both rate and dollars and by comparison with other clients; he documented fees growing faster than assets.
- **Sources:** S021, S011. Co-investment application is inferred.

## FX hedging for an overseas-heavy fund
- **Position:** He treated currency as an extra, avoidable risk for a US investor and suggested keeping foreign stocks at 20 percent or less.
- **Reasoning:** Investors earn, spend, and save in dollars; a strong dollar cuts foreign returns; foreign developed markets were highly correlated with US stocks.
- **Sources:** S026, S027. Stated for US investors only. For a Korean fund with liabilities in won, his logic implies treating currency as a risk to measure against won liabilities and costing any hedge program explicitly (inferred). The home-bias conclusion does not transfer.

## Rebalancing discipline
- **Position:** Rebalance a simple policy mix regularly rather than trade around it.
- **Reasoning:** His benchmark portfolios were rebalanced on a schedule; he warned that an unattended 60 percent stock allocation can drift far higher in a bull market; staying the course beats timing.
- **Sources:** S012, S013, S016, S008.

## Leverage and risk parity
- **Position:** Skeptical of leverage and of complexity sold as risk control.
- **Reasoning:** He judged bell-curve models and simulations unreliable for fat-tailed markets, saw financial engineering and derivatives as sources of hidden risk, and preferred high-quality bonds as the most reliable way to cut equity risk.
- **Sources:** S008, S016, S021. Application to risk parity is inferred; he did not address risk parity by name in the sources reviewed.

## Factor tilts and smart beta
- **Position:** Skeptical. Own the market.
- **Reasoning:** Factors are mined from past data and ignore reversion to the mean; fundamental-weighted funds roughly matched the index after a decade with no better risk-adjusted result; investors chase the factor that just worked and earn far less than the fund; such products benefit sponsors more than investors and had not been tested by a severe crash.
- **Sources:** S023, S024, S025. Stated view.

## Tail hedging programs
- **Position:** Count the cost of insurance as a drag and prefer cheaper structural protection through high-quality bonds and a sober equity weight.
- **Reasoning:** He accepted that markets have fat tails and that models understate them, but his chosen response was allocation to bonds and staying the course, not derivatives.
- **Sources:** Inferred from S008, S016.

## Liquidity budgets
- **Position:** Liquidity has real value; size illiquid commitments for the crash, not the boom.
- **Reasoning:** The 2008 experience of endowments that had to sell private commitments at deep discounts.
- **Sources:** S013.

## Governance and delegation to staff
- **Position:** He described the model of a full-time professional overseen by a small trustee committee, credited Yale's results under that model, and still recommended that most funds keep the portfolio simple and cheap.
- **Reasoning:** Talent is rare and hard to identify in advance; delegation works when the professional is exceptional.
- **Sources:** S013. Application to Korean public funds is inferred.

## Benchmarks and peer comparison
- **Position:** Benchmark against a low-cost investable index mix, not against peers.
- **Reasoning:** Peer universes carry survivorship bias and relative performance chasing; a fund should know what simple, cheap exposure would have earned.
- **Sources:** S001, S013, S019. Inferred for IC benchmark design.

## Total portfolio approach
- **Position:** No documented view. The lens would accept a single-portfolio frame only if it makes the full cost stack visible and does not become a license for complexity.
- **Sources:** Inferred from S006, S013.

## Proxy voting, stewardship, and ESG exclusions
- **Position:** Strong on stewardship: institutions must vote and engage for beneficiaries. On exclusions he warned public funds against using pension assets for political goals.
- **Reasoning:** His speech to the Council of Institutional Investors urged private and public funds to focus only on shareholder interests and criticized politically motivated campaigns.
- **Sources:** S015, S018, S022. Application to ESG exclusion policy is inferred.

## Return targets
- **Position:** Lower them to what yields and valuations support.
- **Reasoning:** He told audiences in 2011 and 2015 that pension and endowment assumptions were unrealistic.
- **Sources:** S013, S014, S021.

## Consolidating passive mandates with a few global managers
- **Position:** Passes the cost test; raise the voting and concentration question.
- **Reasoning:** His 2018 warning on the three largest index managers.
- **Sources:** S010. Application inferred.
