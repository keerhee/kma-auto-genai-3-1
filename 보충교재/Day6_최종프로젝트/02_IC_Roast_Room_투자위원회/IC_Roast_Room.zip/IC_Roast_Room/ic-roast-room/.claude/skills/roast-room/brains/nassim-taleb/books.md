# Nassim Nicholas Taleb: books

## His books (the Incerto and technical works)
- **Dynamic Hedging (1997, S007):** a trader's manual on options risk; the practical root of his view that exposures, not forecasts, are what you can manage.
- **Fooled by Randomness (2001, S001):** luck is routinely mistaken for skill; survivorship and short samples fool observers.
- **The Black Swan (2007, S002; second edition 2010, S003):** rare, high-impact events dominate history and finance; Mediocristan versus Extremistan; the turkey; the barbell. The second edition adds the essay On Robustness and Fragility.
- **Antifragile (2012, S004):** some things gain from disorder; detect fragility through convexity; barbell, via negativa, iatrogenics, Lindy.
- **Skin in the Game (2018, S005):** risk-takers must bear downside; ergodicity and ruin; why systems with asymmetric incentives blow up.
- **Statistical Consequences of Fat Tails (2020, S006):** technical treatment of why standard statistics fail under fat tails and how slowly fat-tailed samples converge.

## Collaborators and related works
- **Benoit Mandelbrot:** co-authored the FT essay on wild versus mild randomness; Taleb credits his fractal view of markets (S021).
- **Raphael Douady:** co-author on the mathematics of fragility and on the precautionary principle (S016, S008).
- **Rupert Read, Joseph Norman, Yaneer Bar-Yam:** co-authors of the precautionary principle paper (S008).
- **Mark Spitznagel:** partner at Empirica and founder of Universa; his Safe Haven (2021) carries a foreword by Taleb and argues that cost-effective safe havens can raise portfolio growth (S030, S027).
- **Daniel Goldstein:** co-author of the HBR six mistakes article (S012).
- **Mark Blyth:** co-author of The Black Swan of Cairo on suppressed volatility (S022).
- **Constantine Sandis:** co-author on the skin in the game heuristic (S017).

## Counterviews worth reading alongside
- **Antti Ilmanen (AQR):** research and reply on whether markets reward buying or selling insurance (S024).
- **Roni Israelov (AQR), Pathetic Protection (2018):** finds protective puts usually less effective than simply lowering equity exposure (S031).
