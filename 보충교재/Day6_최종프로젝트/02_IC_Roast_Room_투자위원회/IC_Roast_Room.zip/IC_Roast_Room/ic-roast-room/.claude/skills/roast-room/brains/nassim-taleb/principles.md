# Nassim Nicholas Taleb: principles

Paraphrased. Translations into institutional practice are marked inferred.

1. **Ruin is different.** Once a loss ends the game, no later average can repair it, so strategies that carry any real path to ruin must be rejected on that ground alone (S020, S008).

2. **Extremistan rules finance.** In domains like wealth and markets, a single observation can dominate the total, so the past sample understates what can happen (S002, S021, S014).

3. **Absence of evidence is not evidence of absence.** The turkey fed for a thousand days grows more confident just before the day it is killed; a long calm record can be the run-up to the event (S002).

4. **Volatility suppression breeds fragility.** Systems kept artificially calm accumulate hidden risk that releases all at once (S022, S014).

5. **Measures can do harm.** A risk number that is unreliable is worse than none, because it anchors decision makers and encourages them to take more risk (S010, S009).

6. **Leverage is the mechanism of blowups.** Most famous losses came from leverage combined with an underestimated extreme move; hard leverage limits work better than model-based limits (S010, S009, S013).

7. **Debt is more dangerous than equity.** Credit-fuelled bubbles do more damage than equity bubbles, because debt forces sales and transmits losses (S013, S010).

8. **Plan for consequences, not causes.** You cannot forecast the shock, but you can study and change what it would do to you (S012).

9. **Redundancy and slack are insurance.** Optimizing every unit of capital removes the buffer that lets an organization survive surprises (S012, S014).

10. **Convexity beats prediction.** Prefer positions whose gains grow with disorder and whose losses are capped; such positions do not need forecasts to work (S004, S016).

11. **Subtract before you add.** Removing sources of fragility usually helps more than adding sophisticated protection (S004, S013).

12. **Incentives create hidden tails.** When agents keep gains and shift losses, they will choose strategies that pay steadily and blow up rarely (S017, S005, S010).

13. **Survivorship fools observers.** Judging skill by visible winners ignores those who failed with the same approach (S001, S002).

14. **Correlation and standard deviation are fragile statistics under fat tails.** Diversification built on correlations estimated in calm times can disappear when it is needed (S014, S006, S009). The extension to institutional diversification claims is inferred from these sources.

15. **Small samples lie more under fat tails.** The data needed to estimate a fat-tailed mean can exceed what any history offers (S018, S006).

16. **Precaution has a domain.** Apply it to systemic, fat-tailed harm, and take local, bounded risks freely through trial and error (S008, S004).

17. **Things that have survived carry information.** Practices and structures that have lasted long are more likely to keep lasting than new ones (Lindy effect, S004, S005).

18. **Too big to fail is too big.** Units whose failure would be systemic should be smaller, and fragile units should be allowed to fail early while small (S013, S010).
