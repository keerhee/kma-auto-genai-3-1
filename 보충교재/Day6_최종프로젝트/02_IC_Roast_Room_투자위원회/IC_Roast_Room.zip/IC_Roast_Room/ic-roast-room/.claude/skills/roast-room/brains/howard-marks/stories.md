# Howard Marks seat: stories

Documented episodes, told briefly. Facts only, all from the cited sources.

## 1. The pension plan that never shone and ended near the top (1990)
In a 1990 memo he described a large Midwestern pension plan whose equity results over fourteen years never ranked above the 27th percentile or below the 47th in any year, yet ranked in the 4th percentile for the whole period. The lesson: consistency without disasters compounds into top results (S003). He retold the example in 2023 (S016).

## 2. bubble.com (January 2000)
His January 2000 memo argued that tech, internet, and telecom stocks were in a speculative mania. Looking back, he notes the S&P 500 fell about 46 percent into 2002 and the Nasdaq about 80 percent (S015). He marked the memo's 25th anniversary in a January 2025 memo on bubble watching (S022).

## 3. Turning defensive before 2008
From late 2004 to mid-2007 his memos flagged low expected returns, thin risk premiums, and deals done on poor terms, and Oaktree sold assets and raised its standards. He says this call rested on reading market behavior, not on special knowledge of subprime, where Oaktree had little exposure (S015). His February 2007 memo listed loosening practices such as dividend recaps, weak covenants, and buyers who never visited the data room (S008).

## 4. Buying through the panic (late 2008)
In October 2008 he wrote that the preceding weeks were the worst panic he had seen, driven by margin calls and forced selling rather than by changes in fundamentals, and that skepticism should now be applied to the pessimism (S005). He later wrote that Oaktree assumed the financial system would survive and invested about 7.5 billion dollars, about 6 billion of it in one quarter (S015).

## 5. The client that would not commit (2014)
He described a sovereign wealth fund client that over fifteen years allocated only a few tenths of a percent of its assets to Oaktree, as an example of how fear of headline risk keeps institutions from acting on conviction (S004).

## 6. March 2020
On March 3, 2020 he wrote that nobody knew how the virus or the economy would develop, and suggested deciding in advance how much to have invested by the eventual bottom, buying part now and keeping the rest (S018). Two weeks later he noted credit spreads had widened and Oaktree was preparing a new distressed debt fund (S019). A year on he observed that the window closed within roughly a month and few investors caught both turns (S020).

## 7. Sea Change (2022 and 2023)
In December 2022 he argued that the period of ultra-low rates from 2009 to 2021 had ended, and that credit could now deliver returns close to equities from contractual cash flows (S012). In October 2023 he added that few readers accepted the full conclusion, and that his remark to a non-profit committee about selling most assets for high yield bonds was meant to start a discussion, not as advice (S013).

## 8. Five calls in fifty years (2023)
In Taking the Temperature he counted only five market calls he considers clearly right in about fifty years: 2000, the 2004 to 2007 run-up, late 2008, early 2012, and March 2020, all at extremes (S015).

## 9. Founding Oaktree
Oaktree was founded in April 1995 by Marks, Bruce Karsh, and colleagues who had worked together at TCW; it listed on the NYSE in 2012, and Brookfield agreed in March 2019 to acquire 62 percent of it (S028, S029).
