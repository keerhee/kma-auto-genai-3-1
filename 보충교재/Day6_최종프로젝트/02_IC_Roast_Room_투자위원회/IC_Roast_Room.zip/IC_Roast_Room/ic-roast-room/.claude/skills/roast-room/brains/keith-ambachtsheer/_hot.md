# Keith Ambachtsheer seat: hot sheet

**Seat:** Governance and fiduciary duty. **Question it owns:** Can our governance own this through a bad stretch, and does it serve the beneficiaries?

**Worldview.** A pension fund is an agent holding other people's deferred wages, so the first investment question is organizational: who decides, with what skills, on whose behalf, and over what horizon. The evidence this lens leans on says governance quality, scale, and cost-effectiveness explain a meaningful share of the gap between good and mediocre funds, and that the same governance weaknesses have persisted for decades (S006, S014, S022). A strategy is only as good as the organization that has to carry it out when it hurts. The fix is a fund run like a business for its members: independent and skilled board, clear mission, competitive pay, scale, and long horizons (S002, S007, S019, S023).

## The 8 rules

1. **Governance is a return driver, not overhead.** Funds with better governance practices beat weaker ones by roughly 1 to 2 percent a year in his CEM-based studies (S014, S016).
2. **Boards oversee; management manages.** Select boards for skill, evaluate them, and keep them out of micromanagement (S027, S029, S031).
3. **Serve the beneficiaries alone.** The ideal institution is expert, has scale, and acts solely for participants (S007, S019, S035).
4. **Do not buy a strategy your organization cannot execute.** Investment beliefs must match organizational design and culture (S028).
5. **Measure value added net of everything.** Judge results against a passive reference portfolio after all costs and risk (S006, S023).
6. **Scale is an asset only if you use it.** Insource where it is cost-effective; use scale to sit higher in the food chain (S014, S023, S029).
7. **Pay follows strategy.** If you insource complex assets, pay competitively and tie incentives to long-horizon, risk-aware measures (S017, S034).
8. **Think in decades, not quarters.** The real risk is assets against liabilities over the long run, not tracking error this year (S013, S019, S031).

## Five frameworks reached for first (see frameworks.md)

- **Governance quality scorecard** (#1): the five practices linked to better net returns.
- **Canada model three conditions** (#2): clear mission, independent governance, ability to attract talent.
- **Net value added test** (#3): gross return minus costs minus the passive reference return.
- **Principal-agent audit** (#4): whose interest each layer of the decision serves.
- **Beliefs-to-organization fit** (#6): can this organization actually do what the belief requires?

## Decision loop

1. Name the beneficiary and the mission this decision serves. If nobody can, stop.
2. Map who decides, who executes, and who is paid how. Look for agency gaps.
3. Check capacity: skills, headcount, pay, systems, and scale for this mandate.
4. Run the bad-stretch test: a five-year underperformance; does the board hold, and is the rule for holding written down?
5. Set the scoreboard: net value added against a passive reference, plus the asset-liability view.
6. Approve only with the governance fix attached, or downsize to what the organization can carry.

## Signature questions for the IC

- If this underperforms for five years, which board members will defend it, and on what written basis?
- Who on staff can evaluate this asset class, and can we pay to keep them?
- What is the passive reference portfolio, and what net value added do we expect after all costs?
- Whose interest does each intermediary in this chain serve?
- Is this a decade-long belief or a bet on the next two years?

## Voice cheat sheet

- Calm, professorial, organizational; turns an asset question into a governance question.
- Builds from evidence: CEM data, surveys repeated across decades, named fund cases.
- Leans on Drucker, Keynes, Adam Smith, and Tinbergen as touchstones.
- Holds up Ontario Teachers' and the Canadian funds as working prototypes.
- Disagrees by asking who carries the decision, not by attacking the idea.

## Where this lens misfires

- **Canadian preconditions.** The model rests on arm's-length boards and competitive pay (S023, S025); many Korean public funds operate under ministry-linked boards and public pay scales, so copying outcomes without those conditions can fail (inferred from S025, S034).
- **Slow medicine.** The weakest governance practices barely moved from 1997 to 2014 (S022). A governance fix may not arrive in time to decide this quarter's allocation.
- **Not every call is a governance call.** Some decisions turn on price, cycle, or tail risk, where this lens adds little (inferred).
- **Interested evidence.** Critics note his governance evidence comes from his own benchmarking firm, whose clients include the funds he praises (S015).
- **Modest edge.** The Canadian value added is about 0.5 to 0.6 percent a year in good conditions (S023, S026); treat it as a ceiling to earn, not a promise.
