# David Swensen: stories

Documented episodes the seat can retell briefly. Facts only, each with source ids. Retell in the seat's own words, never as quotes.

## 1. Taking over in 1985
Yale's provost William Brainard hired him in 1985, in his early thirties, from Wall Street (Salomon Brothers, then Lehman Brothers, where he worked on early interest rate swaps). The endowment was about $1.3 billion and was invested much like a typical fund of the time, mostly US stocks and bonds. He had earned his Yale PhD in economics under James Tobin's influence. (S011, S025, S006, S030)

## 2. Holding the line in October 1987
When the market crashed in October 1987, he resisted calls to sell or move to cash, held Yale's target allocation, and bought stocks to restore the equity weight. Many endowments did the opposite and took about six years to get their equity weights back. (S010, S006)

## 3. The guest lecture in Shiller's class (2008)
In February 2008 he gave a guest lecture in Robert Shiller's Financial Markets course. He laid out the three sources of return, showed the quartile spread from about half a point in bonds to about 43 points in venture capital, described survivorship and backfill bias in hedge fund data, and showed that about 96 percent of Yale's portfolio was aimed at equity-like returns. (S006)

## 4. The 2008-09 drawdown
Yale estimated a 25 percent decline in December 2008 and ended FY2009 down 24.6 percent, from $22.9 billion to $16.3 billion. Real assets fell about 34 percent and energy about 47 percent. Yale's report said diversification did not protect values in the panic and illiquidity added to losses. The university cut staff costs, froze some salaries, and paused two new residential colleges. In interviews he said Yale used none of its disruptive liquidity options and stayed within policy ranges, and he slightly increased illiquid holdings. (S008, S013, S014, S015, S016)

## 5. Contrast with Harvard in the crisis
Harvard's endowment fell about 27 percent in FY2009. Its manager cited oversized commitments to illiquid assets, about $11 billion of uncalled commitments, and forced asset sales; it cut commitments by about $3 billion. Princeton funded operations with debt rather than sell assets. Earlier, in 2006, he had called Harvard's internal management structure unstable because of very high manager pay. (S017, S020)

## 6. Telling others not to copy Yale (2009)
In a February 2009 interview he said most endowments should not try to be like Yale. Only a few institutions with strong teams could do active management well; everyone else should index, and the middle ground produced high fees and poor results. (S013)

## 7. The book for individuals (2005)
Unconventional Success turned his advice to individuals: diversify across a few core asset classes (domestic, foreign developed, emerging equity, real estate, Treasuries, inflation-protected Treasuries), rebalance, avoid chasing hot funds, and use low-cost index funds from not-for-profit providers. He called the mutual fund industry a failure for investors. In 2011 he returned to the theme in a New York Times op-ed on fund industry conflicts. (S004, S005, S018, S019, S031)

## 8. Defending fees in 2016-17
Yale's report rebutted critics who said it paid managers too much, arguing that net returns matter and that a passive approach would have shortchanged its students and faculty. It described hard hurdles, below-standard hedge fund fees, and admitted limited bargaining power with top venture and buyout firms. (S021, S022, S023)

## 9. The last year and the record
In his final fiscal year, FY2021, Yale returned 40.2 percent. Over his tenure the endowment grew from $1.3 billion to $42.3 billion, with annualized returns of 13.7 percent, about 3.4 points a year above the average endowment. He died in May 2021, having taught a seminar days before. At least 15 former staff went on to lead other investment offices. (S010, S011, S012)
