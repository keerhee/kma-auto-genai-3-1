# Nassim Nicholas Taleb: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional decision with it, and sources. Lines marked "inferred from" translate his idea into a pension, sovereign, or endowment decision; they are this brain's reading, not his stated view.

## 1. The Fourth Quadrant map
- **What:** A 2 by 2 that crosses the type of randomness (Mediocristan, where no single observation dominates, versus Extremistan, where one event can dominate the total) with the type of payoff (simple true or false versus complex, where size matters). Statistics is reliable in three quadrants and dangerous in the fourth: complex payoffs under fat tails.
- **Parts:** classify the variable (thin or fat tailed); classify the exposure (binary or open-ended); if both are dangerous, stop relying on point estimates and apply robustness rules: avoid optimization, keep redundancy, distrust past stress tests, prefer long observation windows.
- **When:** any proposal whose risk case rests on a model: VaR budgets, optimizer outputs, private credit loss rates, leverage targets.
- **Score:** If the decision sits in the fourth quadrant and the paper relies on a volatility or VaR figure, score the risk case as unproven regardless of the number (inferred from S014, S015).
- **Sources:** S014, S015, S002, S021.

## 2. Ruin and ergodicity
- **What:** The average outcome across many funds is not the outcome a single fund experiences through time. If any path contains an absorbing loss, the long-run expected return is irrelevant to that fund.
- **Parts:** identify absorbing barriers (forced sale, covenant breach, regulatory capital floor, political loss of mandate); repeat the exposure over many years; ask whether the probability of hitting the barrier compounds toward certainty.
- **When:** leverage, concentrated bets, short-volatility programs, liquidity budgets.
- **Score:** Any option with a non-trivial cumulative path to forced selling over the fund's horizon is marked RUIN RISK, even if its single-year probability looks small (inferred from S020, S008).
- **Sources:** S020, S005, S008.

## 3. Fragility detection heuristic
- **What:** Fragility is harm that grows faster than the size of the shock. You can detect it without knowing probabilities by perturbing the input and checking whether the loss accelerates.
- **Parts:** pick the key stress variable; shock it by X and by 2X; compare losses; if the second is more than twice the first, the exposure is concave (fragile).
- **When:** stress testing leverage, FX hedge collateral, illiquid pacing, liability matching.
- **Score:** Ask staff for the two-shock comparison. Accelerating losses score fragile; linear scores robust; gains that grow with the shock score antifragile (inferred from S016, S004).
- **Sources:** S016, S004.

## 4. Barbell
- **What:** Hold a very safe majority and a small, highly convex minority, avoiding the middle where risk looks moderate but tails are hidden. In The Black Swan he describes keeping most wealth in the safest instruments and a small share in speculative, open-upside bets.
- **Parts:** define the safe leg strictly; cap the risky leg so its total loss is survivable; make sure the risky leg has open upside, not capped upside with open downside.
- **When:** structuring opportunistic sleeves, venture or innovation buckets, crisis reserves.
- **Score:** Check that the worst case of the risky leg is fully absorbed by the safe leg without selling. A sleeve labelled medium risk with fat-tailed exposure fails (inferred from S002, S004).
- **Sources:** S002, S004.

## 5. Via negativa
- **What:** Improve by removing: cut the source of fragility before adding a hedge or a new product.
- **Parts:** list exposures that can cause forced selling; remove or cap them first; add instruments only afterward.
- **When:** any proposal that adds complexity to fix a risk created by complexity.
- **Score:** A plan that hedges leverage with more derivatives scores worse than one that simply lowers leverage (inferred from S004, S013).
- **Sources:** S004, S013, S010.

## 6. Bleed versus blowup
- **What:** Strategies split into those that lose small amounts often and win big rarely (long the tail) and those that earn steadily and lose big rarely (short the tail). People prefer the second because its pain is deferred.
- **Parts:** identify the payoff shape; look at the track record length relative to tail frequency; ask who is on the other side.
- **When:** selling volatility, carry trades, credit spread strategies, smooth-return hedge funds, appraisal-based private assets.
- **Score:** Steady returns with few down months are a warning, not a merit, until the payoff is shown not to be short the tail (inferred from S023, S025, S014).
- **Sources:** S023, S025, S024.

## 7. Skin in the game
- **What:** Those who take risks should bear their downside. Asymmetric compensation, where agents keep upside fees and pass tail losses to others, systematically produces hidden tail exposure.
- **Parts:** map who earns in normal years; map who pays in the tail; check clawbacks and co-investment.
- **When:** manager selection, fee terms, internal staff incentives.
- **Score:** A manager paid on annual performance with no clawback in a short-tail strategy scores poorly on tail alignment (inferred from S017, S005, S010).
- **Sources:** S005, S017, S010, S013.

## 8. Silent evidence and survivorship
- **What:** The visible winners are a biased sample; the dead managers and failed strategies are missing from the data.
- **Parts:** ask what population the track record was drawn from; estimate how many similar strategies vanished; discount accordingly.
- **When:** manager due diligence, peer comparisons, backtests.
- **Score:** Treat a top-quartile track record as weak evidence unless the selection process is known (inferred from S001, S002).
- **Sources:** S001, S002.

## 9. Preasymptotics: how much data you need
- **What:** Under fat tails, sample means converge very slowly, so a record that would be ample under a normal distribution can be far too short.
- **Parts:** estimate tail thickness; compare required sample size to available history; widen uncertainty accordingly.
- **When:** backtests, factor premia claims, private market loss histories with one or two cycles.
- **Score:** If the evidence period does not contain the type of event that would dominate outcomes, score evidence quality low (inferred from S018, S006).
- **Sources:** S018, S006.

## 10. Precaution for systemic, fat-tailed harm
- **What:** Precaution is warranted when harm is both fat-tailed and systemic, not for every uncertainty. Local, bounded risks should be taken through trial and error.
- **Parts:** is the harm local or does it spread; is it bounded or fat-tailed; if both systemic and fat-tailed, require proof of safety from the proposer.
- **When:** decisions whose failure would threaten the whole fund or its mandate, versus decisions whose failure is a contained line item.
- **Score:** Contained, capped bets pass even if risky; whole-fund exposures with unknown tails need the burden of proof reversed (inferred from S008, S010).
- **Sources:** S008, S010.

## 11. Binary forecast versus payoff
- **What:** Being right about whether something happens differs from being right about the payoff. Forecast hit rates say little under fat tails, where one miss can dominate.
- **Parts:** separate the probability claim from the loss size; judge exposure by payoff.
- **When:** macro views, recession calls, manager pitches citing hit rates.
- **Score:** Discount any case built on a high hit rate if misses carry open-ended losses (inferred from S019).
- **Sources:** S019, S014.
