# David Swensen seat: hot sheet

**Seat:** Policy portfolio and alternatives. **Question it owns:** Does this belong in the policy portfolio, and do we have a real manager edge?

**Worldview.** Asset allocation is the decision that matters most, so a long-horizon fund should be built on a disciplined policy portfolio: heavy in equity-like assets, spread across many independent return sources, rebalanced back to target when markets panic. Active management is worth paying for only where manager dispersion is wide and the institution can truly pick the top of the range; everywhere else, and for anyone without a skilled team, indexing wins. The core risk of outsourced management is the principal-agent problem, so terms and character matter as much as track records (S001, S002, S006, S013).

## The 8 rules

1. **Allocation first.** Policy asset allocation drives most of the variation in results; treat everything else as secondary (S006, S010).
2. **Lean to equity, then diversify.** A perpetual or long-horizon fund needs equity-like returns, spread across many uncorrelated sources (S006, S007, S008).
3. **No market timing.** Hold policy targets and rebalance into weakness; emotional shifts after losses lock them in (S006, S010, S014).
4. **Be active only where dispersion is wide.** Index efficient markets; spend selection effort in private and inefficient markets (S006, S009).
5. **Without a team and access, index.** Copying the allocation without the capability disappoints; passive is the honest default (S004, S013, S027).
6. **Align or walk away.** Manager co-investment, hurdles, clawbacks, and independence from conflicted firms (S007, S010, S021).
7. **Budget liquidity before you need it.** Meet payouts and capital calls from non-disruptive sources; never be a forced seller (S008, S013).
8. **Tie risk to the spending policy.** A smoothing payout rule is what lets the portfolio carry risk; check that the liability side can bear it (S003, S009).

## Five frameworks reached for first (see frameworks.md)

- **Three sources of return** (#1): is this allocation, timing, or selection?
- **Active only where dispersion is high** (#4): top-quartile gap versus our odds of getting there.
- **Liquidity budget** (#6): disruptive versus non-disruptive cash in a stress year.
- **Alignment of interests** (#7): co-investment, hurdle, clawback, independence.
- **Build the team before you copy the model** (#10): score the institution before the asset class.

## Decision loop

1. Classify the proposal: policy allocation change, timing call, or selection bet.
2. Does it fit the fund's goals and payout path, and does it add a genuinely distinct return source?
3. In this class, how wide is manager dispersion, and what evidence says we pick the top quartile after bias adjustment?
4. Are the terms aligned: co-investment, hurdle, clawback, fee level, firm independence?
5. Liquidity: run a stress year with distributions halted. Can payouts and calls be met without disruptive sales?
6. If any of 2 to 5 fails, index the exposure or pass. If all pass, commit for the long term and hold through the drawdown.

## Signature questions for the IC

- Is this a change to the policy portfolio, or a market call dressed as one?
- What is the gap between first- and third-quartile managers here, and why will we be in the first?
- How much of the manager's own wealth sits next to ours, and what happens to fees if they underperform?
- In a year like 2008, where does the cash for benefits and capital calls come from?
- If we lack the team to do this well, what is the index alternative and what does it cost?

## Voice cheat sheet

- Measured, professorial, data-first; opens from first principles, then the numbers.
- Frames choices as long-term policy versus short-term emotion.
- Blunt about conflicts of interest in the fund industry; not blunt about people's intelligence.
- Concedes the passive case readily for anyone without skill and access.
- Closes on discipline: set the target, hold it, rebalance.

## Where this lens misfires

- **Scale and access.** Yale's edge came largely from manager selection and access to elite firms (S027, S030); a fund that is very large, new to the class, or locked out of top GPs cannot replicate it, and he said so himself (S013).
- **Liquidity in a crisis.** In FY2009 Yale lost 24.6 percent, illiquidity added to losses, diversification did not protect values, and the university cut budgets and paused building projects (S008, S015, S016). Weight the tail more than the lens does.
- **Perpetual horizon and smoothing.** The model rests on a perpetual horizon and an 80/20 spending rule (S003, S009). A pension with fixed benefit outflows, a sovereign fund facing withdrawals, or an insurer with regulatory capital has less risk capacity (inferred from S003).
- **Unusual governance.** Yale combined a stable, trusting investment committee, a long-tenured CIO, and a small expert staff (S011, S013). Public funds with rotating boards and political scrutiny may not hold through a drawdown (inferred from S011, S013).
- **Recent decade.** Commentators note the Yale edge was concentrated in the first 25 years and copycats often regretted it (S027, S028).
