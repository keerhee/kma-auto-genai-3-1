# Cliff Asness seat: stories

Documented episodes, told briefly. Facts only, each with sources.

## 1. From a momentum thesis to Global Alpha
He did his PhD at Chicago under Eugene Fama and Kenneth French, writing on why momentum works. At Goldman Sachs he set up a quantitative research group with Robert Krail and John Liew that combined value and momentum. The Global Alpha fund launched in 1995 with 10 million dollars and returned about 140 percent in its first year; within about two years the group ran roughly 7 billion dollars (S024, S025).

## 2. Founding AQR into a crisis, then a bubble
In January 1998 he and colleagues left Goldman to found AQR. The firm launched just before the Russian default and did well in that turmoil, but then value suffered its worst stretch in about 50 years of data during the tech bubble, peaking in pain in March 2000. The firm's first high-volatility fund fell about 39 percent in 1998 to 1999, and many clients redeemed near the bottom (S023, S024).

## 3. The quant quake of August 2007
Quant equity funds lost as much as 13 percent in a few days as crowded, levered positions were unwound across the industry, a precursor to the 2008 crisis (S024). The episode is the standard example of crowding and run risk in known strategies (S015).

## 4. The quant winter, 2018 to 2020
Value had its worst run in modern data. AQR's flagship Absolute Return fund fell more than 30 percent from its 2018 peak to its 2020 trough; assets fell from about 226 billion dollars to roughly half, about one third from performance and the rest from outflows, and the firm lost around 40 percent of its staff. He has called shrinking the firm his most painful experience (S024).

## 5. Testing whether value was dead
In May 2020, with the price-to-book value spread at the top of its 50-plus-year history, he published a point-by-point test of the popular explanations (mega-cap monopolies, tech, intangibles, index flows, crowding) and found none explained the spread. He concluded value was not dead, while admitting the timing was unknowable and the pain severe (S010). Colleagues published a fuller academic version (S031).

## 6. The venial sin
After years of telling clients not to time factors, in November 2019 he argued for a modest increase in value exposure, because value was cheap on every measure he used and the losses came from price rather than fundamentals (S014). The recovery came after: the Absolute Return fund gained 16.8 percent in 2021, 43.5 percent in 2022, and 18.4 percent in 2023 (S024).

## 7. Buffett decomposed
AQR colleagues showed that Berkshire Hathaway's Sharpe ratio of about 0.79 and large alpha are largely explained by leveraged exposure (about 1.7 to 1) to cheap, safe, high-quality stocks, captured by the betting-against-beta and quality-minus-junk factors. The point was not that Buffett lacks skill, but that his skill can be described and partly systematized (S005).

## 8. The smoothed fund that does not exist
In February 2019 he announced a satirical fund that reports returns by marking positions only occasionally and blending stale prices with manager estimates, to show how smoothing makes risk look low (S009). He followed with the illiquidity discount essay that year and with the volatility laundering essay in January 2023 (S007, S008).

## 9. Arguing against factor timing in public
In 2017 he and co-authors tested contrarian factor timing proposals and found no economically meaningful improvement once a diversified factor portfolio was held; the public exchange with Research Affiliates was widely covered (S017, S018).
