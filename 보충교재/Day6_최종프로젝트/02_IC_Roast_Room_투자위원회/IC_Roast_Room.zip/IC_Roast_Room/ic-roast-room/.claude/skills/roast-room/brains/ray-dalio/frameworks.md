# Ray Dalio: frameworks

Each entry: what it is, the parts, when to use it, how to score an institutional investment committee decision with it, and sources. This edition holds paraphrases only. Lines marked "inferred from" translate his idea into a pension, sovereign fund, or insurer decision; they are this brain's reading, not his stated view.

## 1. The four economic environments (growth and inflation quadrants)
- **What:** Asset prices move mainly on surprises in two drivers, growth and inflation. That gives four environments: growth above or below what is priced in, inflation above or below what is priced in. Every asset is a bundle of exposures to these surprises.
- **Parts:** rising growth; falling growth; rising inflation; falling inflation; for each, which assets tend to do well; the market's current discounting as the baseline.
- **When:** any new asset class, mandate, or allocation change; any proposal justified by a single macro view.
- **Score:** Map the proposal into the four boxes. Ask which box it pays in and which box hurts it. A proposal that adds more risk to a box the fund already overweights scores low on diversification, however good its stand-alone return (inferred from S005, S008, S013).
- **Sources:** S005, S008, S013, S007.

## 2. Risk parity and the All Weather balance
- **What:** Balance risk, not capital. Put roughly equal risk in each of the four environments so no single scenario dominates the outcome. Use modest leverage on lower-risk assets such as bonds so their risk is comparable to equities, rather than letting equities carry most of the risk.
- **Parts:** risk contribution by asset and by environment; leverage to equalize risk; a target return or volatility; a passive, strategic mix that is not tied to any forecast.
- **When:** setting or reviewing the strategic asset allocation; diagnosing why the fund's results track the equity market almost one for one.
- **Score:** Compute the share of total fund risk coming from equity-like exposure. Bridgewater's research argues typical institutional portfolios are close to 95 percent driven by equity risk even when capital looks balanced (S006). A fund in that position should weight any proposal by how much it lowers that concentration (inferred from S006, S007).
- **Sources:** S005, S006, S007, S008, S033.

## 3. Separating beta from alpha (cash, beta, alpha)
- **What:** Any return breaks into three parts: the risk-free return, beta (the market's risk premium, cheap to get and reliable over long horizons), and alpha (manager skill, a zero-sum game before costs, so negative on average after fees). Build the beta mix first, then decide separately how much active risk to add.
- **Parts:** pick the risk-free benchmark (cash, or inflation-linked bonds for a real-return investor); choose betas; size alpha as a separate tracking-error budget; select alpha managers knowing the average one subtracts value.
- **When:** active versus passive debates, hedge fund allocations, fee negotiations, external manager reviews.
- **Score:** Ask the team to say what share of the target return comes from beta and what share from alpha. If the alpha share is large, ask what evidence makes this manager different from the average, which loses after costs (inferred from S006, S005).
- **Sources:** S005, S006.

## 4. The Holy Grail: many good uncorrelated return streams
- **What:** With 15 to 20 good return streams that are not correlated with each other, total risk can fall dramatically without lowering expected return. The number and independence of bets matter more than the quality of any one bet.
- **Parts:** count of independent streams; their average correlation; the return-to-risk of each slice; the combined return-to-risk.
- **When:** judging whether a new strategy, manager, or asset adds diversification or just repackages risks the fund already holds.
- **Score:** Bridgewater's illustration compares six sources with average correlation 0.25 to 77 sources with average correlation 0.04; the same per-slice quality gives a combined information ratio of about 0.6 versus 1.4 (S006). For an IC: estimate the proposal's correlation to the existing portfolio in stress periods, not just on average. A good return stream with high correlation adds little (inferred from S006, S032).
- **Sources:** S001, S006, S032.

## 5. The economic machine: transactions, productivity, and two debt cycles
- **What:** The economy is the sum of transactions. Three forces drive it: productivity growth over the long run, a short-term debt cycle of roughly a business cycle's length, and a long-term debt cycle that builds over decades until debt cannot be serviced and rate cuts stop working.
- **Parts:** spending equals income for someone else; credit lets spending exceed income today and must be repaid later; central banks steer the short cycle with rates; the long cycle ends in a deleveraging.
- **When:** sizing duration, credit, and equity risk; testing whether a return assumption quietly depends on continued credit growth.
- **Score:** Ask where the major economies sit in the short and long debt cycles and whether the proposal's returns assume further leveraging. If they do, mark it as a cycle bet, not a structural return (inferred from S004, S002).
- **Sources:** S004, S002, S009, S010.

## 6. Big debt crisis template and the four levers
- **What:** Debt crises follow a recurring arc from early growth, through a bubble, top, depression, and the deleveraging that ends it. Policymakers have four levers to cut debt burdens: austerity, defaults and restructuring, money printing, and transfers of wealth. The first two are deflationary, printing is inflationary, and a well-balanced mix gives a beautiful deleveraging in which debt-to-income falls while growth and asset prices recover. Crises in own-currency debt are usually deflationary and manageable; crises in foreign-currency debt are usually inflationary and come with currency collapse.
- **Parts:** stage of the arc; mix of levers being used; currency denomination of the debt; whether rates can still be cut.
- **When:** emerging market debt, sovereign exposure, private credit late in a cycle, currency policy for an overseas-heavy fund.
- **Score:** For any credit-heavy proposal, name the stage of the arc and which lever policymakers are most likely to pull. Printing hurts nominal creditors through inflation; defaults hurt them directly; ask which one the position survives (inferred from S002, S031, S009).
- **Sources:** S002, S009, S031.

## 7. The big cycle of world order and reserve currencies
- **What:** Over roughly five centuries, empires and their reserve currencies rise, peak, and decline. Dalio tracks eight measures of power (education, innovation and technology, competitiveness, economic output, share of world trade, military strength, financial center strength, reserve currency status) alongside the debt cycle and internal conflict.
- **Parts:** the eight measures; the long debt cycle; internal order (wealth gaps, political conflict); external order (great power rivalry).
- **When:** long-horizon policy questions: home bias, overseas allocation by country, FX hedge ratios, gold or real asset sleeves.
- **Score:** Ask whether the fund's long-run assumptions treat today's leading power and currency as permanent. A policy portfolio built only on the last 40 years of one country's data scores low on this lens (inferred from S003, S034).
- **Sources:** S003, S034, S010.

## 8. Paradigm shifts
- **What:** Markets run in paradigms of roughly a decade in which one set of conditions and beliefs dominates, then a shift turns the prior winners into losers. In 2019 he argued the era of falling rates and quantitative easing was ending, that bonds would offer poor real returns, and that the new era would bring deficits funded by money creation and currency weakness.
- **Parts:** the prevailing paradigm; what is being extrapolated; what would break it; which assets did best in the old paradigm and are now crowded.
- **When:** reviewing return assumptions, the bond allocation, and inflation protection.
- **Score:** Ask what the proposal's backtest assumes about rates and inflation, and whether that regime is likely to continue. If the evidence comes almost entirely from one paradigm, discount it (inferred from S011, S014).
- **Sources:** S011, S012, S014.

## 9. Pain plus reflection equals progress (the five-step process)
- **What:** Mistakes are the raw material of improvement when reflected on honestly. The process: set clear goals, identify the problems that block them, diagnose root causes, design a plan, and execute; repeat.
- **Parts:** goals; problems; diagnosis; design; doing; an honest record of what went wrong.
- **When:** post-mortems on a bad year, manager terminations, deciding whether to stay with a strategy after a drawdown.
- **Score:** Ask whether the committee has a written diagnosis of the last major loss and whether it changed a rule. A team that cannot name its own root cause scores low (inferred from S001, S015).
- **Sources:** S001, S015, S029.

## 10. Idea meritocracy and believability weighting
- **What:** Get the best answer by having capable people disagree openly, weighting views by each person's track record and reasoning, and resolving disagreement by an agreed process rather than by rank.
- **Parts:** radical transparency; thoughtful disagreement; believability (who has done this successfully several times and can explain why); a clear decision rule when people still disagree.
- **When:** IC process design, delegation from board to staff, consultant reliance.
- **Score:** Ask who in the room has actually run this strategy through a full cycle, and whether their view carries more weight than seniority. Also ask whether dissent is recorded (inferred from S001, S027).
- **Sources:** S001, S027, S015.

## 11. Thinking in systems and back-testing the rules
- **What:** Write investment decision rules down explicitly, express them as systems, and test them across many decades and countries, including periods outside your own experience. Bridgewater stress-tests All Weather back to 1925 (S006) and built a depression gauge years before 2008 (S016).
- **Parts:** explicit rule; historical test across regimes and countries; check of periods the investor has never lived through; continuous refinement.
- **When:** approving any rule-based program: rebalancing bands, risk overlays, factor programs, liability hedges.
- **Score:** Ask for the rule in writing and the test across at least one inflationary and one deflationary period, and outside the home market. Missing either is a flag (inferred from S006, S015, S016).
- **Sources:** S001, S006, S015, S016.
