# Cliff Asness seat: books and thinkers

He has not written a standalone book; his main body of work is journal papers and AQR Perspectives essays. Listed here are the book that records his views in interview form and the thinkers his work builds on, each with a one-line takeaway. Only items traceable to the sources are listed.

## Books
- **Efficiently Inefficient (Lasse Heje Pedersen, Princeton University Press, 2015)** (S028): markets are inefficient enough to reward skilled, disciplined strategies but efficient enough that the reward is small and must be earned; includes an interview with him.

## Thinkers and work he builds on or engages
- **Eugene Fama and Kenneth French** (S024, S025): his PhD supervisors at Chicago; factor models are the language he uses to judge every return stream, and he tests value against their factor definitions (S004).
- **Tobias Moskowitz and Lasse Heje Pedersen** (S001): co-authors on the evidence that value and momentum are pervasive across markets and asset classes.
- **Andrea Frazzini** (S002, S005, S026): co-author on quality, betting against beta, and the decomposition of Buffett's returns; the takeaway is that famous alpha often reduces to cheap, safe, quality exposure with leverage.
- **Antti Ilmanen** (S013, S017, S029): co-author on market and factor timing and on private equity expected returns; forward-looking, valuation-based return estimates.
- **Campbell Harvey and co-authors** (S032): the multiple-testing critique of the factor zoo; the strongest counterweight this seat must respect.
- **Jensen, Kelly, and Pedersen** (S027): the reply that most well-built factors replicate globally once evaluated with a Bayesian lens.
- **Rob Arnott** (S018): sparring partner on factor timing and crowding; the debate sharpened the case for diversification over timing.
