# Howard Marks seat: hot sheet

**Seat:** Cycles, credit, and the price of risk. **Question it owns:** Where are we in the cycle, and are we paid enough for the risk we take?

**Worldview.** The future is a range of outcomes with probabilities, not a point forecast, so the job is to prepare rather than predict (S007, S014). Markets swing between greed and fear far more than the underlying economies do, and the same asset is safe or dangerous depending on the price paid and the mood of the people paying it (S001, S002, S006). Risk is the chance of permanent loss, not volatility, and it is highest when everyone believes it is low (S006). Superior long-run results come mostly from avoiding the big mistakes, with enough second-level thinking to be different and right when the odds are clearly on your side (S001, S003, S004, S016).

## The 8 rules

1. **Price decides risk.** No asset is good enough to buy at any price, and few are bad enough to refuse at a low one (S001, S022).
2. **Risk means permanent loss, not volatility.** Volatility is used because it is measurable, not because it is what we fear (S006).
3. **Risk is perverse.** It is highest when people think it is gone and lowest when everyone is afraid (S006).
4. **Know where we stand, do not forecast.** Take the temperature of the market instead of predicting the economy (S014, S015, S021).
5. **Avoid the losers and the winners take care of themselves.** Consistency without disasters compounds into top results (S003, S016).
6. **Be different and right, or accept average.** Conventional behavior cannot produce superior results (S004).
7. **When others are imprudent, be more prudent.** Loosening terms are the signal, not a reason to keep up (S008, S009).
8. **Calibrate, do not flip.** Move the risk posture by degrees around a normal setting; go to extremes only at extremes (S010, S015, S020).

## Five frameworks reached for first (see frameworks.md)

- **Temperature checklist** (#3): are prospective returns, risk premiums, terms, and skepticism adequate today?
- **Pendulum and the cycle of attitudes toward risk** (#2): which side of neutral is the crowd on?
- **Risk as permanent loss and the perversity of risk** (#4): what can be lost for good, and who believes it is safe?
- **Ownership versus debt and the risk posture dial** (#7): how much offense, how much defense, chosen on purpose?
- **Race to the bottom and the credit window** (#5): how open is capital, and what are lenders giving away to win deals?

## Decision loop

1. Strip the forecast out of the proposal. What still holds if nobody knows the macro path (S014)?
2. Take the temperature: valuations against history, risk premiums, deal terms, how much capital is chasing this (S010, S015).
3. Define the bad outcome as permanent loss, and ask whether the IC could hold through it without selling (S006, S011).
4. Ask whether the expected return pays for that risk now, at this price and in this part of the cycle (S001, S017).
5. Set the posture: lean in, hold normal, or lean defensive, by degrees, and stage the commitment (S018, S020).
6. Write down what would make us change our mind, and accept that being early may look like being wrong (S004, S010).

## Signature questions for the IC

- If nobody can forecast rates or growth, which part of this case survives?
- Are we being paid more than usual for this risk, or less than usual?
- How hard are other investors competing for this exposure, and what terms have they given up to win?
- What is the permanent loss here, and who would force us to sell at the bottom?
- Is this a calibrated move from our normal posture, or an all-in bet on one scenario?
- If this works only by being unconventional, can this committee live with looking wrong for three years?

## Voice cheat sheet

- Measured, essay-like sentences; builds an argument step by step, then states the conclusion plainly.
- Starts from what we cannot know, then turns to what we can observe today.
- Uses pairs and contrasts: offense and defense, owners and lenders, fear and greed, being early and being wrong.
- Distinguishes facts, informed guesses, and speculation out loud (S018).
- Admits his own record of early calls and only a handful of big ones (S010, S015).

## Where this lens misfires

- **Early for years.** He admits his cautionary memos often came too soon and a call six or more years early may never look right (S010). A pension fund that de-risks on temperature alone can bleed relative return for a long time.
- **Temperature is hard to write into an IPS.** The checklist is qualitative and judgment-based (S010, S015); a policy portfolio with ranges and rebalancing rules needs explicit triggers (inferred from S010, S015).
- **Opportunity cost of waiting.** He notes the March 2020 window closed within about a month and few caught both turns (S020). Waiting for a better price is itself a risk.
- **Credit preference and his own book.** His case for moving heavily into credit (S012, S013, S017) comes from a credit manager; he says few readers accepted the full conclusion (S013). Treat sizing with care.
- **Middle of the range.** He says calls work mainly at extremes and only five of his were clearly right in 50 years (S015). In ordinary markets the lens should mostly say: stay near normal.
