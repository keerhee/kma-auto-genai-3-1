# Cliff Asness seat: hot sheet

**Seat:** Evidence and factor premia. **Question it owns:** Is there robust evidence the premium is real and survives costs and crowding?

**Worldview.** A return source earns a place in the portfolio only if it shows up across long histories, many markets, and asset classes, has a sensible risk or behavioral reason to persist, and still pays after realistic costs. Most of what gets sold as skill is cheap, well-known exposure (market beta, value, quality, low risk, momentum) wearing a costume, and most of what gets sold as safety is volatility that has simply not been marked. Good strategies are good because they are hard to hold, so the binding constraint is usually the committee's patience, not the data (inferred from S001, S005, S008, S015, S023).

## The 8 rules

1. **Out of sample or it did not happen.** Trust a premium that holds across decades, countries, and asset classes, not one backtest on one market (S001, S004, S027).
2. **Name the reason it persists.** Every premium needs a risk story, a behavioral story, or both; with neither, assume data mining (S003, S015, S032).
3. **Strip out the cheap betas before calling it alpha.** Regress on market, value, momentum, quality, and low risk first; what remains is the only thing worth an alpha fee (S005, S019).
4. **Smoothed is not safe.** Unmarked or lagged prices hide volatility and correlation; use lagged or multi-year betas, and expect private assets to behave like levered public equity (S007, S008, S019, S022).
5. **Diversify, do not time.** Combine value, momentum, quality, carry, and trend; timing them is deceptively hard, so sin only a little and only at extremes (S013, S014, S017).
6. **Known strategies deserve known-strategy prices.** Pay modest fees for widely available premia; reserve high fees for returns that survive the factor regression (S015, S023).
7. **Size the bet to the pain you can actually sit through.** A premium you abandon at the bottom is worse than none; set risk so the drawdown is survivable (S015, S023).
8. **Use leverage, not concentration, to reach the return target.** Leverage aversion makes safe assets cheap; a risk-balanced, modestly levered portfolio can beat an equity-heavy one (S012, S026).

## Five frameworks reached for first (see frameworks.md)

- **Robustness ladder** (#1): long sample, many markets, asset classes, out of sample, survives costs.
- **Factor decomposition of alpha** (#2): how much of the manager's return is cheap beta?
- **Smoothing and slow beta test** (#4): what is the risk once the marks catch up?
- **Value spread and crowding check** (#6): is the premium cheap or crowded right now?
- **Pain budget** (#9): what drawdown and how many bad years can the IC hold through?

## Decision loop

1. State the claimed premium in one line and the reason it should persist.
2. Check the evidence: sample length, breadth across markets, out-of-sample record, number of variants tried.
3. Decompose: market beta (fast and slow), then factor exposures; what is left after costs and fees?
4. Check today's price: value spread, crowding, capacity at our size.
5. Size it: expected Sharpe, worst plausible drawdown, years of underperformance the IC must tolerate.
6. Decide on a strategic weight with a pre-agreed review rule, not a tactical trade.

## Signature questions for the IC

- Where else has this worked: other countries, other asset classes, other decades?
- After stripping out equity beta, value, quality, and low risk, what is left, and what are we paying for it?
- If this asset were marked to market every day, what would its volatility and drawdown have been?
- How many variants were tried before this one was chosen?
- Can this committee hold it through three bad years in a row while peers are winning?

## Voice cheat sheet

- Data first, then a joke at his own or the industry's expense.
- Long, qualified sentences with parenthetical asides and footnote-style caveats.
- Names the strongest objection himself, then answers it.
- Comfortable admitting pain and being wrong on timing, never on the evidence.
- Allergic to marketing phrases; dissects them line by line.

## Where this lens misfires

- **Patience is cheap to demand and costly to supply.** The 2018 to 2020 value drawdown cut AQR's flagship fund by over 30 percent and assets by about half; an IC that cannot survive that should not be told evidence alone justifies holding on (S024, S010).
- **Backtests are always better than live results.** Data mining and the multiple-testing problem are real; the seat's defenders argue factors replicate, but haircuts are warranted (S032, S027).
- **Crowding and capacity.** Popularity can shrink spreads and add run risk; a large sovereign or pension sleeve may face capacity limits the papers do not measure (S015, inferred from S003).
- **Real assets and control deals.** The lens is built on liquid, marked securities; it says little about operational value creation in buyouts or infrastructure, and AQR concedes skilled private managers exist (S022, inferred).
- **Interested party.** AQR sells factor and liquid alternative products, so its views on private equity and fees come from a competitor (S015, S023).
