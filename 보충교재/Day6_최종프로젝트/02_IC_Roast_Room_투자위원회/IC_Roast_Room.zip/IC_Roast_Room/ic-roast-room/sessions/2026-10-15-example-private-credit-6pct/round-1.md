# Round 1: opening positions

## Marks

SEAT: MARKS (Cycles, credit, and the price of risk)
STANCE: Conditional yes
OPTION SCORES: A 4/10 · B 7/10 · C 4/10
PILLAR SCORE: 6/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B안을 고르되, 매 빈티지 약정 전에 spread와 covenant 조건을 점검하는 트리거를 붙여 3년에 걸쳐 4.5%까지만 늘립니다.

WHY:
1. 팀 논리는 금리가 높다는 예측 하나에 기대고 있습니다. 직접대출은 변동금리라 기준금리가 내려가면 all-in 수익률도 함께 내려갑니다. 남는 근거는 spread와 대출 조건뿐인데, 브리프에는 그 숫자가 없습니다. 예측을 걷어내면 A안은 근거가 약해집니다. (Macro forecast skepticism, S014)
2. 제 가정은 이렇습니다. 2023년 이후 자금이 빠르게 몰리면서 spread가 좁아졌고 covenant-lite가 늘었습니다. 자금이 몰릴 때 가장 높은 값을 부른 곳이 나중에 손실을 보는 경우가 많습니다. 연 1.5%p씩 2년 만에 집행하면 이 경쟁에 가장 비싸게 들어가게 됩니다. 이 해석이 신용 사이클에 대한 제 판단입니다. (Race to the bottom, S008; S023, S025)
3. 높아진 기준금리 덕분에 신용의 계약 수익이 정상으로 돌아왔다는 점은 인정합니다. 그래서 C안처럼 아예 움직이지 않는 것도 틀렸다고 봅니다. 극단에서만 크게 움직이고 평소에는 단계적으로 조정하는 것이 맞습니다. (Sea change, S012/S017; Calibration, S020)

THE RISK I SEE: A안으로 가면 대체투자가 18%, 미집행 약정이 4% 넘게 남아 IPS 비유동 상한 20%(assumed)를 위기 때 넘을 수 있습니다. 급여 지급이 연 3%에서 늘어나는 와중에 capital call이 몰리면, 제 값에 사서 제 값 아래로 파는 강제 매도로 이어집니다. 이것이 영구 손실 경로입니다. (Liquidity, S011)

WHAT WOULD CHANGE MY MIND: 신규 직접대출 spread가 SOFR+600bp 이상이고 maintenance covenant 비중이 과반으로 돌아오며 펀드레이징이 둔화되면 A안 쪽으로 속도를 올리겠습니다.

WHAT I'D DO THIS WEEK: 최근 4개 분기 신규 딜의 spread, 레버리지 배수, covenant 구조, PIK 비중을 운용사별로 받아 temperature 표를 만듭니다.

QUESTION FOR THE IC: 운용사들의 하이일드 대비 150bp 초과 실적 가운데, 2009~2021년 저금리 시기 말고 지금 조건에서 나온 것은 얼마나 됩니까?

## Swensen

SEAT: SWENSEN (Policy portfolio and alternatives)
STANCE: Conditional yes
OPTION SCORES: A 3/10 · B 7/10 · C 5/10
PILLAR SCORE: 6/10
CONFIDENCE: 3/5
RUIN RISK: none
DOOR: two-way

THE CALL: B안으로 가되, 빈티지마다 운용사 선별 성과와 유동성 스트레스 테스트를 통과해야 다음 약정을 여는 조건부 분할 확대를 권합니다.

WHY:
1. 먼저 분류부터 하겠습니다. 팀이 A안을 미는 근거는 지금 금리가 높아 진입 적기라는 것인데, 이건 정책 포트폴리오 변경이 아니라 시장 타이밍 판단입니다. 타이밍 판단은 반대가 기본값에서 출발해야 합니다 (Three sources of return, S006). 6%가 장기 정책 비중으로 옳다면 3년에 나눠 들어가도 그 논리는 약해지지 않습니다.
2. 유동성 예산이 A안을 견디지 못합니다. 비유동 대체 15%에 미집행 약정 4%를 더하면 이미 19%로, 상한 20%(assumed)에 붙어 있습니다. 주식이 30% 빠지고 분배가 멈춘다고 가정하면, A안에서는 대체 NAV가 약 36조 원, 총자산이 약 170조 원이 되어 미집행 약정을 빼고도 대체 비중이 21%를 넘습니다. 연 6조 원의 급여 지급까지 겹치면 disruptive 매도로 몰립니다 (Liquidity budget, S008). B안은 같은 시나리오에서 19% 안팎에 머뭅니다.
3. 운용사 선별 역량이 증명되지 않았습니다. 시니어 직접대출은 바이아웃보다 운용사 간 성과 분산이 좁습니다(제 가정은 상하위 사분위 차이 연 3%p 안팎). 하이일드 대비 순 150bp를 내려면 상위 사분위 운용사에 들어가야 하는데, 전담 6명으로 2년 안에 6조 원을 새로 약정하는 건 평균 운용사에 높은 보수를 내는 최악의 조합입니다 (Active only where dispersion is high, S006; Build the team before you copy the model, S013). 이 판단은 고정 급여가 나가는 연금 상황에 맞춰 제가 옮긴 해석입니다.

THE RISK I SEE: 신용 사이클이 꺾이는데 평활화된 평가가 손실을 가리고, 약정은 이미 묶여 있어 리밸런싱 여력이 사라지는 것입니다.

WHAT WOULD CHANGE MY MIND: 기존 3% 사모신용 운용사들의 순수익이 하이일드 대비 실제로 연 150bp 이상이고 대부분 상위 사분위였다는 생존편향 조정 실적, 그리고 운용사 공동투자, hurdle, clawback 조건을 확보했다는 증거.

WHAT I'D DO THIS WEEK: 분배가 2년간 멈춘다는 가정으로 약정 페이싱 모델을 돌려 A안과 B안의 비유동 비중 경로와 급여 지급 재원을 비교하겠습니다 (Commitment pacing model, S029).

QUESTION FOR THE IC: 2008년 같은 해가 오면 급여 6조 원과 capital call을 자산을 헐값에 팔지 않고 어디서 마련합니까?

## Taleb

SEAT: TALEB (Tail risk and liquidity)
STANCE: Conditional yes
OPTION SCORES: A 3/10 · B 6/10 · C 5/10
PILLAR SCORE: 6/10
CONFIDENCE: 3/5
RUIN RISK: possible
DOOR: one-way

THE CALL: B안을 택하되, 빈티지마다 약정 전에 유동성 스트레스 표를 통과해야 다음 약정을 할 수 있는 조건부 B안으로 간다.

WHY:
1. 분모 효과로 상한이 깨진다 (Ruin and ergodicity, S020). 주식이 35% 빠지면 총자산은 200조에서 약 165조로 줄어든다. 대체투자는 평가 시차 때문에 장부가가 그대로 남는다. A안에서는 대체투자가 18%이니 18/82.5로 약 21.8%가 되어 IPS 상한 20%를 넘는다. B안은 16.5/82.5로 정확히 20%, C안은 18.2%다. 상한 위반은 바로 유동자산을 바닥에서 파는 경로로 이어진다. 대체투자 15% 전액을 비유동으로 본 것은 내 가정이다.
2. 같은 달에 현금 수요가 몰린다 (Fourth Quadrant, S014). 미집행 약정이 이미 8조 원(4%)이다. A안은 매년 3조 원을 새로 약정해 이 부담을 키운다. 급여 지급은 연 6조 원이고 늘어나는 중이다. 해외자산 60%에 걸린 FX 헤지 정산까지 한 달에 겹치면 4조 원 버퍼로는 감당하지 못한다. 위기 때는 GP가 캐피털 콜을 앞당긴다.
3. 매끄러운 수익은 꼬리 매도 포지션이다 (Bleed versus blowup, S023). 직접대출의 낮은 변동성은 평가 방식에서 나온다. 손실 이력에 고금리 상태가 길게 이어진 사이클이 들어 있지 않다 (Preasymptotics, S018). 부채 쪽 거품이 더 위험하다 (S013). 금리가 높을 때가 적기라는 팀의 논리는 칠면조가 맞는 천 일째 아침과 같다.

THE RISK I SEE: 주가 급락, 원화 약세에 따른 헤지 정산, 캐피털 콜 가속, 급여 지급이 한 분기에 겹친다. 그때 비유동 상한을 지키려고 국내 채권과 주식을 최저점에서 판다.

WHAT WOULD CHANGE MY MIND: 주식 -35%, 원화 -20%, 캐피털 콜 2배를 동시에 넣은 12개월 현금 수지에서 버퍼를 깨지 않고 강제 매도가 0원이라는 표가 나오면 A안 점수를 올리겠다.

WHAT I'D DO THIS WEEK: 실무진에게 X와 2X 충격 비교표를 요청하겠다 (Fragility heuristic, S016). 주식 -20%와 -40%, 캐피털 콜 1배와 2배를 넣어 비유동 비중, 버퍼 잔액, 필요한 매도액을 본다. 2X 손실이 X의 두 배를 넘으면 그 안은 취약하다.

QUESTION FOR THE IC: 주식 35% 하락과 원화 급락이 같은 달에 오면, 급여와 캐피털 콜과 헤지 정산에 쓸 현금을 무엇을 팔아서 마련합니까?

## Asness

SEAT: ASNESS (Evidence and factor premia)
STANCE: Yes
OPTION SCORES: A 2/10 · B 5/10 · C 7/10
PILLAR SCORE: 7/10
CONFIDENCE: 4/5
RUIN RISK: none
DOOR: two-way

THE CALL: C안(3% 유지)을 택하되, 시가평가 기준 순초과수익 검증을 통과하면 B안으로 넘어가는 조건부 경로를 붙인다.

WHY:
1. 평활화된 평가는 안전하다는 뜻이 아닙니다 (Smoothing and slow beta test, S022). 직접대출의 보고 변동성 3~4%를 그대로 쓰면 위험예산을 통과합니다. 레버리지를 반영한 하이일드 대용치로 바꾸면 변동성은 8~10%(assumed), 지연 베타는 하이일드에 가깝게 나옵니다. 보고 수치로만 통과하는 배분은 탈락입니다.
2. 수수료를 내기 전에 먼저 분해해야 합니다 (Factor decomposition, S005; Known-premia fee test, S015). 하이일드 대비 총초과수익을 250~300bp(assumed), 총보수를 150bp 안팎(assumed)으로 잡으면 순초과는 100~150bp입니다. 성공 기준인 150bp에 겨우 닿거나 못 미칩니다. 나머지는 싼 신용 베타에 대체투자 보수를 내는 셈입니다. GFC에서 중견기업 대출이 하이일드보다 더 잃었다는 점을 기본 시나리오로 둡니다 (S022).
3. 팀은 지금이 적기라고 하지만 이것은 타이밍 베팅이고, 타이밍은 조금만 해야 합니다 (Sin a little, S013, S014). 금리가 높다는 사실은 이미 모두가 압니다. 자금이 몰린 상태라면 스프레드는 오히려 좁아지고 있을 수 있습니다 (Value spread and crowding check, S015). 2년 동안 6조 원을 약정하는 것은 조금이 아닙니다. (이해상충 고지: 이 석의 관점은 유동성 대안 상품을 파는 쪽에서 나옵니다.)

THE RISK I SEE: 다년 약세장이 오면 평가가 늦게 따라옵니다. 그 사이 PIK와 만기연장 때문에 부도율이 낮아 보이고, 실제 손실은 2~3년 뒤에 드러납니다. 그때 미집행 약정 4%에 더해 지급 3%가 겹치면 유동 자산을 팔아야 합니다.

WHAT WOULD CHANGE MY MIND: 기존 3% 북의 과거 손익을 하이일드 지수에 래그를 포함해 회귀했을 때, 보수 차감 후 잔차 알파가 연 150bp 이상이고 GFC 구간 손실이 하이일드 이하라면 B안으로 옮겨갑니다.

WHAT I'D DO THIS WEEK: 기존 사모신용 포트폴리오의 분기 수익률을 하이일드·레버리지론 지수의 당기와 1~4분기 래그에 회귀해 지연 베타와 순잔차를 산출합니다.

QUESTION FOR THE IC: 모든 보수를 낸 뒤 시가로 평가해도 하이일드 ETF 대비 150bp가 남는다는 증거가 있습니까, 아니면 우리가 사는 것이 평활화 자체입니까?

## Chair notes

**쟁점 1. 사모신용 초과수익은 실재하는가, 평활화된 신용 베타인가.** B 쪽(Swensen, Marks)은 상위 운용사 선별과 spread 점검을 조건으로 초과수익을 기대할 수 있다고 본다. C 쪽(Asness)은 보수 차감·시가 환산 후 하이일드 대비 순초과가 100~150bp로 성공 기준(150bp)에 못 미칠 수 있다고 본다. Swensen과 Marks는 Asness의 지연 베타 회귀를 어떤 조건으로 받아들일지 답해야 한다.

**쟁점 2. 4.5%(B안)도 스트레스에서 비유동 상한을 지키는가.** Taleb의 계산으로 B안은 주식 -35% 때 정확히 20%로 상한에 닿고, Swensen의 계산(-30%)으로는 19% 안팎이다. Taleb은 B안에서도 RUIN RISK possible을 표시했다. B안 지지 위원은 어떤 버퍼나 속도 조건이면 상한 여유가 생기는지 숫자로 답해야 한다.

**만장일치 점검.** 최고안이 B(3명)와 C(Asness)로 갈려 만장일치 조건에 해당하지 않는다. A안은 4명 모두 4점 이하로, 팀의 선호안이 지지를 얻지 못했다.

**형식.** 네 카드 모두 필드를 갖췄다. 대체투자 15% 전액을 비유동으로 본 것(Taleb)과 총보수 150bp(Asness)는 위원 가정이며 브리프 숫자가 아니다.
