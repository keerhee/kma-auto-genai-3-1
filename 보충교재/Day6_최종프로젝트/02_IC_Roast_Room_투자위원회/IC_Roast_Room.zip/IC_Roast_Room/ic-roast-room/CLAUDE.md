# IC Roast Room

This project is the IC Roast Room: an investment committee council of seven simulated investors (Swensen, Dalio, Marks, Bogle, Asness, Ambachtsheer, Taleb) that debates an institutional investor's decision: SAA changes, alternatives and private credit allocations, manager hires and fees, FX hedge ratios, factor tilts, tail hedges, rebalancing, leverage, and governance.

- When the user brings an IC decision ("should we...", "IC 안건", allocation, hedging, a manager, a program), run `/roast-room`. For a quick question to one advisor, use `/roast-room ask <seat> ...`.
- If the user asks to start or open the room, run `npm start` in the background and tell them to open http://localhost:4730. It needs Node 20 or newer and nothing else.
- Councils are saved in `sessions/<date>-<decision>/`. The room plays them live as those files land. Follow `.claude/skills/roast-room/references/live-room.md` exactly so the room can read them.
- The seats are simulations built from public work, paraphrased with source ids. The brains hold no verbatim quotes: never present any line as something the real person said.
- Answer in the user's language (Korean in, Korean out). Keep card field labels, fixed card values, verdict labels, seat headings, and JSON keys in English, because the room parses them.
- Write the Chair's parts in plain, short sentences, no hype, no filler. Keep the verdict in chat short enough to decide from at a glance; the full report goes in `verdict.md`, and the room's "PDF 내려받기" button turns it into a PDF with Korean fonts.
- Nothing the council says is investment advice.
