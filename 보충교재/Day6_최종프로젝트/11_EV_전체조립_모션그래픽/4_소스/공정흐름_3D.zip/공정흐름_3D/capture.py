import sys, os
from playwright.sync_api import sync_playwright
url, out, fps = sys.argv[1], sys.argv[2], 30
times = [float(x) for x in sys.argv[3].split(',')] if len(sys.argv) > 3 else None
os.makedirs(out, exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/Users/keerhee/Project/node_modules/.remotion/chrome-headless-shell/mac-arm64/chrome-headless-shell-mac-arm64/chrome-headless-shell", args=["--use-angle=metal","--enable-gpu","--ignore-gpu-blocklist"])
    pg = b.new_page(viewport={"width":1920,"height":1080})
    pg.on("console", lambda m: print("console:", m.text) if m.type in ("error","warning") else None)
    pg.add_init_script("window.__CAPTURE=true"); pg.goto(url); pg.wait_for_function("window.READY===true", timeout=60000)
    total = pg.evaluate("window.TOTAL"); print("TOTAL", total, flush=True)
    ts = times if times else [i/fps for i in range(int(total*fps))]
    for i, t in enumerate(ts):
        pg.evaluate(f"window.renderAt({t})")
        pg.screenshot(path=f"{out}/f{i:05d}.png")
        if i % 150 == 0: print(i, flush=True)
    b.close()
