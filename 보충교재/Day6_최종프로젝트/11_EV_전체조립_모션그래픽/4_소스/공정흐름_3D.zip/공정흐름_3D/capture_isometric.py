import sys, os
from playwright.sync_api import sync_playwright
url, out, fps, secs = sys.argv[1], sys.argv[2], 30, float(sys.argv[3])
only = [int(x) for x in sys.argv[4].split(',')] if len(sys.argv) > 4 else None
init = """(()=>{let now=0;const q=[];window.__adv=(ms)=>{now+=ms;const cbs=q.splice(0);cbs.forEach(cb=>cb(now));};
performance.now=()=>now;window.requestAnimationFrame=cb=>{q.push(cb);return q.length;};})();"""
css = ".controls{display:none!important} html,body{overflow:hidden}"
os.makedirs(out, exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/Users/keerhee/Project/node_modules/.remotion/chrome-headless-shell/mac-arm64/chrome-headless-shell-mac-arm64/chrome-headless-shell")
    pg = b.new_page(viewport={"width":1744,"height":981}, device_scale_factor=1920/1744)
    pg.add_init_script(init); pg.goto(url); pg.add_style_tag(content=css); pg.wait_for_timeout(300)
    print("h", pg.evaluate("document.documentElement.scrollHeight"), flush=True)
    n = int(secs*fps)
    for i in range(n):
        pg.evaluate(f"window.__adv({1000/fps})")
        if only is None or i in only: pg.screenshot(path=f"{out}/f{i:05d}.png")
    b.close()
