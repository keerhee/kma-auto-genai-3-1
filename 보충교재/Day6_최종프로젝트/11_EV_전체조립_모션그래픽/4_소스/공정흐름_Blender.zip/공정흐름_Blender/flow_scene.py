"""EV 조립 라인 공정 흐름 — Blender 5.x (EEVEE).
차체까지 든 EV_Crossover_Education.glb가 컨베이어를 따라 다섯 스테이션을 지나며 조립된다.
  ① 프레임  ② 배터리  ③ 구동계  ④ 차체 결합  ⑤ 검사·출하

사용:
  blender -b -P flow_scene.py -- preview            # 핵심 시점 스틸 → preview/
  blender -b -P flow_scene.py -- final [시작 끝]     # 1920x1080 PNG 시퀀스 → renders/
타임라인은 timeline.json으로 저장되어 자막 합성(comp_flow.py)이 같은 값을 쓴다.
"""
import bpy, sys, json, math, os
from mathutils import Vector

ARGS = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
MODE = ARGS[0] if ARGS else "preview"
RANGE = [int(a) for a in ARGS[1:] if a.isdigit()]
FPS = 24
GAP = 7.5                       # 스테이션 간격(m). 차는 -Y(앞) 방향으로 간다
SY = [2 * GAP, GAP, 0, -GAP, -2 * GAP]
STC = [(1.0, 0.71, 0.28), (0.25, 0.71, 1.0), (0.27, 0.82, 0.61), (1.0, 0.48, 0.30), (0.78, 0.57, 1.0)]

# ------------------------------------------------------------------ timeline (초)
PH = []
t = 0.0
def add(kind, st, dur):
    global t
    PH.append({"type": kind, "st": st, "t0": t, "dur": dur}); t += dur
add("enter", 0, 2.5); add("work", 0, 5.5)
for s in range(1, 5):
    add("move", s, 2.6); add("work", s, 6.5 if s == 3 else 5.5)
add("exit", 4, 3.2); add("end", 4, 3.0)
TOTAL = t
F = lambda sec: int(round(sec * FPS)) + 1
W = {p["st"]: p for p in PH if p["type"] == "work"}

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../3_3D모델/EV_Crossover_Education.glb"))
sc = bpy.context.scene

def key(o, path, f):
    o.keyframe_insert(path, frame=f)

def show_from(o, f):
    o.hide_render = True; o.keyframe_insert("hide_render", frame=1)
    o.hide_viewport = True; o.keyframe_insert("hide_viewport", frame=1)
    o.hide_render = False; o.keyframe_insert("hide_render", frame=f)
    o.hide_viewport = False; o.keyframe_insert("hide_viewport", frame=f)

def pbsdf(m):
    return next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")

def mat(name, col, metal=0.2, rough=0.5, emit=0.0):
    m = bpy.data.materials.new(name); b = pbsdf(m)
    b.inputs["Base Color"].default_value = (*col, 1); b.inputs["Metallic"].default_value = metal
    b.inputs["Roughness"].default_value = rough
    if emit:
        b.inputs["Emission Color"].default_value = (*col, 1); b.inputs["Emission Strength"].default_value = emit
    return m

def box(name, loc, size, m, parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.active_object; o.name = name; o.scale = size
    o.data.materials.append(m)
    if parent: o.parent = parent
    return o

# ------------------------------------------------------------------ car parts
parts = [o for o in bpy.data.objects if o.type == "MESH"]
look = {"#a9bacb": (0.85, 0.30), "#b9c8d8": (0.95, 0.18), "#34485e": (0.6, 0.35), "#232b35": (0.0, 0.65),
        "#168bd1": (0.35, 0.22), "#49bded": (0.2, 0.30), "#ff781f": (0.1, 0.35), "#22b68c": (0.4, 0.30),
        "#efbc42": (0.9, 0.25), "#176fa4": (0.5, 0.2), "#111c2b": (0.1, 0.4), "#e9fcff": (0.0, 0.05)}
for m in bpy.data.materials:
    if m.name in look and m.node_tree:
        b = pbsdf(m); b.inputs["Metallic"].default_value, b.inputs["Roughness"].default_value = look[m.name]

car = bpy.data.objects.new("Car", None); sc.collection.objects.link(car)
body_grp = bpy.data.objects.new("BodyGroup", None); sc.collection.objects.link(body_grp); body_grp.parent = car
LIFT = 0.30                                      # 팔레트 높이
for o in parts:
    if o.name.startswith("Body"):
        o.parent = body_grp
    else:
        o.parent = car
    o.location.z += LIFT

def grp(*pre):
    return [o for o in parts if o.name.startswith(pre)]
frame = [o for o in parts if not o.name.startswith(("Body", "Battery_Module", "HV", "Front", "Rear"))]
battery = grp("Battery_Module", "HV")
drive = grp("Front", "Rear")
body = grp("Body")

# 팔레트
pallet = box("Pallet", (0, 0, LIFT / 2), (2.6, 4.9, LIFT * 0.9), mat("Pallet", (0.22, 0.16, 0.10), 0.0, 0.7), car)

# ------------------------------------------------------------------ car path
def car_y(sec):
    for p in PH:
        if sec < p["t0"] + p["dur"]:
            f = (sec - p["t0"]) / p["dur"]
            e = f * f * (3 - 2 * f)
            if p["type"] == "enter": return SY[0] + 11 * (1 - e)
            if p["type"] == "move":  return SY[p["st"] - 1] - GAP * e
            if p["type"] == "exit":  return SY[4] - 12 * e
            if p["type"] == "end":   return SY[4] - 12
            return SY[p["st"]]
    return SY[4] - 12
for fr in range(1, F(TOTAL) + 1, 2):
    car.location = (0, car_y((fr - 1) / FPS), 0); key(car, "location", fr)

# ------------------------------------------------------------------ assembly per station
def fly(o, f0, dur_f, off):
    home = o.location.copy()
    show_from(o, f0)
    o.location = home + Vector(off); key(o, "location", f0)
    o.location = home; key(o, "location", f0 + dur_f)

def stagger(objs, st, offset_fn, span=0.72, each=0.22):
    w = W[st]; f0 = F(w["t0"] + 0.4); n = len(objs); total = (w["dur"] - 1.0) * FPS
    for i, o in enumerate(objs):
        a = f0 + int(total * span * i / max(1, n - 1)); fly(o, a, int(total * each), offset_fn(o, i))

stagger(sorted(frame, key=lambda o: (o.location.z, o.location.y)), 0,
        lambda o, i: (3.2 * (1 if o.location.x >= 0 else -1), 0, 1.0))
stagger(sorted(battery, key=lambda o: (-o.location.y, o.location.x)), 1, lambda o, i: (0, 0, 3.0))
stagger(sorted(drive, key=lambda o: (o.location.y, abs(o.location.x))), 2,
        lambda o, i: (3.0 * (1 if o.location.x >= 0 else -1), 0, -0.2), span=0.65, each=0.28)
# 차체: 한 덩어리로 위에서 내려온다
w = W[3]; b0, b1 = F(w["t0"] + 0.8), F(w["t0"] + w["dur"] * 0.8)
for o in body: show_from(o, b0)
body_grp.location = (0, 0, 3.6); key(body_grp, "location", b0)
body_grp.location = (0, 0, 0.0); key(body_grp, "location", b1)

# ------------------------------------------------------------------ stage set
world = bpy.data.worlds.new("W"); sc.world = world
bg = world.node_tree.nodes["Background"]; bg.inputs[0].default_value = (0.012, 0.02, 0.04, 1); bg.inputs[1].default_value = 0.6

floor_m = mat("Floor", (0.035, 0.05, 0.08), 0.35, 0.35)
bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 0, 0)); fl = bpy.context.active_object; fl.scale = (60, 90, 1); fl.data.materials.append(floor_m)
belt_m = mat("Belt", (0.10, 0.14, 0.22), 0.3, 0.45)
box("Belt", (0, 0, 0.06), (3.2, 5 * GAP + 30, 0.12), belt_m)
stripe_m = mat("Stripe", (0.45, 0.58, 0.85), 0.0, 0.4, 0.6)
for k in range(-30, 31):
    box(f"Stripe{k}", (1.75, k * 1.2, 0.125), (0.08, 0.6, 0.01), stripe_m); box(f"StripeL{k}", (-1.75, k * 1.2, 0.125), (0.08, 0.6, 0.01), stripe_m)

post_m = mat("Post", (0.18, 0.22, 0.30), 0.6, 0.35)
arm_m = mat("Arm", (1.0, 0.55, 0.15), 0.3, 0.35)
zones, arms = [], []
for i, y in enumerate(SY):
    zm = mat(f"Zone{i}", tuple(0.025 + 0.04 * c for c in STC[i]), 0.0, 0.6, 0.0)
    bpy.ops.mesh.primitive_plane_add(size=1, location=(0, y, 0.005)); z = bpy.context.active_object; z.scale = (7.0, 6.2, 1); z.data.materials.append(zm); zones.append(zm)
    # 뒤쪽 기둥 + 위 보 + 공정 색 램프 (앞쪽 기둥은 두지 않는다 — 차를 가린다)
    for dy in (-2.9, 2.9):
        box(f"Post{i}{dy}", (-3.3, y + dy, 2.2), (0.28, 0.28, 4.4), post_m)
    box(f"Beam{i}", (-3.3, y, 4.4), (0.34, 6.2, 0.34), post_m)
    box(f"Over{i}", (-1.2, y, 4.4), (4.2, 0.26, 0.26), post_m)
    lm = mat(f"Lamp{i}", STC[i], 0.0, 0.3, 3.0)
    box(f"Lamp{i}", (-3.1, y, 4.15), (0.14, 5.6, 0.12), lm)
    # 로봇 팔 두 개(뒤쪽)
    for dy in (-1.6, 1.6):
        base = bpy.data.objects.new(f"ArmBase{i}{dy}", None); sc.collection.objects.link(base); base.location = (-2.3, y + dy, 0)
        box(f"ArmFoot{i}{dy}", (0, 0, 0.25), (0.6, 0.6, 0.5), post_m, base)
        sh = bpy.data.objects.new(f"Shoulder{i}{dy}", None); sc.collection.objects.link(sh); sh.parent = base; sh.location = (0, 0, 0.5)
        box(f"Arm1{i}{dy}", (0, 0, 0.8), (0.22, 0.22, 1.6), arm_m, sh)
        el = bpy.data.objects.new(f"Elbow{i}{dy}", None); sc.collection.objects.link(el); el.parent = sh; el.location = (0, 0, 1.6)
        box(f"Arm2{i}{dy}", (0.6, 0, 0), (1.2, 0.18, 0.18), arm_m, el)
        arms.append((i, sh, el, base))

# 로봇 팔 · 존 · 램프 움직임
for i, sh, el, base in arms:
    w = W[i]; a, b = F(w["t0"]), F(w["t0"] + w["dur"])
    for fr in (1, a - 1):
        sh.rotation_euler = (0, 0.25, 0); el.rotation_euler = (0, 0.5, 0); key(sh, "rotation_euler", fr); key(el, "rotation_euler", fr)
    for j, fr in enumerate(range(a, b, 12)):
        ph = j * 0.9 + (0 if base.location.y > SY[i] else 1.5)
        sh.rotation_euler = (0, 0.55 + 0.3 * math.sin(ph), 0.4 * math.sin(ph * 0.7))
        el.rotation_euler = (0, 0.9 + 0.35 * math.cos(ph * 1.3), 0)
        key(sh, "rotation_euler", fr); key(el, "rotation_euler", fr)
    sh.rotation_euler = (0, 0.25, 0); el.rotation_euler = (0, 0.5, 0); key(sh, "rotation_euler", b + 6); key(el, "rotation_euler", b + 6)
for i, zm in enumerate(zones):
    w = W[i]; e = pbsdf(zm); s = e.inputs["Emission Strength"]; e.inputs["Emission Color"].default_value = (*STC[i], 1)
    for fr, v in ((1, 0.0), (F(w["t0"]) - 1, 0.0), (F(w["t0"]) + 6, 0.45), (F(w["t0"] + w["dur"]) - 6, 0.45), (F(w["t0"] + w["dur"]) + 6, 0.06)):
        s.default_value = v; s.keyframe_insert("default_value", frame=fr)

# 검사 스캐너 게이트
scan_m = mat("Scan", (0.78, 0.57, 1.0), 0.0, 0.3, 8.0)
gate = bpy.data.objects.new("Gate", None); sc.collection.objects.link(gate)
for nm, loc, size in (("GL", (-1.7, 0, 1.1), (0.08, 0.08, 2.2)), ("GR", (1.7, 0, 1.1), (0.08, 0.08, 2.2)), ("GT", (0, 0, 2.2), (3.48, 0.08, 0.08))):
    g = box(nm, loc, size, scan_m, gate); show_from(g, F(W[4]["t0"] + 0.5))
    g.hide_render = True; g.keyframe_insert("hide_render", frame=F(W[4]["t0"] + W[4]["dur"] - 0.4))
w = W[4]; gate.location = (0, SY[4] + 2.6, 0); key(gate, "location", F(w["t0"] + 0.5))
gate.location = (0, SY[4] - 2.6, 0); key(gate, "location", F(w["t0"] + w["dur"] / 2))
gate.location = (0, SY[4] + 2.6, 0); key(gate, "location", F(w["t0"] + w["dur"] - 0.5))

# 출하 트레일러
tr_m = mat("Trailer", (0.16, 0.20, 0.30), 0.4, 0.4)
box("Trailer", (0, SY[4] - 17, 1.9), (3.2, 9.0, 3.6), tr_m)

# ------------------------------------------------------------------ lights
sun_d = bpy.data.lights.new("Sun", "SUN"); sun_d.energy = 3.2; sun_d.angle = math.radians(3)
sun = bpy.data.objects.new("Sun", sun_d); sun.rotation_euler = (math.radians(50), math.radians(-25), math.radians(35)); sc.collection.objects.link(sun)
for nm, loc, en, col, size in (("Key", (8, 0, 9), 2500, (1, 0.96, 0.9), 14), ("Rim", (-8, 0, 5), 1400, (0.35, 0.7, 1.0), 12)):
    L = bpy.data.lights.new(nm, "AREA"); L.energy = en; L.color = col; L.size = size; L.shape = "RECTANGLE"; L.size_y = 50
    o = bpy.data.objects.new(nm, L); o.location = loc; sc.collection.objects.link(o)
    o.rotation_euler = (0, math.radians(40 if nm == "Key" else -50), 0)

# ------------------------------------------------------------------ camera: 차를 따라가고 작업 중엔 다가간다
cam = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera")); sc.collection.objects.link(cam)
cam.data.lens = 32; sc.camera = cam
tgt = bpy.data.objects.new("CamTarget", None); sc.collection.objects.link(tgt)
c = cam.constraints.new("TRACK_TO"); c.target = tgt; c.track_axis = "TRACK_NEGATIVE_Z"; c.up_axis = "UP_Y"
def zoom(sec):
    for p in PH:
        if sec < p["t0"] + p["dur"]:
            if p["type"] != "work": return 0.0
            f = (sec - p["t0"]) / p["dur"]
            up = min(1, f / 0.25); dn = min(1, (1 - f) / 0.15)
            return max(0, min(up, dn)) ** 1.5
    return 0.0
for fr in range(1, F(TOTAL) + 1, 2):
    sec = (fr - 1) / FPS; y = max(SY[4] - 6, min(SY[0] + 4, car_y(sec))); z = zoom(sec)
    d = 1.0 - 0.32 * z
    cam.location = (13.0 * d, y + 6.2 * d, 7.4 * d + 0.8); key(cam, "location", fr)
    tgt.location = (0, y - 0.4, 2.0 - 0.3 * z); key(tgt, "location", fr)

# ------------------------------------------------------------------ render settings
r = sc.render; r.fps = FPS
r.engine = "BLENDER_EEVEE" if "BLENDER_EEVEE" in [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items] else "BLENDER_EEVEE_NEXT"
ee = sc.eevee
for k, v in (("taa_render_samples", 32), ("use_shadows", True), ("use_raytracing", True), ("use_gtao", True)):
    if hasattr(ee, k): setattr(ee, k, v)
try:
    sc.view_settings.view_transform = "AgX"; sc.view_settings.look = "AgX - Medium High Contrast"; sc.view_settings.exposure = 0.2
except Exception:
    pass
r.image_settings.file_format = "PNG"
sc.frame_start, sc.frame_end = 1, F(TOTAL)

json.dump({"fps": FPS, "total": TOTAL, "frames": F(TOTAL), "phases": PH}, open("timeline.json", "w"), ensure_ascii=False, indent=1)

if MODE == "preview":
    r.resolution_x, r.resolution_y = 960, 540
    secs = [float(a) for a in ARGS[1:]] if len(ARGS) > 1 else [1.5, 6, 12, 16, 22, 30, 33, 40, 45]
    os.makedirs("preview", exist_ok=True)
    for s in secs:
        sc.frame_set(F(s)); r.filepath = os.path.abspath(f"preview/p_{int(s*10):04d}.png")
        bpy.ops.render.render(write_still=True)
else:
    r.resolution_x, r.resolution_y = 1920, 1080
    if len(RANGE) == 2: sc.frame_start, sc.frame_end = RANGE
    r.filepath = os.path.abspath("renders") + "/"
    r.use_overwrite = False; r.use_placeholder = True
    bpy.ops.render.render(animation=True)
