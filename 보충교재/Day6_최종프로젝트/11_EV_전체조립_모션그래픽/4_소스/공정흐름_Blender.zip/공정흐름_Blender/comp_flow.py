"""Blender 렌더(renders/####.png) 위에 공정 패널 · 탭 · 진행 막대 · 완성 카드를 얹는다 → comp/####.png
사용: python comp_flow.py   (timeline.json은 flow_scene.py가 만든다)"""
import json, os, glob
from PIL import Image, ImageDraw, ImageFont

FD = os.path.expanduser("~/Library/Fonts/")
f = lambda w, s: ImageFont.truetype(FD + f"Pretendard-{w}.otf", s)
F_BADGE, F_NAME, F_EN, F_DESC = f("ExtraBold", 44), f("ExtraBold", 40), f("SemiBold", 16), f("Regular", 23)
F_TAB, F_TABN, F_CNT, F_CNTB, F_FOOT = f("SemiBold", 21), f("Bold", 16), f("Regular", 18), f("ExtraBold", 38), f("Regular", 18)
F_END, F_ENDS = f("ExtraBold", 60), f("Regular", 26)
ST = [("프레임 투입", "FRAME", "사이드 레일 · 크로스멤버 · 배터리 트레이로 스케이트보드 뼈대를 세운다"),
      ("배터리 탑재", "BATTERY", "셀 모듈 18개를 트레이에 깔고 고전압 케이블을 잇는다"),
      ("구동계 장착", "DRIVETRAIN", "앞뒤 모터 · 인버터 · 감속기와 서스펜션 · 바퀴를 단다"),
      ("차체 결합", "BODY MARRIAGE", "도장을 마친 차체를 스케이트보드 위에 내려 하나로 결합한다"),
      ("검사 · 출하", "INSPECTION", "스캐너로 결합 상태를 확인하고 완성차를 출하한다")]
COL = [(255, 181, 71), (63, 182, 255), (69, 210, 156), (255, 122, 77), (199, 146, 255)]
PANEL, LINE, TEXT, MUTED = (12, 20, 36, 225), (34, 48, 75, 255), (234, 240, 250), (142, 162, 191)

tl = json.load(open("timeline.json")); FPS, TOTAL, PH = tl["fps"], tl["total"], tl["phases"]
clamp = lambda v, a=0, b=1: max(a, min(b, v))
def phase(t):
    for p in PH:
        if t < p["t0"] + p["dur"]: return p, (t - p["t0"]) / p["dur"]
    return PH[-1], 1.0
def span(i):
    ps = [p for p in PH if p["st"] == i]; return ps[0]["t0"], ps[-1]["t0"] + ps[-1]["dur"]

def draw(img, t):
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    p, fr = phase(t); s = p["st"]; c = COL[s]
    # 위 패널
    d.rounded_rectangle((48, 36, 1872, 162), 22, fill=PANEL, outline=LINE, width=1)
    d.rounded_rectangle((78, 57, 162, 141), 22, fill=c)
    d.text((120, 99), str(s + 1), font=F_BADGE, fill=(10, 17, 32), anchor="mm")
    d.text((190, 62), ST[s][0], font=F_NAME, fill=TEXT)
    nw = d.textlength(ST[s][0], font=F_NAME)
    d.text((190 + nw + 14, 82), ST[s][1], font=F_EN, fill=MUTED)
    d.text((190, 112), ST[s][2], font=F_DESC, fill=(200, 213, 234))
    done = 1 if t >= PH[-2]["t0"] + PH[-2]["dur"] * 0.7 else 0
    d.text((1840, 100), "대", font=F_CNT, fill=MUTED, anchor="rm")
    d.text((1812, 100), str(done), font=F_CNTB, fill=(255, 255, 255), anchor="rm")
    d.text((1780, 100), "완성 차량", font=F_CNT, fill=MUTED, anchor="rm")
    # 탭 5개
    tw = (1824 - 4 * 12) / 5
    for i in range(5):
        x0 = 48 + i * (tw + 12); x1 = x0 + tw; a, b = span(i); on = i == s
        d.rounded_rectangle((x0, 186, x1, 238), 14, fill=PANEL, outline=c if on else LINE, width=2 if on else 1)
        cc = COL[i] if on else ((42, 143, 107) if t >= b else (34, 48, 75))
        d.ellipse((x0 + 16, 197, x0 + 46, 227), fill=cc)
        d.text((x0 + 31, 212), str(i + 1), font=F_TABN, fill=(10, 17, 32) if on else (220, 235, 245), anchor="mm")
        d.text((x0 + 58, 212), ST[i][0], font=F_TAB, fill=(255, 255, 255) if on else (159, 176, 200), anchor="lm")
        pr = clamp((t - a) / (b - a))
        if pr > 0: d.rectangle((x0 + 2, 234, x0 + 2 + (tw - 4) * pr, 237), fill=COL[i])
    # 아래 줄
    d.text((60, 1044), "전기차 조립 라인 · 스케이트보드 플랫폼 → 차체 결합", font=F_FOOT, fill=MUTED, anchor="ls")
    d.text((1860, 1044), f"{int(t)//60:02d}:{int(t)%60:02d} / 00:{round(TOTAL)}", font=F_FOOT, fill=MUTED, anchor="rs")
    # 완성 카드
    if p["type"] == "end":
        a = int(255 * clamp(fr / 0.3))
        d.rounded_rectangle((610, 440, 1310, 640), 28, fill=(12, 20, 36, int(a * 0.9)), outline=(255, 181, 71, a), width=2)
        d.text((960, 510), "한 대 완성", font=F_END, fill=(255, 255, 255, a), anchor="mm")
        d.text((960, 585), "프레임 → 배터리 → 구동계 → 차체 결합 → 검사 · 출하", font=F_ENDS, fill=(200, 213, 234, a), anchor="mm")
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

os.makedirs("comp", exist_ok=True)
fs = sorted(glob.glob("renders/*.png"))
for k, fp in enumerate(fs):
    n = int(os.path.basename(fp)[:-4]); out = f"comp/{n:04d}.png"
    if os.path.exists(out): continue
    draw(Image.open(fp), (n - 1) / FPS).save(out)
    if k % 200 == 0: print(k, flush=True)
print("done", len(fs))
