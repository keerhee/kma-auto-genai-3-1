"""Composite captions, flow bar and bloom onto rendered frames -> comp/####.png (1920x1080)."""
import sys, os, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1920, 1080
FD = "/usr/share/fonts/opentype/noto/"
def font(weight, size): return ImageFont.truetype(FD + f"NotoSansCJK-{weight}.ttc", size, index=1)
F_CHIP, F_TITLE, F_EN, F_BODY = font("Bold", 24), font("Bold", 60), font("Medium", 26), font("Regular", 31)
F_NODE, F_NODE_ON = font("Medium", 23), font("Bold", 25)
F_BIG, F_BIG_SUB = font("Black", 84), font("Regular", 34)

CYAN, GREEN, WHITE, DIM = (64, 214, 255), (80, 240, 130), (240, 246, 252), (120, 140, 165)

STAGES = [  # start, end, short label, title, english, sentence
    (58, 140, "프레임", "프레임 조립", "Frame Assembly",
     "좌우 레일에 크로스멤버와 범퍼를 결합해 섀시의 뼈대를 만듭니다."),
    (140, 258, "배터리 팩", "배터리 팩 적재", "Battery Pack",
     "트레이에 모듈 18개를 차례로 얹습니다. 팩이 바닥 전체를 차지해 무게중심이 낮아집니다."),
    (258, 318, "고전압 배선", "고전압 배선", "HV Harness",
     "정션박스에서 앞뒤 구동부까지 고전압 케이블을 연결합니다."),
    (318, 398, "e-Axle", "e-Axle 장착", "Electric Drive Unit",
     "모터와 감속기, 인버터를 한 덩어리로 묶은 구동 모듈을 앞뒤 차축에 올립니다."),
    (398, 474, "서스펜션", "서스펜션 조립", "Suspension",
     "컨트롤 암과 허브, 하프샤프트를 끼우고 쇼크 업소버와 스프링을 세웁니다."),
    (474, 548, "휠과 타이어", "휠과 타이어 장착", "Wheels & Tires",
     "네 바퀴를 끼우면 스스로 굴러가는 스케이트보드 플랫폼이 됩니다."),
    (548, 676, "최종 검사", "최종 검사와 출하", "End-of-Line Test",
     "스캐너가 플랫폼 전체를 훑어 조립 상태를 확인하고, 통과하면 출하합니다."),
]

def ease(t): t = max(0.0, min(1.0, t)); return 1 - (1 - t) ** 3
def env(f, a, b, fin=10, fout=8):
    return min(ease((f - a) / fin), ease((b - f) / fout)) if a <= f < b else 0.0

def bloom(img):
    small = img.resize((W // 4, H // 4), Image.BILINEAR)
    a = np.asarray(small).astype(np.float32) / 255
    lum = a.max(axis=2, keepdims=True)
    bright = a * np.clip((lum - 0.62) / 0.38, 0, 1)
    b = Image.fromarray((bright * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(9))
    b = np.asarray(b.resize((W, H), Image.BILINEAR)).astype(np.float32) / 255
    base = np.asarray(img).astype(np.float32) / 255
    out = 1 - (1 - base) * (1 - b * 0.75)                     # screen blend
    yy, xx = np.mgrid[0:H, 0:W]
    v = 1 - 0.32 * (((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2) ** 1.3
    return Image.fromarray((np.clip(out * v[..., None], 0, 1) * 255).astype(np.uint8))

def text_alpha(layer, xy, s, fnt, fill, alpha):
    d = ImageDraw.Draw(layer)
    d.text(xy, s, font=fnt, fill=(*fill, int(255 * alpha)))

def caption(layer, f):
    d = ImageDraw.Draw(layer)
    for i, (a, b, _, title, en, body) in enumerate(STAGES):
        k = env(f, a, b, 12, 10)
        if k <= 0: continue
        dx = int((1 - k) * -40)
        words, lines, cur = body.split(" "), [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if d.textlength(t, font=F_BODY) > 800 and cur: lines.append(cur); cur = w
            else: cur = t
        lines.append(cur)
        bottom = 200 + 42 * len(lines) + 18
        d.rounded_rectangle((60 + dx, 52, 60 + dx + 880, bottom), 18, fill=(6, 14, 28, int(150 * k)))
        d.rounded_rectangle((60 + dx, 52, 66 + dx, bottom), 3, fill=(*CYAN, int(255 * k)))
        d.rounded_rectangle((92 + dx, 74, 92 + dx + 170, 110), 18, outline=(*CYAN, int(255 * k)), width=2)
        text_alpha(layer, (110 + dx, 76), f"STEP {i + 1:02d} / 07", F_CHIP, CYAN, k)
        text_alpha(layer, (280 + dx, 76), en, F_EN, DIM, k)
        text_alpha(layer, (90 + dx, 112), title, F_TITLE, WHITE, k)
        for j, ln in enumerate(lines):
            text_alpha(layer, (92 + dx, 202 + j * 42), ln, F_BODY, (200, 214, 230), k)

def flow_bar(layer, f):
    k = ease((f - 40) / 18) * (1 - ease((f - 668) / 14))
    if k <= 0: return
    d = ImageDraw.Draw(layer)
    n = len(STAGES); x0, x1, y = 200, W - 200, H - 92
    xs = [x0 + (x1 - x0) * i / (n - 1) for i in range(n)]
    d.rounded_rectangle((120, y - 58, W - 120, y + 62), 22, fill=(6, 14, 28, int(140 * k)))
    d.line((x0, y, x1, y), fill=(60, 80, 105, int(255 * k)), width=4)
    # progress fill
    prog = x0
    for i, (a, b, *_ ) in enumerate(STAGES):
        if f >= a:
            nxt = xs[i + 1] if i + 1 < n else xs[i]
            p = min(1.0, (f - a) / max(1, (b - a)))
            prog = xs[i] + (nxt - xs[i]) * p if i + 1 < n else xs[i]
    passed = f >= 622
    col = GREEN if passed else CYAN
    if f >= STAGES[0][0]:
        d.line((x0, y, prog, y), fill=(*col, int(255 * k)), width=4)
        d.ellipse((prog - 7, y - 7, prog + 7, y + 7), fill=(*WHITE, int(255 * k)))
    for i, (a, b, short, *_ ) in enumerate(STAGES):
        cx = xs[i]; active = a <= f < b and not (passed and i == n - 1); done = f >= b or (passed and i == n - 1)
        r = 15 if active else 11
        if active and not passed:
            pulse = 0.5 + 0.5 * math.sin(f * 0.35)
            rr = r + 6 + 4 * pulse
            d.ellipse((cx - rr, y - rr, cx + rr, y + rr), outline=(*CYAN, int(120 * k)), width=2)
        fill = (*col, int(255 * k)) if (active or done) else (20, 32, 50, int(255 * k))
        d.ellipse((cx - r, y - r, cx + r, y + r), fill=fill, outline=(*((col) if (active or done) else DIM), int(255 * k)), width=2)
        fnt = F_NODE_ON if active else F_NODE
        tw = d.textlength(short, font=fnt)
        tc = WHITE if active else ((185, 200, 215) if done else DIM)
        text_alpha(layer, (cx - tw / 2, y + 20), short, fnt, tc, k)
        num = f"{i + 1}"
        nw = d.textlength(num, font=F_CHIP)
        text_alpha(layer, (cx - nw / 2, y - 48), num, F_CHIP, col if (active or done) else DIM, k)

def intro_outro(layer, f):
    d = ImageDraw.Draw(layer)
    k = env(f, 1, 60, 14, 12)
    if k > 0:
        dy = int((1 - k) * 24)
        t1, t2 = "전기차 스케이트보드 플랫폼", "설계 데이터에서 출발해 일곱 단계로 조립합니다"
        w1 = d.textlength(t1, font=F_BIG); w2 = d.textlength(t2, font=F_BIG_SUB)
        text_alpha(layer, ((W - w1) / 2, 120 + dy), t1, F_BIG, WHITE, k)
        text_alpha(layer, ((W - w2) / 2, 232 + dy), t2, F_BIG_SUB, (170, 205, 235), k)
        e = "EV SKATEBOARD PLATFORM  ·  ASSEMBLY FLOW"
        we = d.textlength(e, font=F_CHIP)
        text_alpha(layer, ((W - we) / 2, 84 + dy), e, F_CHIP, CYAN, k)
    k = env(f, 622, 680, 8, 10)
    if k > 0:  # PASS badge
        s = "EOL 검사 통과  PASS"
        bw = d.textlength(s, font=F_NODE_ON) + 64
        x, y = W - 120 - bw, 70
        d.rounded_rectangle((x, y, x + bw, y + 58), 29, fill=(10, 40, 24, int(200 * k)), outline=(*GREEN, int(255 * k)), width=3)
        d.ellipse((x + 20, y + 22, x + 34, y + 36), fill=(*GREEN, int(255 * k)))
        text_alpha(layer, (x + 46, y + 13), s, F_NODE_ON, GREEN, k)
    k = env(f, 676, 722, 14, 1)
    if k > 0:
        t1, t2 = "주행 가능한 플랫폼 완성", "이 위에 차체(Top Hat)를 얹으면 완성차가 됩니다"
        w1 = d.textlength(t1, font=F_BIG); w2 = d.textlength(t2, font=F_BIG_SUB)
        text_alpha(layer, ((W - w1) / 2, 110), t1, F_BIG, WHITE, k)
        text_alpha(layer, ((W - w2) / 2, 222), t2, F_BIG_SUB, (170, 205, 235), k)

def composite(src, f, dst):
    img = Image.open(src).convert("RGB").resize((W, H), Image.LANCZOS)
    img = bloom(img).convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    caption(layer, f); flow_bar(layer, f); intro_outro(layer, f)
    Image.alpha_composite(img, layer).convert("RGB").save(dst)

if __name__ == "__main__":
    if sys.argv[1] == "test":      # python comp.py test <src> <frame> <dst>
        composite(sys.argv[2], int(sys.argv[3]), sys.argv[4])
    else:                          # python comp.py all
        os.makedirs("comp", exist_ok=True)
        lo, hi = (int(sys.argv[2]), int(sys.argv[3])) if len(sys.argv) > 3 else (1, 720)
        for f in range(lo, hi + 1):
            src, dst = f"renders/{f:04d}.png", f"comp/{f:04d}.png"
            if os.path.exists(dst): continue
            composite(src, f, dst)
