"""EV skateboard platform — manufacturing flow motion graphic (Blender 5.x, Cycles CPU).

Usage:
  python scene.py preview     # low-res stills at key frames -> preview/
  python scene.py final       # 1280x720 PNG sequence -> renders/
  python scene.py final 300 450   # render a frame range only
"""
import bpy, sys, json, math
from mathutils import Vector, Matrix
from bpy_extras import anim_utils

MODE = sys.argv[sys.argv.index("scene.py") + 1] if "scene.py" in " ".join(sys.argv) and len(sys.argv) > 1 else "preview"
for a in sys.argv:
    if a in ("preview", "final"):
        MODE = a
RANGE = [int(x) for x in sys.argv if x.isdigit()]
FPS, F_END = 24, 720

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath="model.glb")
sc = bpy.context.scene
vl = bpy.context.view_layer
EVENTS = []      # sound cue list
INTERP = {}      # (id_name, data_path, frame) -> interpolation

# ------------------------------------------------------------------ helpers
def recenter(o, pivot_local=None):
    """Move object origin to bbox centre (or a given local point) without moving the mesh."""
    if o.data.users > 1:
        o.data = o.data.copy()
    c = pivot_local if pivot_local is not None else sum((Vector(v) for v in o.bound_box), Vector()) / 8
    wc = o.matrix_world @ c
    o.data.transform(Matrix.Translation(-c))
    o.matrix_world.translation = wc

def join(objs, name):
    bpy.ops.object.select_all(action="DESELECT")
    for o in objs:
        o.select_set(True)
    vl.objects.active = objs[0]
    bpy.ops.object.join()
    objs[0].name = name
    return objs[0]

def key(o, path, f, interp="BEZIER"):
    o.keyframe_insert(path, frame=f)
    INTERP[(o.name, path, f)] = interp

def show_from(o, f):
    o.hide_render = True;  o.keyframe_insert("hide_render", frame=0)
    o.hide_render = False; o.keyframe_insert("hide_render", frame=f)

def hide_from(o, f):
    o.hide_render = False; o.keyframe_insert("hide_render", frame=f - 1)
    o.hide_render = True;  o.keyframe_insert("hide_render", frame=f)

def fly_in(o, t0, dur, offset, interp="EXPO", spin=None, sound="whoosh", land="clank"):
    final = o.location.copy()
    show_from(o, t0)
    o.location = final + Vector(offset); key(o, "location", t0, interp)
    o.location = final;                  key(o, "location", t0 + dur)
    if spin:
        rot = o.rotation_euler.copy()
        o.rotation_euler = (rot.x + spin, rot.y, rot.z); key(o, "rotation_euler", t0, interp)
        o.rotation_euler = rot;                          key(o, "rotation_euler", t0 + dur)
    if sound: EVENTS.append({"f": t0, "kind": sound})
    if land:  EVENTS.append({"f": t0 + dur, "kind": land})

def pbsdf(mat):
    return next(n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED")

def flash(mat, f, color=None, peak=6.0, decay=12):
    b = pbsdf(mat)
    s = b.inputs["Emission Strength"]
    if color is not None:
        b.inputs["Emission Color"].default_value = (*color, 1)
    for ff, v in ((f - 1, 0.0), (f, peak), (f + decay, 0.0)):
        s.default_value = v; s.keyframe_insert("default_value", frame=ff)

def apply_interps():
    for o in bpy.data.objects:
        ad = o.animation_data
        if not ad or not ad.action:
            continue
        cb = anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot)
        for fc in cb.fcurves:
            for kp in fc.keyframe_points:
                it = INTERP.get((o.name, fc.data_path, int(round(kp.co.x))))
                if it:
                    kp.interpolation = it
                    if it not in ("BEZIER", "LINEAR", "CONSTANT"):
                        kp.easing = "EASE_OUT"
                    if it == "BACK":
                        kp.back = 1.1

def emission_mat(name, color, strength, alpha=1.0):
    m = bpy.data.materials.new(name)
    nt = m.node_tree; nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value = (*color, 1); em.inputs["Strength"].default_value = strength
    if alpha < 1.0:
        tr = nt.nodes.new("ShaderNodeBsdfTransparent")
        mx = nt.nodes.new("ShaderNodeMixShader"); mx.inputs[0].default_value = alpha
        nt.links.new(tr.outputs[0], mx.inputs[1]); nt.links.new(em.outputs[0], mx.inputs[2])
        nt.links.new(mx.outputs[0], out.inputs[0])
    else:
        nt.links.new(em.outputs[0], out.inputs[0])
    return m

# ------------------------------------------------------------------ parts
parts = {o.name: o for o in bpy.data.objects if o.type == "MESH"}
for corner in ("Front_Left", "Front_Right", "Rear_Left", "Rear_Right"):
    segs = sorted(n for n in parts if n.startswith(corner + "_Spring_") and n[-2:].isdigit())
    join([parts[n] for n in segs], corner + "_Spring")
parts = {o.name: o for o in bpy.data.objects if o.type == "MESH"}

for n, o in parts.items():
    if n.startswith("HV_Cable"):
        bb = [Vector(v) for v in o.bound_box]
        cy = sum(v.y for v in bb) / 8; cz = sum(v.z for v in bb) / 8; cx = sum(v.x for v in bb) / 8
        # pivot at the junction-box end (world y = 0)
        inv = o.matrix_world.inverted()
        recenter(o, inv @ Vector(((o.matrix_world @ Vector((cx, cy, cz))).x, 0.0,
                                  (o.matrix_world @ Vector((cx, cy, cz))).z)))
    else:
        recenter(o)

root = bpy.data.objects.new("Platform", None); sc.collection.objects.link(root)
for o in parts.values():
    o.parent = root

def pick(*prefixes, contains=None):
    return [o for n, o in sorted(parts.items())
            if n.startswith(prefixes) and (contains is None or contains in n)]

# ------------------------------------------------------------------ materials
look = {"#a9bacb": (0.85, 0.30), "#b9c8d8": (0.95, 0.18), "#34485e": (0.6, 0.35),
        "#232b35": (0.0, 0.65), "#168bd1": (0.3, 0.30), "#49bded": (0.2, 0.30),
        "#ff781f": (0.1, 0.35), "#22b68c": (0.4, 0.30), "#efbc42": (0.9, 0.25)}
for m in bpy.data.materials:
    if m.name in look:
        b = pbsdf(m); b.inputs["Metallic"].default_value, b.inputs["Roughness"].default_value = look[m.name]
        b.inputs["Emission Color"].default_value = b.inputs["Base Color"].default_value
        b.inputs["Emission Strength"].default_value = 0.0

def own_material(o):
    o.data.materials[0] = o.data.materials[0].copy()
    return o.data.materials[0]

# ------------------------------------------------------------------ hologram ghost (design intent)
ghost = bpy.data.materials.new("Ghost")
nt = ghost.node_tree; nt.nodes.clear()
out = nt.nodes.new("ShaderNodeOutputMaterial")
wf = nt.nodes.new("ShaderNodeWireframe"); wf.use_pixel_size = True; wf.inputs[0].default_value = 1.2
em = nt.nodes.new("ShaderNodeEmission"); em.inputs["Color"].default_value = (0.25, 0.8, 1.0, 1); em.inputs["Strength"].default_value = 2.2
face = nt.nodes.new("ShaderNodeEmission"); face.inputs["Color"].default_value = (0.1, 0.45, 0.8, 1); face.inputs["Strength"].default_value = 0.35
tr = nt.nodes.new("ShaderNodeBsdfTransparent")
mfa = nt.nodes.new("ShaderNodeMixShader"); mfa.inputs[0].default_value = 0.12
nt.links.new(tr.outputs[0], mfa.inputs[1]); nt.links.new(face.outputs[0], mfa.inputs[2])
mwf = nt.nodes.new("ShaderNodeMixShader")
nt.links.new(wf.outputs[0], mwf.inputs[0]); nt.links.new(mfa.outputs[0], mwf.inputs[1]); nt.links.new(em.outputs[0], mwf.inputs[2])
tr2 = nt.nodes.new("ShaderNodeBsdfTransparent")
fade = nt.nodes.new("ShaderNodeMixShader"); fade.name = "Fade"
nt.links.new(tr2.outputs[0], fade.inputs[1]); nt.links.new(mwf.outputs[0], fade.inputs[2])
nt.links.new(fade.outputs[0], out.inputs[0])
fv = fade.inputs[0]
for f, v in ((1, 0.0), (14, 1.0), (52, 1.0), (88, 0.0)):
    fv.default_value = v; fv.keyframe_insert("default_value", frame=f)
for o in list(parts.values()):
    g = o.copy(); sc.collection.objects.link(g); g.parent = root
    for s in g.material_slots:
        s.link = "OBJECT"; s.material = ghost
    hide_from(g, 90)
EVENTS.append({"f": 4, "kind": "hologram"})

# ------------------------------------------------------------------ STEP 1 frame (60-140)
rails = pick("Longitudinal_Rail")
for o in rails:
    fly_in(o, 62, 22, (6.0 * (1 if o.location.x > 0 else -1), 0, 0), "BACK")
for i, o in enumerate(sorted(pick("Crossmember"), key=lambda o: o.location.y)):
    fly_in(o, 86 + i * 5, 14, (0, 0, 3.0), "EXPO", sound=None)
EVENTS.append({"f": 86, "kind": "whoosh"})
fly_in(parts["Front_Bumper"], 112, 18, (0, -4.5, 0), "EXPO")
fly_in(parts["Rear_Bumper"], 116, 18, (0, 4.5, 0), "EXPO", sound=None)

# ------------------------------------------------------------------ STEP 2 battery pack (140-260)
fly_in(parts["Battery_Tray"], 144, 22, (0, 0, -1.6), "EXPO", sound="lift")
mods = sorted(pick("Battery_Module"), key=lambda o: (round(-o.location.y, 2), o.location.x))
for i, o in enumerate(mods):
    t0 = 172 + i * 4
    fly_in(o, t0, 12, (0, 0, 2.4), "EXPO", sound=None, land="tick")
    flash(own_material(o), t0 + 12, peak=7.0, decay=14)
EVENTS.append({"f": 172, "kind": "whoosh"})

# ------------------------------------------------------------------ STEP 3 HV harness (260-320)
jb = parts["HV_Junction_Box"]
fly_in(jb, 262, 14, (0, 0, 2.2), "BACK")
flash(own_material(jb), 276, peak=5.0, decay=16)
for o in pick("HV_Cable"):
    show_from(o, 282)
    o.scale = (1, 0.001, 1); key(o, "scale", 282, "SINE")
    o.scale = (1, 1, 1);     key(o, "scale", 308)
    m = own_material(o)
    s = pbsdf(m).inputs["Emission Strength"]
    for f, v in ((282, 0.0), (296, 6.0), (318, 0.6)):
        s.default_value = v; s.keyframe_insert("default_value", frame=f)
EVENTS.append({"f": 282, "kind": "zap"})

# ------------------------------------------------------------------ STEP 4 e-Axle (320-400)
for side, t in (("Front", 322), ("Rear", 360)):
    fly_in(parts[f"{side}_Motor"], t, 16, (0, 0, -1.4), "EXPO", sound="lift")
    fly_in(parts[f"{side}_Gearbox"], t + 10, 14, (2.6, 0, 0), "BACK")
    inv = parts[f"{side}_Inverter"]
    fly_in(inv, t + 20, 12, (0, 0, 2.0), "EXPO")
    flash(own_material(parts[f"{side}_Motor"]), t + 16, peak=4.0, decay=16)
    flash(own_material(inv), t + 32, peak=5.0, decay=16)

# ------------------------------------------------------------------ STEP 5 suspension (400-476)
def side(o): return 1 if o.location.x > 0 else -1
for o in pick("Front", "Rear", contains="Lower_Control_Arm"):
    fly_in(o, 402, 14, (2.4 * side(o), 0, 0), "EXPO", sound=None, land=None)
for o in pick("Front", "Rear", contains="_Hub"):
    fly_in(o, 412, 14, (3.0 * side(o), 0, 0), "EXPO", sound=None, land=None)
for o in pick("Front", "Rear", contains="Halfshaft"):
    fly_in(o, 420, 14, (2.0 * side(o), 0, 0), "EXPO", sound=None, land=None)
for o in pick("Front", "Rear", contains="Damper"):
    fly_in(o, 430, 12, (0, 0, 2.2), "EXPO", sound=None, land=None)
for o in [parts[c + "_Spring"] for c in ("Front_Left", "Front_Right", "Rear_Left", "Rear_Right")]:
    fly_in(o, 438, 12, (0, 0, 2.2), "BACK", sound=None, land=None)
for o in pick("Front", "Rear", contains="Spring_Mount"):
    fly_in(o, 446, 10, (0, 0, 1.6), "EXPO", sound=None, land=None)
for f in (402, 412, 420, 430, 438, 446):
    EVENTS.append({"f": f, "kind": "whoosh_small"})
for f in (416, 426, 434, 442, 450, 456):
    EVENTS.append({"f": f, "kind": "tick"})

# ------------------------------------------------------------------ STEP 6 wheels (476-548)
order = {"Front_Left": 482, "Rear_Left": 490, "Front_Right": 498, "Rear_Right": 504}
for corner, t in order.items():
    group = [parts[corner + "_Tire"]] + pick(corner + "_Rim")
    for j, o in enumerate(group):
        fly_in(o, t, 22, (5.5 * side(o), 0, 0), "EXPO", spin=-4 * math.pi,
               sound="whoosh" if j == 0 else None, land="clank" if j == 0 else None)

# ------------------------------------------------------------------ STEP 7 EOL inspection (548-720)
scanner = bpy.data.objects.new("Scanner", None); sc.collection.objects.link(scanner)
cyan = (0.2, 0.85, 1.0)
bpy.ops.mesh.primitive_plane_add(size=2, location=(0, 0, 0.72), rotation=(math.pi / 2, 0, 0))
sheet = bpy.context.active_object; sheet.scale = (1.5, 0.74, 1); sheet.parent = scanner
sheet.data.materials.append(emission_mat("ScanSheet", cyan, 1.4, alpha=0.12))
gate_mat = emission_mat("Gate", cyan, 9.0)
for loc, scl in (((-1.55, 0, 0.74), (0.025, 0.025, 0.74)), ((1.55, 0, 0.74), (0.025, 0.025, 0.74)),
                 ((0, 0, 1.48), (1.575, 0.025, 0.025))):
    bpy.ops.mesh.primitive_cube_add(size=2, location=loc); c = bpy.context.active_object
    c.scale = scl; c.parent = scanner; c.data.materials.append(gate_mat)
gate_parts = [o for o in bpy.data.objects if o.parent == scanner]
for o in gate_parts:
    show_from(o, 560); hide_from(o, 626)
scanner.location = (0, -2.7, 0); key(scanner, "location", 562, "SINE")
scanner.location = (0, 2.7, 0);  key(scanner, "location", 620)
EVENTS.append({"f": 562, "kind": "scan"})
EVENTS.append({"f": 622, "kind": "chime"})

# turntable
root.rotation_euler = (0, 0, 0);            key(root, "rotation_euler", 632, "SINE")
root.rotation_euler = (0, 0, math.pi * 0.6); key(root, "rotation_euler", 720)

# ------------------------------------------------------------------ stage set
world = bpy.data.worlds.new("W"); sc.world = world
bg = world.node_tree.nodes["Background"]
bg.inputs[0].default_value = (0.010, 0.016, 0.032, 1); bg.inputs[1].default_value = 1.0

# floor with fading emissive grid
bpy.ops.mesh.primitive_plane_add(size=60, location=(0, 0, -0.04)); floor = bpy.context.active_object
fm = bpy.data.materials.new("Floor"); nt = fm.node_tree
b = pbsdf(fm)
b.inputs["Base Color"].default_value = (0.012, 0.02, 0.035, 1)
b.inputs["Metallic"].default_value = 0.4; b.inputs["Roughness"].default_value = 0.28
tc = nt.nodes.new("ShaderNodeTexCoord"); sep = nt.nodes.new("ShaderNodeSeparateXYZ")
nt.links.new(tc.outputs["Object"], sep.inputs[0])
def grid_axis(sock):
    fr = nt.nodes.new("ShaderNodeMath"); fr.operation = "FRACT"; nt.links.new(sock, fr.inputs[0])
    one = nt.nodes.new("ShaderNodeMath"); one.operation = "SUBTRACT"; one.inputs[0].default_value = 1.0
    nt.links.new(fr.outputs[0], one.inputs[1])
    mn = nt.nodes.new("ShaderNodeMath"); mn.operation = "MINIMUM"
    nt.links.new(fr.outputs[0], mn.inputs[0]); nt.links.new(one.outputs[0], mn.inputs[1])
    lt = nt.nodes.new("ShaderNodeMath"); lt.operation = "LESS_THAN"; lt.inputs[1].default_value = 0.012
    nt.links.new(mn.outputs[0], lt.inputs[0]); return lt.outputs[0]
gx = grid_axis(sep.outputs["X"]); gy = grid_axis(sep.outputs["Y"])
mx = nt.nodes.new("ShaderNodeMath"); mx.operation = "MAXIMUM"; nt.links.new(gx, mx.inputs[0]); nt.links.new(gy, mx.inputs[1])
ln = nt.nodes.new("ShaderNodeVectorMath"); ln.operation = "LENGTH"; nt.links.new(tc.outputs["Object"], ln.inputs[0])
rad = nt.nodes.new("ShaderNodeMapRange"); rad.inputs[1].default_value = 2.0; rad.inputs[2].default_value = 13.0
rad.inputs[3].default_value = 1.0; rad.inputs[4].default_value = 0.0
nt.links.new(ln.outputs["Value"], rad.inputs[0])
mul = nt.nodes.new("ShaderNodeMath"); mul.operation = "MULTIPLY"
nt.links.new(mx.outputs[0], mul.inputs[0]); nt.links.new(rad.outputs[0], mul.inputs[1])
mul2 = nt.nodes.new("ShaderNodeMath"); mul2.operation = "MULTIPLY"; mul2.inputs[1].default_value = 1.4
nt.links.new(mul.outputs[0], mul2.inputs[0])
b.inputs["Emission Color"].default_value = (0.15, 0.5, 0.9, 1)
nt.links.new(mul2.outputs[0], b.inputs["Emission Strength"])
floor.data.materials.append(fm)

# assembly station: platform disc + status ring
bpy.ops.mesh.primitive_cylinder_add(vertices=128, radius=2.75, depth=0.04, location=(0, 0, -0.02))
disc = bpy.context.active_object
dm = bpy.data.materials.new("Disc"); d = pbsdf(dm)
d.inputs["Base Color"].default_value = (0.03, 0.045, 0.07, 1); d.inputs["Metallic"].default_value = 0.6
d.inputs["Roughness"].default_value = 0.55; disc.data.materials.append(dm)
bpy.ops.mesh.primitive_torus_add(major_radius=2.78, minor_radius=0.018, major_segments=192, location=(0, 0, 0.0))
ring = bpy.context.active_object
rm = emission_mat("Ring", cyan, 6.0); ring.data.materials.append(rm)
ec = rm.node_tree.nodes["Emission"].inputs["Color"]
for f, col in ((618, (*cyan, 1)), (624, (0.25, 1.0, 0.45, 1))):
    ec.default_value = col; ec.keyframe_insert("default_value", frame=f)
rs = rm.node_tree.nodes["Emission"].inputs["Strength"]
for f, v in ((618, 6.0), (624, 16.0), (650, 7.0)):
    rs.default_value = v; rs.keyframe_insert("default_value", frame=f)

# lights
def area(name, loc, energy, color, size):
    L = bpy.data.lights.new(name, "AREA"); L.energy = energy; L.color = color; L.size = size
    o = bpy.data.objects.new(name, L); o.location = loc; sc.collection.objects.link(o)
    t = o.constraints.new("TRACK_TO"); t.target = root; t.track_axis = "TRACK_NEGATIVE_Z"; t.up_axis = "UP_Y"
area("Key", (3.5, -4.5, 6.0), 1100, (1.0, 0.96, 0.9), 5)
area("RimCyan", (-5.0, 4.5, 2.8), 900, (0.35, 0.75, 1.0), 3)
area("RimWarm", (5.0, 4.0, 1.8), 500, (1.0, 0.6, 0.3), 3)
area("Fill", (-4.0, -4.0, 2.5), 250, (0.6, 0.75, 1.0), 6)

# camera rig
cam = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera")); sc.collection.objects.link(cam)
cam.data.lens = 35; sc.camera = cam
tgt = bpy.data.objects.new("CamTarget", None); sc.collection.objects.link(tgt)
tc_ = cam.constraints.new("TRACK_TO"); tc_.target = tgt; tc_.track_axis = "TRACK_NEGATIVE_Z"; tc_.up_axis = "UP_Y"
CAM = [  # frame, camera location, target location
    (1,   (7.2, -8.2, 4.6), (0, 0, 0.35)),
    (56,  (5.8, -6.6, 4.0), (0, 0, 0.4)),
    (136, (4.6, -5.0, 3.4), (0, 0, 0.45)),
    (168, (2.6, -3.9, 5.0), (0, 0.0, 0.4)),
    (250, (-2.7, -3.4, 4.6), (0, 0.1, 0.4)),
    (284, (3.1, -1.6, 2.5), (0.45, 0, 0.6)),
    (318, (2.4, -3.7, 1.8), (0, -1.35, 0.6)),
    (348, (2.6, -3.3, 1.7), (0, -1.4, 0.6)),
    (370, (2.2, 3.6, 2.6), (0, 1.2, 0.6)),
    (396, (-2.4, 4.2, 2.0), (0, 1.3, 0.55)),
    (420, (-2.5, 2.6, 1.3), (-0.8, 1.42, 0.55)),
    (462, (-2.9, 3.2, 1.6), (-0.6, 1.2, 0.5)),
    (494, (-4.9, -0.6, 1.2), (0, 0, 0.42)),
    (546, (-4.4, -4.0, 1.6), (0, 0, 0.45)),
    (562, (-4.2, -4.4, 2.0), (0, 0, 0.5)),
    (622, (4.4, -4.9, 2.3), (0, 0, 0.45)),
    (720, (5.4, -5.8, 2.6), (0, 0, 0.4)),
]
for f, cl, tl in CAM:
    cam.location = cl; cam.keyframe_insert("location", frame=f)
    tgt.location = tl; tgt.keyframe_insert("location", frame=f)

apply_interps()

# ------------------------------------------------------------------ render settings
r = sc.render
r.engine = "CYCLES"; r.fps = FPS
cy = sc.cycles
cy.device = "CPU"; cy.use_adaptive_sampling = True
cy.max_bounces = 4; cy.diffuse_bounces = 2; cy.glossy_bounces = 2; cy.transmission_bounces = 0
cy.transparent_max_bounces = 6; cy.caustics_reflective = False; cy.caustics_refractive = False
cy.use_denoising = True; cy.denoiser = "OPENIMAGEDENOISE"; cy.denoising_prefilter = "FAST"
r.use_persistent_data = True
try:
    sc.view_settings.view_transform = "Khronos PBR Neutral"; sc.view_settings.exposure = -0.15
except Exception:
    pass
r.image_settings.file_format = "PNG"

with open("events.json", "w") as fh:
    json.dump(sorted(EVENTS, key=lambda e: e["f"]), fh)

if MODE == "preview":
    r.resolution_x, r.resolution_y = 640, 360; cy.samples = 6
    frames = RANGE or [10, 100, 160, 230, 300, 340, 385, 440, 500, 540, 600, 700]
    for f in frames:
        sc.frame_set(f); r.filepath = f"//preview/p_{f:04d}.png"
        r.filepath = f"preview/p_{f:04d}.png"
        bpy.ops.render.render(write_still=True)
else:
    r.resolution_x, r.resolution_y = 1280, 720; cy.samples = 8
    if (len(RANGE) == 2 and RANGE[0] > 1) or "fast" in sys.argv:
        cy.samples = int(__import__("os").environ.get("SMP","5")); cy.max_bounces = 2; cy.diffuse_bounces = 1; cy.glossy_bounces = 1
        cy.transparent_max_bounces = 4; cy.adaptive_threshold = 0.05
    sc.frame_start, sc.frame_end = (RANGE[0], RANGE[1]) if len(RANGE) == 2 else (1, F_END)
    r.filepath = "renders/"
    r.use_overwrite = False; r.use_placeholder = True
    bpy.ops.render.render(animation=True)
