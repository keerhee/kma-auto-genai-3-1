"""Synthesise music bed + SFX from events.json -> audio.wav (30 s, 48 kHz stereo)."""
import json, numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

SR, FPS, DUR = 48000, 24, 30.0
N = int(SR * DUR)
rng = np.random.default_rng(7)
mix = np.zeros((N, 2))

def t_(sec): return np.arange(int(SR * sec)) / SR
def bp(x, lo, hi): return sosfilt(butter(2, [lo, hi], "bandpass", fs=SR, output="sos"), x)
def lp(x, hi): return sosfilt(butter(2, hi, "lowpass", fs=SR, output="sos"), x)
def place(sig, sec, gain=1.0, pan=0.0):
    i = int(sec * SR); sig = sig[: max(0, N - i)]
    l, r = np.sqrt(0.5 * (1 - pan)), np.sqrt(0.5 * (1 + pan))
    mix[i:i + len(sig), 0] += sig * gain * l; mix[i:i + len(sig), 1] += sig * gain * r

def whoosh(sec=0.5):
    t = t_(sec); n = rng.standard_normal(len(t))
    env = np.sin(np.pi * np.clip(t / sec, 0, 1)) ** 2
    return bp(n, 400, 3200) * env * 0.5 + bp(n, 150, 600) * env * 0.3
def clank():
    t = t_(0.5)
    thump = np.sin(2 * np.pi * (75 - 30 * t) * t) * np.exp(-t * 14)
    metal = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * d) for f, d in ((920, 22), (1460, 28), (2270, 35), (3110, 45)))
    return thump * 0.9 + metal * 0.12
def tick():
    t = t_(0.12)
    return np.sin(2 * np.pi * 2600 * t) * np.exp(-t * 60) * 0.35 + np.sin(2 * np.pi * 140 * t) * np.exp(-t * 40) * 0.4
def lift():
    t = t_(0.9); f = 70 + 90 * t
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.35
    hiss = bp(rng.standard_normal(len(t)), 800, 3000) * 0.15
    env = np.minimum(t / 0.15, 1) * np.exp(-np.maximum(t - 0.6, 0) * 10)
    return (tone + hiss) * env
def zap():
    t = t_(1.2); f = 110 + 60 * t
    saw = 2 * ((np.cumsum(f) / SR) % 1) - 1
    buzz = lp(saw, 2500) * 0.25 + bp(rng.standard_normal(len(t)), 2000, 6000) * 0.08 * (rng.random(len(t)) > 0.97)
    return buzz * np.minimum(t / 0.05, 1) * np.exp(-t * 2.2)
def scan():
    t = t_(2.6); f = 380 + 700 * (t / 2.6) ** 1.4
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * t))
    return s * 0.18 * np.sin(np.pi * t / 2.6) ** 0.6
def chime():
    t = t_(2.2)
    return sum(np.sin(2 * np.pi * f * t) * np.exp(-t * 2.4) for f in (1046.5, 1318.5, 1568.0, 2093.0)) * 0.14
def shimmer():
    t = t_(2.0)
    s = sum(np.sin(2 * np.pi * f * t + p) for f, p in ((1760, 0), (1767, 1), (2637, 2), (3520, 3)))
    return s * 0.05 * np.sin(np.pi * t / 2.0)

# music bed: Am - F - C - G pad with soft pulse, 100 bpm
t = np.arange(N) / SR
chords = [(220.0, 261.6, 329.6), (174.6, 220.0, 261.6), (196.0, 261.6, 329.6), (196.0, 246.9, 293.7)]
bar = 60 / 100 * 4
pad = np.zeros(N)
for i in range(int(DUR / bar) + 1):
    s0, s1 = int(i * bar * SR), min(N, int((i + 1) * bar * SR))
    if s0 >= N: break
    tt = t[s0:s1] - i * bar
    seg = sum(np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt + 0.5) for f in chords[i % 4])
    seg *= np.minimum(tt / 0.4, 1) * np.minimum((bar - tt) / 0.4, 1)
    pad[s0:s1] += seg
pad = lp(pad, 1400) * 0.05
beat = 60 / 100
pulse = np.zeros(N)
for k in range(int(DUR / beat)):
    s0 = int(k * beat * SR); tt = t_(0.35)[: N - s0]
    pulse[s0:s0 + len(tt)] += np.sin(2 * np.pi * (55 - 15 * tt) * tt) * np.exp(-tt * 9) * (0.22 if k % 2 == 0 else 0.12)
bed = (pad + pulse * np.clip((t - 2.0) / 2.0, 0, 1)) * np.clip((DUR - t) / 2.5, 0, 1) * np.clip(t / 1.5, 0, 1)
mix[:, 0] += bed; mix[:, 1] += bed

GEN = {"whoosh": (whoosh, 0.55, -0.15), "whoosh_small": (lambda: whoosh(0.3), 0.35, 0.0), "clank": (clank, 0.7, 0.1),
       "tick": (tick, 0.5, 0.0), "lift": (lift, 0.8, 0.0), "zap": (zap, 0.8, 0.2), "scan": (scan, 1.0, 0.0),
       "chime": (chime, 1.0, 0.0), "hologram": (shimmer, 1.0, 0.0)}
last = {}
for e in json.load(open("events.json")):
    fn, g, pan = GEN[e["kind"]]
    sec = (e["f"] - 1) / FPS
    if e["kind"] in last and sec - last[e["kind"]] < 0.08:   # avoid stacking identical hits
        continue
    last[e["kind"]] = sec
    lead = 0.25 if e["kind"].startswith("whoosh") else 0.0
    place(fn(), max(0, sec - lead), g, pan + rng.uniform(-0.1, 0.1))

mix /= np.abs(mix).max() / 0.89
wavfile.write("audio.wav", SR, (mix * 32767).astype(np.int16))
print("ok", mix.shape)
