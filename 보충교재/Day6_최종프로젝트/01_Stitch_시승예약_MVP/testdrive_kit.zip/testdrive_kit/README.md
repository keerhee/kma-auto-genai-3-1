# 시승 예약 웹앱 실습 키트

Google Stitch와 Claude Code로 모바일 시승 예약 웹앱을 만드는 실습 자료다.
모든 회사명, 차종명, 주소, 전화번호는 실습용으로 지어낸 것이다.

## 오늘 만드는 것

손님이 세 화면을 지나 시승을 예약하는 웹앱 `testdrive_mvp.html` 한 파일.

1. 차종 선택
2. 지점과 일시 선택
3. 예약자 정보 입력과 확인

## 폴더 구성

| 경로 | 내용 | 언제 쓰나 |
|---|---|---|
| `docs/design_brief.md` | 화면 디자인 요청서 | 1단계, Stitch에 화면을 만들 때 |
| `docs/booking_rules.md` | 예약 업무 규칙 | 4~6단계, 동작을 만들고 테스트할 때 |
| `data/vehicles.json` | 차종 네 개 | 3단계 |
| `data/branches.json` | 지점 세 곳과 지점별 보유 차종 | 4단계 |
| `data/bookings_sample.json` | 이미 들어와 있는 예약 네 건 | 4단계, 마감 시각 표시 |
| `images/stitch_screens_example.png` | 세 화면의 배치 예시 그림 | 1단계 |
| `images/expected/` | 단계마다 나와야 하는 결과 화면 | 3~5단계, 내 화면과 비교할 때 |
| `prompts.md` | 단계별 프롬프트 | 모든 단계 |
| `reference/testdrive_mvp_reference.html` | 완성본 예시 | 7단계, 내 결과와 비교할 때 |

## 준비

- Claude 데스크톱 앱 Code 탭에서 이 폴더를 작업 폴더로 연다.
- Stitch를 쓰려면 Stitch MCP가 연결돼 있어야 한다. 연결이 안 돼 있으면 `prompts.md`의 1단계 대안을 쓴다.
