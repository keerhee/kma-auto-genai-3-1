# 실습 프롬프트 모음

모든 프롬프트는 Claude 데스크톱 앱의 **Code 탭**에 붙여 넣는다.
Code 탭에서 작업 폴더를 이 키트 폴더(`testdrive_kit`)로 열어 둔 상태에서 시작한다.

---

## 0단계. 키트 읽기

```
이 폴더의 README.md, docs 폴더, data 폴더를 모두 읽고
오늘 무엇을 만들어야 하는지 다섯 줄로 요약해줘.
아직 아무 파일도 만들지 마.
```

## 1단계. Stitch로 화면 세 장 만들기

```
docs/design_brief.md 내용대로 Stitch에 testdrive-booking 프로젝트를 만들고
모바일 화면 3개를 생성해줘. 배치는 images/stitch_screens_example.png를 참고해.
다 만들면 화면마다 무엇이 들어갔는지 알려줘.
```

### 1단계 대안. Stitch가 연결돼 있지 않을 때

```
Stitch는 쓰지 말고, docs/design_brief.md와 images/stitch_screens_example.png를 보고
화면 3개를 HTML로 직접 디자인해서 stitch 폴더에 screen-1.html, screen-2.html,
screen-3.html로 저장해줘.
```

## 2단계. 세 화면을 한 파일로 합치기

```
Stitch에서 만든 화면 3개의 HTML을 가져와 stitch 폴더에 저장해줘.
그다음 세 화면을 testdrive_mvp.html 한 파일로 합치고
'다음' 버튼을 누르면 다음 화면으로 넘어가게 해줘.
데이터와 기능은 아직 넣지 마. 다 되면 브라우저로 열어줘.
```

## 3단계. 차종 데이터 연결

```
data/vehicles.json의 차종 네 개로 1번 화면의 카드를 채워줘.
파일을 더블클릭해도 열리도록 데이터는 HTML 안에 넣어줘.
카드를 누르면 고른 표시가 나고, 아무것도 안 고른 채 '다음'을 누르면
카드 아래에 빨간 글씨로 "차종을 하나 고르세요."라고 알려줘.
```

## 4단계. 지점과 일시

```
docs/booking_rules.md의 2장, 3장, 4장대로 2번 화면을 동작하게 해줘.
1번에서 고른 차가 있는 지점만 보여 주고, 날짜는 내일부터 14일까지 고르게 하되
일요일은 막아줘. 시간은 일곱 개 버튼으로 보여 주고,
data/bookings_sample.json에 이미 있는 예약 시각은 흐리게 해서 못 누르게 해줘.
```

## 5단계. 예약 정보와 저장

```
docs/booking_rules.md의 5장과 6장대로 3번 화면의 입력 확인과 완료 화면을 만들어줘.
틀린 칸 바로 아래에 무엇이 틀렸는지 빨간 글씨로 알려줘.
예약은 localStorage에 저장해서, 새로고침해도 방금 예약한 시각이 막혀 있게 해줘.
```

## 6단계. 규칙 테스트

```
docs/booking_rules.md의 규칙마다 테스트 시나리오를 하나씩 만들고
브라우저로 직접 눌러 보며 확인해줘.
결과는 규칙, 해 본 것, 결과 세 칸짜리 표로 보여 주고,
실패한 것은 고친 뒤 다시 확인해줘.
```

## 7단계. 완성본과 비교

```
reference/testdrive_mvp_reference.html과 내 testdrive_mvp.html을
같은 순서로 눌러 보고, 규칙을 다르게 처리하는 곳이 있으면 알려줘.
디자인 차이는 괜찮으니 동작 차이만 봐줘.
```
