#!/usr/bin/env python3
"""실습용 가상 외부 데이터 생성기 (표준 라이브러리만 사용).

실제 API 대신 이 폴더의 파일을 '외부 서비스'로 쓴다.
오늘 날짜를 기준으로 다시 만들어 언제 실습해도 '오늘' 데이터가 있게 한다.

    python3 _mock/generate_mock.py              # 오늘 기준
    python3 _mock/generate_mock.py 2026-11-03   # 특정 날짜 기준

만드는 파일
    youtube_daily.csv      채널 누적 조회수·구독자 (최근 60일)
    newsletter_daily.csv   뉴스레터 구독자·오픈율 (최근 60일)
    mail_inbox.json        받은편지함 25건 (최근 8일)
    calendar_events.json   이번 달과 다음 달 일정
"""
import csv, json, random, sys
from datetime import date, datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
today = date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else date.today()
rng = random.Random(42)

# 1) 유튜브 -------------------------------------------------------------------
rows, views, subs = [], 241_300, 11_820
for k in range(59, -1, -1):
    d = today - timedelta(days=k)
    daily = int(rng.gauss(1_150, 260)) + (2_400 if k in (12, 13) else 0)   # 12일 전 영상 업로드 반등
    views += max(daily, 300)
    subs += max(int(rng.gauss(14, 6)), 0) + (55 if k in (12, 13) else 0)
    rows.append([d.isoformat(), views, subs, max(daily, 300)])
with open(HERE / "youtube_daily.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["date", "views_total", "subscribers", "views_day"]); w.writerows(rows)

# 2) 뉴스레터 -----------------------------------------------------------------
rows, n = [], 1_942
for k in range(59, -1, -1):
    d = today - timedelta(days=k)
    n += rng.choice([0, 1, 1, 2, 3]) - (1 if rng.random() < 0.15 else 0)
    issue = d.weekday() == 3   # 매주 목요일 발송
    rows.append([d.isoformat(), n, round(rng.uniform(0.41, 0.53), 3) if issue else "", "Y" if issue else ""])
with open(HERE / "newsletter_daily.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["date", "subscribers", "open_rate", "issue_sent"]); w.writerows(rows)

# 3) 메일 ---------------------------------------------------------------------
M = [
 (0, "08:12", "박서연 <seoyeon.park@garam-logistics.example>", "[가람물류] 2차 미팅 자료 요청드립니다", "다음 주 미팅 전에 교육 커리큘럼 초안과 견적서를 받아 볼 수 있을까요? 인원은 18명으로 확정됐습니다.", False, "client"),
 (0, "07:40", "뉴스레터 플랫폼 <noreply@letterhub.example>", "이번 주 발행 리포트: 오픈율 47.2%", "지난 목요일 발행분 성과 요약입니다.", True, "notice"),
 (0, "06:55", "YouTube Studio <no-reply@youtube.example>", "채널 주간 성과 요약", "지난 7일 조회수가 평소보다 높습니다.", True, "notice"),
 (1, "21:03", "이준호 <junho@ai-community.example>", "AI 실무 밋업 연사 제안", "12월 첫째 주 밋업에서 30분 발표를 부탁드려도 될까요? 주제는 자유입니다.", False, "proposal"),
 (1, "17:22", "정다은 <daeun.jung@univ.example>", "특강 수강생 질문 정리본 전달", "지난 특강 질문 14개를 정리했습니다. 다음 강의에 반영해 주시면 좋겠습니다.", False, "lecture"),
 (1, "11:45", "세무사무소 <tax@hana-tax.example>", "10월 부가세 자료 제출 안내", "매출·매입 자료를 이번 주 금요일까지 보내 주세요.", False, "admin"),
 (2, "19:30", "브랜드 협업팀 <collab@notebrand.example>", "[협업 제안] 노트앱 리뷰 영상", "신제품 리뷰 영상 협업을 제안드립니다. 조건은 첨부 문서를 참고해 주세요.", False, "proposal"),
 (2, "14:08", "박서연 <seoyeon.park@garam-logistics.example>", "Re: 킥오프 회의록 확인", "회의록 확인했습니다. 3번 안건(현업 데이터 사용)은 보안팀 검토 후 회신드리겠습니다.", True, "client"),
 (2, "09:15", "결제 알림 <billing@cloudtools.example>", "구독 갱신 영수증", "이번 달 구독이 갱신되었습니다.", True, "admin"),
 (3, "22:41", "구독자 김민재 <minjae.k@mail.example>", "지난 영상 질문 있습니다", "ep41에서 쓴 프롬프트 전문을 받을 수 있을까요?", False, "audience"),
 (3, "16:00", "편집자 오세라 <sera.oh@edit-studio.example>", "ep42 1차 편집본 업로드", "1차 편집본 올렸습니다. 12분 30초 부근 자막 확인 부탁드립니다.", False, "content"),
 (3, "10:20", "이벤트 <promo@shopping.example>", "오늘만 70% 할인", "놓치지 마세요.", True, "spam"),
 (4, "18:35", "정다은 <daeun.jung@univ.example>", "11월 특강 강의실 확정", "11월 특강 장소가 3층 세미나실로 확정됐습니다. 빔프로젝터 HDMI만 지원합니다.", True, "lecture"),
 (4, "13:12", "최유나 <yuna.choi@startup-hub.example>", "스타트업 대상 AI 워크숍 문의", "직원 25명 대상 반나절 워크숍이 가능할지 문의드립니다. 예산은 협의 가능합니다.", False, "client"),
 (4, "08:02", "YouTube Studio <no-reply@youtube.example>", "새 댓글 23개", "최근 영상에 새 댓글이 달렸습니다.", True, "notice"),
 (5, "20:17", "편집자 오세라 <sera.oh@edit-studio.example>", "ep42 촬영 원본 받았습니다", "A캠과 B캠 원본 모두 받았습니다. 오디오 싱크는 제가 맞추겠습니다.", True, "content"),
 (5, "15:44", "뉴스레터 플랫폼 <noreply@letterhub.example>", "예약 발송 확인", "목요일 오전 7시 예약 발송이 등록되었습니다.", True, "notice"),
 (5, "09:58", "박서연 <seoyeon.park@garam-logistics.example>", "킥오프 회의 감사합니다", "오늘 회의 감사했습니다. 회의록 정리되면 공유 부탁드립니다.", True, "client"),
 (6, "23:10", "구독자 한지우 <jiwoo.han@mail.example>", "뉴스레터 잘 보고 있습니다", "매주 기다리고 있어요. RAG 실습 편도 다뤄 주세요.", True, "audience"),
 (6, "12:30", "보안 알림 <security@account.example>", "새 기기에서 로그인", "새 기기에서 로그인이 감지되었습니다. 본인이 아니라면 비밀번호를 바꾸세요.", True, "admin"),
 (6, "10:05", "이준호 <junho@ai-community.example>", "밋업 일정 미리 공유", "12월 밋업 후보일은 첫째 주 목요일과 금요일입니다.", True, "proposal"),
 (7, "19:00", "이벤트 <promo@shopping.example>", "회원 전용 쿠폰 도착", "쿠폰을 확인하세요.", True, "spam"),
 (7, "14:26", "정다은 <daeun.jung@univ.example>", "11월 특강 일정 확정 요청", "11월 특강 날짜를 이번 달 안에 확정해 주실 수 있을까요?", True, "lecture"),
 (7, "11:11", "결제 알림 <billing@videotools.example>", "편집 툴 결제 실패", "결제 수단을 확인해 주세요.", False, "admin"),
 (7, "09:00", "세무사무소 <tax@hana-tax.example>", "분기 정산 일정", "분기 정산 일정을 안내드립니다.", True, "admin"),
]
mail = [{"id": f"m{i+1:03d}",
         "date": f"{(today - timedelta(days=d)).isoformat()}T{t}:00+09:00",
         "from": fr, "subject": sj, "snippet": sn, "read": rd, "label": lb}
        for i, (d, t, fr, sj, sn, rd, lb) in enumerate(M)]
(HERE / "mail_inbox.json").write_text(json.dumps({"account": "owner@moalab.example", "messages": mail}, ensure_ascii=False, indent=2), encoding="utf-8")

# 4) 캘린더 -------------------------------------------------------------------
def at(off, hm, dur=60):
    d = today + timedelta(days=off)
    s = datetime.combine(d, datetime.strptime(hm, "%H:%M").time())
    return s.isoformat(), (s + timedelta(minutes=dur)).isoformat()
E = [(-20, "10:00", 90, "가람물류 사전 통화", "client"), (-6, "14:00", 120, "가람물류 교육 킥오프 회의", "client"),
     (-5, "10:00", 240, "ep42 촬영", "content"), (-3, "09:30", 60, "주간 리뷰", "ops"),
     (-1, "19:00", 60, "뉴스레터 원고 마감", "content"), (0, "09:30", 30, "모닝 브리핑 확인", "ops"),
     (0, "15:00", 60, "ep42 1차 편집본 검토", "content"), (1, "11:00", 60, "세무사무소 자료 제출", "admin"),
     (2, "07:00", 15, "뉴스레터 발행", "content"), (4, "09:30", 60, "주간 리뷰", "ops"),
     (6, "14:00", 90, "가람물류 2차 미팅", "client"), (8, "10:00", 240, "ep43 촬영", "content"),
     (12, "13:00", 180, "Claude 업무자동화 특강", "lecture"), (13, "09:00", 60, "특강 피드백 정리", "lecture"),
     (16, "11:00", 60, "스타트업 워크숍 사전 미팅", "client"), (20, "19:00", 60, "뉴스레터 원고 마감", "content"),
     (24, "15:00", 120, "가람물류 1회차 교육", "client"), (31, "15:00", 120, "가람물류 2회차 교육", "client")]
ev = []
for i, (off, hm, dur, title, cat) in enumerate(E):
    s, e = at(off, hm, dur)
    ev.append({"id": f"e{i+1:03d}", "start": s + "+09:00", "end": e + "+09:00", "title": title, "category": cat})
(HERE / "calendar_events.json").write_text(json.dumps({"calendar": "모아랩 업무", "events": ev}, ensure_ascii=False, indent=2), encoding="utf-8")

print(f"기준일 {today} — youtube_daily.csv, newsletter_daily.csv, mail_inbox.json({len(mail)}건), calendar_events.json({len(ev)}건) 생성")
