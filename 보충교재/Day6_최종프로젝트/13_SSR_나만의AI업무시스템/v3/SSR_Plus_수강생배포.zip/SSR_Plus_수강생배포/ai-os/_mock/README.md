# 가상 외부 데이터 (_mock)

실습에서는 실제 API 대신 이 폴더를 '외부 서비스'로 씁니다.

| 파일 | 실제로는 | 내용 |
|---|---|---|
| `mail_inbox.json` | Gmail 커넥터 | 받은편지함 25건 |
| `calendar_events.json` | Google Calendar 커넥터 | 이번 달·다음 달 일정 |
| `youtube_daily.csv` | YouTube Data API | 누적 조회수·구독자 60일 |
| `newsletter_daily.csv` | 뉴스레터 플랫폼 API | 구독자·오픈율 60일 |

언제 실습하든 '오늘' 데이터가 있게 하려면 먼저 다시 만듭니다.

```
python3 _mock/generate_mock.py
```

실습이 끝나고 진짜로 쓰려면 수집 스크립트의 MOCK 설정을 끄고 커넥터나 API로 바꿉니다.
