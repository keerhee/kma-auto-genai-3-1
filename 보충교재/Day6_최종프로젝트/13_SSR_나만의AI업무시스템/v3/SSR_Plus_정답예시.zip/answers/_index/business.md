# business — 고객·견적·회의 길잡이

## 진행 중
- [[01_PROJECTS/garam-logistics-training/README|가람물류 AI 업무 교육]] — 2차 미팅 전 견적서·커리큘럼 송부
- 스타트업 워크숍 문의 (최유나) — [[inbox/untitled]] → 견적 필요

## 자주 찾는 원본
- 단가표: [[02_OPERATIONS/price-list]]
- 사업자 정보: [[02_OPERATIONS/business-info]]
- 지난 견적서: [[02_OPERATIONS/quotes/Q-2026-031]], [[02_OPERATIONS/quotes/Q-2026-032]]
- 회의록: [[02_OPERATIONS/meetings/kickoff-garam]]

## 하위 길잡이
- (고객이 늘면 _index/business-clients.md로 나눈다)
