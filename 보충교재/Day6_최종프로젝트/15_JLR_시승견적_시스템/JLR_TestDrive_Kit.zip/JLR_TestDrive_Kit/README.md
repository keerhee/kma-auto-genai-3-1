# JLR 시승·견적 실습 키트 (교육용 가상 자료)

이 폴더를 프로젝트 폴더(예: 문서/AX/jlr-experience) 안에 그대로 복사합니다. 파일은 Claude Code가 읽습니다.

| 폴더 | 내용 |
|---|---|
| reference-assets/ | 차량 이미지 12장, contact_sheet.jpg, image_sources.csv |
| data/ | 차량·트림·옵션·전시장·시승 차량·슬롯 규칙·직원·샘플 신청 CSV, 이미지 매핑 assets-map.json |
| docs/ | 동의서 문안, 견적 정책, 업무 규칙, 견적서 샘플 |

모든 가격·전시장·직원·고객은 가상입니다. 이메일은 example.com만 씁니다. 공식 제휴 서비스가 아닙니다.
