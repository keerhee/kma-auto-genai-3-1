# 시승·견적 업무 규칙 (교육용 가상)

## 신청 유형
- test_drive: 시승만. 전시장·시승 차량·날짜·시간 필수
- quote: 견적만. 시승 일정 입력란 숨김, 서버도 요구하지 않음. 시승 자리를 차지하지 않음
- both: 한 신청에 시승 업무와 견적 업무를 각각 생성. 상태는 따로 움직임

## 시승 상태
pending → confirmed → completed | no_show,  pending/confirmed → cancelled,  pending → expired(24시간 미확정)

## 견적 상태
new → contacting → preparing → issued → closed,  어느 단계에서나 cancelled(사유 필수)

## 시승 규칙
- 슬롯 규칙은 data/slot_rules.csv를 따른다 (60분 + 정비 30분)
- 한 슬롯에는 pending/confirmed 예약이 최대 1건 (DB 제약)
- maintenance 상태 시승 차량은 슬롯을 만들지 않는다
- 화면 시간은 Asia/Seoul, DB는 timestamptz

## 고객 안내 문구
- 접수 직후: "신청이 접수되었습니다. 담당자 확인 후 시승 일정이 확정됩니다."
- 슬롯 충돌: "다른 고객이 먼저 선택했습니다. 시간을 다시 선택해 주세요."
