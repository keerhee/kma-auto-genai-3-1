# course-forge — 강의를 만드는 스킬

**수강생이 자기 강의를 직접 만든다.** 강의 저장소([kma-auto-genai-3-1](https://github.com/keerhee/kma-auto-genai-3-1))의 Day 주제 하나를 고르면, Claude Code가 원본 덱과 데이터를 읽어 `/learn-<주제>`로 부르는 강의 스킬을 만든다. 만든 사람이 먼저 그 강의로 배우고, 결과 대시보드를 공개하고, 동료가 한 줄로 설치해 같은 수업을 듣게 한다.

```
 ① 만들기            ② 배우기               ③ 배포                   ④ 공유
 /course-forge  →   /learn-<주제>     →   결과 대시보드를        →   동료가 한 줄로 설치
 "Day5 예지보전"     내가 먼저 수강          GitHub Pages로 공개       npx skills add 내아이디/learn-<주제>
```

- **목표** AI Native — 교육 내용도 AI에게 맡겨 만들고, 나는 기준을 정하고 확인한다
- **방법** Skills as Curriculum — 만든 스킬이 강사가 되어 설명 → 실습 → 멈춤 → 확인·퀴즈를 진행한다
- **형식** 자율학습 — 강사 없이 내 속도로. 퀴즈와 수치 검증으로 스스로 점검한다

## 여덟 단계와 승인 세 번

| 단계 | 하는 일 | 내가 할 일 |
|---|---|---|
| 0 원본 고르기 | Day 폴더의 덱·데이터·정답 메모를 읽어 요약 | Day 고르기 |
| 1 커리큘럼 | 원본 6단계 흐름을 블록 표로 | **승인 ①** |
| 2 수업 | 블록마다 설명·붙여 넣을 프롬프트·확인할 것 | — |
| 3 퀴즈 | 원본 실습과제·함정으로 판단형 퀴즈 | — |
| 4 실습 MVP | 정답을 실제로 실행해 수치 확정 · 결과 대시보드 | **승인 ②** |
| 5 학습자 자료 | 데스크톱 앱 기준 GUIDE | — |
| 6 배포 | GitHub 저장소 + Pages 주소 | **승인 ③** |
| 7 배우기·공유 | 내가 먼저 수강 → 고치기 → 공유 메시지 → 개정 | 수강하고 공유하기 |

공개(승인 ③)는 내가 승인해야만 진행된다. 회사 내부 자료는 공개 저장소에 넣지 않는다.

## 설치

Claude Code 입력칸에 붙여 넣는다.

```
npx skills add <계정>/course-forge --agent claude-code --global --yes 를 실행해 줘
```

zip을 받았다면 "다운로드 폴더의 course-forge.zip을 풀어 .claude/skills 안의 폴더를 내 홈 폴더 .claude/skills로 복사해 줘"라고 시킨다. 새 세션에서 `/course-forge Day5 예지보전`.

## 이 스킬로 만든 강의 (실례)

| learn- 스킬 | 원본 | 결과물 |
|---|---|---|
| `learn-auto-pdm` | Day5 예지보전 — 단위 점검 · 평상 범위 · 노이즈/추세 · 파일럿 선정 | 예지보전 대시보드 · 4단 보고서 |
| `learn-github-dashboard` | Day3 경쟁사 재무 — 완성차 6사 USD 환산 | 재무 대시보드 GitHub Pages |

## 검수 스크립트

| 스크립트 | 하는 일 |
|---|---|
| `scripts/lint_blocks.py <패키지>` | 멈춤 문구, 블록 세 칸(설명·실행·퀴즈), 공식 문서 줄, 퀴즈 형식·정답 위치 분산, 파일 지도 경로 |
| `scripts/verify_numbers.py <패키지>` | 정답을 임시 폴더에서 다시 돌려 `expected.json`과 비교하고, 각 수치가 블록 본문에 실제로 있는지 확인 |
| `scripts/render_check.py <html>` | 대시보드 데스크톱·모바일 캡처, 콘솔 오류, 모바일 가로 넘침 |
| `scripts/publish_check.py <패키지>` | 토큰·키·주민번호·휴대폰 번호, 대용량 파일, README 출처 절, `.gitignore` |

## 이름 규칙

- 강의 스킬 이름은 `learn-<slug>`(영어 소문자·하이픈). 원본 Day 이름과 같지 않아도 된다. 예: Day5 예지보전 → `learn-auto-pdm`.

## 개정 이력

| 날짜 | 바뀐 점 |
|---|---|
| 2026-10-23 | v2 — 사용자를 강사에서 수강생으로 바꿈. 원본 강의 저장소를 읽는 0단계, 배우기·공유 7단계 추가. 사례를 자동차 과정으로 교체. v1은 `course-forge_v1`로 보관 |

## 출처

- 원본 강의: https://github.com/keerhee/kma-auto-genai-3-1 (능률협회 자동차산업과 생성형 AI 3-1)
- Skills as Curriculum 형식: AI Native Camp camp-1·camp-2 (github.com/ai-native-camp)
- Claude Code 문서: https://code.claude.com/docs/ko
