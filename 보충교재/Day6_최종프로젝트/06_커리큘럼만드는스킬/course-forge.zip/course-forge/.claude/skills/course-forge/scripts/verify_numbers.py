"""verify_numbers.py — 정답을 다시 실행해 expected.json과 블록 본문의 수치를 대조한다.

사용: python3 -I verify_numbers.py <패키지 폴더> [--out 결과.txt] [--no-run]
  forge/forge.json 의 answer 설정을 읽는다:
  {"answer": {"skill": "learn-x", "workdir": "assets/lab", "copy_to": "data",
              "cmd": "python3 {answers}/script.py", "expected": "assets/answers/expected.json"}}
  - workdir/expected 는 스킬 폴더 기준 경로. cmd 안의 {answers} 는 answers 폴더 절대경로로 바뀐다.
  - cmd 는 임시 폴더에서 실행되며, 실행 결과로 그 폴더에 expected.json 을 써야 한다.
종료 코드: 불일치가 있으면 1
"""
import argparse, json, shutil, subprocess, sys, tempfile
from pathlib import Path


def fmt(v, d):
    return f"{v:.{d}f}" if isinstance(v, (int, float)) and d is not None else str(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pkg")
    ap.add_argument("--out")
    ap.add_argument("--no-run", action="store_true", help="정답 재실행 없이 본문 등장만 확인")
    a = ap.parse_args()
    pkg = Path(a.pkg).resolve()
    man = json.loads((pkg / "forge" / "forge.json").read_text(encoding="utf-8"))
    ans = man["answer"]
    sd = pkg / ".claude" / "skills" / ans["skill"]
    stored_p = sd / ans["expected"]
    stored = json.loads(stored_p.read_text(encoding="utf-8"))["values"]
    lines, bad = [], 0

    if not a.no_run:
        with tempfile.TemporaryDirectory() as td:
            dst = Path(td) / ans.get("copy_to", "")
            shutil.copytree(sd / ans["workdir"], dst, dirs_exist_ok=True)
            cmd = ans["cmd"].replace("{answers}", str(sd / "assets" / "answers"))
            r = subprocess.run(cmd, shell=True, cwd=td, capture_output=True, text=True, timeout=600)
            if r.returncode != 0:
                print("정답 실행 실패:\n" + r.stderr[-2000:])
                sys.exit(1)
            fresh = json.loads((Path(td) / "expected.json").read_text(encoding="utf-8"))["values"]
        for k, s in stored.items():
            f = fresh.get(k)
            if f is None:
                lines.append(f"  [불일치] {k}: 재실행 결과에 없음"); bad += 1; continue
            d = s.get("decimals")
            ok = fmt(f["value"], d) == fmt(s["value"], d)
            if not ok:
                lines.append(f"  [불일치] {k}: 저장 {fmt(s['value'], d)} ≠ 재실행 {fmt(f['value'], d)}"); bad += 1
        lines.insert(0, f"재실행 대조: {len(stored)}개 중 일치 {len(stored) - bad}개")

    texts = {p.name: p.read_text(encoding="utf-8") for p in (sd / "references").glob("block*.md")}
    texts["GUIDE.md"] = (pkg / "GUIDE.md").read_text(encoding="utf-8") if (pkg / "GUIDE.md").exists() else ""
    miss = 0
    for k, s in stored.items():
        val = fmt(s["value"], s.get("decimals"))
        d0 = s.get("decimals")
        alts = {val}
        if isinstance(s["value"], (int, float)) and d0 is not None:
            alts.add(f"{s['value']:,.{d0}f}")   # 천 단위 쉼표 표기(836,900.55)도 인정
        where = [n for n, t in texts.items() if any(a in t for a in alts)]
        blk = s.get("block")
        want = f"block{blk}" if blk is not None else None
        if not where or (want and not any(n.startswith(want) for n in where)):
            lines.append(f"  [본문 누락] {k} = {val} (Block {blk})"); miss += 1
    lines.insert(1 if not a.no_run else 0, f"본문 등장: {len(stored)}개 중 {len(stored) - miss}개")
    rep = "\n".join(lines)
    print(rep)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(rep + "\n", encoding="utf-8")
    sys.exit(1 if (bad or miss) else 0)


if __name__ == "__main__":
    main()
