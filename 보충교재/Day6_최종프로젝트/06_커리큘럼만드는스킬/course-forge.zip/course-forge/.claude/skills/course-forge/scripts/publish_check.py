"""publish_check.py — 공개 저장소로 올리기 전에 패키지를 점검한다.

사용: python3 -I publish_check.py <패키지 폴더> [--out 결과.txt]
점검: 비밀값 패턴 · 개인정보 패턴 · 파일 크기 · README 출처 · .gitignore · 남은 임시 파일
종료 코드: 오류가 있으면 1 (경고는 0)
"""
import argparse, re, sys
from pathlib import Path

SECRET = {
    "GitHub 토큰": r"gh[pousr]_[A-Za-z0-9]{30,}",
    "AWS 키": r"AKIA[0-9A-Z]{16}",
    "API 키(sk-)": r"\bsk-[A-Za-z0-9_\-]{20,}",
    "개인 키": r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    "비밀번호 대입": r"(?i)(password|passwd|secret|api_key)\s*[=:]\s*['\"][^'\"]{6,}",
}
PII = {
    "주민등록번호": r"\b\d{6}-[1-4]\d{6}\b",
    "휴대전화": r"\b01[016789]-\d{3,4}-\d{4}\b",
}
TEXT_EXT = {".md", ".py", ".js", ".json", ".csv", ".txt", ".html", ".yml", ".yaml", ".bas", ".toml"}
SKIP_DIRS = {".git", "node_modules", "__pycache__"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pkg")
    ap.add_argument("--out")
    a = ap.parse_args()
    pkg = Path(a.pkg).resolve()
    errs, warns, n, total = [], [], 0, 0
    for f in pkg.rglob("*"):
        if f.is_dir() or any(part in SKIP_DIRS for part in f.relative_to(pkg).parts):
            continue
        n += 1
        size = f.stat().st_size; total += size
        r = str(f.relative_to(pkg))
        if size > 50 * 2**20:
            errs.append(f"{r}: {size/2**20:.1f}MB — GitHub 한도(50MB 권장) 초과")
        elif size > 10 * 2**20:
            warns.append(f"{r}: {size/2**20:.1f}MB — 큰 파일")
        if f.name in {"env_check.txt", ".env", ".DS_Store"}:
            warns.append(f"{r}: 올리지 않을 파일 — .gitignore 확인")
        if f.suffix.lower() in TEXT_EXT and size < 5 * 2**20:
            t = f.read_text(encoding="utf-8", errors="ignore")
            for k, pat in SECRET.items():
                if re.search(pat, t):
                    errs.append(f"{r}: {k} 패턴 발견")
            for k, pat in PII.items():
                if re.search(pat, t):
                    errs.append(f"{r}: {k} 패턴 발견")
            for em in set(re.findall(r"[\w.+-]+@[A-Za-z][\w-]*(?:\.[\w-]+)*\.[A-Za-z]{2,}\b", t)):
                if not re.search(r"noreply|example\.|anthropic\.com$", em):
                    warns.append(f"{r}: 이메일 {em} — 공개해도 되는지 확인")
    readme = pkg / "README.md"
    if not readme.exists():
        errs.append("README.md 없음")
    elif "출처" not in readme.read_text(encoding="utf-8"):
        errs.append("README.md에 데이터 '출처' 절 없음")
    if not (pkg / ".gitignore").exists():
        warns.append(".gitignore 없음")
    rep = [f"파일 {n}개 · {total/2**20:.1f}MB", f"오류 {len(errs)}건 · 경고 {len(warns)}건"]
    rep += ["  [오류] " + e for e in errs] + ["  [경고] " + w for w in sorted(set(warns))]
    print("\n".join(rep))
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text("\n".join(rep) + "\n", encoding="utf-8")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
