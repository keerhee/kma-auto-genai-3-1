// 사용법: helpers.js 뒤에 이어 붙여 실행한다 → cat helpers.js build.js > _run.js && node _run.js
// 이 파일은 learn-github-dashboard 매뉴얼(IV판) 실례다. 슬라이드 데이터만 바꿔 쓴다.
setSubject("{{강의명}}"); let SB = "{{workdir}}";
// =================================================================================
// IV판: 데스크톱 앱 기준 본문 + 수업 체험(Skills as Curriculum) + 부록 B(VS Code)
PLACE.cc = { name: "Code 탭 입력칸", hint: "Claude 데스크톱 앱 Code 탭 아래쪽 칸 — 붙여 넣고 Enter", color: C.blue };

// ---- 데스크톱 앱 화면 모형 (수업 체험용) --------------------------------------------
// msgs: {who:"me"|"claude"|"box"|"perm"|"quiz"|"done", lines:[], q, opts, sel, cmd}
function appScreen(s, x, y, w, h, msgs) {
  rect(s, x, y, w, h, C.white, { color: C.blue, width: 2 });
  rect(s, x, y, w, 0.34, "E5E7EB");
  ["FF5F57", "FEBC2E", "28C840"].forEach((c, i) => s.addShape(p.ShapeType.ellipse, { x: x + 0.12 + i * 0.2, y: y + 0.11, w: 0.13, h: 0.13, fill: { color: c }, line: { type: "none" } }));
  ["Chat", "Cowork", "Code"].forEach((t, i) => {
    const on = t === "Code", tx = x + w / 2 - 1.35 + i * 0.92;
    rect(s, tx, y + 0.04, 0.86, 0.26, on ? C.navy : "F3F4F6");
    s.addText(t, { x: tx, y: y + 0.04, w: 0.86, h: 0.26, align: "center", valign: "middle", fontFace: F, fontSize: 12, bold: on, color: on ? C.white : C.muted });
  });
  // 사이드바
  const sbw = 1.25;
  rect(s, x + 0.02, y + 0.34, sbw, h - 0.36, "F4F5F9");
  s.addText("+ 새 세션", { x: x + 0.1, y: y + 0.42, w: sbw - 0.16, h: 0.28, fontFace: F, fontSize: 12, bold: true, color: C.blue });
  rect(s, x + 0.08, y + 0.76, sbw - 0.12, 0.30, C.panelBlue);
  s.addText("kma-day3-site", { x: x + 0.12, y: y + 0.76, w: sbw - 0.2, h: 0.30, valign: "middle", fontFace: F, fontSize: 12, color: C.navy });
  // 채팅 영역
  const cx = x + sbw + 0.18, cw = w - sbw - 0.32;
  let cy = y + 0.48;
  const LH = 0.25; // 14pt 한 줄 높이
  msgs.forEach(m => {
    if (m.who === "me") {
      const n = m.lines.length, bw = Math.min(cw * 0.78, Math.max(1.6, Math.max(...m.lines.map(l => l.length)) * 0.13 + 0.4)), bh = n * LH + 0.16;
      rect(s, cx + cw - bw, cy, bw, bh, P.fill, { color: "E8C98F", width: 0.75 });
      s.addText(m.lines.map(l => ({ text: l, options: { breakLine: true } })), { x: cx + cw - bw + 0.1, y: cy + 0.04, w: bw - 0.2, h: bh - 0.08, valign: "middle", fontFace: F, fontSize: 14, color: P.ink });
      cy += bh + 0.12;
    } else if (m.who === "claude" || m.who === "done") {
      const n = m.lines.length, bh = n * LH + 0.06;
      s.addText("✻", { x: cx, y: cy, w: 0.22, h: 0.26, fontFace: F, fontSize: 13, color: "D97757" });
      s.addText(m.lines.map(l => ({ text: l, options: { breakLine: true } })), { x: cx + 0.24, y: cy, w: cw - 0.24, h: bh, valign: "top", fontFace: F, fontSize: 14, color: m.who === "done" ? C.green : C.body, bold: m.who === "done" });
      cy += bh + 0.10;
    } else if (m.who === "box") {
      const n = m.lines.length, bh = n * 0.23 + 0.44;
      rect(s, cx + 0.24, cy, cw - 0.24, bh, P.fill, { color: P.acc, width: 1 });
      rect(s, cx + 0.24, cy, cw - 0.24, 0.26, P.acc);
      s.addText("복사해서 붙여 넣을 글", { x: cx + 0.32, y: cy, w: cw - 0.4, h: 0.26, valign: "middle", fontFace: F, fontSize: 11.5, bold: true, color: C.white });
      s.addText(m.lines.map(l => ({ text: l, options: { breakLine: true } })), { x: cx + 0.34, y: cy + 0.30, w: cw - 0.44, h: bh - 0.34, valign: "top", fontFace: MONO, fontSize: 13, color: P.ink });
      cy += bh + 0.12;
    } else if (m.who === "perm") {
      const bh = 1.02;
      rect(s, cx + 0.24, cy, cw - 0.24, bh, C.white, { color: C.navy, width: 1.25 });
      s.addText(m.q, { x: cx + 0.36, y: cy + 0.06, w: cw - 0.5, h: 0.26, fontFace: F, fontSize: 14, bold: true, color: C.navy });
      rect(s, cx + 0.36, cy + 0.34, cw - 0.48, 0.28, "F3F4F6");
      s.addText(m.cmd, { x: cx + 0.42, y: cy + 0.34, w: cw - 0.6, h: 0.28, valign: "middle", fontFace: MONO, fontSize: 11, color: C.body });
      rect(s, cx + 0.36, cy + 0.68, 0.9, 0.26, C.navy);
      s.addText("허용", { x: cx + 0.36, y: cy + 0.68, w: 0.9, h: 0.26, align: "center", valign: "middle", fontFace: F, fontSize: 12, bold: true, color: C.white });
      rect(s, cx + 1.34, cy + 0.68, 0.9, 0.26, C.white, { color: C.hair, width: 1 });
      s.addText("거부", { x: cx + 1.34, y: cy + 0.68, w: 0.9, h: 0.26, align: "center", valign: "middle", fontFace: F, fontSize: 12, color: C.muted });
      if (m.hl) s.addShape(p.ShapeType.ellipse, { x: cx + 0.26, y: cy + 0.60, w: 1.1, h: 0.42, fill: { type: "none" }, line: { color: "D9534F", width: 2 } });
      cy += bh + 0.12;
    } else if (m.who === "quiz") {
      const qn = Math.ceil(m.q.length / 30), bh = qn * LH + 0.22 + m.opts.length * 0.34;
      rect(s, cx + 0.24, cy, cw - 0.24, bh, C.white, { color: C.blue, width: 1.25 });
      s.addText(m.q, { x: cx + 0.36, y: cy + 0.06, w: cw - 0.5, h: qn * LH + 0.06, valign: "top", fontFace: F, fontSize: 14, bold: true, color: C.navy });
      m.opts.forEach((o, i) => {
        const oy = cy + qn * LH + 0.16 + i * 0.34, on = i === m.sel;
        rect(s, cx + 0.36, oy, cw - 0.48, 0.30, on ? C.panelBlue : "F9FAFB", { color: on ? C.blue : C.hair, width: on ? 1.25 : 0.5 });
        s.addText((on ? "● " : "○ ") + o, { x: cx + 0.44, y: oy, w: cw - 0.6, h: 0.30, valign: "middle", fontFace: F, fontSize: 13.5, color: on ? C.navy : C.body, bold: on });
      });
      cy += bh + 0.12;
    }
  });
  // 입력 바
  const iy = y + h - 0.56;
  rect(s, cx, iy, cw, 0.44, C.white, { color: C.blue, width: 1.25 });
  s.addText("여기에 붙여 넣고 Enter", { x: cx + 0.12, y: iy, w: cw - 2.0, h: 0.44, valign: "middle", fontFace: F, fontSize: 12, color: C.muted });
  rect(s, cx + cw - 1.62, iy + 0.08, 1.02, 0.28, "F3F4F6");
  s.addText("Manual ▾", { x: cx + cw - 1.62, y: iy + 0.08, w: 1.02, h: 0.28, align: "center", valign: "middle", fontFace: F, fontSize: 11, color: C.body });
  s.addShape(p.ShapeType.ellipse, { x: cx + cw - 0.48, y: iy + 0.06, w: 0.32, h: 0.32, fill: { color: C.navy }, line: { type: "none" } });
  s.addText("↑", { x: cx + cw - 0.48, y: iy + 0.06, w: 0.32, h: 0.32, align: "center", valign: "middle", fontFace: F, fontSize: 12, bold: true, color: C.white });
}

// 진도 표시 (6장면 중 현재 위치)
const SCENES = ["시작", "설명", "실행", "완료", "확인·퀴즈", "다음"];
function progress(s, x, y, w, cur) {
  const n = SCENES.length, gw = w / n;
  SCENES.forEach((t, i) => {
    const on = i === cur, past = i < cur;
    rect(s, x + i * gw + 0.02, y, gw - 0.04, 0.50, on ? C.navy : past ? C.panelBlue : "F3F4F6");
    s.addText((i + 1) + " " + t, { x: x + i * gw, y, w: gw, h: 0.50, align: "center", valign: "middle", fontFace: F, fontSize: 13, bold: on, color: on ? C.white : past ? C.navy : C.muted });
  });
}

// 수업 체험 장면 슬라이드: 좌 앱 화면 / 우 설명 패널
function scene(o) {
  const s = np();
  const cy = head(s, "수업 체험 " + (o.n + 1) + "/6", 2.1, o.title, o.sub, pg());
  progress(s, LX, cy, CW, o.n);
  const top = cy + 0.64, bot = 6.94, aw = 7.15;
  appScreen(s, LX, top, aw, bot - top, o.msgs);
  const rx = LX + aw + 0.24, rw = CW - aw - 0.24;
  const th = bot - top - 1.30;
  panel(s, rx, top, rw, th, C.panelBlue, C.blue, "지금 일어나는 일", o.what, { fs: 16, valign: "top" });
  rect(s, rx, top + th + 0.14, rw, 1.16, P.fill, { color: P.acc, width: 1.25 });
  rect(s, rx, top + th + 0.14, rw, 0.40, P.acc);
  s.addText("내가 할 일", { x: rx + 0.16, y: top + th + 0.14, w: rw - 0.3, h: 0.40, valign: "middle", fontFace: F, fontSize: 16, bold: true, color: C.white });
  s.addText(o.todo, { x: rx + 0.18, y: top + th + 0.58, w: rw - 0.36, h: 0.68, valign: "top", fontFace: F, fontSize: 17, bold: true, color: P.ink });
}

// 화면 신호 카드(작은 모형 + 뜻 + 할 일)
function signalCell(s, x, y, w, h, title, drawMock, mean, todo) {
  rect(s, x, y, w, h, C.white, { color: C.hair, width: 1 });
  rect(s, x, y, w, 0.46, C.navy);
  s.addText(title, { x: x + 0.16, y, w: w - 0.3, h: 0.46, valign: "middle", fontFace: F, fontSize: 17, bold: true, color: C.white });
  const mw = 2.95;
  drawMock(x + 0.16, y + 0.62, mw, h - 0.78);
  s.addText([
    { text: "뜻", options: { bold: true, color: C.blue, breakLine: true } },
    { text: mean, options: { color: C.body, breakLine: true, paraSpaceAfter: 6 } },
    { text: "내가 할 일", options: { bold: true, color: P.acc, breakLine: true } },
    { text: todo, options: { color: C.navy, bold: true } },
  ], { x: x + mw + 0.32, y: y + 0.58, w: w - mw - 0.44, h: h - 0.70, valign: "top", fontFace: F, fontSize: 16, lineSpacingMultiple: 1.05 });
}

// =================================================================================
// 1. 표지
{ const s = np(); pg();
  cover(s, { chip: "DAY 3 확장 실습 · 따라 하기 매뉴얼", chipW: 4.4,
    title: "내 재무 대시보드를 GitHub에 공개하기",
    sub1: "Claude 데스크톱 앱으로 따라 하는 Skills as Curriculum 실습",
    sub2: "완성차 6사 공시 재무 → 차트 대시보드 → 내 주소 https://아이디.github.io/…",
    desc: "명령어를 외울 필요는 없다. 우리가 하는 일은 두 가지 —\n① 노란 상자의 글을 복사해 붙여 넣기  ② 화면이 맞게 나왔는지 확인하기." }); }

// 2. 오늘 만들 것
{ const s = np();
  figurePanelSlide(s, { chip: "오늘의 목표", chipW: 1.8, pageNo: pg(),
    title: "수업이 끝나면 내 대시보드가 인터넷 주소로 열린다",
    sub: "휴대폰으로 https://내아이디.github.io/auto-finance-dashboard/ 를 연다",
    panelTitle: "완성하면", tint: "green",
    lines: ["내 GitHub 저장소", "6사 매출·이익률 차트", "공시 출처 표", "부품사 조기경보", "휴대폰에서도 열림"],
    path: "preview.png", ratio: 1200 / 1080 }); }

// 3. 수업 방식
{ const s = np();
  const cy = head(s, "수업 방식", 1.6, "스킬이 강사가 되어 AI Native 방식을 가르친다", "AI Native는 도착점, Skills as Curriculum은 배우는 방법이다. 형식은 자율학습이다", pg());
  const cards = [
    { k: "목표", t: "AI Native", d: "AI에게 맡기는 것이\n기본인 방식으로 일한다", eg: "목표 정하기 → 맡기기 → 확인\n나는 검증하는 사람", col: C.navy, fill: C.panelBlue },
    { k: "방법", t: "Skills as Curriculum", d: "교재·슬라이드 대신\n스킬이 수업을 진행한다", eg: "설명 → 실습 → 완료 → 퀴즈\n강사 없이 내 속도로", col: C.blue, fill: C.panelBlue },
    { k: "결과", t: "내 결과물", d: "공부만 하고 끝나지 않고\n블록마다 결과가 남는다", eg: "내 저장소 · 내 대시보드\n내 사이트 주소", col: C.green, fill: C.panelGreen },
  ];
  const gap = 0.3, w = (CW - gap * 2) / 3, y = cy + 0.1, h = 3.45;
  cards.forEach((c, i) => {
    const x = LX + i * (w + gap);
    rect(s, x, y, w, h, c.fill); rect(s, x, y, w, 0.95, c.col);
    s.addText(c.k, { x, y: y + 0.06, w, h: 0.36, align: "center", fontFace: F, fontSize: 16, color: C.coverSub });
    s.addText(c.t, { x, y: y + 0.40, w, h: 0.50, align: "center", valign: "middle", fontFace: F, fontSize: 22, bold: true, color: C.white });
    s.addText(c.d, { x: x + 0.2, y: y + 1.12, w: w - 0.4, h: 0.95, align: "center", valign: "top", fontFace: F, fontSize: 20, bold: true, color: C.navy });
    s.addText(c.eg, { x: x + 0.2, y: y + 2.2, w: w - 0.4, h: 1.1, align: "center", valign: "top", fontFace: F, fontSize: 17, color: C.body });
    if (i < 2) s.addText("▶", { x: x + w + 0.02, y: y + 1.45, w: 0.26, h: 0.5, align: "center", valign: "middle", fontFace: F, fontSize: 18, color: C.muted });
  });
  banner(s, "한 줄 정리 — 자율학습 형식으로, AI에게 일을 맡기는 방식(AI Native)을 몸에 익힌다", y + h + 0.3); }

// 4. 읽는 법
{ const s = np();
  const cy = head(s, "읽는 법", 1.5, "모든 단계는 어디 → 입력 → 출력 → 피드백 네 칸으로 읽는다", "이 매뉴얼의 단계 슬라이드는 모두 같은 모양이다. 번호 순서대로 보면 된다", pg());
  const cards = [
    { n: "①", t: "어디", d: "어느 창에 입력하나", eg: "Code 탭 입력칸 · 브라우저", col: "374151", fill: "EEF0F3" },
    { n: "②", t: "입력", d: "무엇을 넣나\n(복사 → 붙여 넣기 → Enter)", eg: "노란 상자 = 프롬프트\n파란 머리 상자 = 누를 것·칠 것", col: P.acc, fill: P.fill },
    { n: "③", t: "출력", d: "무엇이 나오나\n(화면에 보이는 모습)", eg: "칸 안의 모습 =\n내 화면에 나올 모습", col: C.navy, fill: C.panelGray },
    { n: "④", t: "피드백", d: "맞게 됐나 확인\n아니면 무엇을 하나", eg: "성공 ▸ 이렇게 보이면 OK\n막히면 ▸ 이렇게 한다", col: C.green, fill: C.panelGreen },
  ];
  const gap = 0.22, w = (CW - gap * 3) / 4, y = cy + 0.1, h = 3.55;
  cards.forEach((c, i) => {
    const x = LX + i * (w + gap);
    rect(s, x, y, w, h, c.fill); rect(s, x, y, w, 0.72, c.col);
    s.addText(c.n + " " + c.t, { x, y, w, h: 0.72, align: "center", valign: "middle", fontFace: F, fontSize: 24, bold: true, color: C.white });
    s.addText(c.d, { x: x + 0.15, y: y + 0.88, w: w - 0.3, h: 1.05, align: "center", valign: "top", fontFace: F, fontSize: 18, bold: true, color: C.navy });
    s.addText(c.eg, { x: x + 0.15, y: y + 2.05, w: w - 0.3, h: 1.35, align: "center", valign: "top", fontFace: F, fontSize: 16, color: C.body });
    if (i < 3) s.addText("▶", { x: x + w - 0.02, y: y + 1.5, w: 0.26, h: 0.5, align: "center", valign: "middle", fontFace: F, fontSize: 18, color: C.muted });
  });
  banner(s, "④ 피드백이 '성공'이 아니면 다음 단계로 넘어가지 않는다 — 막히면 칸의 지시대로 한다", y + h + 0.3); }

// 5. 두 개의 장소
{ const s = np();
  const cy = head(s, "두 개의 장소", 1.9, "입력하는 곳은 Code 탭 입력칸과 브라우저 두 군데다", "이 매뉴얼은 Claude 데스크톱 앱 기준이다. VS Code로 하는 사람은 부록 B를 본다", pg());
  const h = 4.05, y = cy + 0.05, w1 = 7.0, w2 = CW - w1 - 0.3;
  screenMock(s, LX, y, w1, h, "app", "Claude 데스크톱 앱", ["Local · kma-day3-site", "", "대부분의 입력은 여기에 한다.", "프롬프트를 붙여 넣고 Enter,", "허용 질문엔 허용, 퀴즈는 눌러서 고른다."]);
  screenMock(s, LX + w1 + 0.3, y, w2, h, "browser", "브라우저", ["GitHub 가입·로그인 승인,", "완성된 내 사이트 확인.", "주소가 정확히", "github.com 인지 본다."]);
  s.addText([{ text: "Code 탭 입력칸", options: { bold: true, color: C.blue } }, { text: " = 파란 띠", options: { color: C.body } }], { x: LX, y: y + h + 0.1, w: w1, h: 0.4, align: "center", fontFace: F, fontSize: 18 });
  s.addText([{ text: "브라우저", options: { bold: true, color: C.green } }, { text: " = 초록 띠", options: { color: C.body } }], { x: LX + w1 + 0.3, y: y + h + 0.1, w: w2, h: 0.4, align: "center", fontFace: F, fontSize: 18 }); }

// 6. 용어
{ const s = np();
  const cy = head(s, "용어", 1.2, "꼭 알아야 할 용어는 여섯 개다", "나머지 용어는 나올 때마다 슬라이드에서 설명한다", pg());
  wtable(s, [
    ["용어", "쉽게 말하면"],
    ["Claude Code", "내 컴퓨터 파일을 직접 읽고 만드는 Claude. 데스크톱 앱의 Code 탭이 바로 그것"],
    ["스킬", "Claude Code에 설치하는 '수업 진행 매뉴얼'. 설치하면 Claude가 선생님처럼 진행"],
    ["GitHub", "내 파일을 인터넷에 올려 두는 사이트 (개발자들의 구글 드라이브)"],
    ["저장소 (repository)", "GitHub에 만든 프로젝트 폴더 하나"],
    ["커밋 / 푸시", "커밋 = 내 컴퓨터에 세이브,  푸시 = GitHub에 업로드"],
    ["GitHub Pages", "저장소의 index.html을 웹사이트로 공개해 주는 무료 기능"],
  ], LX, cy + 0.05, CW, [3.2, CW - 3.2], 0.66); }

// 7. 준비
{ const s = np();
  const cy = head(s, "준비", 1.2, "시작 전에 준비물 다섯 가지와 약속 세 가지를 확인한다", "약속은 내 계정과 회사 자료를 지키기 위한 것이다", pg());
  panel(s, LX, cy + 0.05, 5.6, 4.75, C.panelBlue, C.blue, "준비물", [
    "내 컴퓨터 (맥 macOS 13+ 또는 윈도우 10/11)", "Claude 유료 계정 (Pro·Max·Team)", "개인 이메일 (GitHub 가입용)", "kma-day3-github-skill.zip", "인터넷"]);
  panel(s, LX + 5.84, cy + 0.05, CW - 5.84, 4.75, C.panelGreen, C.green, "약속 세 가지", [
    "비밀번호·일회용 코드는 GitHub 공식 사이트에만 입력한다 — 대화창·단톡방·선생님에게 보내지 않는다",
    "오늘 저장소는 누구나 보는 공개 저장소다 — 회사 자료·개인정보는 넣지 않는다",
    "모르면 멈추고 묻는다 — 그냥 '허용'을 누르지 않는다"]); }

// ===== PART 1 설치 =====
{ const s = np(); divider(s, { num: "01", sec: "STEP 1–2 · 설치", secW: 3.4, title: "데스크톱 앱과 수업 스킬 설치", desc: "윈도우 Git → Claude 데스크톱 앱 → 스킬 설치 (처음 한 번, 약 15분)", pageNo: pg() }); }

iof({ chip: "STEP 1-0 · 윈도우", chipW: 2.6, title: "윈도우는 Git for Windows를 먼저 설치한다", sub: "GitHub에 올리려면 git이 필요하다. 맥은 건너뛴다 — 필요하면 Block 0에서 Claude가 설치한다",
  where: "browser", whereText: "주소창에 git-scm.com/downloads/win 입력",
  inKind: "key", inLabel: "브라우저 → 설치 파일",
  input: ["1. git-scm.com/downloads/win 열기", "2. 맨 위 설치 파일(64-bit) 내려받기", "3. 내려받은 파일 실행", "4. 설정은 바꾸지 말고 Next 계속", "5. Install → Finish"],
  output: ["Git 2.xx Setup", "", "Completing the Git Setup Wizard", "            [ Finish ]"], dark: false,
  ok: ["Finish 화면까지 갔다"], ng: ["'이 앱이 변경하도록 허용?' → 예"] });

iof({ chip: "STEP 1-1", title: "Claude 데스크톱 앱을 설치하고 로그인한다", sub: "앱 안에 Claude Code가 들어 있어 따로 설치할 것이 없다",
  where: "browser", whereText: "주소창에 claude.com/download 입력 → 설치 후에는 앱 화면",
  inKind: "key", inLabel: "브라우저 → 앱",
  input: ["1. claude.com/download 열기", "2. 내 운영체제(맥·윈도우)용 설치 파일 받기", "3. 설치 파일 실행", "   맥: 앱을 Applications 폴더로 끌어 놓기", "4. Claude 앱 실행", "5. Claude 계정으로 로그인"],
  output: ["Claude", "", "      Chat   Cowork   Code", "", "  무엇을 도와드릴까요?"], dark: false,
  ok: ["앱 위쪽 가운데에 Chat · Cowork · Code"], ng: ["로그인 창이 안 뜨면 앱을 껐다 켠다"] });

iof({ chip: "STEP 1-2", title: "Code 탭에서 내 컴퓨터 폴더를 고른다", sub: "Local은 내 컴퓨터의 파일로 일한다는 뜻이다. 처음에는 홈 폴더를 고른다",
  where: "app", inKind: "key", inLabel: "앱에서 순서대로 누른다",
  input: ["1. 위쪽 가운데 Code 탭", "2. Local 선택", "3. 폴더 선택", "   맥: 사람 모양 아이콘 폴더(홈)", "   윈도우: C:\\Users\\내이름", "4. 아래 입력칸이 보이면 준비 끝"],
  output: ["Local · 내이름", "", "  > 무엇을 할까요?", "                         [Manual ▾] [↑]"], dark: false,
  ok: ["아래에 입력칸 · 오른쪽에 모드 선택기"], ng: ["'업그레이드' 안내 → 유료 계정이 필요하다"] });

iof({ chip: "STEP 2-1", title: "zip 파일 설치는 Claude Code에게 시킨다", sub: "kma-day3-github-skill.zip을 다운로드 폴더에 그대로 둔다. 압축은 안 풀어도 된다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["내 다운로드 폴더에 있는", "kma-day3-github-skill.zip 압축을 풀고,", "그 안의 .claude/skills 폴더 안에 있는 폴더들을", "내 홈 폴더의 .claude/skills 폴더로 복사해 줘.", "(없으면 만들어 줘)", "끝나면 그 안에 day3-github-dashboard 폴더가", "있는지 확인해 줘."],
  output: ["명령을 실행할까요?  [허용] [거부]", "...", "✔ day3-github-dashboard 설치 확인"], dark: false,
  ok: ["'설치 확인' 메시지 · 허용 질문엔 허용"], ng: ["zip을 못 찾으면 '다운로드 폴더 파일 목록 보여 줘'"] });

iof({ chip: "STEP 2-2", title: "새 세션에서 /day3 목록이 보이면 설치가 끝난 것이다", sub: "Claude Code는 세션을 시작할 때 스킬을 읽는다. 그래서 새 세션을 연다",
  where: "app", whereText: "왼쪽 사이드바의 새 세션(+)",
  inKind: "key", inLabel: "새 세션 → /day3 입력",
  input: ["1. 왼쪽 사이드바 새 세션(+)", "2. Local → 홈 폴더", "3. 입력칸에 /day3 까지만 친다", "   (또는 + 버튼 → Slash commands)", "4. 목록이 뜰 때까지 기다린다"],
  output: ["> /day3", "  /day3-github-dashboard", "    Day 3 확장 실습 — 완성차 6사…"], dark: false,
  ok: ["목록에 /day3-github-dashboard"], ng: ["안 보이면 STEP 2-1을 다시 붙여 넣는다"] });

// ===== PART 2 수업 체험 =====
{ const s = np(); divider(s, { num: "02", sec: "수업 체험", secW: 3.0, title: "Skills as Curriculum 맛보기", desc: "Block 2(첫 저장소)가 실제로 진행되는 모습을 여섯 장면으로 따라간다", pageNo: pg() }); }

{ const s = np();
  const cy = head(s, "수업 사이클", 1.9, "블록 하나는 여섯 장면으로 진행되고 블록마다 반복된다", "다음 여섯 장은 Block 2 '첫 저장소 만들기'가 실제 앱 화면에서 진행되는 모습이다", pg());
  stepCards(s, [
    { title: "1 시작", sub: "내가 한다", body: "스킬 이름 입력\n블록 고르기", tint: "green" },
    { title: "2 설명", sub: "Claude", body: "개념 설명\n노란 상자 제시\n그리고 멈춤" },
    { title: "3 실행", sub: "내가 → Claude", body: "붙여 넣기\nClaude 실행\n허용 누르기", tint: "green" },
    { title: "4 완료", sub: "내가 한다", body: "결과를 보고\n'완료' 입력", tint: "green" },
    { title: "5 확인·퀴즈", sub: "Claude", body: "내 파일 점검\n판단형 퀴즈" },
    { title: "6 다음", sub: "둘이 함께", body: "해설 듣기\n다음 블록 →\n다시 2부터" },
  ], cy + 0.1, 3.55);
  banner(s, "핵심 — Claude는 2 설명 뒤에 멈춘다. 내가 붙여 넣고 '완료'를 쳐야 수업이 진행된다", cy + 3.95); }

scene({ n: 0, title: "스킬을 부르면 Claude가 시작 블록을 묻는다",
  sub: "작업 폴더(kma-day3-site)를 연 세션에서 시작한다",
  msgs: [
    { who: "me", lines: ["/day3-github-dashboard"] },
    { who: "claude", lines: ["이 수업은 Skills as Curriculum 방식입니다.", "스킬이 강사가 되어 설명 → 실습 → 퀴즈를 진행합니다."] },
    { who: "quiz", q: "어디서부터 시작할까요?", opts: ["Block 0: 준비", "Block 2: 첫 저장소", "Block 3: 대시보드", "Block 4: Pages 공개"], sel: 1 },
  ],
  what: ["스킬 이름을 넣으면 수업이 열린다", "Claude가 수업 방식을 소개한다", "블록 카드 중 하나를 고른다 (처음이면 Block 0)"],
  todo: "/day3-github-dashboard 입력 → 블록을 눌러 고른다" });

scene({ n: 1, title: "Claude가 설명하고 붙여 넣을 글을 준 뒤 멈춘다",
  sub: "이 상태에서 기다리면 아무 일도 일어나지 않는다. 내 차례다",
  msgs: [
    { who: "claude", lines: ["📖 공식 문서: cli.github.com/manual/gh_repo_create", "커밋 = 내 컴퓨터에 세이브, 푸시 = GitHub에 업로드.", "둘 다 해야 GitHub 화면이 바뀝니다."] },
    { who: "box", lines: ["이 폴더를 GitHub에 올리자.", "1. README.md를 만들어 줘 …", "4. gh로 auto-finance-dashboard 공개 저장소를", "   만들고 푸시해 줘. …"] },
    { who: "claude", lines: ["👆 위 글을 붙여 넣어 실행해 보세요.", "결과를 확인했으면 '완료'라고 입력해 주세요."] },
  ],
  what: ["개념을 짧게 설명한다", "노란 상자 = 내가 복사할 글", "'완료라고 입력' = 멈춤 신호"],
  todo: "노란 상자 글을 드래그해서 복사한다" });

scene({ n: 2, title: "글을 붙여 넣으면 Claude가 실행하고 허용을 묻는다",
  sub: "허용 카드에는 Claude가 하려는 일이 한 줄로 적혀 있다. 읽고 누른다",
  msgs: [
    { who: "me", lines: ["이 폴더를 GitHub에 올리자.", "1. README.md를 만들어 줘 … (붙여 넣은 글)"] },
    { who: "claude", lines: ["올라갈 파일: README.md · .gitignore · data/ 4개", "개인정보·비밀번호 없음 ✓"] },
    { who: "perm", q: "명령을 실행할까요?", cmd: "gh repo create auto-finance-dashboard --public --push", hl: true },
  ],
  what: ["붙여 넣은 글이 오른쪽 말풍선", "Claude가 올라갈 파일을 점검", "실행 전에 허용 카드 (여러 번 나올 수 있다)"],
  todo: "입력칸에 Ctrl+V(맥 ⌘+V) → Enter → [허용]" });

scene({ n: 3, title: "Claude가 결과를 보고하면 확인하고 '완료'를 입력한다",
  sub: "Claude는 내가 '완료'를 칠 때까지 다음으로 넘어가지 않는다",
  msgs: [
    { who: "done", lines: ["✓ README.md, .gitignore 만들기", "✓ 첫 커밋: 데이터와 README", "✓ 저장소 auto-finance-dashboard 생성·푸시"] },
    { who: "claude", lines: ["브라우저로 저장소를 열었습니다.", "완료라고 입력하면 퀴즈로 넘어갑니다."] },
    { who: "me", lines: ["완료"] },
  ],
  what: ["한 일을 체크 목록으로 보고", "브라우저에 내 저장소가 열린다", "README가 보이면 '완료'"],
  todo: "브라우저에서 내 저장소 확인 → '완료' 입력" });

scene({ n: 4, title: "Claude가 내 결과를 점검한 뒤 판단형 퀴즈를 낸다",
  sub: "퀴즈는 외우기 문제가 아니다. 방금 한 일의 원리를 묻는다",
  msgs: [
    { who: "claude", lines: ["결과를 확인했습니다.", "✓ README와 data/ 폴더  ✓ env_check.txt 제외"] },
    { who: "quiz", q: "동료가 'README를 고치고 커밋했는데 GitHub 화면은 그대로'라고 한다. 가장 가능성 높은 원인은?", opts: ["커밋만 하고 푸시를 안 했다", "GitHub 서버가 고장 났다", "README는 원래 고칠 수 없다"], sel: -1 },
  ],
  what: ["Claude가 내 파일을 직접 점검", "빠진 것이 있으면 고칠 글을 준다", "퀴즈 카드 — 점수는 없다"],
  todo: "보기 하나를 눌러 고른다" });

scene({ n: 5, title: "해설을 듣고 다음 블록으로 넘어간다",
  sub: "다음 블록을 고르면 장면 2(설명)부터 다시 시작한다",
  msgs: [
    { who: "me", lines: ["커밋만 하고 푸시를 안 했다"] },
    { who: "claude", lines: ["정답입니다. 커밋은 내 컴퓨터에 버전을 저장할 뿐이고,", "GitHub에 반영하려면 푸시해야 합니다.", "'커밋하고 푸시해 줘'처럼 함께 말하면 됩니다."] },
    { who: "quiz", q: "다음 블록으로 갈까요?", opts: ["Block 3: 대시보드 만들기", "잠깐 쉬기"], sel: -1 },
  ],
  what: ["오답이어도 해설로 배운다", "쉬었다 와도 세션이 남아 있다", "다음 블록 → 다시 장면 2부터"],
  todo: "다음 블록을 눌러 고른다 → 장면 2부터 반복" });

// 화면 신호 4가지 (예시 화면)
{ const s = np();
  const cy = head(s, "화면 신호", 1.6, "수업 중 화면에 뜨는 신호는 네 가지뿐이다", "각 신호가 실제로 어떻게 보이는지와 무엇을 누르면 되는지 정리했다", pg());
  const gw = (CW - 0.24) / 2, gh = (6.94 - cy - 0.2) / 2;
  const cells = [
    [LX, cy, "① 허용 카드", (x, y, w, h) => {
      rect(s, x, y, w, h, C.white, { color: C.navy, width: 1.25 });
      s.addText("명령을 실행할까요?", { x: x + 0.1, y: y + 0.08, w: w - 0.2, h: 0.28, fontFace: F, fontSize: 13, bold: true, color: C.navy });
      rect(s, x + 0.1, y + 0.42, w - 0.2, 0.30, "F3F4F6");
      s.addText("git push origin main", { x: x + 0.16, y: y + 0.42, w: w - 0.3, h: 0.30, valign: "middle", fontFace: MONO, fontSize: 12, color: C.body });
      rect(s, x + 0.1, y + h - 0.44, 1.0, 0.32, C.navy); s.addText("허용", { x: x + 0.1, y: y + h - 0.44, w: 1.0, h: 0.32, align: "center", valign: "middle", fontFace: F, fontSize: 13, bold: true, color: C.white });
      rect(s, x + 1.2, y + h - 0.44, 1.0, 0.32, C.white, { color: C.hair, width: 1 }); s.addText("거부", { x: x + 1.2, y: y + h - 0.44, w: 1.0, h: 0.32, align: "center", valign: "middle", fontFace: F, fontSize: 13, color: C.muted });
    }, "파일·명령 실행 전에 묻는다", "한 줄 읽고 [허용]"],
    [LX + gw + 0.24, cy, "② 질문 카드 (퀴즈·선택)", (x, y, w, h) => {
      rect(s, x, y, w, h, C.white, { color: C.blue, width: 1.25 });
      s.addText("어디서부터 시작할까요?", { x: x + 0.1, y: y + 0.08, w: w - 0.2, h: 0.28, fontFace: F, fontSize: 13, bold: true, color: C.navy });
      ["Block 0: 준비", "Block 2: 첫 저장소"].forEach((t, i) => { rect(s, x + 0.1, y + 0.46 + i * 0.38, w - 0.2, 0.32, i === 0 ? C.panelBlue : "F9FAFB", { color: i === 0 ? C.blue : C.hair, width: 0.75 }); s.addText((i === 0 ? "● " : "○ ") + t, { x: x + 0.18, y: y + 0.46 + i * 0.38, w: w - 0.3, h: 0.32, valign: "middle", fontFace: F, fontSize: 12.5, color: C.navy }); });
    }, "퀴즈·블록을 고르게 한다", "보기를 눌러 고른다"],
    [LX, cy + gh + 0.2, "③ 컴퓨터 권한 창", (x, y, w, h) => {
      rect(s, x, y, w, h, "EAF2FB", { color: "5B8DD6", width: 1.25 });
      s.addText("사용자 계정 컨트롤", { x: x + 0.1, y: y + 0.08, w: w - 0.2, h: 0.28, fontFace: F, fontSize: 12.5, bold: true, color: C.navy });
      s.addText("이 앱이 디바이스를 변경할 수 있도록\n허용하시겠어요?", { x: x + 0.1, y: y + 0.38, w: w - 0.2, h: 0.55, fontFace: F, fontSize: 12, color: C.body });
      rect(s, x + w - 2.2, y + h - 0.44, 1.0, 0.32, C.blue); s.addText("예", { x: x + w - 2.2, y: y + h - 0.44, w: 1.0, h: 0.32, align: "center", valign: "middle", fontFace: F, fontSize: 13, bold: true, color: C.white });
      rect(s, x + w - 1.1, y + h - 0.44, 1.0, 0.32, C.white, { color: C.hair, width: 1 }); s.addText("아니요", { x: x + w - 1.1, y: y + h - 0.44, w: 1.0, h: 0.32, align: "center", valign: "middle", fontFace: F, fontSize: 13, color: C.muted });
    }, "도구를 설치할 때 컴퓨터가 묻는다", "[예] · 맥은 비밀번호"],
    [LX + gw + 0.24, cy + gh + 0.2, "④ 일하는 중", (x, y, w, h) => {
      rect(s, x, y, w, h, C.white, { color: C.hair, width: 1 });
      s.addText("✻ 작업 중… (12초)", { x: x + 0.12, y: y + 0.12, w: w - 0.2, h: 0.3, fontFace: F, fontSize: 13, color: "D97757", bold: true });
      s.addText("build_site.py 실행\ndata/summary_usd.csv 저장", { x: x + 0.12, y: y + 0.46, w: w - 0.2, h: 0.55, fontFace: MONO, fontSize: 11.5, color: C.body });
      s.addShape(p.ShapeType.ellipse, { x: x + w - 0.5, y: y + h - 0.48, w: 0.36, h: 0.36, fill: { color: C.navy }, line: { type: "none" } });
      s.addText("■", { x: x + w - 0.5, y: y + h - 0.48, w: 0.36, h: 0.36, align: "center", valign: "middle", fontFace: F, fontSize: 11, color: C.white });
      s.addText("정지", { x: x + w - 1.25, y: y + h - 0.46, w: 0.7, h: 0.32, align: "right", valign: "middle", fontFace: F, fontSize: 12, color: C.muted });
    }, "Claude가 일하는 중", "기다린다 · 엉뚱하면 정지"],
  ];
  cells.forEach(([x, y, t, mock, mean, todo]) => signalCell(s, x, y, gw, gh, t, mock, mean, todo)); }

// ===== PART 3 블록 =====
{ const s = np(); divider(s, { num: "03", sec: "BLOCK 0–1 · 준비", secW: 3.6, title: "작업 폴더와 GitHub 연결", desc: "도구 설치 → GitHub 가입 → 로그인 연결", pageNo: pg() }); }

iof({ chip: "BLOCK 0 · ①", chipW: 2.3, title: "작업 폴더와 도구 준비는 프롬프트 하나로 끝난다", sub: "Claude가 실제 경로를 채운 상자를 보여 준다. 그 상자를 복사한다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["홈 폴더 아래에 kma-day3-site 폴더를 만들고,", "그 안에 data 폴더를 만들어 줘.", "(스킬 폴더)/assets/lab 안의 csv 3개와", "README.md를 data 폴더로 복사해 줘.", "", "그다음 아래를 점검해서 env_check.txt로 저장해 줘.", "- 운영체제", "- git 버전, user.name / user.email 설정 여부", "- gh(GitHub CLI) — 없으면 설치해 줘", "- python, pandas — 없으면 설치해 줘", "- data 폴더의 파일 목록", "항목마다 OK / 조치 필요를 표시해 줘."],
  output: ["git      OK  2.47", "gh       OK  (방금 설치)", "pandas   OK", "data     OK  csv 3개 + README"],
  ok: ["env_check.txt 항목이 모두 OK"], ng: ["권한 창이 뜨면 [예] · 맥은 비밀번호", "이름·이메일을 물으면 답한다"] });

iof({ chip: "BLOCK 0 · ②", chipW: 2.3, title: "작업 폴더로 새 세션을 열어 수업을 이어 간다", sub: "이 폴더가 그대로 GitHub 저장소가 된다. 세션마다 폴더가 정해진다",
  where: "app", whereText: "왼쪽 사이드바의 새 세션(+)",
  inKind: "key", inLabel: "새 세션 → 폴더 → 수업 다시 시작",
  input: ["1. 왼쪽 사이드바 새 세션(+)", "2. Local → 폴더 선택", "3. 홈 폴더 안의 kma-day3-site 선택", "4. 입력칸에 /day3-github-dashboard", "5. 시작 블록에서 Block 1 선택"],
  output: ["kma-day3-site", "", "어디서부터 시작할까요?", " ● Block 1: GitHub 연결"], dark: false,
  ok: ["사이드바 세션 이름이 kma-day3-site"], ng: ["폴더가 안 보이면 Block 0 ①을 다시 실행"] });

iof({ chip: "BLOCK 1 · ①", chipW: 2.3, title: "GitHub 가입은 브라우저에서 직접 한다", sub: "계정이 이미 있으면 건너뛴다. 아이디는 사이트 주소에 그대로 들어간다",
  where: "browser", whereText: "주소창에 github.com/signup 입력",
  inKind: "key", inLabel: "브라우저에서 순서대로",
  input: ["1. github.com/signup 열기", "2. 개인 이메일 입력 (회사 메일 X)", "3. 비밀번호 만들기", "4. 아이디 정하기", "   → 주소가 아이디.github.io 가 된다", "   → 이력서에 써도 괜찮은 이름으로", "5. 메일함에서 인증 코드 확인 → 입력"],
  output: ["github.com", "", "  Welcome, 내아이디!", "  (내 프로필 화면)"], dark: false,
  ok: ["github.com 오른쪽 위에 내 프로필 사진"], ng: ["인증 메일이 없으면 스팸함 확인"] });

iof({ chip: "BLOCK 1 · ②", chipW: 2.3, title: "GitHub 연결은 일회용 코드로 시작한다", sub: "Claude Code가 연결을 시작해 코드를 보여 준다. Claude 로그인과는 별개다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["GitHub CLI 로그인을 도와줘.", "먼저 gh auth status로 연결 여부를 확인해 줘.", "연결이 안 돼 있으면", "gh auth login --web --hostname github.com", "  --git-protocol https 를 시작하고,", "화면의 일회용 코드와 접속 주소만 보여 줘.", "나는 코드를 브라우저에만 입력할 거야.", "코드나 비밀번호를 대화창에 입력하라고 하지 마.", "내가 승인했다고 말하면", "gh auth status로 내 아이디를 확인해 줘."],
  output: ["! First copy your one-time code:", "    ABCD-1234   (예시)", "Open: https://github.com/login/device"],
  ok: ["8자리 코드와 주소가 보인다 → 다음 장"], ng: ["안 되면 Ctrl+` (맥 ⌃+`)로 앱 안 터미널을 열고", "gh auth login --web 입력"], fbFs: 16 });

iof({ chip: "BLOCK 1 · ③", chipW: 2.3, title: "코드는 브라우저에만 넣고 승인한 뒤 돌아온다", sub: "장소가 두 번 바뀐다 — 브라우저에서 승인, Code 탭에서 확인",
  where: "browser", whereText: "주소가 정확히 github.com/login/device 인지 먼저 본다",
  inKind: "key", inLabel: "브라우저 → 다시 Code 탭",
  input: ["[브라우저]", "1. github.com/login/device 열기", "2. 화면의 8자리 코드 입력 → Continue", "3. 앱 이름 'GitHub CLI' 확인", "4. Authorize 클릭", "", "[Code 탭 입력칸]", "5. 승인했어  ← 이렇게 입력"],
  output: ["✓ Logged in to github.com", "  account 내아이디 (keyring)", "- Git operations protocol: https"],
  ok: ["Logged in … account 내아이디"], ng: ["코드 만료 → 'GitHub 로그인 다시 시작해 줘'", "코드는 남에게 절대 보내지 않는다"] });

{ const s = np(); divider(s, { num: "04", sec: "BLOCK 2–3 · 만들기", secW: 3.8, title: "저장소와 대시보드", desc: "첫 저장소 → 데이터로 차트 만들기 → 올리기", pageNo: pg() }); }

{ const s = np();
  const cy = head(s, "BLOCK 2 · 개념", 2.1, "커밋은 내 컴퓨터에 세이브, 푸시는 GitHub에 업로드다", "둘 다 해야 GitHub 화면이 바뀐다. 가장 흔한 실수가 커밋만 하고 푸시를 안 하는 것이다", pg());
  const y = cy + 0.35, h = 2.3, w = 3.3;
  const items = [["파일 수정", "index.html·README", C.panelGray, C.navy], ["커밋 (commit)", "내 컴퓨터에 세이브", C.panelBlue, C.blue], ["푸시 (push)", "GitHub에 업로드", C.panelGreen, C.green]];
  items.forEach((it, i) => {
    const x = LX + i * (w + 1.09);
    rect(s, x, y, w, h, it[2]);
    s.addText(it[0], { x, y: y + 0.35, w, h: 0.7, align: "center", fontFace: F, fontSize: 24, bold: true, color: it[3] });
    s.addText(it[1], { x, y: y + 1.15, w, h: 0.6, align: "center", fontFace: F, fontSize: 20, color: C.body });
    if (i < 2) s.addText("▶", { x: x + w + 0.2, y: y + 0.8, w: 0.7, h: 0.7, align: "center", fontFace: F, fontSize: 32, color: C.muted });
  });
  panel(s, LX, y + h + 0.3, CW, 1.65, C.panelBlue, C.blue, "Claude Code에게는 이렇게 말한다", ["\"○○로 커밋하고 푸시해 줘\" — 두 동작을 한 문장에 함께 말한다"]); }

iof({ chip: "BLOCK 2", title: "첫 저장소를 만들어 GitHub에 올린다", sub: "수업 체험에서 본 그 장면이다. 올리기 전에 Claude가 올라갈 파일 목록을 보여 준다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["이 폴더를 GitHub에 올리자.", "1. README.md를 만들어 줘: 제목 '완성차 6사 재무", "   대시보드', 한 줄 소개, 데이터 출처.", "2. .gitignore로 env_check.txt와 잡파일은 제외.", "3. git 저장소로 만들고 '첫 커밋: 데이터와 README'", "   로 커밋해 줘.", "4. gh로 auto-finance-dashboard 공개(public)", "   저장소를 만들고 푸시해 줘.", "5. 올리기 전에 파일 목록을 보여 주고", "   개인정보·비밀번호가 없는지 점검해 줘.", "6. 끝나면 저장소를 브라우저로 열어 줘."],
  output: ["올라갈 파일: README.md, .gitignore, data/…", "✓ Created repository", "  내아이디/auto-finance-dashboard", "✓ Pushed commits"],
  ok: ["브라우저에 내 저장소 · README가 보인다"], ng: ["'인증 필요' 오류 → BLOCK 1 ②로 돌아가 연결 확인"] });

iof({ chip: "BLOCK 3 · ①", chipW: 2.3, title: "대시보드는 계획부터 받고 승인한다", sub: "붙여 넣기 전에 입력칸 오른쪽 모드 선택기를 Plan으로 바꾼다",
  where: "cc", whereText: "모드 선택기(Manual ▾) → Plan   ·   Ctrl+Shift+M",
  inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸 (Plan 모드)",
  input: ["data 폴더의 csv로 완성차 6사 재무 대시보드를", "만드는 계획을 세워 줘.", "- build_site.py가 csv를 읽어 index.html을 만든다", "- 매출은 fx_annual_average.csv로 USD 십억 달러로", "  환산. 도요타는 3월 결산이라 '도요타 20XX년", "  3월기' 엔/달러를, BYD는 천 위안, 유로는", "  유로당 달러인 점에 주의", "- 차트 3개: 매출 막대, 영업이익률 꺾은선,", "  R&D 비율 막대", "- 위에 한 줄 요약, 아래에 표와 공시 출처 링크", "- 휴대폰에서도 가로 스크롤 없이", "계획에 회사별 환산 규칙 표를 넣어 줘."],
  output: ["[Plan ▾]", "Plan: ① 단위 환산 규칙 표 …", "이 계획으로 진행할까요?  [승인]"], dark: false,
  ok: ["계획에 6개 회사 환산 규칙 표 → 승인"], ng: ["표가 없으면 '환산 규칙 표를 넣어 다시 계획해 줘'"] });

iof({ chip: "BLOCK 3 · ②", chipW: 2.3, title: "실행해서 브라우저로 열고 숫자를 대조한다", sub: "회사마다 통화가 달라 달러로 통일했다. 아래 숫자와 비슷하면 맞다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["build_site.py를 실행해서 index.html을 만들고,", "내 기본 브라우저로 열어 줘.", "그리고 회사별 2025년 매출(USD bn)과", "영업이익률을 표로 보여 줘."],
  output: ["현대 131.0 6.16% │ 기아   80.3 7.95%", "도요타 336.4 7.43% │ 폭스바겐 364.0 2.75%", "테슬라 94.8 4.59% │ BYD   111.9 5.00%"],
  outH: 1.75,
  ok: ["브라우저에 차트 3개 · 숫자가 위와 비슷"], ng: ["BYD가 수만·도요타가 수천 → '단위 환산을 점검해 줘'", "그래도 안 되면 '정답 보기'"], fbFs: 16 });

iof({ chip: "BLOCK 3 · ③", chipW: 2.3, title: "만든 대시보드를 커밋하고 푸시한다", sub: "아직 사이트 주소는 없다. 저장소에 파일이 올라가는 것까지다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["index.html, build_site.py,", "data/summary_usd.csv를", "'대시보드 첫 버전'으로", "커밋하고 푸시해 줘."],
  output: ["[main 3f2a1c] 대시보드 첫 버전", " 3 files changed", "✓ pushed to origin/main"],
  ok: ["github.com 저장소에 index.html이 보인다"], ng: ["안 보이면 '푸시까지 했는지 확인해 줘'"] });

{ const s = np(); divider(s, { num: "05", sec: "BLOCK 4–5 · 공개", secW: 3.6, title: "인터넷에 공개하고 고치기", desc: "GitHub Pages → 휴대폰 확인 → 수정 → 다시 올리기", pageNo: pg() }); }

iof({ chip: "BLOCK 4 · ①", chipW: 2.3, title: "GitHub Pages를 켜면 내 사이트 주소가 생긴다", sub: "켠 뒤 1~3분은 404가 보이는 것이 정상이다. Claude가 기다렸다 확인한다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["auto-finance-dashboard 저장소에", "GitHub Pages를 켜 줘.", "main 브랜치의 루트(/) 폴더를 사이트로 쓰게", "gh api로 설정해 줘.", "설정이 끝나면 사이트 주소를 알려 주고,", "배포 상태가 built가 될 때까지 30초 간격으로", "확인해 줘(최대 5분).", "끝나면 사이트를 내 브라우저로 열고,", "주소를 다시 한 번 크게 보여 줘."],
  output: ["status: building … building … built ✓", "", "https://내아이디.github.io/", "        auto-finance-dashboard/"],
  ok: ["status built · 브라우저에 대시보드"], ng: ["5분 넘게 404 → 'Pages가 404인데 원인을 찾아 줘'"] });

iof({ chip: "BLOCK 4 · ②", chipW: 2.3, title: "휴대폰으로 내 사이트를 연다", sub: "QR 코드를 만들어 카메라로 찍으면 주소를 칠 필요가 없다",
  where: "phone", whereText: "Code 탭에서 QR을 만들고 → 휴대폰 카메라로 찍는다",
  inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["내 사이트 주소의 QR 코드를 만들어서", "qr.png로 저장하고 열어 줘.", "", "", "→ 휴대폰 카메라로 화면의 QR을 찍는다"],
  output: ["(휴대폰 화면)", "완성차 6사 재무 대시보드", "한 줄 요약 · 매출 막대 · 이익률 …"], dark: false,
  ok: ["휴대폰에서 차트가 보이고 가로로 안 밀린다"], ng: ["404면 1~2분 뒤 새로고침"] });

iof({ chip: "BLOCK 5 · ①", chipW: 2.3, title: "부품사 조기경보 섹션을 추가한다", sub: "현금화비율 = 영업활동현금흐름 ÷ 영업이익. 1 미만이면 이익이 현금으로 덜 들어왔다는 신호다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["build_site.py를 고쳐서 페이지 아래에", "'부품사 재무 조기경보' 섹션을 추가해 줘.", "- 데이터: data/parts_suppliers_financials_3y.csv", "- 차트: 회사별 영업이익률 꺾은선,", "  현금화비율 막대 — 1.0에 기준선", "- 현금화비율 1.0 미만인 해는 표에서 빨간색", "- 주요 고객사 비중은 표에 그대로", "다시 실행해서 브라우저로 열어 줘.", "현금화비율이 1 미만인 회사·연도를 알려 줘."],
  output: ["현금화비율 1.0 미만:", "  한온시스템 2025  0.42", "(나머지는 모두 1.0 이상)"],
  ok: ["한온시스템 2025년(0.42) 한 건만 빨간색"], ng: ["여러 건이면 '현금화비율 계산식을 점검해 줘'"] });

iof({ chip: "BLOCK 5 · ②", chipW: 2.3, title: "다시 푸시하면 1~2분 뒤 사이트가 바뀐다", sub: "커밋 메시지에는 무엇을 왜 바꿨는지를 적는다",
  where: "cc", inKind: "prompt", inLabel: "프롬프트 · Code 탭 입력칸",
  input: ["바뀐 파일을", "'부품사 3곳 조기경보 섹션 추가(Day 3 보강 A)'", "로 커밋하고 푸시해 줘.", "2분 뒤 사이트 주소를 다시 열어", "새 섹션이 보이는지 확인하고,", "지금까지의 커밋 이력을 표로 보여 줘."],
  output: ["1  첫 커밋: 데이터와 README", "2  대시보드 첫 버전", "3  부품사 3곳 조기경보 섹션 추가", "✓ 사이트에 새 섹션 확인"],
  ok: ["사이트 맨 아래에 부품사 섹션"], ng: ["예전 화면 그대로 → 브라우저 새로고침 · 푸시 확인"] });

// ===== 마무리 =====
{ const s = np();
  const cy = head(s, "막혔을 때", 1.6, "막히면 상황을 그대로 Claude Code에게 말한다", "아래 문장을 Code 탭 입력칸에 그대로 쓴다", pg());
  wtable(s, [
    ["상황", "Code 탭 입력칸에 이렇게 쓴다"],
    ["뭘 해야 할지 모르겠다", "지금 뭘 하면 돼?"],
    ["빨간 오류 글자가 나왔다", "방금 오류 고쳐 줘"],
    ["숫자가 매뉴얼과 다르다", "결과가 가이드와 다른데 원인을 찾아 줘"],
    ["사이트가 404 (3분 이상)", "Pages가 404인데 원인을 찾아 줘"],
    ["도저히 안 된다 (Block 3)", "정답 보기"],
    ["윈도우에서 git이 없다고 한다", "(STEP 1-0) Git for Windows 설치 후 새 세션"],
    ["Claude가 계속 일하고 안 멈춘다", "(입력칸 옆) 정지 버튼"],
  ], LX, cy + 0.05, CW, [4.6, CW - 4.6], 0.58, 18); }

iof({ chip: "다시 시작", chipW: 1.6, title: "중간에 끊겼다면 세션을 다시 열어 이어 간다", sub: "앱을 껐거나 컴퓨터를 재시작한 경우다. 하던 블록 번호만 기억한다",
  where: "app", whereText: "Claude 앱 → Code 탭 → 왼쪽 사이드바",
  inKind: "key", inLabel: "다시 여는 순서",
  input: ["1. Claude 앱 → Code 탭", "2. 사이드바에서 전에 쓰던 세션 누르기", "   (없으면 새 세션 → Local → kma-day3-site)", "3. /day3-github-dashboard", "4. 하던 블록 선택"],
  output: ["kma-day3-site", "", "어디서부터 시작할까요?", " ● Block 3: 대시보드"], dark: false,
  ok: ["시작 블록 질문이 뜨면 하던 블록 선택", "사이트와 저장소는 그대로 남아 있다"], ng: ["공용 PC였다면 끝날 때 'GitHub CLI에서 로그아웃해 줘'"], fbFs: 16 });

{ const s = np();
  const cy = head(s, "제출", 1.2, "제출물은 내 사이트 주소 한 줄과 과제 세 가지다", "과제는 Block 5 퀴즈가 끝나면 Claude가 화면에 보여 준다", pg());
  msgRows(s, [
    { n: 1, t: "내 사이트 주소", d: "https://내아이디.github.io/auto-finance-dashboard/ — 휴대폰으로 열리는지 확인하고 낸다" },
    { n: 2, t: "내 한 줄 해석", d: "대시보드 맨 위에 '자동차 부품 재직자로서 본 시사점' 2~3줄을 내 말로 쓰고 푸시" },
    { n: 3, t: "README 꾸미기", d: "'사이트 화면을 캡처해서 README에 넣어 줘' — 저장소 첫 화면에 주소와 화면" },
  ], cy + 0.15);
  banner(s, "공개 저장소에는 공개해도 되는 자료만 — 회사 자료는 회사가 승인한 비공개 저장소에", cy + 4.35); }

// ===== 부록 B · VS Code =====
{ const s = np(); divider(s, { num: "B", sec: "부록 · VS Code", secW: 3.0, title: "VS Code로 따라 하기", desc: "데스크톱 앱 대신 VS Code 터미널에서 Claude Code를 쓰는 경우", pageNo: pg() }); }

{ const s = np();
  const cy = head(s, "부록 B", 1.4, "VS Code로 할 때는 다섯 군데만 다르다", "프롬프트·블록 순서·확인할 숫자는 본문과 같다. 아래 다섯 가지만 바꿔 읽는다", pg());
  wtable(s, [
    ["상황", "데스크톱 앱 (본문)", "VS Code"],
    ["설치", "앱 설치 파일 하나", "VS Code 설치 + 설치 명령 한 줄 (B-1~B-3)"],
    ["입력하는 곳", "Code 탭 입력칸", "아래 터미널의 > 옆"],
    ["작업 폴더 열기", "새 세션 → Local → 폴더 선택", "/exit → 파일 → 폴더 열기 → 새 터미널 → claude"],
    ["계획 모드", "모드 선택기 → Plan", "Shift + Tab → ⏸ plan mode on"],
    ["GitHub 로그인 직접", "Ctrl+` 앱 안 터미널", "입력칸에 ! gh auth login --web"],
    ["멈추기", "정지 버튼", "Esc 키"],
  ], LX, cy + 0.05, CW, [3.0, 3.9, CW - 6.9], 0.62, 18); }

iof({ chip: "부록 B-1", chipW: 1.8, title: "VS Code를 설치하고 터미널을 연다", sub: "VS Code는 무료 코드 편집기다. 아래쪽 터미널에서 Claude Code를 쓴다",
  where: "pc", whereText: "브라우저에서 code.visualstudio.com → 설치 후 VS Code 화면",
  inKind: "key", inLabel: "설치 → 터미널 열기",
  input: ["1. code.visualstudio.com 에서 내려받아 설치", "   윈도우: 'PATH에 추가'는 켠 채로 둔다", "2. VS Code 실행", "3. 메뉴 터미널 → 새 터미널", "   단축키 Ctrl + `  (` 는 숫자 1 왼쪽 키)", "4. 아래쪽에 터미널 칸이 열린다"],
  output: ["맥:     내이름@MacBook ~ %", "윈도우: PS C:\\Users\\내이름>"],
  ok: ["아래쪽에 % 또는 PS C:\\ 가 보인다"], ng: ["맨 앞에 PS가 없으면 오른쪽 위 ∨ → PowerShell"] });

iof({ chip: "부록 B-2", chipW: 1.8, title: "설치 명령 한 줄로 Claude Code를 설치한다", sub: "맨 앞 표시를 보고 내 경우의 한 줄만 붙여 넣는다. 윈도우도 Ubuntu가 필요 없다",
  where: "vscode", inKind: "cmd", inLabel: "명령어 · 내 경우 한 줄만 붙여 넣고 Enter",
  input: ["맥 (% 또는 $)", "curl -fsSL https://claude.ai/install.sh | bash", "", "윈도우 PowerShell (PS C:\\…>)", "irm https://claude.ai/install.ps1 | iex"], inFs: 15,
  output: ["(진행 표시 없이 잠시 멈춘 듯 보인다)", "✔ Claude Code successfully installed!"],
  ok: ["installed 메시지가 보인다"], ng: ["'irm'이 명령이 아니라고 하면 CMD 창 → PowerShell로 바꾼다"] });

iof({ chip: "부록 B-3", chipW: 1.8, title: "새 터미널에서 claude를 실행하고 로그인한다", sub: "설치 직후의 터미널은 claude를 못 찾는다. 터미널을 새로 연다",
  where: "vscode", inKind: "cmd", inLabel: "명령어 · 새 터미널에서",
  input: ["(터미널 오른쪽 위 휴지통 → 터미널 → 새 터미널)", "", "claude", "", "→ 화면 색 고르기 → Claude 계정으로 로그인", "→ 브라우저에서 승인"], inFs: 15,
  output: ["Select login method:", " ❯ Claude account with subscription", "✻ Welcome to Claude Code", ">"],
  ok: ["Welcome 화면과 > 입력칸"], ng: ["claude를 못 찾으면 VS Code를 완전히 껐다 켠다"] });

iof({ chip: "부록 B-4", chipW: 1.8, title: "작업 폴더를 VS Code로 열고 수업을 이어 간다", sub: "본문 BLOCK 0 ②(새 세션)를 VS Code에서는 이렇게 한다. 이후 블록은 본문과 같다",
  where: "vscode", inKind: "key", inLabel: "폴더 열기 → 수업 다시 시작",
  input: ["1. 입력칸에 /exit", "2. 메뉴 파일 → 폴더 열기 → kma-day3-site", "   ('작성자를 신뢰합니다' 선택)", "3. 메뉴 터미널 → 새 터미널 → claude", "4. /day3-github-dashboard → Block 1", "", "계획 모드(Block 3)는 Shift + Tab"],
  output: ["PS C:\\Users\\내이름\\kma-day3-site> claude", "✻ Welcome to Claude Code", "어디서부터 시작할까요?"],
  ok: ["왼쪽 탐색기 제목이 KMA-DAY3-SITE"], ng: ["claude를 못 찾으면 새 터미널을 연다"] });

p.writeFile({ fileName: "GitHub_Dashboard_Lab_Manual_IV.pptx" }).then(f => console.log("saved", f, "slides", PAGE));
