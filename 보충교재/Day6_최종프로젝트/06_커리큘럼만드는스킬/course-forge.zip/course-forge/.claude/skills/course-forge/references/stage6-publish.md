# Stage 6 — 배포 (공개 점검 · 승인 ③ · GitHub 저장소 · Pages)

## 목표

내 강의 패키지를 GitHub 저장소로 올리고, 실습 결과 대시보드(`index.html`)를 GitHub Pages 주소로 공개한다. 저장소 하나가 **강의(스킬)와 결과물(사이트)을 함께** 담는다.

## 순서

1. **README.md** — `templates/readme.md`를 채운다: 한 줄 소개, 결과 대시보드 주소와 화면, 블록 표, 수업 방식 표, **설치 한 줄**(`npx skills add <내아이디>/learn-<slug> --agent claude-code --global --yes`), 원본 강의 출처(저장소·Day 폴더), 데이터 출처, 만든 사람.
2. **.gitignore** — `forge/qa/`의 임시 파일, `env_check.txt`, OS 잡파일, 렌더 중간물.
3. **공개 점검** — `python3 -I scripts/publish_check.py <패키지>` → 결과를 대화창에 요약.
4. **최종 수치 검증** — `verify_numbers.py` 한 번 더.
5. **승인 ③** — 올라갈 파일 목록, 공개 점검 결과, 저장소 이름·공개 범위를 보여 주고 AskUserQuestion: "이대로 공개할까요?" — 공개(public) / 비공개(private)로 올리기 / 보류.
   - 회사 내부 자료가 하나라도 들어 있으면 공개(public)를 권하지 않는다.
   - 사용자가 답하지 않으면 공개하지 않는다. zip만 만들어 두고 멈춘다.
6. **공개** — `gh auth status` 확인(안 되어 있으면 일회용 코드 로그인을 안내한다. 코드와 비밀번호는 브라우저에만 입력하게 한다) → `git init` · 커밋(메시지에 무엇·왜) → `gh repo create learn-<slug> --public|--private --source . --push` → Pages(main, /) 설정 → `built`까지 확인 → 사이트 주소를 휴대폰으로 열어 보게 한다.
7. **zip** — 같은 내용을 `learn-<slug>.zip`으로 만든다(저장소를 쓰지 않는 동료용).
8. status.md에 저장소 주소·사이트 주소·커밋·날짜를 적는다.

## 끝내기

사용자에게 알려 줄 것: 저장소 주소, 사이트 주소, 설치 한 줄, zip 파일. 그리고 7단계(배우기·공유)로 넘어간다.
