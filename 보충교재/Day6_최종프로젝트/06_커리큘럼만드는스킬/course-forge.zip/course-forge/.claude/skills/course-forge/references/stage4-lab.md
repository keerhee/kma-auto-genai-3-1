# Stage 4 — 실습 MVP (수치 검증 · 대시보드 · 승인 ②)

## 목표

수강생이 블록을 따라 하면 얻게 될 결과물을 **정답으로 먼저 만들어 실행**하고, 그 실행 결과로 '확인할 것'의 수치와 공개할 대시보드를 확정한다.

## 순서

1. **데이터**
   - 원본 강의 저장소의 데이터(`data/DayN/`)를 파일명 그대로 `assets/lab/`에 복사한다. `assets/lab/README.md`에 파일별 내용·행 수·실데이터/가상 구분·출처(저장소 경로, 실데이터는 원문 URL)를 표로 적는다.
   - 원본에 데이터가 없으면 공개 데이터를 찾고, 없으면 가상 데이터를 만들어 파일명·README에 '가상'을 붙인다.
   - 내려받기 실습(API 등)이면 데이터 파일을 넣지 않고 정답 스크립트가 내려받게 한다. 이때 '확인할 것'은 범위나 구조로 쓴다.
2. **정답** — `assets/answers/`에 정답 스크립트를 쓴다. 수강생이 붙여 넣을 프롬프트로 Claude Code가 만들 법한 수준의 코드로, 한국어 주석. 원본 덱의 계산 규칙(예: 평균 ± 2표준편차, 연간 정지손실 ÷ 초기 투자)을 그대로 쓴다.
3. **대시보드** — 정답 스크립트가 블록 산출물(표·차트)을 모아 `index.html` 한 장을 만들게 한다. 상단 한 줄 요약, 차트, 판정표, 출처와 '가상 데이터' 표기. 휴대폰에서 가로 스크롤이 없게 한다. 이 파일이 6단계에서 GitHub Pages 첫 화면이 된다.
4. **expected.json** — 정답 스크립트가 실행 끝에 **현재 폴더**에 `expected.json`을 쓰게 한다. 같은 파일을 `assets/answers/expected.json`으로도 저장한다(기준값).
   ```json
   {"values": {"press_pilot_ratio": {"value": 2.59, "decimals": 2, "block": 4}}}
   ```
   - `decimals`는 블록 본문에 쓰는 소수 자리, `block`은 그 수치가 나오는 블록 번호.
5. **manifest** — 패키지의 `forge/forge.json`에 정답 실행 방법을 적는다.
   ```json
   {"slug": "learn-auto-pdm",
    "answer": {"skill": "learn-auto-pdm", "workdir": "assets/lab",
               "cmd": "python3 -I {answers}/build_pdm.py", "expected": "assets/answers/expected.json"}}
   ```
   - `workdir`(스킬 폴더 기준)의 파일을 임시 폴더(필요하면 `copy_to` 하위)로 복사하고 `cmd`를 실행한다. `{answers}`는 정답 폴더 절대경로로 바뀐다.
6. **원본 대조** — 정답 수치를 원본 덱 모범답안·정답 메모와 대조해 `forge/qa/source_check.md`에 표로 남긴다.
7. **블록 채우기** — 블록의 `{{expected:키}}` 자리를 실제 값(소수 자리 맞춤)으로 바꾼다.
8. **검증** — `python3 -I scripts/verify_numbers.py <패키지>` 통과.
9. **렌더** — `python3 -I scripts/render_check.py <index.html> -o assets/answers/preview.png` (CDN이 막힌 환경이면 `--local-js 패턴=파일`). PNG를 직접 열어 본다.

## 승인 ②

preview.png, 핵심 수치 표, 원본 대조 결과를 대화창에 보여 주고 AskUserQuestion: "실습 결과물을 승인할까요?" — 승인 / 수정 요청 / 데이터 바꾸기. 승인되면 status.md에 기록하고 5단계로 간다.
