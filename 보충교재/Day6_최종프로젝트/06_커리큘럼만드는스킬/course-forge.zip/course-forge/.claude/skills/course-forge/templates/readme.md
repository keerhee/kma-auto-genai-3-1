# {{강의 제목}} — learn-{{slug}}

{{한 줄 소개}}. 수업은 Claude Code 스킬 `/learn-{{slug}}`가 진행한다 (Skills as Curriculum). 이 강의는 {{만든 사람}}이 course-forge로 직접 만들었다.

- **결과 대시보드**: https://{{owner}}.github.io/learn-{{slug}}/
- 처음이면 [GUIDE.md](GUIDE.md)부터. 기본 환경은 Claude 데스크톱 앱(Code 탭). VS Code는 GUIDE 부록 B

## 설치 — 한 줄

Claude Code 입력칸에 붙여 넣는다.

```
npx skills add {{owner}}/learn-{{slug}} --agent claude-code --global --yes 를 실행해 줘
```

새 세션에서 `/learn-{{slug}}`를 입력하면 수업이 시작된다. zip을 받았다면 GUIDE.md 2단계대로 설치한다.

## 블록

| Block | 주제 | 끝나면 생기는 것 |
|---|---|---|

## 수업 방식

| 구분 | 내용 |
|---|---|
| 목표 — AI Native | AI에게 맡기는 것이 기본인 방식으로 일한다 |
| 방법 — Skills as Curriculum | 스킬이 블록마다 설명 → 실습 → STOP → 확인·퀴즈를 진행한다 |
| 형식 — 자율학습 | 강사 없이 자기 속도로, 퀴즈로 스스로 점검한다 |

## 원본 강의와 데이터 출처

| 자료 | 출처 | 구분 |
|---|---|---|

## 개정 이력

| 날짜 | 바뀐 점 |
|---|---|

## 만든 방법

- `/course-forge`로 만들었다. 제작 기록(원본 요약·커리큘럼·검수 결과)은 `forge/`에 있다.
- 출처: 원본 강의 저장소 {{저장소 URL}}
