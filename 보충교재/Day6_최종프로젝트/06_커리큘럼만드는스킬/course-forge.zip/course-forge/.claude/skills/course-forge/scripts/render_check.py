"""render_check.py — HTML 결과물을 헤드리스 Chromium으로 열어 화면을 저장하고 점검한다.

사용: python3 -I render_check.py <index.html> -o preview.png [--local-js 패턴=파일 ...]
  --local-js : CDN이 막힌 환경에서 URL에 '패턴'이 들어간 스크립트를 로컬 '파일'로 대신 제공
점검: 콘솔 오류 0건, 390px 폭에서 가로 스크롤 없음(scrollWidth ≤ 390)
종료 코드: 문제가 있으면 1
"""
import argparse, os, sys
from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--local-js", action="append", default=[])
    ap.add_argument("--width", type=int, default=1200)
    a = ap.parse_args()
    url = "file://" + os.path.abspath(a.html)
    errs = []
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": a.width, "height": 900})
        for spec in a.local_js:
            pat, path = spec.split("=", 1)
            body = open(path, encoding="utf-8").read()
            pg.route(f"**/*{pat}*", lambda r, _req=None, body=body: r.fulfill(body=body, content_type="application/javascript"))
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(url); pg.wait_for_timeout(2000)
        pg.screenshot(path=a.out, full_page=True)
        pg.set_viewport_size({"width": 390, "height": 844}); pg.wait_for_timeout(600)
        sw = pg.evaluate("document.documentElement.scrollWidth")
        pg.screenshot(path=a.out.replace(".png", "_mobile.png"))
        b.close()
    print(f"저장: {a.out} (모바일: {a.out.replace('.png', '_mobile.png')})")
    print(f"콘솔 오류 {len(errs)}건" + ("" if not errs else ": " + " | ".join(errs[:3])))
    print(f"모바일 폭 scrollWidth = {sw} (390 이하면 가로 스크롤 없음)")
    sys.exit(1 if errs or sw > 390 else 0)


if __name__ == "__main__":
    main()
