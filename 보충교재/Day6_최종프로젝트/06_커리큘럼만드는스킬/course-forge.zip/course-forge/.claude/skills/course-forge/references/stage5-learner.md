# Stage 5 — 학습자 자료 (GUIDE.md · 매뉴얼 덱)

## 목표

수강생이 "어디에 무엇을 넣는가"를 헷갈리지 않게, **데스크톱 앱 기준**의 가이드와 매뉴얼 덱을 만든다.

## GUIDE.md

`templates/guide.md`의 골격을 채운다. 완성 실례는 `templates/guide-example.md`(learn-github-dashboard). 구성은 고정:

0. 먼저 알아 둘 것 — 수업 방식(AI Native · Skills as Curriculum · 자율학습 표), 용어 6개, 입력하는 곳 두 군데(Code 탭 입력칸 · 브라우저), 화면 신호 네 가지(허용 카드 · 질문 카드 · 컴퓨터 권한 창 · 일하는 중), 준비물, 약속
1. 설치 — Git for Windows(윈도우만) → Claude 데스크톱 앱 → Code 탭 → Local → 폴더
2. 스킬 설치 — zip을 Claude Code에게 풀게 하는 프롬프트, 새 세션에서 `/learn` 확인
3. 수업 체험 — 대표 블록 하나가 여섯 장면(시작 · 설명 · 실행 · 완료 · 확인·퀴즈 · 다음)으로 도는 대화 예시
4. 블록별 미리 보기 — 하는 일 · 주의 · ✅ 성공 기준(수치 포함)
5. 막혔을 때 — 상황 | 입력칸에 쓸 문장 표
6. 제출물
부록 B — VS Code로 하기 (다른 다섯 가지 대조표 + 설치 명령)

대상이 자동차 재직자면 현장 용어(평상 범위·파일럿·MTBF·라인 정지 등)를 그대로 쓰고 필요하면 영어를 병기한다. 입문자면 비유를 더한다.

## 매뉴얼 덱

`templates/manual/`의 빌더로 만든다(Node + pptxgenjs, report-navy-deck field 모드 · 본문 20pt).

1. `templates/manual/*.js`를 `forge/manual/`로 복사한다.
2. `example_build.js`(learn-github-dashboard 매뉴얼 실례)를 `build.js`로 복사해 슬라이드 데이터만 바꾼다.
   - 단계 슬라이드는 `iof({...})` — ① 어디 ② 입력 ③ 출력 ④ 피드백 네 칸.
   - 수업 체험은 `scene({...})` 여섯 장, 화면 신호 슬라이드, 부록 B.
   - 제목은 두 층: 표지·디바이더는 명사구, 본문은 문어체 주장문, 부제는 전제·설정.
   - 워드마크·기관명·로고를 넣지 않는다. `setSubject()`에는 강의명만.
3. `node build.js` → LibreOffice로 PDF 렌더 → 전 슬라이드 이미지를 직접 열어 겹침·넘침을 고친다.
4. 정규화: `soffice --headless --convert-to pptx:"Impress MS PowerPoint 2007 XML"` 후 report-navy-deck의 `fix_keynote_notes.py`와 `qa_callout_overlap.py`를 통과시킨다.
5. 결과를 `docs/<Slug>_Lab_Manual.pptx`로 둔다. 개정 시 이전 판은 `_II`·`_III`로 보관.

## 끝내기

status.md에 5단계 완료. 렌더 이미지 3~4장을 대화창에 보여 준다(승인 게이트는 아니다).
