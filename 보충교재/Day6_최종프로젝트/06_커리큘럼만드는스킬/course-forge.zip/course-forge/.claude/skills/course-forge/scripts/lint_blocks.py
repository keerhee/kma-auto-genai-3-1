"""lint_blocks.py — learn- 스킬 패키지의 구조를 검사한다.

사용: python3 -I lint_blocks.py <패키지 폴더> [--stage 2|3] [--out 결과.txt]
  --stage 2 : QUIZ 미작성("(3단계에서 작성)")과 {{expected:…}} 자리표시자를 경고로만 본다
  기본(3 이상): 위 둘도 오류로 본다
종료 코드: 오류가 있으면 1
"""
import argparse, json, re, sys
from pathlib import Path

END_PHRASE = "👆 위 프롬프트를"


def find_skills(pkg: Path):
    return sorted(p.parent for p in pkg.glob(".claude/skills/*/SKILL.md"))


def frontmatter(text):
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    if not m:
        return {}
    out = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip()] = v.strip()
    return out


def sections(text):
    """'## 이름' 단위로 자른다."""
    parts, cur, buf = {}, None, []
    for line in text.splitlines():
        m = re.match(r"^## (\S+)", line)
        if m:
            if cur:
                parts[cur] = "\n".join(buf)
            cur, buf = m.group(1), []
        elif cur:
            buf.append(line)
    if cur:
        parts[cur] = "\n".join(buf)
    return parts


def lint_skill(sd: Path, stage: int, errs, warns):
    rel = lambda p: str(p.relative_to(sd.parent.parent.parent))
    sk = (sd / "SKILL.md").read_text(encoding="utf-8")
    fm = frontmatter(sk)
    name = fm.get("name", "")
    if not name:
        errs.append(f"{rel(sd/'SKILL.md')}: frontmatter name 없음")
    elif not name.startswith("learn-"):
        warns.append(f"{rel(sd/'SKILL.md')}: name '{name}'이 learn- 으로 시작하지 않음")
    if name and name != sd.name:
        errs.append(f"{rel(sd/'SKILL.md')}: name '{name}'과 폴더명 '{sd.name}'이 다름")
    if len(fm.get("description", "")) < 30:
        errs.append(f"{rel(sd/'SKILL.md')}: description이 없거나 너무 짧음")
    for must in ["STOP PROTOCOL", "Phase A", "Phase B", END_PHRASE, "AskUserQuestion"]:
        if must not in sk:
            errs.append(f"{rel(sd/'SKILL.md')}: '{must}' 없음 (STOP 프로토콜 문구 훼손)")
    # 파일 지도
    mapped = set(re.findall(r"references/[\w.\-]+\.md", sk))
    for m in sorted(mapped):
        if not (sd / m).exists():
            errs.append(f"{rel(sd/'SKILL.md')}: 파일 지도의 {m} 이 없음")
    blocks = sorted((sd / "references").glob("block*.md"))
    if not blocks:
        errs.append(f"{rel(sd)}: references/block*.md 가 없음")
    for b in blocks:
        if f"references/{b.name}" not in mapped:
            warns.append(f"{rel(b)}: SKILL.md 파일 지도에 없음")
    answers_seen = []
    for b in blocks:
        t = b.read_text(encoding="utf-8")
        r = rel(b)
        num = re.match(r"block(\d+)", b.name)
        n = int(num.group(1)) if num else -1
        sec = sections(t)
        for s in ["EXPLAIN", "EXECUTE", "QUIZ"]:
            if s not in sec:
                errs.append(f"{r}: ## {s} 없음")
        if "📖" not in t.split("## EXPLAIN")[0]:
            warns.append(f"{r}: 블록 첫머리에 📖 공식 문서 줄 없음")
        ex = sec.get("EXECUTE", "")
        if "```" not in ex:
            errs.append(f"{r}: EXECUTE에 붙여 넣을 코드 블록 없음")
        if "확인할 것" not in ex:
            errs.append(f"{r}: EXECUTE에 '확인할 것' 없음")
        if "AskUserQuestion" in sec.get("EXPLAIN", "") + ex.split("확인할 것")[0]:
            errs.append(f"{r}: Phase A 범위(EXPLAIN·EXECUTE)에 AskUserQuestion — STOP 위반")
        q = sec.get("QUIZ", "")
        pending = "(3단계에서 작성)" in q
        if pending:
            (warns if stage <= 2 else errs).append(f"{r}: QUIZ 미작성")
        elif n != 0:
            nq = q.count("AskUserQuestion")
            if nq == 0:
                errs.append(f"{r}: QUIZ에 AskUserQuestion 문항 없음")
            if "정답" not in q:
                errs.append(f"{r}: QUIZ에 정답·해설 없음")
            for js in re.findall(r"```json\n(.*?)```", q, re.S):
                k = js.count('"label"')
                if k > 4:
                    warns.append(f"{r}: 보기 {k}개 — 4개 이하 권장")
            answers_seen += re.findall(r"정답:\s*(\d)번", q)
        ph = [x for x in re.findall(r"\{\{[^}]*\}\}", t) if not re.fullmatch(r"\{\{ [^}]* \}\}|\{\{ \}\}", x)]  # Jinja식 {{ x }}(공백 포함)는 수업 내용으로 본다
        exp = [x for x in ph if x.startswith("{{expected:")]
        other = [x for x in ph if not x.startswith("{{expected:")]
        if other:
            errs.append(f"{r}: 템플릿 자리표시자 남음 {other[:3]}")
        if exp:
            (warns if stage <= 3 else errs).append(f"{r}: 수치 자리표시자 남음 {exp[:3]} (4단계에서 채움)")
    if answers_seen and len(set(answers_seen)) == 1 and len(answers_seen) >= 4:
        warns.append(f"{rel(sd)}: 정답이 모두 {answers_seen[0]}번 ({len(answers_seen)}문항) — 위치를 섞을 것")
    return len(blocks), len(answers_seen)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pkg")
    ap.add_argument("--stage", type=int, default=5)
    ap.add_argument("--out")
    a = ap.parse_args()
    pkg = Path(a.pkg).resolve()
    errs, warns, lines = [], [], []
    skills = find_skills(pkg)
    if not skills:
        print(f"오류: {pkg}/.claude/skills/*/SKILL.md 가 없음")
        sys.exit(1)
    for sd in skills:
        nb, nq = lint_skill(sd, a.stage, errs, warns)
        lines.append(f"{sd.name}: 블록 {nb}개 · 퀴즈 {nq}문항")
    lines += [f"오류 {len(errs)}건 · 경고 {len(warns)}건"]
    lines += ["  [오류] " + e for e in errs] + ["  [경고] " + w for w in warns]
    rep = "\n".join(lines)
    print(rep)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(rep + "\n", encoding="utf-8")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
