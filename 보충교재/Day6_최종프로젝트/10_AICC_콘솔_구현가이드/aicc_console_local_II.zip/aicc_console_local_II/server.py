"""
AICC 콘솔 II — 내 PC에서 내 Claude 구독으로 돌리는 빠른 응답판
------------------------------------------------------------
실행:  python server.py          (기본: Claude 구독 모드)
       SIM_MODE=api python server.py   (선택: ANTHROPIC_API_KEY 필요)
Chrome에서 http://localhost:8770 을 연다. 통화 기록과 매뉴얼은 data/ 폴더에 저장된다.

II에서 빨라진 점
1. 통화 하나에 Claude Code를 한 번만 켜 두고(stream-json) 손님 말만 한 줄씩 보낸다.
   턴마다 프로그램을 새로 켜는 시간이 사라진다. '전화 받기'를 누르는 순간 미리 켠다.
2. 설정·플러그인·MCP·CLAUDE.md를 불러오지 않는 빈 작업 폴더에서 실행한다.
3. 옵션이 맞지 않는 Claude Code 버전이면 자동으로 기본 옵션으로 다시 시도한다.
4. 세션이 실패하면 이전 방식(한 번씩 호출)으로 자동 전환한다.
"""
import json, os, queue, re, shutil, subprocess, threading, time, urllib.request
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
WORK = os.path.join(HERE, ".claude_work")          # 빈 작업 폴더: CLAUDE.md·프로젝트 설정을 읽지 않게 한다
MODE = os.environ.get("SIM_MODE", "cli").lower()
PORT = int(os.environ.get("SIM_PORT", "8770"))
CLI_MODEL = {"quick": os.environ.get("SIM_QUICK_MODEL", "haiku"), "default": os.environ.get("SIM_DEFAULT_MODEL", "sonnet")}
API_MODEL = {"quick": "claude-haiku-5-5", "default": "claude-sonnet-5-5"}
SYSTEM = "너는 사용자가 요청한 형식으로만 답하는 도우미다. 도구는 쓰지 않는다. JSON을 요청받으면 JSON만 출력한다."
NAME = re.compile(r"^[A-Za-z0-9_\-]{1,80}$")
FAST_OPTS = ["--strict-mcp-config", "--setting-sources", "project", "--disable-slash-commands"]
state = {"fast_ok": True}                            # 빠른 옵션이 이 PC의 Claude Code에서 통하는지


def claude_exe():
    exe = shutil.which("claude")
    if not exe:
        raise RuntimeError("claude 명령을 찾을 수 없습니다. Claude Code를 설치하고 터미널에서 claude 로 로그인하세요.")
    return exe


def opts():
    return FAST_OPTS if state["fast_ok"] else []


def looks_like_option_error(text):
    t = (text or "").lower()
    return "unknown option" in t or "unknown argument" in t or "invalid value" in t or "error: option" in t


# ---------- 한 번씩 호출 (후처리, AI 손님, 세션 실패 시) ----------
def ask_cli(prompt, tier):
    for attempt in range(2):
        cmd = [claude_exe(), "-p", "--model", CLI_MODEL.get(tier, CLI_MODEL["default"]), "--system-prompt", SYSTEM,
               "--tools", "", "--output-format", "json", "--no-session-persistence", *opts()]
        r = subprocess.run(cmd, input=prompt, capture_output=True, text=True, encoding="utf-8", timeout=180, cwd=WORK)
        if r.returncode == 0:
            return json.loads(r.stdout).get("result", "")
        if attempt == 0 and state["fast_ok"] and looks_like_option_error(r.stderr):
            state["fast_ok"] = False; print("[안내] 빠른 옵션을 지원하지 않는 버전이라 기본 옵션으로 다시 실행합니다.")
            continue
        raise RuntimeError((r.stderr or r.stdout)[-400:])


def ask_api(prompt, tier, system=SYSTEM, messages=None):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("SIM_MODE=api 에는 ANTHROPIC_API_KEY 환경변수가 필요합니다.")
    body = json.dumps({"model": API_MODEL.get(tier, API_MODEL["default"]), "max_tokens": 1500,
                       "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
                       "messages": messages or [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        d = json.loads(resp.read())
    return "".join(b.get("text", "") for b in d.get("content", []))


# ---------- 통화 세션: Claude Code를 켜 둔 채 대화를 이어 보낸다 ----------
class Session:
    def __init__(self, system):
        self.system = system; self.lock = threading.Lock(); self.last = time.time()
        self.history = []          # API 모드용
        self.proc = None
        if MODE != "api":
            self._spawn()

    def _spawn(self):
        cmd = [claude_exe(), "-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose",
               "--model", CLI_MODEL["quick"], "--system-prompt", self.system, "--tools", "", *opts()]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     text=True, encoding="utf-8", bufsize=1, cwd=WORK)
        self.q = queue.Queue(); self.err = []
        threading.Thread(target=self._read, daemon=True).start()
        threading.Thread(target=lambda: self.err.extend(self.proc.stderr), daemon=True).start()

    def _read(self):
        for line in self.proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                self.q.put(json.loads(line))
            except Exception:
                pass
        self.q.put({"type": "_eof"})

    def turn(self, text, retry=True):
        self.last = time.time()
        if MODE == "api":
            self.history.append({"role": "user", "content": text})
            out = ask_api(None, "quick", system=self.system, messages=self.history[-28:])
            self.history.append({"role": "assistant", "content": out})
            return out
        try:
            msg = {"type": "user", "message": {"role": "user", "content": [{"type": "text", "text": text}]}}
            self.proc.stdin.write(json.dumps(msg, ensure_ascii=False) + "\n"); self.proc.stdin.flush()
        except Exception:
            pass
        parts = []
        deadline = time.time() + 120
        while time.time() < deadline:
            try:
                ev = self.q.get(timeout=1)
            except queue.Empty:
                continue
            if ev.get("type") == "assistant":
                for b in (ev.get("message") or {}).get("content", []):
                    if b.get("type") == "text":
                        parts.append(b.get("text", ""))
            elif ev.get("type") == "result":
                if ev.get("is_error"):
                    raise RuntimeError(str(ev.get("result") or ev.get("subtype")))
                return ev.get("result") or "".join(parts)
            elif ev.get("type") == "_eof":
                err = "".join(self.err)[-400:]
                if retry and state["fast_ok"] and looks_like_option_error(err):
                    state["fast_ok"] = False; print("[안내] 빠른 옵션을 지원하지 않는 버전이라 기본 옵션으로 다시 켭니다.")
                    self._spawn(); return self.turn(text, retry=False)
                raise RuntimeError("Claude Code 세션이 종료되었습니다. " + err)
        raise RuntimeError("응답 시간이 초과되었습니다.")

    def close(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.stdin.close(); self.proc.wait(timeout=3)
            except Exception:
                self.proc.kill()


SESSIONS = {}
SLOCK = threading.Lock()


def janitor():                       # 10분 넘게 쓰지 않은 세션은 닫는다
    while True:
        time.sleep(60)
        with SLOCK:
            for k in [k for k, s in SESSIONS.items() if time.time() - s.last > 600]:
                SESSIONS.pop(k).close()


ASK = (lambda p, t: ask_api(p, t)) if MODE == "api" else ask_cli


def col_dir(col):
    p = os.path.join(DATA, col); os.makedirs(p, exist_ok=True); return p


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def _parts(self):
        return [p for p in self.path.split("?")[0].split("/") if p]

    def do_GET(self):
        p = self._parts()
        if not p or p == ["index.html"]:
            return self._send(200, open(os.path.join(HERE, "index.html"), "rb").read(), "text/html; charset=utf-8")
        if len(p) == 3 and p[:2] == ["api", "col"] and NAME.match(p[2]):
            d = col_dir(p[2]); out = []
            for f in os.listdir(d):
                if f.endswith(".json"):
                    try: out.append({"id": f[:-5], "data": json.load(open(os.path.join(d, f), encoding="utf-8"))})
                    except Exception: pass
            return self._send(200, out)
        self._send(404, {"error": "not found"})

    def do_POST(self):
        p = self._parts(); req = self._body(); t0 = time.time()
        try:
            if p == ["api", "tts"]:  # 2026-10-28: 브라우저 음성(speechSynthesis)이 조용히 실패해 맥 `say`로 소리를 만든다
                text = str(req.get("text", "")).strip()[:600]
                if not text or not shutil.which("say"): return self._send(404, {"error": "no tts"})
                import tempfile
                with tempfile.TemporaryDirectory() as td:
                    aiff, m4a = os.path.join(td, "a.aiff"), os.path.join(td, "a.m4a")
                    subprocess.run(["say", "-v", os.environ.get("SIM_VOICE", "Yuna"), "-r", "200", "-o", aiff, text], check=True, timeout=60)
                    subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", aiff, m4a], check=True, timeout=60)
                    data = open(m4a, "rb").read()
                return self._send(200, data, "audio/mp4")
            if p == ["api", "sample"]:
                text = ASK(str(req.get("prompt", "")), req.get("tier", "default"))
                print(f"[한 번 호출 {req.get('tier')}] {time.time() - t0:.1f}초")
                return self._send(200, {"text": text})
            if p == ["api", "session", "start"]:
                sid = str(req.get("id", ""))
                if not NAME.match(sid): return self._send(400, {"error": "bad id"})
                s = Session(str(req.get("system", "")))
                with SLOCK: SESSIONS[sid] = s
                print(f"[세션 시작] {sid}")
                return self._send(200, {"ok": True})
            if p == ["api", "session", "turn"]:
                s = SESSIONS.get(str(req.get("id", "")))
                if not s: return self._send(404, {"error": "no session"})
                with s.lock:
                    text = s.turn(str(req.get("text", "")))
                print(f"[세션 응답] {time.time() - t0:.1f}초")
                return self._send(200, {"text": text})
            if p == ["api", "session", "end"]:
                with SLOCK: s = SESSIONS.pop(str(req.get("id", "")), None)
                if s: s.close()
                return self._send(200, {"ok": True})
        except Exception as e:
            print("[오류]", e)
            return self._send(500, {"error": str(e)})
        self._send(404, {"error": "not found"})

    def _doc(self):
        p = self._parts()
        if len(p) == 4 and p[:2] == ["api", "doc"] and NAME.match(p[2]) and NAME.match(p[3]):
            return os.path.join(col_dir(p[2]), p[3] + ".json")
        return None

    def do_PUT(self):
        f = self._doc()
        if not f: return self._send(404, {"error": "not found"})
        json.dump(self._body(), open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self._send(200, {"ok": True})

    def do_PATCH(self):
        f = self._doc()
        if not f or not os.path.exists(f): return self._send(404, {"error": "not found"})
        d = json.load(open(f, encoding="utf-8")); d.update(self._body())
        json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self._send(200, {"ok": True})

    def do_DELETE(self):
        f = self._doc()
        if f and os.path.exists(f): os.remove(f)
        self._send(200, {"ok": True})


if __name__ == "__main__":
    os.makedirs(DATA, exist_ok=True); os.makedirs(WORK, exist_ok=True)
    threading.Thread(target=janitor, daemon=True).start()
    print(f"모드: {'API' if MODE == 'api' else '구독(claude, 통화 세션 유지)'}  |  Chrome에서 http://localhost:{PORT} 을 여세요  (종료: Ctrl+C)")
    print("터미널에 턴마다 응답 시간이 찍힙니다. 기존 판과 비교해 보세요.")
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
