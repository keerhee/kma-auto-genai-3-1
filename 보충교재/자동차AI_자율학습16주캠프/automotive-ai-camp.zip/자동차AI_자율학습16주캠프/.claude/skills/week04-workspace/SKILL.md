---
name: week04-workspace
description: 자동차 AI 자율학습 16주 캠프 4주차 수업 — Google Workspace 기반 업무 환경 구축. "4주차 시작", "4주차 수업", "week04" 등을 요청하면 사용한다.
week: 4
title: Google Workspace 기반 업무 환경 구축
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, Google Drive, Google Docs]
---

# Week 4 — Google Workspace 기반 업무 환경 구축

## 학습 목표
- Google Drive 표준 폴더 구조 8개 설계 및 구축
- Docs·Sheets·Slides·Gmail 표준 템플릿 설정
- Claude Code로 EV 보고서를 Google Docs에 자동 생성

---

## 이론 요약

**Drive 표준 폴더 구조:**
```
📁 01_Market_Research/
📁 02_Data_Analysis/
📁 03_Reports/
📁 04_Presentations/
📁 05_Competitor_Intelligence/
📁 06_Strategy/
📁 07_Automation/
📁 08_Archive/
```

---

## 실습 1: Drive 환경 구축

1. Google Drive에 위 폴더 8개 생성
2. 각 폴더에 README.md(폴더 용도 설명) 추가

## 실습 2: EV 보고서 자동 생성 → Google Docs 저장

```
[Claude Code에 입력]
"Week 1에서 수집한 EV 시장 데이터를 바탕으로
Google Docs 형식의 분석 보고서를 작성해줘.
파일명: W04_EV_Market_Brief.md
구성: Executive Summary, 시장 현황, 한국 기업 포지션, 전략 제언"
```

결과 파일을 `03_Reports/` 폴더에 업로드.

---

## 산출물
- [ ] Drive 표준 폴더 구조 (8개 폴더)
- [ ] `W04_EV_Market_Brief.docx`
