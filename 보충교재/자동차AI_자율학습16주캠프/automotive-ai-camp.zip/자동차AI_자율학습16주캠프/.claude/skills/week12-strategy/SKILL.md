---
name: week12-strategy
description: 자동차 AI 자율학습 16주 캠프 12주차 수업 — 전략 보고서 자동화 + AI 콘텐츠 제작. "12주차 시작", "12주차 수업", "week12" 등을 요청하면 사용한다.
week: 12
title: 전략 보고서 자동화 + AI 콘텐츠 제작
duration: 3H | 이론 0.5H · 실습 2.5H
mode: 오프라인
tools: [Claude Code, Google Opal, Remotion, Google Veo 3.1, Google Docs]
---

# Week 12 — 전략 보고서 + AI 콘텐츠 제작

## 학습 목표
- 컨설팅 수준 전략 보고서(피라미드 원칙) 생성
- Google Opal로 노코드 AI 미니앱 제작·배포
- Remotion으로 수치 카운트업 애니메이션 MP4 생성
- Google Veo 3.1로 실사형 홍보 영상 생성

---

## 이론: 피라미드 원칙

```
Why (왜 중요한가?)
  ↓
So What (그래서 무엇을 해야 하는가?)
  ↓
Now What (지금 당장 무엇을 할 것인가?)
```

---

## 실습 1: 통합 전략 보고서 생성

```
[Claude Code에 입력]
"7~11주 분석 결과를 통합해서 C-Level 임원용 전략 보고서를 작성해줘.
구성: Executive Summary, 시장 현황, 경쟁 분석, 기술 전망, 전략 권고안, 실행 계획
분량: 8페이지 수준
파일명: W12_Strategy_Report.md"
```

임원용 슬라이드 7장도 추가:
```
"위 보고서의 슬라이드 버전 7장을 작성해줘. 파일명: W12_Executive_Slides.md"
```

## 실습 2: Google Opal로 EV 전략 미니앱 제작 ★신규

1. opal.google 접속
2. 텍스트 프롬프트 입력:
```
"EV 시장 현황(판매량, 성장률, 점유율)을 입력하면
전략 인사이트와 권고사항을 출력하는 미니앱을 만들어줘"
```
3. 워크플로 편집기에서 노드 확인 및 조정
4. 웹 배포 → 공유 링크 생성

## 실습 3: Remotion으로 발표 인트로 영상

```
[Claude Code에 입력]
"Remotion으로 EV 전략 발표 인트로 영상 코드를 작성해줘.
- 핵심 수치 3개 카운트업 애니메이션 (예: 시장규모 $500B, 성장률 35%, 점유율 12%)
- 15초 MP4
- 파일명: Intro_Animation 으로 렌더링"
```

## 실습 4: Google Veo 3.1로 AI 홍보 영상

Gemini 또는 Google Vids 접속:
```
"자동차 회사의 EV 전략 발표를 위한 홍보 영상을 만들어줘.
미래 도시에서 전기차가 달리는 실사형 영상.
30초, 1080p, 배경음악 포함."
```

---

## 산출물
- [ ] `W12_Strategy_Report.docx`
- [ ] `W12_Executive_Slides.md`
- [ ] EV_Opal_App (공유 링크)
- [ ] `Intro_Animation.mp4`
- [ ] `EV_Strategy_Intro.mp4`
