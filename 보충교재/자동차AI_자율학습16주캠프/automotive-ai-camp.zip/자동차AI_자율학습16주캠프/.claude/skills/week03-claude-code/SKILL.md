---
name: week03-claude-code
description: 자동차 AI 자율학습 16주 캠프 3주차 수업 — Claude Code 기본과 자동차 산업 적용. "3주차 시작", "3주차 수업", "week03" 등을 요청하면 사용한다.
week: 3
title: Claude Code 기본과 자동차 산업 적용
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, Google Docs]
---

# Week 3 — Claude Code 기본과 자동차 산업 적용

## 학습 목표
- Claude Code 핵심 구성요소(Skills, Sub-Agent, MCP, Plan Mode) 이해
- VS Code / Claude Desktop / 터미널 CLI 환경 설정
- 자연어로 EV 시장 분석 보고서 자동 생성

---

## 이론 요약

| 구성요소 | 역할 |
|----------|------|
| **Skills** | 반복 업무를 재사용 가능한 지시서로 저장 |
| **Sub-Agent** | 하위 작업을 병렬로 처리하는 AI |
| **MCP** | 외부 도구(Google Docs 등)와 연결하는 프로토콜 |
| **Plan Mode** | 실행 전 작업 계획을 검토·승인 |
| **자동 메모리** | 프로젝트 맥락을 자동으로 기억 |

**설치:**
```bash
npm install -g @anthropic-ai/claude-code
claude
```

---

## 실습 1: EV 시장 보고서 초안 생성

```
[Claude Code에 입력]
"EV 시장 분석 보고서를 작성해줘.
포함 내용: 글로벌 시장 규모, 상위 5개 브랜드 점유율, 한국 기업 포지셔닝, 전략 시사점 3개
저장 위치: EV_Market_Analysis.md"
```

## 실습 2: Automotive Skill 라이브러리 초안 작성

```
[Claude Code에 입력]
"자동차 산업 실무자가 자주 쓸 Claude Code Skill 10종 목록을 만들어줘.
각 Skill마다: 이름, 목적, 사용 시나리오를 포함해서
Automotive_Skill_Library.md 파일로 저장해줘."
```

---

## 산출물
- [ ] `Automotive_Skill_Library.md` — Skill 10종 목록
- [ ] 첫 번째 EV 분석 결과 파일
