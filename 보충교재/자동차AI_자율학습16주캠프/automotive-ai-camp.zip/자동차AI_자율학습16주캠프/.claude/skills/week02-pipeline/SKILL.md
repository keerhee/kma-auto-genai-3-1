---
name: week02-pipeline
description: 자동차 AI 자율학습 16주 캠프 2주차 수업 — AI 업무 생산성 파이프라인 설계. "2주차 시작", "2주차 수업", "week02" 등을 요청하면 사용한다.
week: 2
title: AI 업무 생산성 파이프라인 설계
duration: 3H (이론 1H · 실습 2H)
mode: 온라인
tools: [Claude, Google Docs]
---

# Week 2 — AI 업무 생산성 파이프라인 설계

## 학습 목표

- AI 업무 파이프라인 6단계를 설명하고 본인 업무에 적용할 수 있다
- RACI 프롬프트 구조로 정밀한 지시를 작성할 수 있다
- Porter's 5 Forces 전략 분석을 AI로 자동 생성할 수 있다

---

## 이론 (60분)

### 1. AI 업무 파이프라인 6단계

```
Research → Curate → Analyze → Write → Present → Automate
  리서치       선별       분석       작성      발표      자동화
```

| 단계 | 역할 | AI 도구 |
|------|------|---------|
| **Research** | 원시 정보 수집 | Perplexity, ChatGPT |
| **Curate** | 관련 정보 선별·정리 | Claude, NotebookLM |
| **Analyze** | 패턴 발견, 인사이트 도출 | Claude, Google Colab |
| **Write** | 보고서·문서 초안 작성 | Claude Code |
| **Present** | 발표자료·시각화 생성 | Claude Code, Google Slides |
| **Automate** | 반복 업무 워크플로화 | Claude Code, n8n |

### 2. RACI 프롬프트 구조

효과적인 AI 지시를 위한 4요소:

- **R**ole (역할): "너는 자동차 산업 전략 컨설턴트야"
- **A**ction (행동): "다음 데이터를 분석해서"
- **C**ontext (맥락): "한국 자동차 기업의 EV 전략 수립 목적으로"
- **I**nput/Output (입출력): "표 + 3가지 인사이트 형식으로 출력해줘"

**예시:**
```
[R] 너는 15년 경력의 자동차 산업 전략 애널리스트야.
[C] 현대자동차의 EV 글로벌 전략을 검토하는 중이야.
[A] Porter's 5 Forces 프레임워크로 현대차 EV 사업 환경을 분석해줘.
[I] 각 Force마다: 강도(상/중/하), 핵심 요인 3개, 전략적 시사점 1개를 포함해줘.
```

### 3. Porter's 5 Forces란

마이클 포터의 산업 경쟁 구조 분석 프레임워크:
1. 기존 경쟁자 간 경쟁 강도
2. 신규 진입자 위협
3. 대체재 위협
4. 구매자 교섭력
5. 공급자 교섭력

---

## 실습 (120분)

### 실습 1: 본인 업무 AI 파이프라인 재설계 (60분)

**Step 1: 현재 업무 목록 작성**
본인의 주요 반복 업무 5가지를 적어보자:
- 예: 주간 시장 동향 보고서 작성
- 예: 경쟁사 가격 모니터링
- 예: 고객 피드백 수집 및 정리

**Step 2: Claude로 파이프라인 설계**
```
프롬프트:
"나는 자동차 회사 [부서명] 담당자야.
내 주요 업무는 다음과 같아:
1. [업무 1]
2. [업무 2]
3. [업무 3]

각 업무를 Research→Curate→Analyze→Write→Present→Automate
6단계 AI 파이프라인으로 재설계해줘.
각 단계에서 어떤 AI 도구를 쓰고, 어떤 프롬프트를 사용할지 구체적으로 알려줘."
```

**Step 3: Google Docs에 저장**
- 문서명: `AI_Workflow_Design`

### 실습 2: Porter's 5 Forces 전략 분석 자동 생성 (60분)

**Step 1: 분석 대상 선정**
한국 자동차 기업 중 하나 선택 (현대/기아/한국GM 등)

**Step 2: Claude로 분석 생성**
```
프롬프트:
"[회사명]의 EV(전기차) 사업을 Porter's 5 Forces로 분석해줘.

형식:
## Porter's 5 Forces 분석: [회사명] EV 사업

### 1. 기존 경쟁자 간 경쟁 강도
- 강도: [상/중/하]
- 핵심 요인: (3가지)
- 전략적 시사점:

[나머지 4개 Force도 동일 형식으로]

## 종합 결론
- 가장 위협적인 Force와 대응 전략
- 가장 유리한 Force와 활용 방안"
```

**Step 3: 결과 저장**
- 문서명: `Porter_Analysis`

---

## 산출물 체크리스트

- [ ] `AI_Workflow_Design.docx` — 본인 업무 6단계 파이프라인
- [ ] `Porter_Analysis.docx` — Porter's 5 Forces 전략 분석

---

## 다음 주 예고

**Week 3: Claude Code 기본과 자동차 산업 적용**  
오프라인 실습: Claude Code 환경을 직접 설치하고 첫 번째 분석을 실행한다.
