---
name: week05-dataset
description: 자동차 AI 자율학습 16주 캠프 5주차 수업 — 자동차 산업 데이터셋 구축. "5주차 시작", "5주차 수업", "week05" 등을 요청하면 사용한다.
week: 5
title: 자동차 산업 데이터셋 구축
duration: 3H | 이론 0.5H · 실습 2.5H
mode: 오프라인
tools: [Claude Code, Google Sheets]
---

# Week 5 — 자동차 산업 데이터셋 구축

## 학습 목표
- 자동차 산업 핵심 데이터 유형 10종 이해
- EV 판매 교육용 데이터셋 50행 CSV 생성
- 고객 리뷰 데이터셋 30행 생성

---

## 자동차 산업 핵심 데이터 유형 10종

| # | 유형 | 예시 |
|---|------|------|
| D1 | EV 판매 데이터 | 브랜드별 월간 판매량 |
| D2 | 경쟁사 벤치마크 | 사양·가격·평점 비교 |
| D3 | 배터리 기술 | 에너지밀도·충전속도 |
| D4 | 고객 리뷰(VOC) | 감성·키워드·평점 |
| D5 | 부품 공급망 | 공급사·리드타임·단가 |
| D6 | 충전 인프라 | 지역별 충전소 수 |
| D7 | 금융/보조금 | 국가별 보조금 정책 |
| D8 | 생산 실적 | 공장별 생산량 |
| D9 | 시장 점유율 | 세그먼트별 MS |
| D10 | R&D 투자 | 기업별 R&D 비용 |

---

## 실습 1: EV 판매 데이터셋 생성 (D1)

```
[Claude Code에 입력]
"EV 판매 교육용 CSV 데이터를 생성해줘.
- 50행, 2022~2024년
- 컬럼: year, month, brand, model, country, sales_volume, price_usd, segment
- 브랜드: Tesla, BYD, Hyundai, Kia, BMW 포함
- 파일명: D1_EV_Sales.csv"
```

Google Sheets에 붙여넣기 → raw / clean / kpi 탭 3개 생성.

## 실습 2: 고객 리뷰 데이터셋 생성 (D4)

```
[Claude Code에 입력]
"전기차 고객 리뷰 교육용 데이터를 생성해줘.
- 30행 (아이오닉5·모델Y·BMW iX 각 10개)
- 컬럼: review_id, model, rating, review_text, sentiment, keywords
- 파일명: D4_Customer_Reviews.csv"
```

---

## 산출물
- [ ] `D1_EV_Sales.csv` (50행, raw/clean/kpi 탭)
- [ ] `D4_Customer_Reviews.csv` (30행)
