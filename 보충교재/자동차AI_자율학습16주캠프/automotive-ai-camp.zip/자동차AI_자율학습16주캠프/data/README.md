# data — 교육용 가상 샘플 데이터

**모두 실습용으로 지어낸 값이다.** 실제 판매량·재무·리뷰가 아니므로 업무 보고나 투자 판단에 쓰지 않는다.

5주차에 Claude Code로 직접 데이터를 만드는 것이 원래 순서다. 5주차를 건너뛰었거나 만든 파일이 깨졌을 때, 아래 파일로 6~8주차·11주차를 그대로 이어 갈 수 있다.

| 파일 | 쓰는 주차 | 내용 |
|---|---|---|
| `D1_EV_Sales.csv` | 6 · 7 | EV 판매 50행 — year, month, brand(Tesla · BYD · Hyundai · Kia · BMW 각 10행), model, country, sales_volume, price_usd, segment. 2022~2024년 분기 첫 달 |
| `D4_Customer_Reviews.csv` | 8 | 고객 리뷰 30행 — 아이오닉5 · 모델Y · BMW iX 각 10개, 모델마다 긍정 5 · 중립 2 · 부정 3. review_id, model, rating, review_text, sentiment, keywords(`;`로 구분) |
| `D2_Competitor_Benchmark.csv` | 11 | Tesla · BYD · Hyundai 대표 차종 3행 — 주행거리, 배터리, 급속 충전 시간, 가격, EV 점유율, 매출, 영업이익률, R&D, 브랜드 호감도, 주요 진출 지역 |

7주차의 `D1_EV_Sales.xlsx`는 이 CSV를 Google Sheets로 열어 raw · clean · kpi 탭을 만든 것이다. 실습 중에 Claude Code에게 "data/D1_EV_Sales.csv를 엑셀로 바꾸고 raw·clean·kpi 탭을 만들어 줘"라고 시키면 된다.

## 다시 만들기

```
python3 data/make_sample_data.py
```

시드가 고정돼 있어 몇 번을 돌려도 같은 파일이 나온다. 표준 라이브러리만 써서 따로 설치할 것이 없다.
