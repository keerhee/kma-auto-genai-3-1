"""교육용 가상 샘플 데이터 3종을 만든다 (시드 고정 — 다시 돌려도 같은 파일).

실제 판매·재무·리뷰가 아니다. 5주차에 직접 만든 데이터가 없을 때 6~8주차·11주차를 이어 가기 위한 대체용이다.
실행: python3 data/make_sample_data.py  (표준 라이브러리만 쓴다)
"""
import csv, random
from pathlib import Path

OUT = Path(__file__).resolve().parent
rng = random.Random(20260729)

# D1 — EV 판매 50행 (5주차 실습 1과 같은 컬럼)
MODELS = {'Tesla': [('Model 3', 'Sedan', 42000), ('Model Y', 'SUV', 47000)],
          'BYD': [('Atto 3', 'SUV', 33000), ('Seal', 'Sedan', 38000)],
          'Hyundai': [('IONIQ 5', 'SUV', 45000), ('IONIQ 6', 'Sedan', 43000)],
          'Kia': [('EV6', 'SUV', 46000), ('EV9', 'SUV', 58000)],
          'BMW': [('i4', 'Sedan', 56000), ('iX', 'SUV', 84000)]}
BASE = {'Tesla': 9000, 'BYD': 11000, 'Hyundai': 3500, 'Kia': 3200, 'BMW': 2600}
COUNTRIES = ['USA', 'China', 'Germany', 'Korea', 'Norway']
rows = []
months = [(y, m) for y in (2022, 2023, 2024) for m in (1, 4, 7, 10)]  # 분기 첫 달 12개
for i in range(50):
    y, m = months[i % len(months)]
    brand = list(MODELS)[i % 5]
    model, seg, price = MODELS[brand][(i // 5) % 2]
    growth = 1 + 0.18 * (y - 2022) + 0.03 * (m // 3)
    vol = int(BASE[brand] * growth * rng.uniform(0.7, 1.3))
    rows.append([y, m, brand, model, rng.choice(COUNTRIES), vol, int(price * rng.uniform(0.96, 1.04) // 100 * 100), seg])
rows.sort()
with open(OUT / 'D1_EV_Sales.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['year', 'month', 'brand', 'model', 'country', 'sales_volume', 'price_usd', 'segment']); w.writerows(rows)

# D4 — 고객 리뷰 30행 (5주차 실습 2와 같은 컬럼, 모델당 10개)
POS = [('주행거리가 기대보다 길어서 장거리도 걱정이 없다', '주행거리;장거리'), ('급속 충전이 빨라 휴게소에서 금방 채운다', '충전속도;급속충전'),
       ('실내가 넓고 조용해서 가족이 만족한다', '실내공간;정숙성'), ('소프트웨어 업데이트로 기능이 계속 좋아진다', 'OTA;소프트웨어'),
       ('가속이 부드럽고 힘이 넉넉하다', '가속;주행감')]
NEU = [('전반적으로 무난하지만 특별한 인상은 없다', '무난'), ('가격에 비해 옵션 구성이 평범하다', '가격;옵션')]
NEG = [('겨울철 주행거리가 눈에 띄게 줄어든다', '겨울;주행거리감소'), ('충전소 고장이 잦아 불편하다', '충전인프라;고장'),
       ('서비스센터 예약이 오래 걸린다', '서비스센터;대기'), ('승차감이 다소 딱딱하다', '승차감')]
reviews = []
rid = 1
for model in ['IONIQ 5', 'Model Y', 'BMW iX']:
    # 모델마다 긍정 5 · 중립 2 · 부정 3, 한 모델 안에서는 같은 문장을 되풀이하지 않는다
    pool = [(t, 'positive') for t in rng.sample(POS, 5)] + [(t, 'neutral') for t in NEU] + [(t, 'negative') for t in rng.sample(NEG, 3)]
    rng.shuffle(pool)
    for (text, kw), s in pool:
        rating = rng.choice([4, 5]) if s == 'positive' else 3 if s == 'neutral' else rng.choice([1, 2])
        reviews.append([f'R{rid:03d}', model, rating, text, s, kw]); rid += 1
with open(OUT / 'D4_Customer_Reviews.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['review_id', 'model', 'rating', 'review_text', 'sentiment', 'keywords']); w.writerows(reviews)

# D2 — 3사 벤치마크 (11주차 7가지 비교 축 중 수치로 쓸 수 있는 칸)
D2 = [
    # brand, model, range_km, battery_kwh, charge_10_80_min, price_usd, global_ev_share_pct, revenue_bn_usd, op_margin_pct, rnd_bn_usd, brand_favorability_1to5, main_regions
    ['Tesla', 'Model Y', 530, 75, 27, 47000, 18, 95, 9, 4.0, 4.1, '북미;중국;유럽'],
    ['BYD', 'Atto 3', 420, 60, 30, 33000, 22, 80, 6, 5.5, 3.7, '중국;동남아;유럽'],
    ['Hyundai', 'IONIQ 5', 480, 77, 18, 45000, 5, 120, 8, 3.0, 3.9, '한국;북미;유럽'],
]
with open(OUT / 'D2_Competitor_Benchmark.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['brand', 'model', 'range_km', 'battery_kwh', 'charge_10_80_min', 'price_usd', 'global_ev_share_pct',
                'revenue_bn_usd', 'op_margin_pct', 'rnd_bn_usd', 'brand_favorability_1to5', 'main_regions'])
    w.writerows(D2)
print('D1', len(rows), '행 · D4', len(reviews), '행 · D2', len(D2), '행')
