# 시작하기 — 자동차 AI 자율학습 16주 캠프

이 폴더 하나로 16주를 혼자 따라 할 수 있게 정리했다. 순서대로 읽고 준비한다.

## 1. 이 캠프의 방식 — 스킬이 수업을 한다

주차마다 `.claude/skills/weekNN-…/SKILL.md` 파일이 하나씩 있다. 이 파일이 그 주의 교재이자 강사다. Claude Code가 스킬을 읽고 이론 설명 → 실습 안내 → 산출물 만들기를 진행한다. 수강생은 프롬프트를 붙여 넣고 결과를 확인한다. 코드는 직접 쓰지 않는다.

## 2. 준비물

### 꼭 필요한 것

| 무엇 | 쓰는 주차 | 비용 |
|---|---|---|
| **Claude 구독(Pro 이상) + Claude 데스크톱 앱** — 앱 안의 **Code 탭**이 Claude Code다 | 2~16 | 구독료 |
| **Google 계정** — Docs · Sheets · Drive · Slides · Colab · NotebookLM · Gmail | 1, 4~16 | 무료 |

### 그 주에만 쓰는 것

| 무엇 | 쓰는 주차 | 비용 · 참고 |
|---|---|---|
| ChatGPT · Perplexity | 1, 9, 10 | 무료 요금제로 충분하다. Perplexity가 없으면 Claude 웹 검색으로 대신한다 |
| Google Opal (opal.google) | 12, 13 | 무료. 지역·계정에 따라 열리지 않을 수 있다 — 안 되면 해당 실습을 건너뛴다 |
| Google Veo 3.1 (Gemini · Google Vids) | 12, 13 | 요금제에 따라 사용 횟수가 다르다. 선택 실습 |
| Remotion (영상 코드) | 12 | Claude Code가 설치한다. 선택 실습 |
| n8n | 14, 15 | n8n 클라우드 무료 체험 또는 내 PC 설치(Claude Code에게 "n8n을 내 PC에 설치하고 실행해 줘") |
| Claude API 키 | 14 | **쓴 만큼 과금**된다. n8n 워크플로가 뉴스 요약에 쓴다. 키는 n8n 화면에만 넣고 파일·채팅에 붙이지 않는다 |

## 3. 설치와 첫 실행 (10분)

1. Claude 데스크톱 앱을 설치하고 로그인한다.
2. 앱에서 **Code** 탭 → 새 세션 → 작업 폴더로 **이 캠프 폴더**를 고른다.
3. 입력칸에 붙여 넣는다.

```
이 폴더의 START_HERE.md와 README.md를 읽고, .claude/skills에 있는 주차 스킬 16개를 표로 보여 줘.
그다음 1주차 수업을 시작해 줘.
```

3주차 스킬에는 터미널 설치 명령(`npm install -g @anthropic-ai/claude-code`)이 나온다. 데스크톱 앱 Code 탭을 쓰면 이 설치는 건너뛴다.

## 4. 매주 하는 일

1. Code 탭에서 이 폴더를 연다.
2. `/weekNN-…`(예: `/week05-dataset`)를 입력하거나 "5주차 수업을 시작해 줘"라고 쓴다.
3. 스킬이 안내하는 프롬프트를 붙여 넣고, 산출물이 생겼는지 확인한다.
4. 마지막에 "이번 주 산출물 체크리스트를 확인해 줘"라고 묻는다.

산출물은 이 폴더 안에 생긴다. 정리하고 싶으면 "이번 주 산출물을 output/W05로 옮겨 줘"라고 시킨다. `.docx`로 적힌 산출물은 Claude Code가 만든 `.md`를 Google Docs에 붙여 넣어 만든다.

## 5. 주차가 이어지는 방식 — 앞 주차 산출물이 뒤에서 쓰인다

| 만드는 주차 | 산출물 | 다시 쓰는 주차 | 없을 때 |
|---|---|---|---|
| 1 | `W01_Automotive_AI_Landscape` (AI 사례 20개) | 4 | 4주차에서 Claude Code에게 사례 조사부터 시킨다 |
| 5 | `D1_EV_Sales.csv` | 6, 7 | `data/D1_EV_Sales.csv` |
| 5 | `D4_Customer_Reviews.csv` | 8 | `data/D4_Customer_Reviews.csv` |
| 7 | `D1_EV_Sales.xlsx` (KPI 탭) | 7 | `data/` CSV를 엑셀로 바꿔 달라고 시킨다 |
| 9 | NotebookLM 지식베이스 (뉴스 10개) | 10 (기술 자료 3개를 더한다) | 9주차 실습 1을 먼저 한다 |
| 11 | `D2_Competitor_Benchmark.xlsx` (3사 비교표) | 11 산출물 | `data/D2_Competitor_Benchmark.csv`를 엑셀로 바꿔 달라고 시킨다 |
| 7~11 | 시장 · VOC · 뉴스 · 기술 · 경쟁사 보고서 | 12 (임원용 전략 보고서로 통합) | 있는 보고서만으로 통합해 달라고 시킨다 |
| 1~14 | 지금까지의 산출물 전체 | 15 (최종 프로젝트, 옵션 A · B · C 중 택 1) | 갖춘 산출물이 많은 옵션을 고른다 |
| 15 | 최종 프로젝트 | 16 (발표) | — |

## 6. 처음 나오는 말

| 말 | 뜻 |
|---|---|
| 스킬(Skill) | Claude에게 주는 업무 설명서 파일(`SKILL.md`). 부르면 그 안의 순서대로 일한다 |
| Claude Code | 내 PC의 파일을 읽고 만들고 실행까지 하는 Claude. 데스크톱 앱의 Code 탭 |
| 프롬프트(prompt) | AI에게 주는 작업 지시문 |
| MCP(Model Context Protocol) | Claude가 Google Docs 같은 외부 도구를 쓰게 연결하는 규격 |
| VOC(Voice of Customer) | 고객 리뷰·불만 같은 고객의 목소리 |
| NotebookLM | 올린 자료만 근거로 답하고 요약·오디오·영상을 만들어 주는 Google 도구 |
| n8n | 정해진 시각에 정해진 일을 이어서 하게 만드는 자동화 도구(워크플로) |
| 에이전트 팀(Agent Team) | 역할을 나눈 여러 Claude가 한 과제를 나눠 맡는 구조(13주차) |

## 7. 막힐 때

- 증상을 그대로 Claude Code에 붙여 넣는다: "이런 오류가 났어. 원인을 찾아 고쳐 줘."
- 데이터 파일이 없거나 깨졌으면 `data/` 샘플로 바꾼다.
- 외부 도구(Opal · Veo · n8n)가 안 열리면 그 실습은 건너뛰고, 같은 주차의 Claude Code 실습을 먼저 끝낸다.
