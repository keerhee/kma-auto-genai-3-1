# showreel 스킬 사용법

## 설치
- **claude.ai(웹·데스크톱)**: 설정 → 기능(Capabilities) → Skills → "스킬 업로드"에서 `showreel_skill.zip` 업로드
- **로컬 Claude Code(macOS)**: `unzip showreel_skill.zip -d ~/.claude/skills/` → `cd ~/.claude/skills/showreel/scripts && npm install`
  - 필요: `brew install ffmpeg node`, `pip3 install numpy pillow`, Google Chrome
  - 나레이션·AI 음악: `export ELEVENLABS_API_KEY=sk_...` (Music은 유료 플랜)
- 점검: `python3 <스킬폴더>/scripts/preflight.py`

## 요청 예시
"쇼릴"이라는 말만 넣으면 스킬이 실행됩니다(`/showreel`도 됨).
- `KAIST 금융 AI 강의 소개 20초 쇼릴, 나레이션 없이`
- `이 내용으로 쇼릴 만들어줘, 바탕은 일관성 있게`
- `/showreel KAIST 금융 AI 강의 소개 60초 영상. 나레이션 없이 음악과 타이포로.`
- `연기금 TPA 개념을 설명하는 30초 티저 모션그래픽`
- `ZeroOneAI 브랜드 필름 60초, 웅장하게, 나레이션 넣어서` (나레이션은 로컬+ElevenLabs 키 필요)
- 세로 숏폼: `... 9:16 릴스용 15초`

## Claude가 묻는 것 / 스스로 정하는 것
- 묻는 것: 대상, 꼭 넣을 정보(이름 표기·일시·URL·CTA), 자료 위치
- 스스로 정하는 것: 무드·팔레트·길이·구성·나레이션 여부 (콘셉트 후보 3개 이상 비교 후 선택)

## 산출물 (프로젝트 폴더 out/)
마스터 MP4 · 공유용 MP4 · 포스터 JPG · SRT(나레이션 시) · 제작노트(재생성 명령 포함)

## 환경별 차이
| 항목 | 로컬 macOS | 클라우드 세션 |
|---|---|---|
| 렌더·믹스·검수 | ○ | ○ (느림: 60초 최종본 수십 분) |
| 한글 폰트 | ○ | ○ (npm 경로로 자동 확보) |
| ElevenLabs 나레이션·음악 | ○ (키 필요) | ✕ (네트워크 차단) → 합성 음악·무나레이션 |
| AI 이미지(codex-image) | ○ (별도 설치) | ✕ → 코드 그래픽·사용자 사진 |
| 인물 누끼 | ○ | ✕ |

## 팁
- 사진·로고를 쓰려면 첨부하고 "이 사진 넣어줘"라고 하면 됩니다.
- 오디오만 고칠 때는 영상 재렌더 없이 `mix.py`·`finish.py`만 다시 돕니다.
- 소리는 Claude가 들을 수 없으니 완성본은 직접 들어 보고 피드백 주세요.

원본: https://github.com/revfactory/showreel (MIT)
