---
name: "remotion-motion-catalog"
description: "효과 이름(자막·전환·로고·데이터·지도·3D·금융 차트 등 106종)으로 요청하면 Remotion 컴포지션으로 모션그래픽을 만들어 MP4·투명 오버레이로 렌더한다. \"모션그래픽\", \"lower third\", \"이름 자막\", \"키네틱 타이포\", \"막대 순위 경주\", \"켄 번스\", \"수식 등장 애니메이션\", \"누적수익 곡선 영상\", \"강의 영상 인서트\", \"리모션으로 만들어줘\" 등에 사용."
---

# Remotion 모션그래픽 카탈로그

효과 **이름**으로 주문하면 Remotion 컴포지션을 만들어 렌더한다. 카탈로그는 일반 모션그래픽 88종(I·T·B·M·S·E·N·H 계열)과 금융·강의용으로 보강한 18종(F 계열)으로 이루어진다.
분류와 효과 이름은 한국경영교육연구소 AI ACADEMY «모션그래픽 주문 사전»(nondev-thinking.web.app/motion, HyperFrames용)을 참고했고, 요청 문장과 Remotion 구현은 새로 썼다.

## 1. 주문 공식

```
그래픽 이름(영문명) + 넣을 글자·파일 + 길이·시점 + 색·화면 비율
예) 방송형 이름 자막(lower third) 만들어줘. 이름: 이기홍. 직함: KAIST 겸임교수. 4초. 네이비 판에 주황 선.
```

- 이름이 모호하면 §5 카탈로그에서 가장 가까운 ID를 고르고, 고른 ID를 한 줄로 알린다.
- 비율 기본값은 16:9 1920×1080, 30fps다. 쇼츠는 1080×1920, 정사각은 1080×1080.
- 색 기본값은 네이비 금융 강의 톤(`theme.ts`: navy `#0B1F3A`, 포인트 orange `#F28C28`)이다.

## 2. 작업 순서

1. **프로젝트 확인.** 작업 폴더에 `remotion-motion-starter`(src/theme.ts, src/lib/anim.ts, src/motions/*.tsx)가 있으면 그대로 쓴다. 없으면 §3 최소 골격을 만들고 `npm i remotion @remotion/cli react@18 react-dom@18 katex`로 설치한다.
2. **ID 고르기.** §5에서 ID를 찾는다. ✅ 표시가 있으면 스타터에 컴포넌트가 이미 있으므로 props만 채운다. 없으면 표의 "구현 요점"대로 `src/motions/`에 새 컴포넌트를 쓰고 `Root.tsx`에 `<Composition id="<ID>-<Name>">`로 등록한다.
3. **props 분리.** 글자·숫자·파일명은 `props.json`으로 넘긴다(`--props=props.json`). 데이터는 CSV/JSON을 `public/`에 두고 `staticFile` + `delayRender`로 읽거나, 파이썬으로 미리 계산해 JSON으로 넣는다.
4. **정지 화면 점검.** 영상 렌더 전에 `bash scripts/stills.sh <ID>`로 70% 지점 스틸과 contact sheet를 뽑고 **직접 열어 본다**. 겹침, 넘침, 잘림, 한글 폰트 대체를 고친다.
5. **렌더.**
   - 일반: `npx remotion render src/index.ts <ID> out/<ID>.mp4 --props=props.json`
   - 투명 오버레이(자막·이름표·진행 바를 기존 영상에 얹을 때): 배경을 `transparent`로 두고 `--codec=prores --prores-profile=4444 --image-format=png --pixel-format=yuva444p10le` → `.mov`
   - 미리보기만 할 때는 `--scale=0.5`
6. **결과 확인.** 렌더된 MP4에서 3~4 지점 프레임을 뽑아 본 뒤 전달한다.

## 3. Remotion 구현 규칙 (반드시 지킨다)

- **모든 움직임은 프레임 함수로 계산한다**: `useCurrentFrame()` → `interpolate` / `spring`. CSS `transition`·`@keyframes`·`setTimeout`·차트 라이브러리 내장 애니메이션은 렌더에서 깨지므로 쓰지 않는다.
- **`Math.random()` 금지.** 입자·그레인·흔들림은 시드 기반 의사난수(`rand(seed)`)를 쓴다.
- 이미지는 `<Img src={staticFile('a.jpg')}>`, 영상은 `<OffthreadVideo>`, 소리는 `<Audio>`. 외부 URL 대신 `public/`에 둔다.
- 장면 이어 붙이기는 `<Series>`, 겹치는 타이밍은 `<Sequence from=…>`, 장면 전환은 `@remotion/transitions`(`TransitionSeries` + fade·slide·wipe·flip·clockWipe 등)을 쓴다.
- 선 그리기는 SVG `strokeDasharray`/`strokeDashoffset` 또는 `@remotion/paths`의 `evolvePath`로 한다.
- 3D는 `@remotion/three`의 `<ThreeCanvas>` + three.js로 만든다. 회전·카메라는 `useCurrentFrame`으로 계산하고, R3F의 `useFrame`은 쓰지 않는다. 3D 안에 한글을 새기지 말고 2D 레이어를 위에 얹는다.
- 수식은 KaTeX(`katex.renderToString` + `katex/dist/katex.min.css`)로 렌더한다. 수식을 텍스트로 풀어 쓰지 않는다.
- 지도는 d3-geo + 공개 GeoJSON(Natural Earth, 행정구역 경계 공개 데이터)으로 그리고 출처를 화면 구석에 작게 적는다.
- 글꼴은 Pretendard → Noto Sans KR 순으로 폴백한다. 1080p 기준 본문은 28px 이상, 제목은 60px 이상으로 하고, 가장자리 80px 안쪽(세이프 에어리어)에 둔다.
- 제목·자막·숫자·차트는 이미지 생성 모델에 맡기지 않고 Remotion에서 그린다.
- 리눅스·샌드박스에서 Chrome Headless Shell 다운로드가 막히면 `--browser-executable=<로컬 chrome/headless_shell 경로>`를 붙인다(Playwright 설치본 사용 가능).

### 공용 헬퍼 (`src/lib/anim.ts`)

| 함수 | 용도 |
|---|---|
| `prog(f, from, dur)` | 0→1 진행률 (easeOut) |
| `pop(f, from, stiffness, damping)` | 튀어나오는 스프링 |
| `inOut(f, a, b, c, d)` | 들어왔다 나가는 0→1→0 |
| `shake(f, from, amp, dur)` | 감쇠 진동 (도장·충격) |
| `rand(seed)` | 결정적 의사난수 |
| `countUp(f, from, dur, target, digits)` | 숫자 카운트업 문자열 |
| `typed(text, f, from, cps)` | 한 글자씩 타이핑 |

### 최소 골격 (스타터가 없을 때)

```
src/index.ts      registerRoot(RemotionRoot)
src/Root.tsx      <Composition id component durationInFrames fps=30 width=1920 height=1080 defaultProps>
src/theme.ts      색·글꼴·sec(s)=Math.round(s*30)
src/lib/anim.ts   위 헬퍼
src/motions/*.tsx 계열별 컴포넌트 (Captions / Explain / Finance / Media / Map / Three …)
public/           이미지·영상·데이터
remotion.config.ts  Config.setVideoImageFormat('jpeg'); Config.setOverwriteOutput(true)
```

## 4. 사실성 규칙

- 후기·인용문·통계·수익률·인증·수상은 **사용자가 준 실제 자료만** 쓴다. 지어내지 않는다.
- 예시 데이터로 만든 화면에는 화면 안에 «예시»라고 표시한다.
- 인용문에는 출처를 적는다. 출처가 불확실하면 그렇게 표시한다.
- 수익률·적립 그래프는 «세전·예시 계산» 표기를 붙이고, 수익을 약속하는 문구는 쓰지 않는다(금융 광고 규제).
- 누적수익·드로다운·효율적 투자선처럼 계산이 들어가는 값은 컴포넌트나 파이썬에서 **계산해서** 넣고, 손으로 적지 않는다.
- 인물 이름·사진은 본인 동의가 있는 경우만 넣는다. 외부 사진·아이콘·3D 모델은 상업 이용이 가능한지 확인한다.

## 5. 카탈로그

✅ = 스타터에 컴포넌트가 있음 (컴포지션 id = `ID-이름`). 길이는 권장값이다.

### 🖼️ 내 이미지 넣기 (I)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| I01 ✅ | 켄 번스 줌 배경 (Ken Burns) | 5–10s | 사진 한 장으로 영상 배경 | `scale` 1.0→1.18 + `translateX` 선형, `objectFit: cover` |
| I02 ✅ | 사진 배경 + 제목 (photo title card) | 3–6s | 챕터 표지 | 사진 blur·어둡게 → 제목 아래에서 올라옴 |
| I03 | 폴라로이드 떨어뜨리기 (polaroid drop) | 4–6s | 행사·현장 사진 모음 | 흰 테두리 카드가 `pop`으로 낙하, 카드마다 `rand` 각도 ±8° |
| I04 | 사진 콜라주 그리드 (bento collage) | 4–6s | 포트폴리오·상품 모음 | CSS grid 크기 다른 칸, 칸별 지연 `pop`, 전체 `scale` 1→1.05 |
| I05 | 3D 사진 카드 기울이기 (3D tilt card) | 3–5s | 대표 사진·자격증 | CSS `perspective` + `rotateY/X` 사인 곡선, 대각 광택 그라데이션 이동 |
| I06 | 3D 궤도 갤러리 (orbit carousel) | 6–10s | 사진 여러 장 자랑 | 카드 N장을 원 위 배치, 각도 = f·ω, 앞쪽일수록 `scale`·`zIndex` 크게 |
| I07 | 2.5D 패럴랙스 사진 (parallax photo) | 4–8s | 다큐·회상 | 전경(누끼 PNG)·배경 레이어를 다른 속도로 `scale`·`translate` |
| I08 | 휴대폰 화면 목업 (phone mockup) | 4–8s | 앱·홈페이지 소개 | 기기 프레임 div 안 캡처 `translateY` 스크롤, 기기 `rotateY` 살짝 |
| I09 | 글자 속 사진 (image text mask) | 3–5s | 오프닝 타이틀 | `background-clip: text` + 사진 배경, 끝에 글자 `scale` 확대로 전체 노출 |
| I10 | 입자로 사진 등장 (particle image reveal) | 4–6s | 대표 사진 공개 | 사진 픽셀 샘플 → 점 수천 개가 `rand` 위치에서 모임(three Points 또는 canvas), 2/3 지점 원본 크로스페이드 |

### 🔤 자막·글자 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T03 ✅ | 키네틱 타이포 (kinetic typography) | 2–3s | 쇼츠 첫 3초 훅 | 단어별 구간, `pop` 2.4→1 스케일 + `shake`, 단어마다 배경색 |
| B01 ✅ | 예능 효과 자막 (variety pop caption) | 1–1.5s | 리액션 강조 | 노란 글자 + `WebkitTextStroke` 굵은 외곽선, 강한 스프링 + 흔들림 |
| B02 | 속마음 자막 (inner-thought caption) | 1.5–3s | 공감 포인트 | 글자별 `blur`→0 번짐, 배경 `saturate` 낮춤 |
| B03 ✅ | 효과 도장 (stamp impact) | 0.6–1s | 정답·결론 못 박기 | 3.2→1 낙하, 착지 순간 잉크 방울 방사 + 화면 `shake` |
| B07 | 뉴스 속보 띠 + 흐르는 자막 (breaking bar · ticker) | 5–20s | 핵심 한 줄, 공지 | 빨간 딱지 slide-in, 하단 티커 `translateX = -f·속도` 반복 |
| T20 ✅ | 인용문 카드 + 필름 그레인 (quote card) | 5–8s | 강의 마무리 한 문장 | 단어별 blur-in, 비네트 + 결정적 그레인 오프셋, 출처 필수 |

### 🧑‍🏫 설명·교육 (T)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T10 ✅ | 개념 도해 자동 그리기 (animated diagram) | 4–6s | 순서·흐름 설명 | 상자 `pop` 순차 등장, 화살표 선 길이 `prog`, 박스 폭 자동 맞춤 |
| T11 ✅ | AI 채팅 화면 재현 (chat UI mockup) | 5–10s | 프롬프트 강의 | 질문 `typed` → 점 세 개 → 답 줄별 fade-up |
| T12 ✅ | 터미널 실행 화면 (terminal typing) | 4–8s | 코딩·설치 시연 | 창 크롬 + 명령 `typed` + ✓ 줄 순차 |
| T13 | 3D 디오라마 (isometric diorama) | 6–12s | 구조를 비유로 설명 | `@remotion/three` 박스 세트, 구슬 경로 보간, 카메라 궤도, 이름표는 2D 오버레이 |
| T14 | OX 퀴즈 카운트다운 (quiz countdown) | 6–8s | 강의 중 참여 | 원형 타이머 `strokeDashoffset` 감소 → B03 도장 + 해설 |
| T17 | 용어 팝업 카드 (pop-up info card) | 3–5s | 전문 용어 등장 순간 | 카드 `pop`, 뜻 `typed`, 형광펜 밑줄 폭 `prog` |
| T19 | 화면 줌 + 스포트라이트 (zoom & spotlight) | 4–6s | 사용법 안내 | `OffthreadVideo` 위 radial mask로 주변 어둡게, 대상 좌표로 `scale` 확대 + 말풍선 |

### 📊 데이터·비교 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T06 | 3D 데이터 도시 (3D bar city) | 10–15s | 결산·성과 발표 | three 박스 높이 = 값, 순차 상승 후 카메라 상승, 합계 `countUp` |
| T07 | 지도 핀 드롭 (map pin drop) | 6–10s | 지점·매장 분포 | d3-geo 점 지도, 핀 `pop` 낙하 + 물결 원 확대, 개수 카운터 |
| T08 ✅ | 막대 순위 경주 (bar chart race) | 8–15s | 순위 변화 | 기간 사이 값 선형 보간, 매 프레임 정렬 → `top` 위치, 우하단 큰 기간 라벨 |
| T09 ✅ | 전·후 비교 스플릿 (before/after split) | 4–6s | 개선 전후 | 두 이미지 겹침 + `clipPath inset`, 경계선 좌우 왕복 |
| B10 | 투표·설문 결과 그래프 (poll results) | 3–5s | 설문 결과 | 가로 막대 폭 `prog` + % `countUp` |

### 🔀 장면 전환 (B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| B09 ✅ | 코너 전환 브리지 (bumper) | 1–1.5s | 챕터 전환 | 사선 면 두 장이 시차를 두고 통과, 번호·제목 잠깐 노출 |
| B12 | 3D 큐브 전환 (cube transition) | 0.8–1.2s | 주제 급전환 | 두 장면을 큐브 두 면에 `rotateY` 0→-90°(CSS 3D) 또는 transitions의 `flip` 변형 |
| B13 | 잉크 번짐 전환 (ink bleed) | 1–1.5s | 감성 챕터 전환 | `@remotion/noise` 임계값 마스크를 `prog`로 확장 |
| B14 | 필름 빛 샘 전환 (light leak) | 0.6–1s | 브이로그·감성 | 주황·분홍 radial 그라데이션이 대각 이동, `mixBlendMode: screen`, 최고 밝기에서 장면 교체 |
| B15 | 분할 화면 (split screen) | 1.5–3s | 여러 반응·현장 | grid 1→2→4 칸 `clipPath`로 열기, 각 칸 `OffthreadVideo` |
| B16 | VHS 되감기 (VHS rewind) | 1–2s | 회상·다시 보기 | 줄무늬·RGB 분리(`text-shadow`/채널 오프셋)·`rand` 흔들림 + ◀◀ 표시 |

### 🎬 오프닝·로고 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T01 | 입자 로고 인트로 (particle logo reveal) | 3–5s | 채널·과정 인트로 | 로고 알파 샘플 → 입자 수렴·반짝·흩어짐 |
| B08 | 3D 로고 스팅 (3D logo sting) | 1.5–2.5s | 매 영상 맨 앞 | three 원기둥 배지 + 로고 텍스처, 감속 회전, 스펙큘러 하이라이트 이동 |
| B19 | 3D 무대 오프닝 타이틀 (stage opening) | 3–5s | 특집·행사 오프닝 | 스포트라이트 원뿔 순차 점등(opacity 깜빡임), 제목 상승 |
| T15 | 물결 배경 루프 (gradient loop) | 무한 | 자막 뒤 배경 | 위상 = 2π·f/D로 사인 물결 → 첫·끝 프레임 일치(끊김 없는 루프) |

### ✨ 효과·오브젝트 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T02 | 제품 360° 턴테이블 (product turntable) | 5–8s | 교재·굿즈 소개 | three 평면/박스 + 텍스처, 반사 바닥, `rotation.y = f·ω` |
| T18 | 3D 떠다니는 아이콘 (floating icons) | 5–8s | 챕터 전환·썸네일 | 아이콘별 `rand` 위상의 상하 사인 + 느린 회전 |
| B06 | 이모지 폭죽 (emoji burst) | 1–2s | 축하 장면 | 중심에서 방사 속도 + 중력 포물선, 투명 배경 |
| B04 | 집중선 + 화면 흔들림 (speed lines · shake) | 0.5–1s | 반전·충격 | 방사 선 SVG, 1.2배 줌 펀치, 흰 플래시, `shake` 감쇠 |

### 🙋 인물·후기 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T16 ✅ | 방송형 이름 자막 (lower third) | 4–5s | 강의·인터뷰 시작 | 포인트 바 `scaleY` → 흰 판 `clipPath` 펼침 → 이름·직함, 역순 퇴장. 오버레이는 `bg:'none'` |
| B05 | 캐릭터 이름표 (name callout) | 2–3s | 출연자 소개 | 화살표 선 그리기 + 이름표 `pop`, 얼굴 가리지 않게 좌표 지정 |
| B11 | 화상 연결 창 (PiP call window) | 3–6s | 인터뷰·원격 연결 | «연결 중…» 점멸 → 창 `scale` 확대 + `OffthreadVideo` |
| T04 | 후기 카드 캐러셀 (testimonial carousel) | 6–10s | 홍보 영상 | 카드 `translateX` 순차, 별점. **실제 후기만** |

### 🔔 엔딩·구독 (T·B)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| T05 | 전화 CTA 엔드카드 (CTA end card) | 3–5s | 문의 유도 | 번호 `typed` + 버튼 `scale` 1+0.05·sin 맥동 |
| B17 ✅ | 챕터 진행 바 (chapter progress bar) | 영상 내내 | 긴 강의 길잡이 | 점·진행선, 현재 챕터 강조. 오버레이는 투명 배경으로 렌더 |
| B18 | 구독·좋아요 유도 (subscribe animation) | 3–4s | 구독 유도 | 커서 경로 보간 → 클릭 시 버튼 색 전환 → 종 흔들림 → 좋아요 pop |
| B20 | 엔딩 카드 (end screen) | 5–20s | 유튜브 최종 화면 | 흐린 배경 + 다음 영상 칸 2개·구독 원 자리(실제 요소는 YouTube Studio에서 배치) |

### 🗺️ 지도·장소 안내 (M)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| M01 | 도시 소개 3D 비행 (city flyover) | 6–10s | 지역 소개 첫 장면 | three 블록 미니어처 도시, 카메라 스플라인 경로, 명소 통과 시 2D 라벨 |
| M02 | 지역 확대 + 동그라미 (map zoom-in highlight) | 5–8s | 대상 지역 소개 | d3-geo `fitExtent` 전역→대상 투영 보간, 손그림 원 `evolvePath` |
| M03 | 찾아오는 길 경로 (route line) | 5–8s | 오시는 길 | 경로 좌표 → 선 그리기 + 이동 점, 도착 시 «도보 N분» 칩 |
| M04 | 명소 핀 투어 + 사진 카드 (map pin tour) | 8–12s | 코스·맛집 투어 | 핀 사이 카메라(투영 중심·축척) 보간, 핀마다 사진 카드 pop, 점선 연결 |
| M05 | 노선도식 코스 안내 (transit-style map) | 6–10s | 코스·과정 순서 | 45° 꺾인 경로, 열차 점 경로 보간 + 역 정차, 지난 구간 색 채움 |
| M06 | 층별 안내 3D (floor directory) | 6–10s | 병원·상가 층 안내 | three 반투명 판 N장 벌어짐, 선+라벨, 대상 층 발광 |
| M07 | 3D 지형 코스 비행 (terrain trail flyover) | 8–15s | 둘레길·등산로 | DEM 높이맵 → PlaneGeometry 변위, GPX 경로 선, 하단 고도 그래프 동기화 |
| M08 | 날씨 안내 카드 (weather card) | 5–8s | 행사·관광 안내 | 아이콘 애니메이션 + 기온 `countUp` + 3일 예보 순차. 입력값만 사용 |
| M09 | 지역 한눈에 카드 (region fact card) | 6–10s | 지자체·지역 소개 | I01 배경 + 네 칸 아이콘 타일 순차. 통계는 최신 공식값 |
| M10 | 산지에서 식탁까지 (farm-to-table) | 5–8s | 로컬푸드 홍보 | 트럭 SVG가 곡선 경로 이동(`getPointAtLength`), 도착 후 접시 pop |
| M11 | 역세권 거리 링 (distance rings) | 5–8s | 입지 장점 | 동심원 반지름 = 도보 속도×시간÷축척, 원 안 장소 점 순차 |

### 🏪 가게·서비스 안내 (S)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| S01 | 메뉴판 보드 (menu board) | 5–7s | 메뉴·가격 안내 | 칠판 배경, 줄별 slide-in, 점선 리더, 추천 배지 반짝 |
| S02 | 영업시간 안내 (business hours) | 4–6s | 운영·진료 시간 | 요일 칸 7개 순차 점등, 오늘 요일 맥동, 휴무 회색 |
| S03 | 요금제 3단 비교 (pricing tiers) | 4–6s | 수강료·회원권 | 카드 3장 상승, 가운데 확대 + 추천 배지, 체크 순차, 가격 `countUp` |
| S04 | 쿠폰·도장 적립 (coupon & stamp card) | 4–6s | 단골 이벤트 | 쿠폰 절취 회전, 도장 칸 순차 B03 |
| S05 | 예약 3단계 안내 (booking steps) | 5–7s | 예약 방법 | 상단 진행 레일 + 단계 카드 pop, 지난 단계 ✓ |
| S06 | 제품 특징 콜아웃 (spec callouts) | 4–6s | 상품 상세 | 사진 위 점 맥동 → 꺾인 선 그리기 → 라벨 |
| S07 | 매물 소개 카드 (property listing) | 5–7s | 부동산·숙소 | 사진 크로스페이드 + 정보 카드 slide-in + 핀 |
| S08 | 평면도 → 3D 집 (floor plan to 3D) | 5–7s | 구조 설명 | 벽 선 그리기 → three `ExtrudeGeometry` 높이 0→h → 카메라 궤도 + 방 라벨 |
| S09 | 한정 수량 카운터 (limited stock) | 4–6s | 한정 판매 | 숫자 롤 다운 + 잔량 막대 감소. **실제 수량만** |

### 📅 일정·행사 (E)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| E01 | D-day 카운트다운 (event countdown) | 4–6s | 개강·행사 예고 | 플립 숫자판(`rotateX` 반쪽 회전) D-7→D-DAY, 끝에 B06 |
| E02 | 행사 시간표 (event timetable) | 5–8s | 세미나 순서 | 줄 순차 점등, «지금» 막대 `top` 보간, 지난 줄 흐리게 |
| E03 ✅ | 연혁 타임라인 (history timeline) | 6–10s | 기관 소개 | 가로선 성장 + 연도 점 pop, 라벨 위아래 교차 |
| E04 | 행사 포스터 모션 (animated poster) | 5–8s | SNS 공유 | 세로 판 위 도형 → 제목 → 날짜 → 장소 순 조립 |
| E05 | QR 참가 신청 (scan-QR CTA) | 4–6s | 신청 안내 | `qrcode` 패키지로 **실제 주소** SVG 생성, 스캔선 이동 + 모서리 괄호 수축 |
| E06 | 축제 불꽃 오프닝 (fireworks opening) | 4–6s | 개막 알림 | 입자 발사 → 폭발 방사 + 중력, 제목 glow |
| E07 | 행사장 부스 배치도 (venue booth map) | 5–8s | 박람회 안내 | 격자 부스 순차 점등, 입구→대상 점선 경로, 핀 |

### 📢 공지·절차·캠페인 (N)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| N01 | 안전 수칙 픽토그램 (safety pictograms) | 5–8s | 안전·위생 교육 | 타일 순차 + ⭕/❌ 도장(B03) |
| N02 | 신청 절차 흐름도 (process flow) | 5–8s | 지원 사업 안내 | T10 변형 + 서류 아이콘이 단계 이동, 지난 단계 ✓ |
| N03 | 채용 공고 카드 (hiring announcement) | 5–8s | 인력 모집 | 제목 → 조건 칩 순차 → 지원 띠 펼침. 실제 공고와 일치 |
| N04 | 조직도 펼치기 (org chart) | 5–8s | 기관 소개 | 트리 레이아웃 계산 → 가지선 그리기 → 노드 pop, 팀별 색 |
| N05 | 인증·수상 배지 벽 (awards wall) | 4–6s | 신뢰 부여 | 배지 걸림(스윙 감쇠) + 광택 스윕. 실제 인증만 |
| N06 | 목표 달성 온도계 (goal thermometer) | 5–8s | 모금·참여 목표 | 수은 높이 `prog` + 금액·% `countUp` + 남은 % 칩 |
| N07 | 사람 아이콘 통계 (people pictogram) | 4–6s | 비율 설명 | 10×10 아이콘 중 k개 순차 색칠, «10명 중 n명». 출처 표기 |
| N08 | FAQ 카드 넘기기 (FAQ flip cards) | 6–10s | 자주 묻는 질문 | 카드 `rotateY` 180° 앞뒤(`backfaceVisibility`), 옆으로 빠짐 |

### 💪 생활 도우미 (H)
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| H01 | 운동 인터벌 타이머 (interval timer) | 운동 길이 | 홈트·체조 | 원형 링 감소, 운동/휴식 색 전환, 라운드 표시, 투명 오버레이 |
| H02 | 레시피 단계 카드 (recipe steps) | 6–10s | 요리 교육 | 재료 체크 순차 + 단계 카드 넘김 + 시간 칩 |
| H03 | 적금·복리 성장 그래프 (savings growth) | 5–8s | 금융 교육 | 월 납입 막대 누적 + 월복리 곡선(코드로 계산), «세전·예시 계산» |

### 📈 금융·강의 보강 (F) — 이 스킬에서 추가
| ID | 이름 (영문) | 길이 | 쓰임 | 구현 요점 |
|---|---|---|---|---|
| F01 ✅ | 수식 단계 등장 (equation build) | 5–8s | 공식 도입 | KaTeX 줄별 fade-up + 해설, 마지막 줄 강조 테두리 |
| F02 ✅ | 누적수익 + 드로다운 (equity curve & drawdown) | 6–10s | 전략 성과 | 수익률 배열 → 누적·드로다운 **계산**, 선 진행 + MDD 표시 |
| F03 ✅ | 효율적 투자선 (efficient frontier) | 5–7s | MVO 강의 | 자산 점 pop → 투자선 그리기 → CML·접점 포트폴리오 |
| F04 ✅ | 상관 히트맵 (correlation heatmap) | 3–5s | 분산 효과 | 셀 대각선 순서 등장, 양(주황)·음(파랑) 발산 색 |
| F05 ✅ | 성과 기여 워터폴 (attribution waterfall) | 4–6s | 초과수익 분해 | 누적 막대 순차 성장, 증가 초록·감소 빨강 |
| F06 | 수익률 곡선 이동 (yield curve shift) | 5–8s | 금리 강의 | 만기별 금리 두 시점 보간 → 평행이동·기울기·곡률 구분 음영 |
| F07 | 캔들 차트 전개 (candlestick reveal) | 6–10s | 시장 사건 설명 | OHLC 봉 순차 등장 + 이벤트 주석 말풍선 |
| F08 | 분포 + VaR 꼬리 (return distribution & VaR) | 5–8s | 리스크 강의 | 히스토그램 막대 상승 → 정규 곡선 겹침 → 5% 꼬리 빨강 음영 + VaR 선 |
| F09 ✅ | KPI 카운터 타일 (KPI counters) | 3–5s | 성과 요약 | 타일 상승 + `countUp`, 단위 강조 |
| F10 | 팩터 노출 레이더 (factor exposure radar) | 4–6s | 팩터 강의 | 다각형 꼭짓점 반지름 0→값 보간, 두 포트폴리오 비교 |
| F11 | 몬테카를로 경로 부채꼴 (Monte Carlo fan) | 6–10s | 시뮬레이션 | 시드 고정 경로 수백 개 반투명 → 분위수 밴드(5·50·95%) 채움 |
| F12 | 자산배분 도넛 리밸런싱 (allocation donut) | 4–6s | SAA·리밸런싱 | 도넛 호 각도 현재→목표 보간 + 비중 % 카운트 |
| F13 | 의사코드 하이라이트 (code walkthrough) | 6–12s | 알고리즘 설명 | 코드 블록 + 줄 강조 바 이동 + 옆 변수값 패널 갱신 |
| F14 | 논문 인용 카드 (paper citation card) | 3–5s | 선행연구 소개 | 저자·연도·저널·핵심 한 줄 카드, 초록 문장 형광펜. 서지는 실제값 |
| F15 | 수식 항 치환·강조 (term substitution) | 4–8s | 유도 과정 | KaTeX 두 식 크로스페이드, 바뀐 항 `\htmlClass`로 색·밑줄 |
| F16 | 롤링 지표 선 (rolling metric line) | 6–10s | 샤프·베타 시변성 | 롤링 창 사각형이 시계열 위를 이동하며 아래 지표 선 그림 |
| F17 | 산점도 + 회귀선 (scatter & fit) | 5–7s | 회귀·CAPM 베타 | 점 순차 pop → 최소제곱선(코드 계산) 그리기 → 기울기·R² 라벨 |
| F18 | 레짐 음영 시계열 (regime shading) | 6–10s | HMM·국면 모형 | 가격선 진행 + 상태별 배경 띠 색칠 + 전이 시점 표시 |

## 6. 기존 영상 파이프라인과 합치기

- 장면을 1920×1080·30fps로 렌더하면 PPTX→대본→영상 파이프라인의 장면 MP4와 바로 `ffmpeg concat`할 수 있다. 오디오는 합친 뒤 한 번만 `loudnorm`한다.
- 이름 자막·챕터 진행 바·타이머는 투명 `.mov`로 렌더해 `ffmpeg -filter_complex overlay`로 얹거나, 같은 Remotion 프로젝트 안에서 `<Sequence>`로 본편 위에 올린다.
- 나레이션 문장 타이밍(초)을 받으면 `sec(t)`로 프레임에 맞춰 각 요소의 `from`을 정한다.