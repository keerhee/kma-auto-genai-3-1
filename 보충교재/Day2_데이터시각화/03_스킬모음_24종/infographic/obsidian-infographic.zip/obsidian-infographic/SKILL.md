---
name: obsidian-infographic
description: Obsidian·Tistory·GitHub에서 스크롤 없이 한 화면에 완결되는 인포그래픽(Mermaid 다이어그램, 인라인 SVG 차트, 비교 표, 코드 블록)을 작성하는 스킬. "인포그래픽", "다이어그램", "플로우차트", "mermaid", "SVG 차트", "시각화", "포지셔닝 맵", "타임라인", "마인드맵", "거버넌스 트리", "스펙트럼", "코드 블록", "코드 예시", "강의노트 시각화" 등의 표현이 나오면 이 스킬을 사용한다. Obsidian 강의노트(KIC 커리큘럼 포함)나 블로그에 들어갈 Mermaid/SVG 인포그래픽을 만들거나, 기존 다이어그램이 스크롤되는 문제, 코드 정렬이 깨지는 문제를 고쳐달라는 요청에도 반드시 트리거한다.
---

# Obsidian 인포그래픽 스킬

Obsidian·Tistory·GitHub에서 모두 작동하는 인포그래픽을 작성한다. **한 화면 안에서 완결되어야 하며, 가로·세로 어느 방향으로도 스크롤이 발생하면 안 된다.**

## 작업 순서

1. 사용자가 원하는 것이 어떤 유형인지 판별한다 (아래 패턴 표 참고).
2. 해당 패턴의 규격·템플릿을 `references/patterns.md`에서 확인한다.
3. 규격 준수 여부를 아래 체크리스트로 검증한 뒤 출력한다.

## 도구 선택

| 용도 | 도구 |
|------|------|
| 개념 관계·위계·흐름 | Mermaid |
| 정량 비교·포지셔닝·스펙트럼 | 인라인 SVG |
| 단순 정보 분류 | Markdown 표 |
| 코드·수식·명령어 예시 | `<pre>` 블록 (아래 규격 필수) |

Tistory 발행 시 Mermaid는 이미지 변환(`mmdc`)이 필요하고, SVG는 그대로 유지된다.

## 패턴 카탈로그

8개 패턴 전체와 완성된 템플릿·예시는 `references/patterns.md`에 있다. 해당 파일을 읽어서 사용하라.

| 번호 | 패턴 | 도구 | 주 용도 |
|------|------|------|---------|
| 1 | 돈의 흐름 | Mermaid flowchart TD | 자본시장 생태계, 거버넌스 위임 |
| 2 | 포지셔닝 매트릭스 | SVG | 4분면 분류, 전략 포지셔닝 |
| 3 | 막대 비교 차트 | SVG | AUM·수익률·비중 비교 |
| 4 | 타임라인 | Mermaid timeline | 제도 역사, 위기 타임라인 |
| 5 | 마인드맵 | Mermaid mindmap | 핵심 개념 가지 전개 |
| 6 | 이분 비교 | Mermaid subgraph TB | DB vs DC, MV vs RP 등 |
| 7 | 거버넌스 트리 | Mermaid flowchart TB | 이사회·CIO·운용팀 계층 |
| 8 | 스펙트럼 | SVG | 1차원 연속체 비교 |

## 스크롤 방지 핵심 규칙 (위반 금지)

### Mermaid

- **`flowchart LR` 절대 금지** — 항상 `TD` 또는 `TB`
- **subgraph 내 `direction LR` 금지** — `direction TB`로 통일
- 노드 텍스트 한글 15자 / 영문 25자 이내
- `<br/>` 최대 1회 (노드당 최대 2줄)
- 노드 ≤ 10개, subgraph ≤ 2개, timeline 항목 ≤ 6개, mindmap 리프 ≤ 8개
- 에지 라벨 5자 이내

### SVG

- **여는 `<svg ...>` 태그는 반드시 한 줄로 작성** (완결된 태그, 줄 맨 앞에서 시작·들여쓰기 금지). 여러 줄로 쪼개면 마크다운이 HTML 블록으로 인식하지 못해 코드가 그대로 노출된다.
- **`<svg>...</svg>` 내부에 빈 줄 절대 금지** — 마크다운(옵시디언·CommonMark)은 **빈 줄에서 HTML 블록을 끊는다.** 빈 줄 뒤의 `<rect>`·`<text>`는 SVG가 아니라 일반 텍스트로 처리되어 화면에 그대로 보인다. (가장 흔한 "SVG가 글자로 보임" 원인)
- SVG 블록 **바로 앞·뒤에는 빈 줄을 1개** 둔다 (블록 외부는 빈 줄, 내부는 빈 줄 0개).
- **`viewBox="0 0 680 H"` 고정** + `width="100%" style="max-width:680px"`
- 최대 x 좌표 ≤ 640 (우측 여백 40px)
- 최대 y 좌표 ≤ H − 15 (하단 여백 15px)
- 원: `cx + r ≤ 620` / 막대: `x + width ≤ 630`
- `font-size` ≥ 10, `role="img"` + `aria-label` 필수

## 코드 블록 렌더링 (HTML 인포그래픽용)

HTML 인포그래픽 안에 Python·LangGraph·Cypher·SQL·JSON·Bash 등 **여러 줄 코드 예시**를 넣을 때는 아래 규칙을 **반드시** 지킨다. 위반 시 브라우저가 연속 공백과 줄바꿈을 축약해 정렬이 완전히 무너진다.

### 태그 선택 (위반 시 렌더링 깨짐)

- **`<pre>` 태그 필수** — `<div>`는 절대 사용 금지. `<div>`는 기본 CSS가 `white-space: normal`이라 공백·줄바꿈이 축약됨.
- 한 줄 인라인 코드는 `<code>`, 여러 줄 블록 코드는 `<pre class="code-box">...</pre>`.
- `<pre>` 안에 들여쓰기 span을 쓸 때는 **`<pre>`와 `<span>` 사이에 줄바꿈 넣지 말 것** — 여백 오차 생김.

### 필수 CSS

```css
.code-box{
  background:#0f172a;color:#e2e8f0;
  border-radius:8px;padding:14px 16px;
  font-family:'Consolas','Monaco','Courier New',monospace;
  font-size:11px;line-height:1.7;
  margin:12px 0;overflow-x:auto;
  white-space:pre;     /* 필수: 공백·줄바꿈 보존 */
  tab-size:2           /* 필수: 탭 폭 고정 */
}
.code-box .ck{color:#93c5fd}          /* keyword */
.code-box .cs{color:#fcd34d}          /* string/identifier */
.code-box .cc{color:#64748b;font-style:italic}  /* comment */
```

### 정렬 원칙 (탭 혼용 금지)

- **탭(`\t`) 절대 금지 · 공백(스페이스)만 사용** — 에디터 탭 폭이 브라우저에서 달라짐.
- 들여쓰기는 4칸 또는 2칸 중 **하나로만 통일**.
- **컬럼 정렬**: 함수 인자·TypedDict 필드·주석은 콜론이나 `#` 위치를 맞춰 컬럼 정렬한다. 가독성이 2배 이상 개선됨.

### 좋은 예시 (올바른 정렬)

```html
<pre class="code-box"><span class="cc"># LangGraph 부동산 후보지 심사 그래프 골격</span>
<span class="ck">from</span> langgraph.graph <span class="ck">import</span> StateGraph, END
<span class="ck">from</span> claude_agent_sdk <span class="ck">import</span> query

<span class="ck">class</span> <span class="cs">DealState</span>(TypedDict):
    parcel_id:     str
    graph_context: dict   <span class="cc"># GraphRAG 결과</span>
    financial:     dict   <span class="cc"># Monte Carlo 결과</span>
    verdict:       str    <span class="cc"># Judge 최종 판정</span>

graph = StateGraph(DealState)
graph.add_node(<span class="cs">"classify"</span>,        route_query)            <span class="cc"># Router</span>
graph.add_node(<span class="cs">"graph_rag"</span>,       query_kg)               <span class="cc"># 관계 추론</span>
graph.add_node(<span class="cs">"financial"</span>,      run_irr_monte_carlo)    <span class="cc"># 계산</span>
graph.add_node(<span class="cs">"judge"</span>,           final_verdict)          <span class="cc"># Go/No-Go</span></pre>
```

### 나쁜 예시 (깨지는 패턴)

```html
<!-- ❌ div 사용 — 공백 축약 -->
<div class="code-box">
from langgraph.graph import StateGraph
graph.add_node("classify", route_query)
</div>

<!-- ❌ pre 쓰되 첫 줄에 공백 — 빈 줄 생김 -->
<pre class="code-box">
<span>from langgraph</span>
</pre>

<!-- ❌ 탭과 공백 혼용 -->
<pre class="code-box">
def foo():
	x = 1       # 탭 들여쓰기
    y = 2       # 공백 들여쓰기 — 결과가 맞지 않음
</pre>
```

### 주석 정렬 요령

여러 줄의 `#` 주석을 다는 경우 **주석 시작 컬럼을 맞춘다**. 파이썬 기준으로 코드 본문 최대 길이 + 3~4 공백 뒤에 `#` 배치:

```
graph.add_node("classify",        route_query)            # Router
graph.add_node("graph_rag",       query_kg)               # 관계 추론
graph.add_node("financial_agent", run_irr_monte_carlo)    # 계산
```

### 구문 하이라이트 색상 (일관 적용)

| 클래스 | 용도 | 색상 |
|--------|------|------|
| `.ck` | keyword (`from`, `import`, `class`, `def`, `return`) | `#93c5fd` (연한 파랑) |
| `.cs` | string/identifier (`"classify"`, `DealState`) | `#fcd34d` (골드) |
| `.cc` | comment (`# ...`) | `#64748b` (차분한 회색, italic) |

## SVG 기본 템플릿

모든 SVG는 이 템플릿으로 시작한다. **여는 태그는 한 줄, 내부에 빈 줄 없음**이 핵심이다:

```xml
<svg width="100%" style="max-width:680px" viewBox="0 0 680 [높이]" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="[설명]">
  <!-- 콘텐츠: x ≤ 640, y ≤ 높이-15. 줄 사이에 빈 줄을 넣지 말 것 -->
</svg>
```

가독성을 위해 요소를 그룹으로 묶고 싶으면 빈 줄 대신 `<!-- 주석 -->`으로 구분한다 (주석 줄은 빈 줄이 아니므로 HTML 블록이 끊기지 않는다).

## 색상 팔레트 (KIC 커리큘럼 기본)

| 의미 | Fill / Stroke |
|------|---------------|
| KIC (오렌지) | `#FFB74D` / `#E65100` |
| 한국 (골드) | `#F5A623` / `#B07517` |
| 미국 (레드) | `#E74C3C` / `#A93226` |
| 캐나다 (퍼플) | `#9B59B6` / `#6A3782` |
| 노르웨이 (블루) | `#4A90E2` / `#2C5F8D` |
| 일본 (그린) | `#50C878` / `#2F7A4A` |
| 위험·경고 (핑크) | `#F48FB1` / `#AD1457` |
| 중립 (라이트블루) | `#E3F2FD` / `#0D47A1` |

## 출력 전 체크리스트

**Mermaid**
- [ ] 방향이 `TD`/`TB`인가? (LR 절대 금지)
- [ ] subgraph `direction`이 `TB`인가?
- [ ] 노드 ≤ 10, 리프 ≤ 8, timeline ≤ 6인가?
- [ ] 노드 텍스트 ≤ 15자, `<br/>` ≤ 1회인가?
- [ ] 에지 라벨 ≤ 5자인가?

**SVG**
- [ ] 여는 `<svg ...>` 태그가 **한 줄·완결형**이고 줄 맨 앞에서 시작하는가?
- [ ] `<svg>...</svg>` **내부에 빈 줄이 0개**인가? (가장 흔한 렌더링 실패 원인)
- [ ] SVG 블록 앞·뒤에 빈 줄이 각각 1개 있는가?
- [ ] `width="100%" style="max-width:680px"` 있는가?
- [ ] `viewBox="0 0 680 H"` 형식인가?
- [ ] 최대 x ≤ 640, cx+r ≤ 620, x+width ≤ 630인가?
- [ ] 최대 y ≤ H − 15인가?
- [ ] `font-size` ≥ 10, `role="img"` + `aria-label` 있는가?

**코드 블록 (`<pre class="code-box">`)**
- [ ] `<div>`가 아닌 `<pre>`를 썼는가?
- [ ] CSS에 `white-space:pre`와 `tab-size:2`가 있는가?
- [ ] 탭 대신 공백만 사용했는가?
- [ ] 함수 인자·TypedDict 필드·주석이 컬럼 정렬되어 있는가?
- [ ] `<pre>` 직후에 불필요한 줄바꿈이 없는가?

**공통**
- [ ] 이 시각화가 없으면 독자가 놓치는 것이 있는가?
- [ ] 핵심 메시지를 5초 안에 읽어낼 수 있는가?
- [ ] 흑백 인쇄 시에도 구분 가능한가?

## 금지 패턴 (자주 실수하는 항목)

| 금지 | 대안 |
|------|------|
| `flowchart LR` | `TD` 또는 `TB` |
| subgraph 내 `direction LR` | `direction TB` |
| SVG 고정 `width="680"` | `width="100%" style="max-width:680px"` |
| **`<svg>` 내부 빈 줄** | **빈 줄 제거 (내부 빈 줄 0개)** |
| **여는 `<svg>` 태그 여러 줄 분할** | **한 줄 완결 태그로 작성** |
| **그룹 구분에 빈 줄 사용** | **`<!-- 주석 -->`으로 구분** |
| SVG에서 x > 640 또는 y > H−15 | 여백 준수 |
| `<br/>` 3줄 이상 노드 | 최대 2줄 |
| 에지 라벨 6자 이상 | 5자 이하 또는 생략 |
| timeline 항목 7개 이상 | 6개로 축소 또는 표 전환 |
| mindmap 리프 9개 이상 | 8개 이하 |
| **코드 블록에 `<div>` 사용** | **`<pre class="code-box">` 필수** |
| **CSS에 `white-space` 누락** | **`white-space:pre` 필수** |
| **코드에 탭 혼용** | **공백만 사용, 들여쓰기 통일** |

## Tistory 발행 시 주의점

- Mermaid → 이미지로 변환 필요 (`mmdc -i input.mmd -o output.png`)
- SVG → 그대로 유지 (MathJax와 충돌 없음)
- `<svg>` 블록을 `<p>` 태그로 감싸지 말 것
- `<pre class="code-box">` → 그대로 유지 (Tistory는 `<pre>` 태그를 보존함)

## 참고 파일

- `references/patterns.md` — 8개 패턴 전체의 완성 템플릿과 예시 코드
- `references/check_svg.py` — SVG 렌더링 깨짐 자동 검증기 (내부 빈 줄·다중 라인 태그 탐지). 출력 직전 반드시 실행: `python3 references/check_svg.py 파일.md`
