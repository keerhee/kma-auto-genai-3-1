# SVG 다이어그램 검증 템플릿 모음

본 파일은 Week 11-14 케이스 시리즈에서 실제로 검증된 SVG 템플릿이다. 한국어 폰트가 깨지지 않고 cairosvg로 정상 PNG 변환된 패턴만 수록.

## 1. 표준 한국어 안전 SVG 골격

```xml
<svg width="1500" height="900" viewBox="0 0 750 450" xmlns="http://www.w3.org/2000/svg">
  <style>
    .ko { font-family: "Noto Sans CJK KR", sans-serif; }
  </style>
  
  <!-- 모든 한국어 <text>는 class="ko" 필수 -->
  <text x="375" y="22" text-anchor="middle" font-size="15" font-weight="bold" fill="#1f2937" class="ko">
    제목 한국어
  </text>
</svg>
```

## 2. 듀얼 패널 다이어그램 (왼쪽 + 오른쪽 비교)

```xml
<svg width="1500" height="900" viewBox="0 0 750 450" xmlns="http://www.w3.org/2000/svg">
  <style>
    .ko { font-family: "Noto Sans CJK KR", sans-serif; }
  </style>

  <!-- 제목 -->
  <text x="375" y="22" text-anchor="middle" font-size="15" font-weight="bold" fill="#1f2937" class="ko">
    주제명
  </text>
  <text x="375" y="40" text-anchor="middle" font-size="10" fill="#6b7280" class="ko">
    왼쪽: 패널 A — 오른쪽: 패널 B
  </text>

  <!-- 왼쪽 패널 -->
  <rect x="40" y="60" width="320" height="370" fill="none" stroke="#e5e7eb" stroke-width="1"/>
  <text x="200" y="80" text-anchor="middle" font-size="12" font-weight="bold" fill="#1f2937" class="ko">
    A. 왼쪽 패널
  </text>

  <!-- 오른쪽 패널 -->
  <rect x="390" y="60" width="320" height="370" fill="none" stroke="#e5e7eb" stroke-width="1"/>
  <text x="550" y="80" text-anchor="middle" font-size="12" font-weight="bold" fill="#1f2937" class="ko">
    B. 오른쪽 패널
  </text>
</svg>
```

## 3. 컬러 그룹별 박스 (학술 출판물 톤)

### 노란색 — 학술 출처 / 가설

```xml
<rect x="55" y="92" width="290" height="65" fill="#FEF3C7" stroke="#D97706" stroke-width="2" rx="3"/>
<text x="200" y="106" text-anchor="middle" font-size="11" font-weight="bold" fill="#92400E" class="ko">
  학술 출처 + 가설
</text>
<text x="65" y="120" text-anchor="start" font-size="8" fill="#92400E" class="ko">
  Author (Year). "Title." Journal Vol(Issue).
</text>
```

### 빨간색 — 위기 / 위반 / 충격

```xml
<rect x="55" y="92" width="290" height="92" fill="#FFEBEE" stroke="#A93226" stroke-width="2" rx="3"/>
<text x="200" y="106" text-anchor="middle" font-size="11" font-weight="bold" fill="#A93226" class="ko">
  위기 / 충격 데이터
</text>
<text x="65" y="121" text-anchor="start" font-size="8" font-weight="bold" fill="#A93226" class="ko">
  S&amp;P 500 (Real): -19.5%
</text>
```

### 녹색 — 학술 결과 / 성공

```xml
<rect x="55" y="190" width="290" height="92" fill="#E8F5E9" stroke="#1B5E20" stroke-width="2" rx="3"/>
<text x="200" y="204" text-anchor="middle" font-size="11" font-weight="bold" fill="#1B5E20" class="ko">
  학술 결과
</text>
<text x="65" y="219" text-anchor="start" font-size="8" font-weight="bold" fill="#1B5E20" class="ko">
  SG CTA Trend Index 2022: +27.4%
</text>
```

### 파란색 — 정보 / 메커니즘

```xml
<rect x="55" y="163" width="290" height="85" fill="#E3F2FD" stroke="#0D47A1" stroke-width="2" rx="3"/>
<text x="200" y="177" text-anchor="middle" font-size="11" font-weight="bold" fill="#0D47A1" class="ko">
  학술 메커니즘
</text>
```

### 보라색 — 한국 적용 / 종합

```xml
<rect x="405" y="365" width="290" height="58" fill="rgba(91, 33, 182, 0.1)" stroke="#5B21B6" stroke-width="2" rx="3"/>
<text x="550" y="379" text-anchor="middle" font-size="10" font-weight="bold" fill="#5B21B6" class="ko">
  한국 종합 결론
</text>
```

## 4. 자주 보는 깨짐 문제 — 처리법

### 4.1 mixed text "1926 이래 최대 감소"

```xml
<!-- ❌ 위험 — 영문/숫자/한글 혼합 -->
<text x="65" y="167" class="ko">1926 이래 최대 감소</text>

<!-- ✅ 안전 1: class="ko" 유지하고 그대로 -->
<text x="65" y="167" class="ko">1926년 이래 최대 감소</text>
  <!-- "1926" + 한글 + "감소" 모두 Noto Sans CJK가 처리 -->

<!-- ✅ 안전 2: 영문화 -->
<text x="65" y="167">Since 1926, max decline</text>

<!-- ✅ 안전 3: 분리 -->
<text x="65" y="167">1926~ </text>
<text x="120" y="167" class="ko">최대 감소</text>
```

### 4.2 '&' 자동 이스케이프 — 표 안

```xml
<!-- ❌ XML 파서 오류 -->
<text>S&P 500</text>

<!-- ✅ 정답 -->
<text>S&amp;P 500</text>
```

### 4.3 long text — 줄바꿈 처리

SVG `<text>`는 자동 줄바꿈 안 됨. 각 줄을 별도 `<text>`로 분리:

```xml
<text x="65" y="120" font-size="8" class="ko">첫째 줄 내용</text>
<text x="65" y="131" font-size="8" class="ko">둘째 줄 내용</text>
<text x="65" y="142" font-size="8" class="ko">셋째 줄 내용</text>
<!-- y 좌표를 11씩 증가 (font-size + 행간) -->
```

## 5. 표준 좌표 시스템 (1500x900 출력 기준)

viewBox는 `0 0 750 450` (절반 크기), 출력은 1500x900 (2배 확대).

| 영역 | 좌표 |
|---|---|
| 제목 | y=22 (font-size 15) |
| 부제 | y=40 (font-size 10) |
| 패널 외곽 | x=40~360 (왼쪽), x=390~710 (오른쪽), y=60~430 |
| 패널 제목 | y=80 (font-size 12) |
| 박스 시작 | y=92 |
| 박스 내 첫 줄 | y=106 (제목), y=120 (첫 내용) |
| 행간 | font-size 8 → y 증가 11, font-size 10 → 13 |

## 6. 글자 크기 가이드

| font-size | 용도 |
|---|---|
| 15 | 메인 제목 |
| 12 | 패널 제목 |
| 11 | 박스 제목 |
| 10 | 부제, 박스 제목 (small) |
| 9 | 강조 본문 |
| 8 | 일반 본문 |
| 7 | 작은 메모 (가능하면 피함) |

## 7. 검증 체크리스트

SVG 작성 후 다음 항목 확인:

- [ ] `<style>` 안에 `.ko { font-family: "Noto Sans CJK KR", sans-serif; }` 정의
- [ ] 모든 한국어 `<text>` 요소에 `class="ko"` 부착
- [ ] `&` → `&amp;` 모두 이스케이프
- [ ] `width="1500" height="900" viewBox="0 0 750 450"` 표준 크기
- [ ] xmlns 선언 `xmlns="http://www.w3.org/2000/svg"`
- [ ] Mixed text 점검 (1926 + 한글 같은 패턴)
- [ ] long text는 각 줄 별도 `<text>`로 분리

## 8. cairosvg 변환 명령

```python
import cairosvg
cairosvg.svg2png(
    url='diagram.svg',
    write_to='diagram.png',
    output_width=1500,
    output_height=900
)
```

또는 명령행:

```bash
python3 /home/claude/skills/latex-svg-render/scripts/svg_to_png.py diagram.svg diagram.png
```

자동 점검 + 정정 포함.
