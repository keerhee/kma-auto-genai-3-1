# LaTeX 수식 패턴 모음 — 학술 강의/논문용

본 파일은 Week 11-14 학술 시리즈에서 검증된 LaTeX 수식 패턴을 수록한다. 모두 pdflatex로 정상 PNG 변환되며, MathJax (옵시디언/Tistory)에서도 동일 렌더링된다.

## 1. Factor Asset Pricing

### 1.1 Fama-French 5-Factor (FF5)

```latex
$$
r_{i,t} - r_{f,t} = \alpha + \beta_{i,M}\,\text{MKT}_t + \beta_{i,S}\,\text{SMB}_t + \beta_{i,H}\,\text{HML}_t + \beta_{i,R}\,\text{RMW}_t + \beta_{i,C}\,\text{CMA}_t + \epsilon_{i,t}
$$
```

### 1.2 Hou-Mo-Xue-Zhang q5 모델

```latex
$$
r_{i,t} - r_{f,t} = \alpha + \beta\,\text{MKT}_t + m\,\text{ME}_t + a\,\text{I/A}_t + r\,\text{ROE}_t + g\,\text{EG}_t + \epsilon_{i,t}
$$
```

### 1.3 Buffett's Alpha (Frazzini-Kabiller-Pedersen 2018)

```latex
$$
\alpha_{\text{Berkshire}} = f(\text{MKT}, \text{SMB}, \text{HML}, \text{RMW}, \text{CMA}) + \beta_{\text{BAB}}\,\text{BAB} + \gamma_{\text{QMJ}}\,\text{QMJ} + \text{Leverage}
$$
```

## 2. Meta-Labeling (Lopez de Prado 2018)

### 2.1 Primary → Secondary 분리

```latex
$$
\text{Primary (Side, High Recall)} \to \text{Secondary ML (Size, High F1)}
$$
```

### 2.2 Triple-Barrier Method

```latex
$$
\text{Label} = \begin{cases}
+1 & \text{if Upper first touched } (P_t \ge P_0 \cdot (1 + k_u\sigma_t)) \\
-1 & \text{if Lower first touched } (P_t \le P_0 \cdot (1 - k_d\sigma_t)) \\
0 & \text{if Vertical first reached } (t \ge T)
\end{cases}
$$
```

### 2.3 Importance Weight

```latex
$$
w_i = \frac{\pi_e(a_i \mid x_i)}{\pi_0(a_i \mid x_i)}
$$
```

## 3. Off-Policy Evaluation

### 3.1 정책 가치 (Policy Value)

```latex
$$
V(\pi) = \mathbb{E}_{p(x)\,\pi(a \mid x)\,p(r \mid x,a)}\!\left[\,r\,\right]
$$
```

### 3.2 Doubly Robust 분해

```latex
$$
\hat V_{\text{DR}} \;=\; \underbrace{\hat V_{\text{DM}}(\pi_e; \mathcal{D}_0, \hat r)}_{\text{baseline (DM)}} \;+\; \underbrace{\frac{1}{n}\sum_i w_i \,(r_i - \hat r(x_i, a_i))}_{\text{IPS correction}}
$$
```

### 3.3 MSE 분해

```latex
$$
\mathrm{MSE}(\hat V; \pi_e) = \mathbb{E}\!\left[(\hat V - V(\pi_e))^2\right] = \mathrm{Bias}^2 + \mathrm{Var}
$$
```

### 3.4 조건부 독립

```latex
$$
r \;\perp\!\!\!\perp\; a \mid x
$$
```

## 4. Duration & Convexity

### 4.1 Macaulay Duration

```latex
$$
D_{\text{Mac}} = \frac{\sum_{t=1}^{T} t \cdot \frac{CF_t}{(1+y)^t}}{P}
$$
```

### 4.2 Modified Duration

```latex
$$
D_{\text{Mod}} = \frac{D_{\text{Mac}}}{1+y} = -\frac{1}{P}\frac{dP}{dy}
$$
```

### 4.3 Convexity

```latex
$$
C = \frac{1}{P}\frac{d^2P}{dy^2}
$$
```

### 4.4 2차 Taylor 전개 (채권 가격 변화)

```latex
$$
\frac{\Delta P}{P} \approx -D_{\text{Mod}} \cdot \Delta y + \frac{1}{2}\,C\,(\Delta y)^2
$$
```

### 4.5 Key Rate Duration

```latex
$$
\alpha_{\text{KRD}} = \sum_{\text{통화}}\sum_{\text{만기 } i} \Delta KRD_i \cdot \Delta y_i
$$
```

## 5. Global Macro (TSMOM)

### 5.1 TSMOM 신호 (Moskowitz-Ooi-Pedersen 2012)

```latex
$$
\text{Signal}^{\text{TSMOM}}_{i,t} = \text{sign}(r_{i,t-12:t-1})
$$
```

### 5.2 Volatility Targeting

```latex
$$
w^{\text{TSMOM}}_{i,t} = \text{sign}(r_{i,t-12:t-1}) \cdot \frac{\sigma_{\text{target}}}{\sigma_{i,t}}
$$
```

### 5.3 Pooled Regression (MOP 2012)

```latex
$$
r_{i,t}/\sigma_{i,t-1} = \alpha + \beta_h \cdot \frac{r_{i,t-h}}{\sigma_{i,t-h-1}} + \epsilon_{i,t}
$$
```

### 5.4 EWM 변동성

```latex
$$
\sigma_{i,t}^2 = \lambda \cdot \sigma_{i,t-1}^2 + (1 - \lambda) \cdot r_{i,t}^2
$$
```

## 6. Sharpe Ratio & Information Ratio

### 6.1 Sharpe Ratio

```latex
$$
SR = \frac{\mathbb{E}[r] - r_f}{\sigma(r)}
$$
```

### 6.2 Information Ratio

```latex
$$
IR = \frac{\alpha}{\text{TE}}
$$
```

여기서 TE는 Tracking Error.

## 7. Tangency Portfolio (Markowitz + JKP)

### 7.1 분산 효과

```latex
$$
\sigma_{60/40}^2 = 0.36\,\sigma_s^2 + 0.16\,\sigma_b^2 + 2 \cdot 0.6 \cdot 0.4 \cdot \rho \cdot \sigma_s \sigma_b
$$
```

### 7.2 Tangency Weights

```latex
$$
w^* = \frac{\Sigma^{-1}\mu}{\mathbf{1}^T \Sigma^{-1} \mu}
$$
```

## 8. Market Impact (Almgren-Chriss 2001)

```latex
$$
\text{Market Impact} = \eta \cdot \frac{Q}{V} + \xi \cdot \left(\frac{Q}{V}\right)^{3/2}
$$
```

## 9. 통합 시너지 분해 (Week 11+12+13+14)

```latex
$$
\Delta\alpha_{\text{Coord}} = \underbrace{3.5\%\text{p}}_{\text{Week 11 주식}} + \underbrace{1.0\%\text{p}}_{\text{Week 12 채권}} + \underbrace{0.5\%\text{p}}_{\text{Week 13 JKP}} + \underbrace{1.0\text{-}2.0\%\text{p}}_{\text{Week 14 매크로}}
$$
```

## 10. LaTeX 패턴 — 자주 쓰는 명령어

### 10.1 큰 괄호로 묶은 기댓값

```latex
$$
\mathbb{E}\!\left[\frac{\pi_e(a \mid x)}{\pi_0(a \mid x)} \cdot r\right] = V(\pi_e)
$$
```

`\!\left[...\right]` 으로 괄호 크기 자동 조절.

### 10.2 aligned 환경 (다중 라인 정렬)

```latex
$$
\begin{aligned}
\mathbb{E}\!\left[\frac{\pi_e(a \mid x)}{\pi_0(a \mid x)} r\right]
&= \iiint \frac{\pi_e(a \mid x)}{\pi_0(a \mid x)} \cdot r \cdot p(r \mid x,a) \cdot \pi_0(a \mid x) \cdot p(x)\,dx\,da\,dr \\
&= \iiint \pi_e(a \mid x) \cdot r \cdot p(r \mid x,a) \cdot p(x)\,dx\,da\,dr \\
&= V(\pi_e)
\end{aligned}
$$
```

### 10.3 자주 쓰는 명령어 (안전)

| 명령어 | 의미 |
|---|---|
| `\frac`, `\dfrac` | 분수 |
| `\sqrt` | 제곱근 |
| `\underbrace{...}_{...}` | 아래 라벨 |
| `\overbrace{...}^{...}` | 위 라벨 |
| `\mathcal{}`, `\mathbb{}`, `\mathrm{}` | 글꼴 변경 |
| `\boldsymbol{}` | 굵게 |
| `\;`, `\,`, `\quad` | 간격 |
| `\to`, `\Longrightarrow` | 화살표 |
| `\sum_{i=1}^{n}`, `\prod_{i=1}^{n}` | 합·곱 |
| `\int`, `\iint`, `\iiint`, `\oint` | 적분 |
| `\mid` | 조건부 막대 (절대 `|` 사용 X) |
| `\perp`, `\perp\!\!\!\perp` | 수직 / 조건부 독립 |

## 11. LaTeX 패턴 — 자주 보는 함정

| ❌ 함정 | ✅ 대안 |
|---|---|
| `_DM`, `_IPS` (단일 글자 외 첨자) | `_{\text{DM}}`, `_{\text{IPS}}` |
| 한글 라벨에 `_DM` | `_{\text{DM}}` 으로 묶기 |
| `\hat V_DM` | `\hat V_{\mathrm{DM}}` 또는 `_{\text{DM}}` |
| `r \perp a \| x` | `r \perp\!\!\!\perp a \mid x` |
| `\pi_e(a\|x)` | `\pi_e(a \mid x)` |
| `&` 단독 (수식 외) | `&amp;` (HTML/SVG) |

## 12. PNG 렌더링 (pdflatex)

전체 LaTeX 문서 형태:

```latex
\documentclass[border=2pt,12pt]{standalone}
\usepackage{amsmath,amssymb}
\usepackage[utf8]{inputenc}
\begin{document}
$
\hat V_{\text{DR}} \;=\; \underbrace{\hat V_{\text{DM}}}_{\text{baseline}} \;+\; \frac{1}{n}\sum_i w_i (r_i - \hat r)
$
\end{document}
```

PDF 생성 + PNG 변환:

```bash
pdflatex -interaction=nonstopmode eq.tex
pdftoppm -png -r 300 eq.pdf eq
# eq-1.png 생성
```

또는 일괄 처리:

```bash
python3 /home/claude/skills/latex-svg-render/scripts/render_eq.py equations.json output_dir/
```
