---
name: latex-svg-render
description: 학술 산출물의 LaTeX 수식과 SVG 다이어그램을 PNG로 렌더링하는 도구 스킬. "LaTeX 수식 PNG", "SVG to PNG", "다이어그램 PNG", "수식 이미지", "케이스 다이어그램", "옵시디언 시각화", "Noto Sans CJK", "한국어 폰트", "cairosvg", "수식이 텍스트로 보임", "PPT 수식", "강의 다이어그램 PNG", "SVG 한글 깨진다", "ko class", "ASCII filename" 등의 표현이 나오면 반드시 이 스킬을 사용한다. LaTeX 수식을 pdflatex+pdftoppm으로 PNG로 만들거나, SVG 다이어그램(케이스 스터디 부록 등)을 cairosvg로 PNG로 변환할 때 항상 적용한다. 특히 한국어 텍스트가 포함된 SVG의 폰트 깨짐, mixed text 처리, & → &amp; 이스케이프, ASCII-only 파일명 등 자주 발생하는 문제를 모두 처리한다. korean-md-standard 스킬과 결합하여 학술 산출물 작성 전체 파이프라인을 완성한다.
---

# LaTeX & SVG → PNG 렌더링 도구

## 0. 이 스킬의 목적

학술 산출물에 들어갈 두 종류의 이미지를 PNG로 렌더링한다:

1. **LaTeX 수식 PNG** — 강의 PPT, 케이스 스터디, Apple White 덱 등에 들어갈 진짜 LaTeX 외관
2. **SVG 다이어그램 PNG** — 옵시디언 부록의 시각화 (한국어 텍스트 포함)

대상 용도:
- 강의 PPT (KAIST·ZeroOneAI·금융기관 고객사)
- 케이스 스터디 부록 (Week N 다이어그램)
- Apple White 덱 슬라이드의 수식 부분
- 학술 논문의 figure

원칙: **렌더링 결과물에 한국어 텍스트가 절대 깨지지 않는다 + ASCII-only 파일명으로 present_files 호환**.

---

## 1. 작업 분기 — 어떤 도구를 쓸까

| 입력 | 도구 | 출력 | 비고 |
|---|---|---|---|
| LaTeX 수식 (`\frac`, `\underbrace` 등) | `pdflatex` + `pdftoppm` | PNG | 진짜 LaTeX 외관 |
| SVG 코드 (한국어 텍스트 포함) | `cairosvg` | PNG | Noto Sans CJK 보존 |
| 케이스 다이어그램 (블록·박스·라벨) | `cairosvg` | PNG | 한국어 글자 깨짐 방지 |

작업 분기가 명확하지 않으면 *"수식이면 LaTeX, 시각화면 SVG"*로 판단.

---

## 2. LaTeX 수식 → PNG (pdflatex 방식)

### 2.1 환경 요구사항

```bash
# 시스템 패키지 확인
which pdflatex pdftoppm
# /usr/bin/pdflatex
# /usr/bin/pdftoppm

# Anthropic 환경에 기본 설치되어 있음. 없으면:
apt-get install -y texlive-latex-base texlive-latex-extra texlive-latex-recommended
```

### 2.2 표준 워크플로우 — 단일 수식 PNG

```bash
# 1) 임시 디렉터리 생성
WORK=/tmp/eq_$(date +%s)
mkdir -p "$WORK"
cd "$WORK"

# 2) LaTeX 문서 작성 (standalone class)
cat > eq.tex << 'EOF'
\documentclass[border=2pt,12pt]{standalone}
\usepackage{amsmath,amssymb}
\usepackage[utf8]{inputenc}
\begin{document}
$\hat V_{\text{DR}} = \underbrace{\hat V_{\text{DM}}}_{\text{baseline}} + \frac{1}{n}\sum_i w_i (r_i - \hat r)$
\end{document}
EOF

# 3) PDF 생성
pdflatex -interaction=nonstopmode eq.tex
# eq.pdf 생성됨

# 4) PDF → PNG 변환 (고해상도)
pdftoppm -png -r 300 eq.pdf eq
# eq-1.png 생성됨 (300 DPI)

# 5) 출력 폴더로 이동 (ASCII-only 파일명)
cp eq-1.png /mnt/user-data/outputs/equation_01.png
```

### 2.3 일괄 처리 스크립트

`scripts/render_eq.py` 참조 — 여러 수식을 한 번에 PNG로 일괄 변환.

### 2.4 자주 보는 LaTeX 오류

| 오류 | 원인 | 해결 |
|---|---|---|
| `Undefined control sequence \mathbb` | `amssymb` 미포함 | `\usepackage{amssymb}` 추가 |
| `Missing $ inserted` | math mode 외부 명령 | `$...$`로 감싸기 |
| `Package inputenc Error` | 한글 포함 (해당 없음) | LaTeX 수식에 한글 직접 X, `\text{...}` 사용 |
| 빈 페이지 출력 | `border=` 설정 누락 | `\documentclass[border=2pt]{standalone}` |

---

## 3. SVG → PNG (cairosvg 방식)

### 3.1 환경 요구사항

```bash
# Python 패키지 확인
python3 -c "import cairosvg; print(cairosvg.__version__)"
# 2.x.x

# 없으면 설치
pip install cairosvg --break-system-packages

# 한국어 폰트 확인
fc-list | grep -i "Noto Sans CJK KR" | head -3
# /usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc 등이 있어야 함

# 없으면 설치
apt-get install -y fonts-noto-cjk
```

### 3.2 SVG 작성 시 절대 지켜야 할 규칙

#### Rule 1: 한국어 텍스트는 모두 `class="ko"`

```xml
<!-- ❌ 금지 — 한국어가 깨짐 -->
<text x="100" y="50">한국어 텍스트</text>

<!-- ✅ 정답 — class="ko"로 표시 -->
<text x="100" y="50" class="ko">한국어 텍스트</text>
```

CSS 스타일 정의:

```xml
<style>
  .ko { font-family: "Noto Sans CJK KR", sans-serif; }
</style>
```

#### Rule 2: `&` 문자는 `&amp;`로 이스케이프

```xml
<!-- ❌ 금지 — XML 파서 오류 -->
<text>S&P 500</text>

<!-- ✅ 정답 -->
<text>S&amp;P 500</text>
```

#### Rule 3: Mixed text는 영문/한글 분리 또는 영문화

```xml
<!-- ⚠️ 주의 — mixed text는 폰트 fallback 시 깨질 위험 -->
<text class="ko">1926 이래 ★ 최대 감소</text>

<!-- ✅ 정답 1 — class="ko" 보장 -->
<text class="ko">1926 이래 최대 감소</text>

<!-- ✅ 정답 2 — 영문화로 회피 -->
<text>Since 1926, max decline</text>
```

### 3.3 표준 워크플로우 — SVG → PNG

```bash
# 1) SVG 파일 작성 (한국어 텍스트는 class="ko")
cat > /tmp/diagram.svg << 'EOF'
<svg width="1500" height="900" viewBox="0 0 750 450" xmlns="http://www.w3.org/2000/svg">
  <style>
    .ko { font-family: "Noto Sans CJK KR", sans-serif; }
  </style>
  
  <text x="375" y="22" text-anchor="middle" font-size="15" font-weight="bold" class="ko">
    제목 한국어
  </text>
  
  <rect x="40" y="60" width="320" height="370" fill="none" stroke="#e5e7eb"/>
  <text x="200" y="80" text-anchor="middle" font-size="12" class="ko">
    내용 박스
  </text>
</svg>
EOF

# 2) cairosvg로 PNG 변환
python3 -c "
import cairosvg
cairosvg.svg2png(
    url='/tmp/diagram.svg',
    write_to='/tmp/diagram.png',
    output_width=1500,
    output_height=900
)
print('OK')
"

# 3) 결과 확인 (한국어 깨짐 검사)
# view /tmp/diagram.png

# 4) 출력 폴더로 이동 (ASCII-only 파일명)
cp /tmp/diagram.png /mnt/user-data/outputs/W14_01_PureAlpha_TSMOM.png
```

### 3.4 SVG 다이어그램 표준 템플릿 (Week N 부록용)

```xml
<svg width="1500" height="900" viewBox="0 0 750 450" xmlns="http://www.w3.org/2000/svg">
  <!-- 1. 폰트 정의 — 한국어 보존 -->
  <style>
    .ko { font-family: "Noto Sans CJK KR", sans-serif; }
  </style>
  
  <!-- 2. 제목 (한국어 포함) -->
  <text x="375" y="22" text-anchor="middle" font-size="15" font-weight="bold" fill="#1f2937" class="ko">
    Week N — 주제명
  </text>
  <text x="375" y="40" text-anchor="middle" font-size="10" fill="#6b7280" class="ko">
    부제 또는 안내문
  </text>
  
  <!-- 3. 두 패널 — 왼쪽 + 오른쪽 -->
  <rect x="40" y="60" width="320" height="370" fill="none" stroke="#e5e7eb" stroke-width="1"/>
  <text x="200" y="80" text-anchor="middle" font-size="12" font-weight="bold" fill="#1f2937" class="ko">
    A. 왼쪽 패널 제목
  </text>
  
  <rect x="390" y="60" width="320" height="370" fill="none" stroke="#e5e7eb" stroke-width="1"/>
  <text x="550" y="80" text-anchor="middle" font-size="12" font-weight="bold" fill="#1f2937" class="ko">
    B. 오른쪽 패널 제목
  </text>
  
  <!-- 4. 박스 + 내용 (반복 패턴) -->
  <rect x="55" y="92" width="290" height="65" fill="#FEF3C7" stroke="#D97706" stroke-width="2" rx="3"/>
  <text x="200" y="106" text-anchor="middle" font-size="11" font-weight="bold" fill="#92400E" class="ko">
    박스 제목
  </text>
  <text x="65" y="120" text-anchor="start" font-size="8" fill="#92400E" class="ko">
    내용 첫 줄
  </text>
  <text x="65" y="131" text-anchor="start" font-size="8" fill="#92400E" class="ko">
    내용 둘째 줄
  </text>
</svg>
```

표준 SVG 컬러 (학술 출판물 톤):

| 컬러 그룹 | fill | stroke |
|---|---|---|
| 학술 출처 (Yellow) | `#FEF3C7` | `#D97706` |
| 위기 / 경고 (Red) | `#FFEBEE` | `#A93226` |
| 학술 결과 (Green) | `#E8F5E9` | `#1B5E20` |
| 정보 (Blue) | `#E3F2FD` | `#0D47A1` |
| 강조 (Purple) | `rgba(91, 33, 182, 0.1)` | `#5B21B6` |

---

## 4. 파일명 규칙 (present_files 호환)

### 4.1 ASCII-only 파일명 필수

`present_files` 도구는 한글 파일명을 처리하지 못한다. **모든 출력 파일은 ASCII-only**.

```bash
# ❌ 금지 — present_files 실패
cp /tmp/diagram.png /mnt/user-data/outputs/Week14_부록_다이어그램.png

# ✅ 정답 — ASCII-only
cp /tmp/diagram.png /mnt/user-data/outputs/Week14_Macro_CTA_Diagram.png
```

### 4.2 표준 파일명 명명 규칙

| 종류 | 명명 패턴 | 예시 |
|---|---|---|
| 케이스 부록 | `W{NN}_{NN}_TopicName.png` | `W14_01_PureAlpha_TSMOM.png` |
| 수식 PNG | `eq_{NN}_{NameHint}.png` | `eq_01_DR_decomposition.png` |
| 시너지 분해 | `synergy_{NN}_{Topic}.png` | `synergy_01_Week11_12_13_14.png` |

---

## 5. 자주 발생하는 문제와 해결

### 5.1 한국어 텍스트가 □ □ □ 로 깨짐

**원인**: SVG에 `class="ko"` 누락 또는 Noto Sans CJK 미설치

**해결**:
```bash
# 1) 폰트 설치 확인
fc-list | grep -i "Noto Sans CJK KR"

# 2) 없으면 설치
apt-get install -y fonts-noto-cjk

# 3) SVG의 모든 한국어 `<text>`에 `class="ko"` 추가
# 4) `<style>` 정의 확인
```

### 5.2 `&` 문자로 cairosvg 오류

**원인**: XML 파서가 `&`를 엔티티 시작으로 인식

**해결**: 모든 `&`를 `&amp;`로 이스케이프
```bash
# 자동 정정
sed -i 's/\&\([^a]\)/\&amp;\1/g' diagram.svg
```

### 5.3 mixed text 깨짐 (영문 + 한글 + 특수문자)

**원인**: 폰트 fallback 시 일부 문자만 한국어 폰트 처리

**해결책 1**: 텍스트를 분리
```xml
<!-- 분리 -->
<text class="ko">1926 이래</text>
<text>1926 max decline</text>
```

**해결책 2**: 영문화
```xml
<text>Since 1926, max decline</text>
```

**해결책 3**: 모두 한국어로 통일 + class="ko"
```xml
<text class="ko">1926년 이래 최대 감소</text>
```

### 5.4 cairosvg가 width/height를 무시

**원인**: viewBox만 있고 width/height 속성이 없음

**해결**:
```python
cairosvg.svg2png(
    url='diagram.svg',
    write_to='diagram.png',
    output_width=1500,  # 명시적 지정
    output_height=900   # 명시적 지정
)
```

### 5.5 LaTeX 수식의 한글 라벨

**원인**: LaTeX는 기본적으로 한국어 미지원

**해결책 1**: `\text{...}` 환경 + xelatex 사용
```bash
# 한국어 포함 시 xelatex 권장
xelatex -interaction=nonstopmode eq.tex
```

**해결책 2**: 한글 라벨을 영문/수식 기호로 변환
```latex
% 한글 라벨 회피
\underbrace{\hat V_{\text{DM}}}_{\text{baseline}}  % "기준선" 대신
```

---

## 6. 통합 워크플로우 — 케이스 스터디 부록 작성

```
1. 부록 .md 작성 (korean-md-standard 적용)
   - 별표 절제
   - 자연 한국어
   - 수식 4규칙 준수

2. 두 SVG 작성 (PNG 2개로 변환할 부록)
   - W14_01_*.svg
   - W14_02_*.svg
   - 한국어 텍스트는 모두 class="ko"
   - & → &amp;
   - mixed text 점검

3. cairosvg로 PNG 변환
   - output_width=1500, output_height=900
   - 결과 미리보기 (한국어 깨짐 검사)

4. 출력 폴더로 이동
   - ASCII-only 파일명
   - /mnt/user-data/outputs/W14_01_TopicName.png
   - /mnt/user-data/outputs/W14_02_TopicName.png

5. present_files로 사용자에게 전달
```

---

## 7. 참고 자료

- `scripts/render_eq.py` — LaTeX 수식 일괄 PNG 변환
- `scripts/svg_to_png.py` — SVG → PNG 일괄 변환 + 한국어 폰트 검증
- `references/svg_templates.md` — 검증된 SVG 다이어그램 템플릿 모음
- `references/latex_patterns.md` — 자주 쓰는 LaTeX 수식 패턴 모음

이 스킬과 함께 사용하는 골드 스킬:
- `korean-md-standard` — 한국어 학술 마크다운 + 별표 규칙 + 수식 4규칙

이 스킬과 함께 사용하는 다른 도구 스킬:
- `apple-white-deck` — Apple Keynote 톤 PPT 덱 (수식 PNG를 슬라이드에 배치)
- `latex-equation-png` — 기존 LaTeX 수식 PNG 스킬 (이 스킬이 통합 대체)
- `obsidian-infographic` — Mermaid + SVG 인포그래픽
