#!/usr/bin/env python3
"""
LaTeX 수식 일괄 PNG 변환

사용법:
    python3 render_eq.py equations.json output_dir/

equations.json 형식:
    [
      {"id": "eq_01", "latex": "\\hat V_{\\text{DR}} = \\hat V_{\\text{DM}} + \\frac{1}{n}\\sum_i w_i (r_i - \\hat r)"},
      {"id": "eq_02", "latex": "V(\\pi) = \\mathbb{E}_{p,\\pi}[r]"}
    ]

출력:
    output_dir/eq_01.png
    output_dir/eq_02.png
"""
import json
import subprocess
import sys
import shutil
from pathlib import Path
import tempfile


LATEX_TEMPLATE = r"""\documentclass[border=2pt,12pt]{standalone}
\usepackage{amsmath,amssymb}
\usepackage[utf8]{inputenc}
\begin{document}
$%s$
\end{document}
"""


def check_dependencies():
    """필수 도구 확인"""
    for tool in ['pdflatex', 'pdftoppm']:
        if not shutil.which(tool):
            print(f"오류: {tool} 미설치")
            print(f"설치: apt-get install -y texlive-latex-base texlive-latex-extra")
            sys.exit(1)


def render_one(latex_str, output_path, dpi=300):
    """단일 수식을 PNG로 렌더링"""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tex_file = tmpdir / "eq.tex"
        
        # LaTeX 문서 작성
        tex_content = LATEX_TEMPLATE % latex_str
        tex_file.write_text(tex_content, encoding='utf-8')
        
        # PDF 생성
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-output-directory', str(tmpdir), str(tex_file)],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        pdf_file = tmpdir / "eq.pdf"
        if not pdf_file.exists():
            print(f"  ✗ PDF 생성 실패: {latex_str[:60]}...")
            print(f"  stderr: {result.stderr[-300:]}")
            return False
        
        # PNG 변환
        png_prefix = tmpdir / "eq"
        subprocess.run(
            ['pdftoppm', '-png', '-r', str(dpi), str(pdf_file), str(png_prefix)],
            check=True
        )
        
        # 생성된 PNG 찾기 (eq-1.png)
        png_file = tmpdir / "eq-1.png"
        if not png_file.exists():
            png_files = list(tmpdir.glob("eq-*.png"))
            if not png_files:
                print(f"  ✗ PNG 생성 실패")
                return False
            png_file = png_files[0]
        
        # 출력 위치로 복사
        shutil.copy(png_file, output_path)
        return True


def main():
    if len(sys.argv) < 3:
        print("사용법: python3 render_eq.py equations.json output_dir/")
        print()
        print("equations.json 형식:")
        print('  [{"id": "eq_01", "latex": "수식"}, ...]')
        sys.exit(1)
    
    check_dependencies()
    
    json_file = Path(sys.argv[1])
    output_dir = Path(sys.argv[2])
    output_dir.mkdir(parents=True, exist_ok=True)
    
    equations = json.loads(json_file.read_text(encoding='utf-8'))
    
    print(f"=== LaTeX 수식 PNG 변환 ===")
    print(f"입력: {json_file} ({len(equations)} 식)")
    print(f"출력: {output_dir}/")
    print()
    
    success = 0
    for eq in equations:
        eq_id = eq['id']
        latex_str = eq['latex']
        output_path = output_dir / f"{eq_id}.png"
        
        print(f"렌더링: {eq_id}")
        print(f"  수식: {latex_str[:70]}...")
        
        if render_one(latex_str, output_path):
            success += 1
            print(f"  ✓ {output_path}")
        print()
    
    print(f"=== 완료: {success}/{len(equations)} ===")


if __name__ == '__main__':
    main()
