#!/usr/bin/env python3
"""
SVG → PNG 일괄 변환 + 한국어 폰트 검증

사용법:
    python3 svg_to_png.py input.svg output.png [--width 1500] [--height 900]
    python3 svg_to_png.py input_dir/ output_dir/  (디렉터리 일괄 처리)

기능:
    1. SVG → PNG 변환 (cairosvg)
    2. 한국어 폰트 (Noto Sans CJK KR) 사전 검증
    3. & → &amp; 자동 이스케이프
    4. class="ko" 누락 경고
"""
import sys
import argparse
import re
import subprocess
from pathlib import Path


def check_korean_font():
    """Noto Sans CJK KR 폰트 설치 확인"""
    try:
        result = subprocess.run(
            ['fc-list'],
            capture_output=True,
            text=True
        )
        if 'Noto Sans CJK KR' not in result.stdout and 'NotoSansCJK' not in result.stdout:
            print("⚠ 경고: Noto Sans CJK KR 폰트 미설치")
            print("  설치: apt-get install -y fonts-noto-cjk")
            return False
        return True
    except FileNotFoundError:
        print("⚠ 경고: fontconfig (fc-list) 미설치 — 폰트 확인 불가")
        return False


def check_cairosvg():
    """cairosvg 패키지 확인"""
    try:
        import cairosvg
        return True
    except ImportError:
        print("오류: cairosvg 미설치")
        print("설치: pip install cairosvg --break-system-packages")
        sys.exit(1)


def validate_svg(svg_content):
    """SVG 내용 점검 — 한국어 안전성"""
    issues = []
    
    # 1. & 이스케이프 점검 (이미 &amp; 형태가 아닌 단독 &)
    raw_amps = re.findall(r'&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)', svg_content)
    if raw_amps:
        issues.append(f"  ⚠ 이스케이프 안 된 '&' {len(raw_amps)}개 발견 — '&amp;'로 자동 변환")
    
    # 2. 한국어 텍스트 검출 + class="ko" 누락 점검
    text_pattern = re.compile(r'<text[^>]*>([^<]+)</text>', re.DOTALL)
    korean_pattern = re.compile(r'[가-힣]')
    
    missing_ko = []
    for match in text_pattern.finditer(svg_content):
        text_tag = match.group(0)
        text_content = match.group(1)
        if korean_pattern.search(text_content):
            # 한국어 포함됨 — class="ko" 확인
            if 'class="ko"' not in text_tag and "class='ko'" not in text_tag:
                missing_ko.append(text_content.strip()[:40])
    
    if missing_ko:
        issues.append(f"  ⚠ 한국어 텍스트 {len(missing_ko)}개에 class=\"ko\" 누락 (폰트 깨짐 위험):")
        for t in missing_ko[:5]:
            issues.append(f"    - \"{t}...\"")
        if len(missing_ko) > 5:
            issues.append(f"    ... 그 외 {len(missing_ko)-5}개")
    
    # 3. <style> 정의 점검
    if korean_pattern.search(svg_content):
        if '.ko' not in svg_content and 'Noto Sans CJK' not in svg_content:
            issues.append("  ⚠ 한국어 포함 but `.ko { font-family: \"Noto Sans CJK KR\" }` 스타일 정의 누락")
    
    return issues


def fix_svg(svg_content):
    """자동 정정"""
    # & 이스케이프 (이미 정상인 entity는 보존)
    svg_content = re.sub(r'&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)', '&amp;', svg_content)
    
    # .ko 스타일 정의가 없고 한국어가 있으면 자동 추가
    korean_pattern = re.compile(r'[가-힣]')
    if korean_pattern.search(svg_content) and '.ko {' not in svg_content and ".ko{" not in svg_content:
        # <svg> 태그 직후에 <style> 삽입
        style_def = '\n  <style>\n    .ko { font-family: "Noto Sans CJK KR", sans-serif; }\n  </style>'
        # 첫 <svg ...> 태그 찾기
        m = re.search(r'(<svg[^>]*>)', svg_content)
        if m:
            svg_content = svg_content[:m.end()] + style_def + svg_content[m.end():]
    
    # 한국어 포함 <text>에 class="ko" 자동 추가
    def add_ko_class(match):
        tag = match.group(0)
        if 'class=' in tag:
            return tag  # 이미 class 있으면 그대로
        text_content = match.group(1)
        if korean_pattern.search(text_content):
            # <text ...> 부분에 class="ko" 추가
            return re.sub(r'(<text)(\s)', r'\1 class="ko"\2', tag, count=1)
        return tag
    
    # <text ...>...</text> 형태 처리
    svg_content = re.sub(
        r'<text(?:\s[^>]*)?>([^<]+)</text>',
        add_ko_class,
        svg_content
    )
    
    return svg_content


def convert_one(input_path, output_path, width=1500, height=900, auto_fix=True):
    """단일 SVG → PNG 변환"""
    import cairosvg
    
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"\n[{input_path.name}]")
    svg_content = input_path.read_text(encoding='utf-8')
    
    # 점검
    issues = validate_svg(svg_content)
    if issues:
        print("  점검 결과:")
        for issue in issues:
            print(issue)
    
    # 자동 정정 (& 이스케이프만)
    if auto_fix:
        fixed = fix_svg(svg_content)
        if fixed != svg_content:
            svg_content = fixed
            print("  ✓ '&' → '&amp;' 자동 정정 적용")
    
    # 변환
    try:
        cairosvg.svg2png(
            bytestring=svg_content.encode('utf-8'),
            write_to=str(output_path),
            output_width=width,
            output_height=height
        )
        size_kb = output_path.stat().st_size / 1024
        print(f"  ✓ {output_path} ({size_kb:.1f} KB)")
        return True
    except Exception as e:
        print(f"  ✗ 변환 실패: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description='SVG → PNG 변환 + 한국어 폰트 검증')
    parser.add_argument('input', help='입력 SVG 파일 또는 디렉터리')
    parser.add_argument('output', help='출력 PNG 파일 또는 디렉터리')
    parser.add_argument('--width', type=int, default=1500, help='출력 너비 (기본 1500)')
    parser.add_argument('--height', type=int, default=900, help='출력 높이 (기본 900)')
    parser.add_argument('--no-fix', action='store_true', help='자동 정정 비활성화')
    
    args = parser.parse_args()
    
    check_cairosvg()
    check_korean_font()
    
    input_path = Path(args.input)
    output_path = Path(args.output)
    
    if input_path.is_dir():
        # 디렉터리 일괄 처리
        output_path.mkdir(parents=True, exist_ok=True)
        svg_files = list(input_path.glob('*.svg'))
        print(f"=== 디렉터리 일괄 변환: {len(svg_files)}개 SVG ===")
        
        success = 0
        for svg in svg_files:
            png = output_path / (svg.stem + '.png')
            if convert_one(svg, png, args.width, args.height, not args.no_fix):
                success += 1
        
        print(f"\n=== 완료: {success}/{len(svg_files)} ===")
    else:
        # 단일 파일
        print(f"=== SVG → PNG 변환 ===")
        convert_one(input_path, output_path, args.width, args.height, not args.no_fix)


if __name__ == '__main__':
    main()
