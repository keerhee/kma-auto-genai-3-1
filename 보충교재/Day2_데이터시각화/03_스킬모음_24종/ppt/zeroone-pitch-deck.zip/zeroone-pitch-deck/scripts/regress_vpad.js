/**
 * 세로 여백 회귀 점검 (v1.6에서 신설) — §1.5
 *
 *   node scripts/regress_vpad.js && python3 scripts/qa_overflow.py regress_vpad.pptx
 *
 * 낮은 카드와 항목이 많은 표지 체인은 세로 여백 결함이 가장 먼저 드러나는 자리다.
 * 빌드 경고 0건 · QA 0건이어야 한다. 하나라도 뜨면 §1.5 규약을 어긴 것이다.
 */
const T = require("./template.js");
const C = T.C;

T.setBrand({ eyebrow: "REGRESSION · VERTICAL PADDING", wordmark: "" });

/* 01 표지 — 체인 항목을 최대(4개)로 넣어 누적 오프셋 결함을 드러낸다 */
T.cover(T.slide(), {
  title: "세로 여백\n회귀 점검",
  sub: "표지 체인과 낮은 카드에서 위아래 여백이 같아야 한다",
  org: "ZeroOne Pitch Deck",
  chain: ["첫 항목", "둘째 항목", "셋째 항목", "마지막 항목"],
});

/* 02 낮은 카드 3종 — h 를 극단으로 낮춰 바닥 붙음을 본다 */
{
  const s = T.slide();
  const cy = T.head(s, {
    title: "낮은 카드에서 글씨가 바닥에 붙지 않아야 합니다",
    sub: "h = 1.10 / 1.60 — v1.6 이전에는 1.10에서 0.04in 넘쳤다",
    page: 2,
  });
  T.cards(s, [
    { kind: "white", cap: "h = 1.10", title: "가장 낮은 경우" },
    { kind: "lime",  cap: "h = 1.10", title: "라임 카드도 같다" },
  ], { y: cy + 0.06, h: 1.10 });
  T.cards(s, [
    { kind: "white", cap: "h = 1.60", title: "cap + title" },
    { kind: "white", cap: "h = 1.60", title: "sub 까지 넣으면", sub: "세 줄 블록이 중앙에 온다" },
  ], { y: cy + 1.32, h: 1.60 });
  T.statCards(s, [
    { cap: "통계 카드", value: "1.02" },
    { cap: "같은 규칙", value: "0.00" },
    { cap: "여백 균등", value: "OK" },
  ], { y: cy + 3.00, h: 1.02 });
  T.punch(s, [
    { text: "세 줄 모두 위아래 여백이 같아야 하고 빌드 경고가 0건이어야 합니다.", color: C.red },
  ], { y: 6.16 });
}

/* 03 flow3 · insightBox 하단 여백 */
{
  const s = T.slide();
  const cy = T.head(s, {
    title: "flow3 와 insightBox 의 하단 여백도 상단과 같아야 합니다",
    sub: "v1.6 이전에는 각각 0.08in · 0.15in 이었다",
    page: 3,
  });
  T.flow3(s, [
    { kind: "white", cap: "1단계", lines: ["첫 줄", "둘째 줄", "셋째 줄"] },
    { kind: "white", cap: "2단계", lines: ["첫 줄", "둘째 줄", "셋째 줄"] },
    { kind: "dark",  cap: "3단계", lines: ["첫 줄", "둘째 줄", "셋째 줄"] },
  ], { y: cy + 0.06, h: 3.40 });
  T.punch(s, [
    { text: "카드 안 첫 줄 위와 마지막 줄 아래의 여백이 같아야 합니다.", color: C.red },
  ], { y: 6.10 });
}

T.save("regress_vpad.pptx").then(() => console.log("saved regress_vpad.pptx"));
