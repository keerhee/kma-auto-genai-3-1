// v1.9 시각화 레퍼런스 덱 — SVG 도해 · matplotlib 차트 · LaTeX 수식을 한 번씩 얹는다.
// 사용:  python3 demo_viz_assets.py && node demo_viz_build.js
//        python3 qa_overflow.py zeroone_viz_demo.pptx   → 경고 0건이어야 한다
const fs = require("fs");
const T = require("./template.js");
const { C } = T;
T.setBrand({ eyebrow: "VISUAL REFERENCE · v1.9", wordmark: "" });   // 워드마크·로고 금지 (§5-1)

const S = () => T.slide();
const ratio = p => { const b = fs.readFileSync(p); return b.readUInt32BE(16) / b.readUInt32BE(20); };
let n = 1;

T.cover(S(), {
  title: "수식·도해·차트를\n한 덱에 얹는 법",
  sub: "LaTeX · SVG · matplotlib — 시각화 기본 의무",
  org: "zeroone-pitch-deck 시각화 레퍼런스",
});

/* 02 SVG 인포그래픽 — 구조·흐름 */
T.figureSlide(S(), {
  title: "운영 스택은 다섯 단계의 흐름으로 그린다", page: ++n,
  sub: "구조·흐름 → svg-infographic → cairosvg PNG (1600×620, §7.1~7.3)",
  path: "viz/stack.png", ratio: ratio("viz/stack.png"),
  caption: "※ 배경을 #F7F5F0으로 칠해 아이보리 위에서 경계가 뜨지 않게 한다",
});

/* 03 matplotlib — 민감도 (좌 패널 + 우 차트) */
T.figurePanelSlide(S(), {
  title: "연 매출은 가동률에 선형으로 반응한다", page: ++n,
  sub: "수치·데이터 → zo_mpl.py panel 프리셋 (1120×720, §7.4)",
  path: "viz/sens.png", ratio: ratio("viz/sens.png"),
  panel: { cap: "읽는 법", bullets: ["선 3개 = 체감 속도", "빨간 점선 = 가정 50%", "※ 예시 데이터"] },
});

/* 04 LaTeX — 수식 카드 두 장 체이닝 */
{ const s = S();
  const cy = T.head(s, { title: "모든 수식은 LaTeX PNG로 카드에 얹는다", page: ++n,
    sub: "render_eq.py — 카드 배경색을 PNG에 구워 넣는다 (§7.5)" });
  const w = 8.6, x = T.M + (T.CW - w) / 2;
  let y = T.eqInCard(s, { y: cy, h: 1.95, w, x, kind: "white", cap: "연간 Token 매출",
    path: "eq/eq_rev.png", ratio: ratio("eq/eq_rev.png") });
  T.eqInCard(s, { y: y + 0.20, h: 1.95, w, x, kind: "white", accent: true, cap: "투자 판단",
    path: "eq/eq_npv.png", ratio: ratio("eq/eq_npv.png") });
}

/* 05 matplotlib — 시나리오 경로 (전체폭) */
T.figureSlide(S(), {
  title: "시나리오 경로를 한 장의 차트로 비교한다", page: ++n,
  sub: "Bear · Base · Bull — zo_mpl.py wide 프리셋 (1600×620)",
  path: "viz/paths.png", ratio: ratio("viz/paths.png"),
  caption: "※ 예시 데이터 — 실제 덱에서는 원고·데이터에서 계산한 값만 쓴다",
});

T.closing(S(), {
  statements: ["EQUATIONS IN LATEX.", "STRUCTURE IN SVG.", "NUMBERS IN CHARTS."],
  message: "텍스트 수식과 글자만의 슬라이드를 남기지 않는다.",
  contacts: [],
});

T.save("zeroone_viz_demo.pptx").then(() => console.log("saved zeroone_viz_demo.pptx"));
