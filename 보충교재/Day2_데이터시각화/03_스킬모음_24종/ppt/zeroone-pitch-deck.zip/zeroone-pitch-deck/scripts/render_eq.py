#!/usr/bin/env python3
"""
zeroone-pitch-deck 전용 LaTeX 수식 → PNG 렌더러.

latex-equation-png 스킬의 방식(standalone → pdflatex → pdftoppm)을 쓰되,
이 덱에 맞춰 두 가지를 바꿨다.

  1) 배경색을 굽는다 — pdftoppm의 -transp가 이 환경에서 안 되므로,
     PNG 배경이 흰색이면 아이보리(#F7F5F0) 위에서 흰 사각형으로 뜬다.
     \\pagecolor로 카드 배경색을 미리 칠해 경계를 없앤다.
  2) 가장자리 1px을 잘라낸다 — PDF 페이지 경계가 실선으로 남는 것을 막는다.

사용:
    python3 render_eq.py          # 아래 __main__의 예시가 렌더된다
    또는 from render_eq import render, PAPER, DARK, LIME

주의: LaTeX 안에 한글을 넣지 않는다(inputenc 에러). 한글 라벨은
      eqInCard의 cap 인자로 PPT 텍스트로 넣는다.
"""
import os
import re
import shutil
import subprocess

OUT, TMP = "./eq", "./eq_tmp"

# zeroone-pitch-deck 팔레트 (SKILL.md §1.1과 동일)
INK, PAPER, WHITE = "102027", "F7F5F0", "FFFFFF"
LIME, TEAL, DARK, RED = "B7F34A", "0B6B68", "071A1D", "C00000"

TPL = r"""\documentclass[border=14pt]{standalone}
\usepackage{amsmath}
\usepackage{amssymb}
\usepackage[HTML]{xcolor}
\definecolor{eqcolor}{HTML}{COLORHEX}
\definecolor{bgcolor}{HTML}{BGHEX}
\pagecolor{bgcolor}
\begin{document}
{\fontsize{FONTSIZEpt}{FONTSIZEpt}\selectfont
\textcolor{eqcolor}{$EQUATION$}}
\end{document}
"""


def _check_hangul(latex, filename):
    """LaTeX에 한글이 들어가면 pdflatex가 그 글자를 '조용히 버린다'.
    에러도 안 나고 PDF도 만들어지므로 렌더 결과를 눈으로 보기 전에는 모른다.
    (실제 사고: "₩1,848.7조" → "₩1,848.7", underbrace 한글 라벨은 통째로 증발)
    그래서 굽기 전에 막는다."""
    bad = sorted({ch for ch in latex if 0xAC00 <= ord(ch) <= 0xD7A3
                  or 0x3130 <= ord(ch) <= 0x318F})
    if bad:
        raise ValueError(
            f"[render_eq] '{filename}': LaTeX 안에 한글이 있습니다 → {''.join(bad)}\n"
            "  pdflatex는 이 글자들을 경고 없이 버립니다. 수식에서 빼고,\n"
            "  한글 라벨은 eqInCard의 cap 인자로 PPT 텍스트로 넣으세요\n"
            "  (단위가 필요하면 \\text{KRW tn} 처럼 로마자로 쓰거나 캡션으로 옮깁니다).")


def _render_mathtext(latex, filename, fontsize, color, bg, dpi):
    """[로컬 패치] pdflatex가 없는 맥에서 matplotlib mathtext(Computer Modern)로 굽는다.
    배경색 굽기·(경로, 비율) 반환은 pdflatex 경로와 같다. \\dfrac·\\Big 등 일부 명령은 근사한다."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from PIL import Image
    s = latex.replace("\\dfrac", "\\frac").replace("\\tfrac", "\\frac").replace("\\displaystyle", "")
    s = re.sub(r"\\(?:textrm|mbox)\{", r"\\text{", s)
    s = re.sub(r"\\[Bb]igg?[lr]?(?![a-zA-Z])", "", s)
    s = s.replace("\\bm{", "\\mathbf{").replace("\\boldsymbol{", "\\mathbf{")
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, filename)
    with plt.rc_context({"mathtext.fontset": "cm"}):
        fig = plt.figure(figsize=(0.01, 0.01))
        fig.text(0, 0, "$" + s + "$", fontsize=fontsize, color="#" + color)
        fig.savefig(path, dpi=dpi, bbox_inches="tight", pad_inches=14 / 72, facecolor="#" + bg)
        plt.close(fig)
    im = Image.open(path).convert("RGB")
    im.save(path)
    ratio = im.width / im.height
    print(f"  o {filename}  {im.width}x{im.height}  ratio={ratio:.3f}  (mathtext)")
    return path, ratio


def render(latex, filename, fontsize=30, color=INK, bg=WHITE, dpi=300, trim=True):
    """LaTeX 식을 PNG로 굽고 (경로, 가로/세로 비)를 돌려준다.

    v1.10: 수식은 항상 흰 카드(eqInCard 기본 kind="white")에 잉크색으로 얹는다.
        기본값 color=INK, bg=WHITE 그대로 쓴다.
        다크 카드 + 라임 수식(LIME on DARK)은 읽기 어려워 금지한다 — 넘기면 경고 후 INK/WHITE로 바꾼다.
        핵심 수식 강조는 eqInCard(..., accent:true)의 왼쪽 티일 띠로 한다.
    trim=True면 배경과 같은 여백을 잘라 내(24px만 남김) 같은 카드 높이에서 글씨가 커진다.
    """
    if bg == DARK or color == LIME:
        print(f"  ! {filename}: 다크 카드 + 라임 수식은 v1.10부터 쓰지 않습니다 — INK/WHITE로 굽습니다 (강조는 accent:true)")
        color, bg = INK, WHITE
    _check_hangul(latex, filename)
    if shutil.which("pdflatex") is None:          # [로컬 패치] 이 맥에는 TeX가 없다
        res = _render_mathtext(latex, filename, fontsize, color, bg, dpi)
        if trim and res:
            from PIL import Image
            _trim(res[0]); im = Image.open(res[0]); res = (res[0], im.width / im.height)
        return res
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(TMP, exist_ok=True)
    base = filename.replace(".png", "")
    tex = (TPL.replace("EQUATION", latex)
              .replace("FONTSIZE", str(fontsize))
              .replace("COLORHEX", color)
              .replace("BGHEX", bg))
    tex_path = os.path.join(TMP, base + ".tex")
    with open(tex_path, "w") as f:
        f.write(tex)

    # pdflatex의 returncode는 신뢰하지 않는다 (warning만 있어도 != 0)
    subprocess.run(["pdflatex", "-interaction=nonstopmode",
                    "-output-directory", TMP, tex_path],
                   capture_output=True, timeout=60)
    pdf = os.path.join(TMP, base + ".pdf")
    if not os.path.exists(pdf):
        log = os.path.join(TMP, base + ".log")
        hint = ""
        if os.path.exists(log):
            for line in open(log, errors="ignore"):
                if line.startswith("!"):
                    hint = " — " + line.strip()
                    break
        print(f"  x FAIL {filename}{hint}")
        return None

    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), pdf,
                    os.path.join(OUT, base)], capture_output=True, timeout=60)
    cand = os.path.join(OUT, base + "-1.png")
    if not os.path.exists(cand):
        print(f"  x FAIL {filename} — PNG 변환 실패")
        return None

    from PIL import Image
    im = Image.open(cand)
    im = im.crop((1, 1, im.width - 1, im.height - 1))   # 페이지 경계선 제거
    path = os.path.join(OUT, filename)
    im.save(path)
    os.remove(cand)
    if trim:
        path = _trim(path)
        im = Image.open(path)
    ratio = im.width / im.height
    print(f"  o {filename}  {im.width}x{im.height}  ratio={ratio:.3f}")
    return path, ratio


def _trim(path, margin=24):
    """배경색과 다른 픽셀의 경계 + margin 만 남긴다 (standalone border 여백 제거)."""
    from PIL import Image, ImageChops
    im = Image.open(path).convert("RGB")
    bgim = Image.new("RGB", im.size, im.getpixel((2, 2)))
    bb = ImageChops.difference(im, bgim).getbbox()
    if bb:
        bb = (max(0, bb[0]-margin), max(0, bb[1]-margin),
              min(im.width, bb[2]+margin), min(im.height, bb[3]+margin))
        im.crop(bb).save(path)
    return path


if __name__ == "__main__":
    # 흰 카드용 (v1.10: 모든 수식은 INK on WHITE)
    # 한 줄 띠에 얹는 식은 underbrace·분수 없이 납작하게 — 높이가 낮을수록 글씨가 커진다 (§7.5.1)
    render(r"R_{\text{annual}}=\text{tok/s}\times S\times u\times 31{,}536{,}000"
           r"\,/\,10^{6}\times p",
           "eq_revenue.png")
    # 핵심 수식도 같은 흰 카드 — 강조는 eqInCard accent:true
    render(r"\Delta\text{FX}=\text{AUM}\times\Delta w_{\text{intl}}\times(1-h)",
           "eq_fx.png")
