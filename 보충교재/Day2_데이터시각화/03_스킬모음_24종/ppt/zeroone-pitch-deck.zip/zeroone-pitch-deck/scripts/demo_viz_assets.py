#!/usr/bin/env python3
"""
v1.9 시각화 레퍼런스 덱(demo_viz_build.js)의 그림을 굽는다 — 세 파이프라인을 한 번씩 보여 준다.

  1) SVG 인포그래픽  → cairosvg → viz/stack.png        (구조·흐름: §7.1~7.3)
  2) matplotlib 차트 → zo_mpl   → viz/sens.png, viz/paths.png  (수치: §7.4)
  3) LaTeX 수식      → render_eq → eq/eq_rev.png, eq/eq_npv.png  (수식: §7.5)

사용:  python3 demo_viz_assets.py   (작업 폴더에 viz/ · eq/ 생성)
의존:  matplotlib, numpy, cairosvg, pdflatex, pdftoppm, Noto Sans CJK KR
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import cairosvg
from zo_mpl import fig, save, C
from render_eq import render, INK, PAPER, LIME, DARK

os.makedirs("viz", exist_ok=True)

# ---- 1) SVG 인포그래픽: 운영 스택 (1600×620, 덱 팔레트 §7.1) ----------------
steps = ["전력·공간", "GPU Cluster", "Open LLM", "Serving", "TOKEN"]
bw, gap, y0, bh = 270, 46, 170, 230
x0 = (1600 - (len(steps) * bw + (len(steps) - 1) * gap)) // 2
parts = [f'<rect width="1600" height="620" fill="{C["paper"]}"/>',
         f'<text x="800" y="110" text-anchor="middle" font-size="38" font-weight="700" '
         f'fill="{C["body"]}">전기가 매출이 되기까지 — 다섯 단계</text>']
for i, t in enumerate(steps):
    x = x0 + i * (bw + gap)
    last = i == len(steps) - 1
    fill = C["lime"] if last else C["white"]
    parts.append(f'<rect x="{x}" y="{y0}" width="{bw}" height="{bh}" rx="14" fill="{fill}" '
                 f'stroke="{C["hair"]}" stroke-width="2"/>')
    parts.append(f'<text x="{x + bw / 2}" y="{y0 + 70}" text-anchor="middle" font-size="30" '
                 f'fill="{C["muted"]}">STEP {i + 1}</text>')
    parts.append(f'<text x="{x + bw / 2}" y="{y0 + 130}" text-anchor="middle" font-size="40" '
                 f'font-weight="700" fill="{C["body"]}">{t}</text>')
    if not last:
        ax = x + bw + 6
        parts.append(f'<path d="M{ax} {y0 + bh / 2} h{gap - 16}" stroke="{C["teal"]}" stroke-width="5"/>')
        parts.append(f'<path d="M{ax + gap - 16} {y0 + bh / 2 - 10} l14 10 l-14 10 z" fill="{C["teal"]}"/>')
parts.append(f'<rect x="{x0}" y="470" width="{len(steps) * bw + (len(steps) - 1) * gap}" height="80" '
             f'rx="12" fill="{C["ink"]}"/>')
parts.append(f'<text x="800" y="522" text-anchor="middle" font-size="32" font-weight="700" '
             f'fill="{C["lime"]}">운영 범위: 배포 · 최적화 · 관제 · SLA · 과금</text>')
svg = ('<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="620" '
       'font-family="Noto Sans CJK KR">' + "".join(parts) + "</svg>")
open("viz/stack.svg", "w").write(svg)
cairosvg.svg2png(bytestring=svg.encode(), write_to="viz/stack.png",
                 output_width=1600, output_height=620)
print("[svg] viz/stack.png  1600×620  ratio:1600/620")

# ---- 2) matplotlib: 가동률 민감도 (panel) · 시나리오 경로 (wide) -------------
u = np.linspace(0.2, 0.9, 50)
f, ax = fig("panel")
for tps, col, lab in [(40, C["muted"], "40 tok/s"), (60, C["teal"], "60 tok/s"),
                      (80, C["lime_dk"], "80 tok/s")]:
    rev = tps * 16 * u * 31_536_000 / 1e6 * 5.5 / 1e3       # $K
    ax.plot(u * 100, rev, color=col, label=lab)
ax.axvline(50, color=C["red"], lw=1.6, ls="--")
ax.set_xlabel("가동률 (%)"); ax.set_ylabel("연 매출 ($K)")
ax.legend(loc="upper left")
save(f, "viz/sens.png")

rng = np.random.default_rng(7)
t = np.arange(37)
f, ax = fig("wide")
for mu, col, lab in [(-0.6, C["muted"], "Bear"), (0.4, C["teal"], "Base"), (1.2, C["lime_dk"], "Bull")]:
    ax.plot(t, 100 + np.cumsum(mu + rng.normal(0, 0.8, 37)), color=col, label=lab)
ax.set_xlabel("개월"); ax.set_ylabel("누적 매출 지수")
ax.legend(loc="upper left", ncol=3)
save(f, "viz/paths.png")

# ---- 3) LaTeX 수식 ---------------------------------------------------------
render(r"R=\text{tok/s}\times S\times u\times\frac{3.15\times10^{7}}{10^{6}}\times p",
       "eq_rev.png", fontsize=30)
render(r"\text{NPV}=\sum_{t=1}^{T}\frac{\text{CF}_t}{(1+r)^t}-I_0",
       "eq_npv.png", fontsize=30)
