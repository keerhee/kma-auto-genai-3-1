/* zeroone-pitch-deck 데모 빌드 — 원본 19장 톤 재현 (스킬 자기검증용)
 * 실행: node scripts/demo_build.js
 */
const T = require("./template.js");
const { C } = T;

T.setBrand({ eyebrow: "ZeroOneAI · TOKEN CLOUD", wordmark: "" });

let n = 0;
const S = () => T.slide();
// 수식 PNG 비율 — 먼저 `python3 render_eq.py`로 eq/eq_revenue.png를 굽는다 (§7.5)
const EQ_REV_RATIO = (()=>{ const b=require("fs").readFileSync("eq/eq_revenue.png");
  return b.readUInt32BE(16)/b.readUInt32BE(20); })();

/* 01 표지 */
T.cover(S(), {
  title: "공간과 전력을\nToken 생산 자산으로",
  sub: "기관·투자자 대상 Token Cloud 사업 제안",
  org: "Token Cloud 레퍼런스 덱",
  chain: ["GPU", "LLM", "TOKEN"],
});

/* 02 목차 */
{ const s=S(); T.head(s,{eyebrow:"ZeroOneAI · PROPOSAL OVERVIEW",title:"목차",
    sub:"Token Cloud의 산업 논리에서 기관 파트너십과 경제성까지",page:++n+1});
  T.agenda(s,[
    {num:"01",title:"시장 변화와 Token의 이해",kicker:"Token이란 무엇인가",desc:"CSP → NeoCloud → Token Cloud"},
    {num:"02",title:"수요 폭증과 기술 전환",kicker:"PC·업무·교육의 AI 전환",desc:"Agent 수요 · 고밀도 GPU · Qwen3.8"},
    {num:"03",title:"ZeroOneAI Token Cloud",kicker:"Token Factory 포지셔닝",desc:"운영 Architecture · Micro Data Center"},
    {num:"04",title:"파트너십과 사업 경제성",kicker:"장기 독점 Tenant · Revenue Share",desc:"1 GPU Feasibility · Bear/Base/Bull"},
  ],{y:2.20,rowH:0.92});
  T.banner(s,"산업 이해 → 기술적 가능성 → 운영모델 → 투자·기관 제안",{y:6.15}); }

/* 03 Token 정의 — 좌 white / 우 dark */
{ const s=S(); const cy=T.head(s,{title:"Token이란 '글자 조각'입니다",
    sub:"전기는 kWh, 데이터는 GB, AI는 Token으로 사용량을 셉니다.",page:++n+1});
  T.pairPanels(s,
    {kind:"white",cap:"내가 AI에게 묻습니다",title:"“세종대왕을 세 줄로\n쉽게 설명해 줘.”",titleSize:24,
     footCap:"질문도 Token으로",foot:"답변도 Token 으로"},
    {kind:"dark",cap:"AI는 질문을 작은 조각으로 읽고",
     title:"답을 쓸 때도 조각마다 Token을 씁니다.",titleSize:20,
     foot:"질문 Token + 답변 Token = AI 사용량"},
    {y:cy,h:3.55,w:4.90});
  T.note(s,"※ 실제 조각 수는 모델과 언어에 따라 달라집니다.",{y:6.05,color:C.muted}); }

/* 04 판매 단위 이동 — 체인 카드 */
{ const s=S(); const cy=T.head(s,{title:"컴퓨팅의 판매 단위가 '자원'에서 '결과'로 이동합니다",page:++n+1});
  T.cards(s,[
    {title:"SERVER",sub:"구매",titleSize:24},
    {title:"VM",sub:"시간",titleSize:24},
    {title:"GPU",sub:"시간",titleSize:24},
    {kind:"lime",title:"TOKEN",sub:"지능의 결과",titleSize:24},
  ],{y:cy+0.35,h:2.40,gap:0.35,connect:true});
  T.punch(s,[
    {text:"Cloud 사업자는 컴퓨터를 판매",color:C.teal,size:20},
    {text:"NeoCloud 사업자는 GPU 컴퓨터를 판매",color:C.teal,size:20},
    {text:"Token Cloud 사업자는 AI의 답(토큰, 지능)을 판매합니다.",color:C.red,size:24},
  ],{y:5.20,gap:0.46}); }

/* 05 3단 비교 카드 */
{ const s=S(); const cy=T.head(s,{title:"일반 Cloud → NeoCloud → Token Cloud: 고객이 해야 할 일이 줄어듭니다",page:++n+1});
  T.cards(s,[
    {title:"일반 Cloud",rows:[["판매","VM / 컴퓨터"],["과금","VM·시간",true],["고객 책임","SW 설치·운영"],["핵심 KPI","가동률"]]},
    {title:"NEO Cloud",rows:[["판매","GPU 인스턴스"],["과금","GPU·시간",true],["고객 책임","모델·서빙 운영"],["핵심 KPI","GPU 가동률"]]},
    {kind:"dark",title:"TOKEN CLOUD",rows:[["판매","AI 답변"],["과금","Token",true],["고객 책임","업무에 바로 사용"],["핵심 KPI","tok/s · 원/token"]]},
  ],{y:cy+0.10,h:3.95,gap:0.20}); }

/* 06 PC 용도 확장 */
{ const s=S(); const cy=T.head(s,{title:"PC의 핵심 용도가 PPT 엑셀 이용에서 “모든 일의 AI 동반”으로 넓어집니다",page:++n+1});
  T.txt(s,"과거의 일반 사용자",{x:T.M+0.10,y:cy-0.06,w:5,h:0.34,fontSize:16,bold:true,color:C.muted});
  T.card(s,T.M,cy+0.32,4.05,3.10,"white");
  [["PPT",C.blue],["Word · HWP",null],["Excel",null]].forEach((b,i)=>{
    const y=cy+1.00+i*0.68;
    T.rect(s,T.M+0.42,y,3.22,0.55,b[1]||C.white,b[1]?null:{color:C.hair,width:1});
    T.txt(s,b[0],{x:T.M+0.42,y,w:3.22,h:0.55,align:"center",valign:"middle",fontSize:17,bold:true,
      color:b[1]?C.white:C.body});
  });
  T.txt(s,"PC",{x:T.M+0.42,y:cy+0.48,w:3.22,h:0.40,fontSize:18,bold:true,color:C.body});
  T.txt(s,"단순작업용으로\n컴퓨터자원을 거의 사용안함",{x:T.M,y:cy+3.50,w:4.05,h:0.60,align:"center",
    fontSize:14,bold:true,color:C.muted,...T.lsp(14,1.15)});
  T.txt(s,"이제",{x:5.10,y:cy+1.28,w:1.8,h:0.34,align:"center",fontSize:16,color:C.muted});
  T.arrowR(s,4.95,cy+1.78,2.10,C.teal,3);
  T.txt(s,"프로그램이 아니라\nAI를 호출하고 Token을 소비",{x:4.70,y:cy+1.98,w:2.70,h:0.60,align:"center",
    fontSize:14,bold:true,color:C.red,...T.lsp(14,1.15)});
  T.card(s,7.56,cy+0.02,4.95,3.70,"dark");
  T.txt(s,"AI와 함께하는 모든 일",{x:7.98,y:cy+0.28,w:4.2,h:0.42,fontSize:20,bold:true,color:C.lime,valign:"middle"});
  [["문서 초안","PPT 구성"],["표·데이터 분석","이미지 생성"],["행정 처리","수업·과제"],["논문 탐색","연구·실험"]]
   .forEach((r,i)=>{
    const y=cy+0.92+i*0.60;
    T.txt(s,r[0],{x:7.98,y,w:2.2,h:0.50,fontSize:16,color:C.white,valign:"middle"});
    T.txt(s,r[1],{x:10.20,y,w:2.1,h:0.50,fontSize:16,color:C.white,valign:"middle"});
    if(i<3) T.hline(s,7.98,y+0.55,4.11,"33474A",1);
  });
  T.punch(s,[
    {text:"일반 PPT, 엑셀, 한글 사용에서,",color:C.teal,size:20,align:"center"},
    {text:"기존 모든 PC 사용자의 “업무 방식”이 Token 수요로 바뀌고 있습니다.",color:C.red,size:22,align:"center"},
  ],{y:5.98,gap:0.44}); }

/* 07 Agent 반복 소비 */
{ const s=S(); const cy=T.head(s,{title:"Agent는 한 업무에서 Token을 반복 소비합니다",page:++n+1});
  T.pairPanels(s,
    {kind:"white",cap:"HUMAN",title:"질문 → 답변",titleSize:28,foot:"하루 수십 회"},
    {kind:"dark",cap:"AGENT",title:"계획 → 호출 → 검증\n→ 수정 → 재호출",titleSize:26,foot:"한 업무 안에서 다수 호출"},
    {y:cy+0.06,h:3.60,w:4.48});
  T.punch(s,[{text:"수요 = 사용자 수 × 업무 수 × 업무당 모델 호출 수",color:C.teal,size:22}],{y:6.05}); }

/* 08 하드웨어 3종 */
{ const s=S(); const cy=T.head(s,{title:"데이터센터급 AI 성능이 “한 개 Rack” 안으로 압축됩니다",page:++n+1});
  T.txt(s,"모두 1 Rack 이내",{x:T.M,y:cy-0.14,w:CWx(),h:0.32,align:"right",fontSize:16,bold:true,color:C.body});
  T.cards(s,[
    {cap:"소형 Node",title:"2× RTX PRO 6000",titleSize:20,sub:"96GB × 2",value:"약 1.2억원",valueSize:24},
    {cap:"고성능 Server",title:"8× NVIDIA B200",titleSize:20,sub:"HGX 8-GPU",value:"약 8억원",valueSize:24},
    {kind:"dark",cap:"완성형 AI Rack",title:"GB300 NVL72",titleSize:20,sub:"Blackwell Ultra × 72",value:"약 60억원",valueSize:24},
  ],{y:cy+0.24,h:3.20});
  T.chips(s,[{text:"저렴·안정적인 전력",color:C.teal},{text:"냉각·시설 운영",color:C.blue},
             {text:"Token Cloud SW",color:C.lime}],{y:5.66,x:T.M+3.30,label:"공간보다 중요한 경쟁력"});
  T.note(s,"※ NVL72는 한 Rack이지만 최대 142kW급 전력과 액체냉각이 필요합니다.",{y:6.48}); }
function CWx(){ return T.CW; }

/* 09 벤치마크 막대 */
{ const s=S(); const cy=T.head(s,{title:"오픈소스 AI 성능이 ChatGPT 모델과 동급성능이 나옵니다",
    sub:"Artificial Analysis Intelligence Index v4.1.1 · 높을수록 우수",page:++n+1});
  T.barsH(s,[
    {label:"Qwen3.8-Flash-Next\n(오픈모델)",value:56,color:C.lime},
    {label:"GPT-5.4",value:53,color:C.amber},
    {label:"Qwen3.8-27B\n(오픈모델)",value:52,color:C.teal},
    {label:"GPT-5.2",value:43,color:C.blue,bold:false},
    {label:"GPT-5 mini (high)",value:26,color:C.hair,bold:false},
  ],{y:cy+0.06,rowH:0.68,barX:3.30,barW:5.37,max:56});
  T.insightBox(s,{x:9.68,y:cy+0.06,w:3.28,h:3.55,cap:"직관적 결론",blocks:[
    {title:"Qwen3.8-Flash-Next\n(오픈모델)",desc:"GPT-5.4 보다 높음",fs:19},
    {title:"Qwen3.8 27B (오픈모델)",desc:"GPT-5.4 와 사실상 동급권",fs:19},
  ]});
  T.note(s,"※ 사용자 표기 “Flash-Next-128B” 대신 Artificial Analysis의 공식 모델명 사용",{y:6.10}); }

/* 10 등식 */
{ const s=S(); T.head(s,{title:"고밀도 GPU × 효율적 모델 = Micro Data Center의 상업적 가능성",page:++n+1});
  T.equation(s,{y:2.30,a:"고밀도 GPU",b:"실사용급 Open LLM",result:"TOKEN FACTORY",resultSize:22});
  T.punch(s,[{text:"작은 공간에서도 모델을 보유하고, 지능을 생산·판매하는 독립 인프라가 가능",
    color:C.red,size:24,align:"center"}],{y:5.90}); }

/* 11 GPU IS THE FACTORY */
{ const s=S(); T.head(s,{title:"ZeroOneAI는 GPU가 아니라 Token을 운영합니다",page:++n+1});
  T.statementStack(s,{y:2.10,lead:"GPU IS THE FACTORY.",punch:"TOKEN IS THE PRODUCT.",
    stack:["모델 선정·최적화","Serving / Routing","API·보안·관제","사용량 측정·정산",
           {text:"고객·Agent 연결",color:C.teal}]}); }

/* 12 3자 구도 */
{ const s=S(); T.head(s,{title:"3자가 역할과 위험을 나누고, ZeroOneAI가 장기 수요를 연결합니다",page:++n+1});
  T.hub(s,{title:"자산운용사 / 투자자",sub:"GPU·HW 자금"},{title:"기관",sub:"전력·공간·시설"},
    {title:"ZeroOneAI",sub:"장기 Tenant · HW/SW 운영 · Token 판매"},{y:2.25});
  T.punch(s,[{text:"계약이 정할 핵심: CAPEX 소유 · 최소사용량 · 전력비 · 성능 SLA · 수익배분 · 잔존가치",
    color:C.teal,size:18,align:"center"}],{y:6.40}); }

/* 13 파이프라인 */
{ const s=S(); T.head(s,{title:"Token Factory는 전기에서 매출까지 하나의 운영 스택입니다",page:++n+1});
  T.pipeline(s,["전력·공간","GPU Cluster","Open-weight\nLLM","01Serving /\nMiddleware",
    "API · Agent\nEnterprise","Token Revenue"],{y:2.45,h:1.40,gap:0.18,fs:16});
  T.txt(s,"ZeroOneAI 운영 범위",{x:T.M,y:4.42,w:T.CW,h:0.36,align:"center",fontSize:17,bold:true,color:C.teal});
  T.banner(s,"배포 · 최적화 · 관제 · SLA · 과금 · 고객 운영",{y:4.87,w:6.8,fs:21}); }

/* 14 기관 자산 → CASH COW */
{ const s=S(); T.head(s,{title:"저가 전력과 작은 공간이 AI 시대의 반복 현금흐름을 만듭니다",page:++n+1});
  T.txt(s,"기관이 이미 가진 희소자원",{x:T.M+0.10,y:1.66,w:5,h:0.34,fontSize:16,bold:true,color:C.muted});
  T.flow3(s,[
    {kind:"white",lines:[{text:"저렴한 전력",fs:24,color:C.teal},{text:"+",fs:20,color:C.body},
      {text:"작은 운영 공간",fs:24},{text:"기존 자산 활용도 상승",fs:16,color:C.muted,bold:false}]},
    {kind:"dark",lines:[{text:"GPU",fs:22},{text:"+",fs:18},{text:"TOKEN CLOUD",fs:22,color:C.lime},
      {text:"전기 → Token → 매출",fs:18}]},
    {kind:"lime",lines:[{text:"CASH COW",fs:18},{text:"장기 임대료",fs:17},{text:"수익 배분",fs:17},
      {text:"지역 AI 활용",fs:17},{text:"AI 전초기지",fs:17,color:C.teal}]},
  ],{y:2.05,h:3.45,gap:0.72});
  T.punch(s,[{text:"부가가치는 면적이 아니라 “전력 1kWh가 몇 개의 Token과 매출로 전환되는가”에서 만들어집니다.",
    color:C.teal,size:19,align:"center"}],{y:6.05}); }

/* 15 상생 계약 */
{ const s=S(); const cy=T.head(s,{title:"장기 독점 Tenant와 Revenue Share가 기관·ZeroOneAI를 한 팀으로 만듭니다",page:++n+1});
  T.pairPanels(s,
    {kind:"white",title:"기관",titleSize:26,
     bullets:["저렴한 장소·전력 제공","HW의 장기 사용권 부여","시설·지역 인프라 연계"],
     footCap:"얻는 것",foot:"안정 수입 + Token 매출 Upside"},
    {kind:"dark",title:"ZeroOneAI",titleColor:C.lime,titleSize:26,
     bullets:["독점 장기 Tenant","HW·LLM·SW 통합운영","고객 확보·Token 판매"],
     footCap:"제공하는 것",foot:"가동률·기술·시장 위험의 실행 책임"},
    {y:cy+0.02,h:3.88,w:4.02});
  // 중앙 라임 배지
  T.rect(s,5.44,2.62,2.45,1.94,C.lime);
  T.txt(s,"상생 계약",{x:5.44,y:2.80,w:2.45,h:0.44,align:"center",fontSize:21,bold:true,color:C.limeInk});
  T.txt(s,"낮은 사용료\n+\nToken Revenue Share",{x:5.44,y:3.30,w:2.45,h:1.05,align:"center",
    fontSize:16,bold:true,color:C.limeInk,...T.lsp(16,1.25),valign:"middle"});
  T.punch(s,[{text:"기관은 공실·유휴자산 위험을 줄이고, ZeroOneAI는 장기 저원가 생산기반을 확보합니다.",
    color:C.teal,size:20,align:"center"}],{y:6.10}); }

/* 16 Fixed Lease vs Revenue Share */
{ const s=S(); const cy=T.head(s,{title:"임대료와 Token 매출을 함께 나눕니다",page:++n+1});
  T.pairPanels(s,
    {kind:"white",cap:"FIXED LEASE",title:"예측 가능한 현금흐름",titleSize:24,titleColor:C.teal,
     bullets:["장기 최소사용량 / 임대료","기관의 공실·가동률 위험 축소","ZeroOneAI의 독점 용량 확보"]},
    {kind:"dark",cap:"REVENUE SHARE",title:"Token 매출의 Upside 공유",titleSize:24,
     bullets:["매출 정의와 감사권","OPEX 우선순위","배분 waterfall·상한/하한"]},
    {y:cy+0.02,h:3.76,w:5.42}); }

/* 17 1 GPU Feasibility */
{ const s=S(); T.head(s,{title:"RTX PRO 6000 한 장의 연간 Token 매출 약 1억원을 가정으로 검증합니다",page:++n+1});
  // v1.9: 수식은 텍스트로 풀어쓰지 않는다 — render_eq.py가 구운 LaTeX PNG (§7.5)
  T.figImg(s,"eq/eq_revenue.png",EQ_REV_RATIO,{y:1.60,bottom:2.20,quiet:true});
  T.statCards(s,[{cap:"사용자 체감 속도",value:"60 tok/s"},{cap:"동시 처리",value:"16 streams"},
    {cap:"가동률",value:"50%"},{cap:"River 출력단가",value:"$5.50 / 1M"}],{y:2.28,h:1.05});
  T.arrowR(s,1.92,3.90,8.90,C.teal,2.5);
  T.resultBar(s,{y:4.28,h:1.50,cap:"연간 판매 Output Token",value:"15.14B",
    mid:[{text:"× $5.50 / 1M",x:5.10,w:2.6,fs:22},{text:"=",x:7.60,w:0.7,fs:22}],
    result:"$83.3K ≈ 1억원"});
  T.note(s,"※ 전기비 예시: GPU당 1.0kW, PUE 1.3, ₩100/kWh 기준 연 ₩1.14M  |  CAPEX·인건비·SW·네트워크·세금 제외",{y:6.10}); }

/* 18 시나리오 표 */
{ const s=S(); T.head(s,{title:"GPU 매출은 처리량과 가동률이 좌우합니다",page:++n+1});
  T.dataTable(s,["시나리오","Aggregate tok/s","가동률","연 판매 Token","Gross 매출"],
    [["BEAR","480","35%","5.30B","약 5천만원"],
     ["BASE","960","50%","15.14B","약 1억원"],
     ["BULL","1,440","65%","29.52B","약 2억원"]],
    {y:1.90,rowH:1.10,emph:1,widths:[2.20,2.60,2.00,2.60,2.39]});
  T.note(s,"동일 River 출력단가 $5.50/1M · ₩/$ 1,350 가정",{y:5.95});
  T.note(s,"다음 단계: 2× RTX PRO 6000 Node에서 동시사용자 8·16·32 부하테스트",{y:6.40,color:C.teal,fs:17}); }

/* 19 마감 */
T.closing(S(),{
  statements:["CLOUD SOLD COMPUTERS.","NEOCLOUD SELLS GPUs.","TOKEN CLOUD SELLS INTELLIGENCE."],
  message:"공간과 전력을 제공하는 기관에서\nAI 시대의 Token 생산자로.",
  contacts:["www.zeroone.ai","info@zeroone.ai"],
  note:"ZeroOneAI · Long-term Exclusive Tenant / Token Cloud Operator",
});

T.save("zeroone_demo.pptx").then(()=>console.log("saved zeroone_demo.pptx"));
