// =============================================================
// Apple White Deck — Template
// 12개 슬라이드 패턴이 모두 포함된 동작하는 시작점.
// 새 덱을 만들 때는 이 파일을 복사한 뒤 필요한 패턴만 남기고
// 텍스트만 교체한다.
//
// 실행:
//   NODE_PATH=$(npm root -g) node template.js
// =============================================================

const pptxgen = require("pptxgenjs");

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3" × 7.5"
pres.author = "Author Name";
pres.title = "Deck Title";

// =========================
// Design Tokens (절대 바꾸지 않는다)
// =========================
const C = {
  bg:       "FFFFFF",
  ink:      "1D1D1F",
  inkSoft:  "424245",
  muted:    "86868B",
  hairline: "D2D2D7",
  surface:  "F5F5F7",
  blue:     "0071E3",
  blueDeep: "0040DD",
  green:    "30D158",
  orange:   "FF9F0A",
  red:      "FF3B30",
  purple:   "AF52DE",
};

const F = {
  display:  "SF Pro Display",
  text:     "SF Pro Text",
  fallback: "Helvetica Neue",
};

// =========================
// Helpers
// =========================

// ⚠️ 매 호출마다 새 객체를 반환해야 한다 (pptxgenjs가 in-place mutate).
const cardShadow = () => ({
  type: "outer", color: "000000", blur: 16, offset: 3, angle: 90, opacity: 0.06,
});

function addFooter(slide, footerLeft, page) {
  slide.addText(footerLeft, {
    x: 0.6, y: 7.05, w: 8, h: 0.3,
    fontSize: 10, fontFace: F.text, color: C.muted, margin: 0,
  });
  slide.addText(`${page}`, {
    x: 12.4, y: 7.05, w: 0.4, h: 0.3,
    fontSize: 10, fontFace: F.text, color: C.muted, align: "right", margin: 0,
  });
}

function addEyebrow(slide, text, x = 0.6, y = 0.5) {
  slide.addText(text, {
    x, y, w: 6, h: 0.3,
    fontSize: 11, fontFace: F.text, color: C.blue, bold: true,
    charSpacing: 4, margin: 0,
  });
}

function addTitle(slide, text, opts = {}) {
  slide.addText(text, {
    x: 0.6, y: opts.y ?? 0.9, w: 12.1, h: opts.h ?? 0.95,
    fontSize: opts.size ?? 36, fontFace: F.display, color: C.ink, bold: true,
    margin: 0, valign: "top",
  });
}

function addSubtitle(slide, text, y = 1.85) {
  slide.addText(text, {
    x: 0.6, y, w: 12.1, h: 0.5,
    fontSize: 16, fontFace: F.text, color: C.inkSoft, margin: 0,
  });
}

const FOOTER_LEFT = "Day X  ·  코스명";   // 모든 슬라이드에 들어갈 footer 좌측 텍스트

// =========================
// P1. Cover (표지)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };

  s.addText("Course Code  ·  Day 1", {
    x: 0.6, y: 2.5, w: 12.1, h: 0.4,
    fontSize: 14, fontFace: F.text, color: C.blue, bold: true,
    charSpacing: 6, margin: 0,
  });

  // 큰 한글 제목은 줄당 h: 1.1 확보 (54pt 한글 wrap 방지)
  s.addText("메인 타이틀 1", {
    x: 0.6, y: 2.95, w: 12.1, h: 1.1,
    fontSize: 54, fontFace: F.display, color: C.ink, bold: true,
    margin: 0, valign: "top",
  });
  s.addText("메인 타이틀 2", {
    x: 0.6, y: 4.0, w: 12.1, h: 1.1,
    fontSize: 54, fontFace: F.display, color: C.ink, bold: true,
    margin: 0, valign: "top",
  });

  s.addText("부제 한 줄 설명", {
    x: 0.6, y: 5.1, w: 12.1, h: 0.4,
    fontSize: 18, fontFace: F.text, color: C.inkSoft, margin: 0,
  });

  s.addShape(pres.shapes.LINE, {
    x: 0.6, y: 6.4, w: 12.1, h: 0,
    line: { color: C.hairline, width: 0.75 },
  });
  s.addText("이론 3H  ·  실습 5H  ·  오프라인", {
    x: 0.6, y: 6.55, w: 8, h: 0.3,
    fontSize: 12, fontFace: F.text, color: C.muted, margin: 0,
  });
  s.addText("강사명   |   2026", {
    x: 8.6, y: 6.55, w: 4.1, h: 0.3,
    fontSize: 12, fontFace: F.text, color: C.muted, align: "right", margin: 0,
  });
}

// =========================
// P2. Agenda
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "AGENDA");
  addTitle(s, "오늘의 흐름");
  addSubtitle(s, "이론 N시간으로 기본기를 세우고, 실습 M시간으로 체화한다.");

  const items = [
    ["01", "섹션 1 타이틀", "한 줄 설명"],
    ["02", "섹션 2 타이틀", "한 줄 설명"],
    ["03", "섹션 3 타이틀", "한 줄 설명"],
    ["04", "섹션 4 타이틀", "한 줄 설명"],
  ];

  const startY = 2.7, rowH = 0.95;
  items.forEach(([num, title, desc], i) => {
    const y = startY + i * rowH;
    s.addText(num, {
      x: 0.6, y, w: 1.0, h: rowH - 0.1,
      fontSize: 36, fontFace: F.display, color: C.blue, bold: true, margin: 0,
    });
    s.addText(title, {
      x: 1.7, y: y + 0.05, w: 4.5, h: 0.45,
      fontSize: 20, fontFace: F.display, color: C.ink, bold: true, margin: 0,
    });
    s.addText(desc, {
      x: 1.7, y: y + 0.5, w: 9, h: 0.35,
      fontSize: 14, fontFace: F.text, color: C.inkSoft, margin: 0,
    });
    if (i < items.length - 1) {
      s.addShape(pres.shapes.LINE, {
        x: 0.6, y: y + rowH - 0.05, w: 12.1, h: 0,
        line: { color: C.hairline, width: 0.5 },
      });
    }
  });
  addFooter(s, FOOTER_LEFT, 2);
}

// =========================
// P3. Objectives — 3-Card Goals
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "OBJECTIVES");
  addTitle(s, "이 차시를 마치면");

  const goals = [
    { tag: "GOAL 1", title: "동사 1", desc: "구체적 능력 설명." },
    { tag: "GOAL 2", title: "동사 2", desc: "구체적 능력 설명." },
    { tag: "GOAL 3", title: "동사 3", desc: "구체적 능력 설명." },
  ];

  const cardW = 4.0, gap = 0.25, startX = 0.6, y = 2.6, h = 3.6;
  goals.forEach((g, i) => {
    const x = startX + i * (cardW + gap);
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addText(g.tag, {
      x: x + 0.35, y: y + 0.4, w: cardW - 0.7, h: 0.3,
      fontSize: 11, fontFace: F.text, color: C.blue, bold: true,
      charSpacing: 4, margin: 0,
    });
    s.addText(g.title, {
      x: x + 0.35, y: y + 0.85, w: cardW - 0.7, h: 0.7,
      fontSize: 28, fontFace: F.display, color: C.ink, bold: true, margin: 0,
    });
    s.addShape(pres.shapes.LINE, {
      x: x + 0.35, y: y + 1.7, w: 0.6, h: 0,
      line: { color: C.blue, width: 2 },
    });
    s.addText(g.desc, {
      x: x + 0.35, y: y + 1.95, w: cardW - 0.7, h: 1.4,
      fontSize: 14, fontFace: F.text, color: C.inkSoft, margin: 0, valign: "top",
    });
  });
  addFooter(s, FOOTER_LEFT, 3);
}

// =========================
// P4. Two-Column Comparison (Included vs Excluded)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  적용 영역");
  addTitle(s, "어디에 쓰고, 어디에는 쓰지 않는가");
  addSubtitle(s, "한 줄 설명.");

  const y = 2.85, h = 3.7;

  // LEFT: Included
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.6, y, w: 6.05, h,
    fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
  });
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.6, y, w: 0.08, h,
    fill: { color: C.blue }, line: { color: "FFFFFF", width: 0 },
  });
  s.addText("포함 영역", {
    x: 0.95, y: y + 0.35, w: 5.5, h: 0.5,
    fontSize: 22, fontFace: F.display, color: C.ink, bold: true, margin: 0,
  });
  s.addText("INCLUDED  ·  본 과정 범위", {
    x: 0.95, y: y + 0.85, w: 5.5, h: 0.3,
    fontSize: 11, fontFace: F.text, color: C.blue, bold: true, charSpacing: 3, margin: 0,
  });
  s.addText([
    { text: "포함 항목 1", options: { bullet: { code: "25CF" }, breakLine: true } },
    { text: "포함 항목 2", options: { bullet: { code: "25CF" }, breakLine: true } },
    { text: "포함 항목 3", options: { bullet: { code: "25CF" }, breakLine: true } },
    { text: "포함 항목 4", options: { bullet: { code: "25CF" } } },
  ], {
    x: 0.95, y: y + 1.4, w: 5.5, h: 2.2,
    fontSize: 16, fontFace: F.text, color: C.ink, paraSpaceAfter: 8, margin: 0,
  });

  // RIGHT: Excluded
  s.addShape(pres.shapes.RECTANGLE, {
    x: 6.85, y, w: 6.05, h,
    fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
  });
  s.addShape(pres.shapes.RECTANGLE, {
    x: 6.85, y, w: 0.08, h,
    fill: { color: C.muted }, line: { color: "FFFFFF", width: 0 },
  });
  s.addText("제외 영역", {
    x: 7.2, y: y + 0.35, w: 5.5, h: 0.5,
    fontSize: 22, fontFace: F.display, color: C.ink, bold: true, margin: 0,
  });
  s.addText("EXCLUDED  ·  별도 절차 필요", {
    x: 7.2, y: y + 0.85, w: 5.5, h: 0.3,
    fontSize: 11, fontFace: F.text, color: C.muted, bold: true, charSpacing: 3, margin: 0,
  });
  s.addText([
    { text: "제외 항목 1", options: { bullet: { code: "25CB" }, breakLine: true } },
    { text: "제외 항목 2", options: { bullet: { code: "25CB" }, breakLine: true } },
    { text: "제외 항목 3", options: { bullet: { code: "25CB" }, breakLine: true } },
    { text: "제외 항목 4", options: { bullet: { code: "25CB" } } },
  ], {
    x: 7.2, y: y + 1.4, w: 5.5, h: 2.2,
    fontSize: 16, fontFace: F.text, color: C.muted, paraSpaceAfter: 8, margin: 0,
  });

  addFooter(s, FOOTER_LEFT, 4);
}

// =========================
// P5. Data Table
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  매트릭스");
  addTitle(s, "테이블 페이지 타이틀");
  addSubtitle(s, "한 줄 설명.");

  const tableData = [
    [
      { text: "헤더 1", options: { bold: true, color: C.bg, fill: { color: C.ink }, fontFace: F.text, fontSize: 13 } },
      { text: "헤더 2", options: { bold: true, color: C.bg, fill: { color: C.ink }, fontFace: F.text, fontSize: 13 } },
      { text: "헤더 3", options: { bold: true, color: C.bg, fill: { color: C.ink }, fontFace: F.text, fontSize: 13, align: "center" } },
      { text: "헤더 4", options: { bold: true, color: C.bg, fill: { color: C.ink }, fontFace: F.text, fontSize: 13, align: "center" } },
    ],
    [
      { text: "행 라벨 1", options: { bold: true, color: C.ink } },
      "본문 셀",
      { text: "★★★★★", options: { color: C.blue, align: "center", bold: true } },
      { text: "중간", options: { color: C.inkSoft, align: "center" } },
    ],
    [
      { text: "행 라벨 2", options: { bold: true, color: C.ink } },
      "본문 셀",
      { text: "★★★★☆", options: { color: C.blue, align: "center", bold: true } },
      { text: "중간", options: { color: C.inkSoft, align: "center" } },
    ],
    [
      { text: "행 라벨 3 (강조)", options: { bold: true, color: C.muted } },
      { text: "강조 본문", options: { color: C.muted } },
      { text: "☆☆☆☆☆", options: { color: C.muted, align: "center" } },
      { text: "임계치", options: { color: C.red, align: "center", bold: true } },
    ],
  ];

  s.addTable(tableData, {
    x: 0.6, y: 2.7, w: 12.1, colW: [3.0, 4.6, 2.25, 2.25],
    rowH: 0.5,
    fontSize: 13, fontFace: F.text, color: C.ink,
    border: { type: "solid", pt: 0.5, color: C.hairline },
    valign: "middle",
  });

  s.addText("테이블 아래 강조 한 줄 (italic blue).", {
    x: 0.6, y: 6.55, w: 12.1, h: 0.35,
    fontSize: 13, fontFace: F.text, color: C.blue, italic: true, margin: 0,
  });

  addFooter(s, FOOTER_LEFT, 5);
}

// =========================
// P6. 4-Card Grid (2×2)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  배경");
  addTitle(s, "4-Card 그리드 타이틀");
  addSubtitle(s, "한 줄 설명.");

  const items = [
    { num: "01", title: "카드 1", desc: "한 줄 설명 텍스트." },
    { num: "02", title: "카드 2", desc: "한 줄 설명 텍스트." },
    { num: "03", title: "카드 3", desc: "한 줄 설명 텍스트." },
    { num: "04", title: "카드 4", desc: "한 줄 설명 텍스트." },
  ];

  const cardW = 5.95, cardH = 1.85, gap = 0.25;
  items.forEach((it, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.6 + col * (cardW + gap);
    const y = 2.7 + row * (cardH + gap);

    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: cardH,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addText(it.num, {
      x: x + 0.4, y: y + 0.35, w: 1.0, h: 0.5,
      fontSize: 28, fontFace: F.display, color: C.blue, bold: true, margin: 0,
    });
    s.addText(it.title, {
      x: x + 1.5, y: y + 0.35, w: cardW - 1.7, h: 0.5,
      fontSize: 22, fontFace: F.display, color: C.ink, bold: true, margin: 0, valign: "middle",
    });
    s.addText(it.desc, {
      x: x + 1.5, y: y + 0.95, w: cardW - 1.7, h: 0.85,
      fontSize: 13, fontFace: F.text, color: C.inkSoft, margin: 0, valign: "top",
    });
  });
  addFooter(s, FOOTER_LEFT, 6);
}

// =========================
// P7. Process Pipeline (가로 6단계)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  파이프라인");
  addTitle(s, "6단계 프로세스");
  addSubtitle(s, "한 줄 설명.");

  const steps = [
    { n: "1", t: "단계 1", d: "짧은 설명" },
    { n: "2", t: "단계 2", d: "짧은 설명" },
    { n: "3", t: "단계 3", d: "짧은 설명" },
    { n: "4", t: "단계 4", d: "짧은 설명" },
    { n: "5", t: "검증",   d: "짧은 설명" },
    { n: "6", t: "산출물", d: "짧은 설명" },
  ];

  const startX = 0.6, y = 3.0, w = 1.95, h = 2.2, gap = 0.1;
  steps.forEach((st, i) => {
    const x = startX + i * (w + gap);
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w, h,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addShape(pres.shapes.OVAL, {
      x: x + (w - 0.55) / 2, y: y + 0.3, w: 0.55, h: 0.55,
      fill: { color: i === 4 ? C.orange : (i === 5 ? C.green : C.blue) },
      line: { color: "FFFFFF", width: 0 },
    });
    s.addText(st.n, {
      x: x + (w - 0.55) / 2, y: y + 0.3, w: 0.55, h: 0.55,
      fontSize: 18, fontFace: F.display, color: C.bg, bold: true,
      align: "center", valign: "middle", margin: 0,
    });
    s.addText(st.t, {
      x: x + 0.1, y: y + 1.05, w: w - 0.2, h: 0.45,
      fontSize: 15, fontFace: F.display, color: C.ink, bold: true, align: "center", margin: 0,
    });
    s.addText(st.d, {
      x: x + 0.1, y: y + 1.5, w: w - 0.2, h: 0.65,
      fontSize: 11, fontFace: F.text, color: C.inkSoft, align: "center", margin: 0, valign: "top",
    });
    if (i < steps.length - 1) {
      s.addShape(pres.shapes.RIGHT_TRIANGLE, {
        x: x + w + 0.005, y: y + h / 2 - 0.06, w: 0.09, h: 0.12,
        rotate: 90,
        fill: { color: C.hairline }, line: { color: "FFFFFF", width: 0 },
      });
    }
  });

  s.addText("프로세스 강조 한 줄 (italic blue).", {
    x: 0.6, y: 5.6, w: 12.1, h: 0.4,
    fontSize: 13, fontFace: F.text, color: C.blue, italic: true, margin: 0,
  });
  addFooter(s, FOOTER_LEFT, 7);
}

// =========================
// P8. 4-Card Concept (한 줄 4장 + 상단 액센트 + 예시 박스)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  개념");
  addTitle(s, "4가지 개념 한 줄 정리");
  addSubtitle(s, "X = A + B + C + D. 네 가지를 모두 명시하면 결과가 결정된다.");

  const four = [
    { tag: "TAG A", ko: "한글1", desc: "짧은 한 줄", eg: "예시 한두 줄\n여기" },
    { tag: "TAG B", ko: "한글2", desc: "짧은 한 줄", eg: "예시 한두 줄\n여기" },
    { tag: "TAG C", ko: "한글3", desc: "짧은 한 줄", eg: "예시 한두 줄\n여기" },
    { tag: "TAG D", ko: "한글4", desc: "짧은 한 줄", eg: "예시 한두 줄\n여기" },
  ];

  const cardW = 2.95, cardH = 4.0, gap = 0.15;
  four.forEach((f, i) => {
    const x = 0.6 + i * (cardW + gap);
    const y = 2.55;

    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: cardH,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: 0.08,
      fill: { color: C.blue }, line: { color: "FFFFFF", width: 0 },
    });
    s.addText(f.tag, {
      x: x + 0.3, y: y + 0.35, w: cardW - 0.6, h: 0.3,
      fontSize: 11, fontFace: F.text, color: C.blue, bold: true, charSpacing: 4, margin: 0,
    });
    s.addText(f.ko, {
      x: x + 0.3, y: y + 0.7, w: cardW - 0.6, h: 0.55,
      fontSize: 26, fontFace: F.display, color: C.ink, bold: true, margin: 0,
    });
    s.addText(f.desc, {
      x: x + 0.3, y: y + 1.35, w: cardW - 0.6, h: 0.4,
      fontSize: 14, fontFace: F.text, color: C.inkSoft, margin: 0,
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: x + 0.3, y: y + 1.95, w: cardW - 0.6, h: 1.75,
      fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
    });
    s.addText("예시", {
      x: x + 0.45, y: y + 2.05, w: cardW - 0.9, h: 0.25,
      fontSize: 10, fontFace: F.text, color: C.muted, charSpacing: 3, bold: true, margin: 0,
    });
    s.addText(f.eg, {
      x: x + 0.45, y: y + 2.35, w: cardW - 0.9, h: 1.3,
      fontSize: 12, fontFace: F.text, color: C.ink, margin: 0, valign: "top",
    });
  });
  addFooter(s, FOOTER_LEFT, 8);
}

// =========================
// P9. Chart + KPI Sandwich
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  효과");
  addTitle(s, "차트와 핵심 수치");
  addSubtitle(s, "한 줄 인사이트 설명.");

  s.addChart(pres.charts.BAR, [{
    name: "단축률 (%)",
    labels: ["항목 1", "항목 2", "항목 3", "항목 4"],
    values: [90, 80, 95, 80],
  }], {
    x: 0.6, y: 2.85, w: 7.5, h: 3.8,
    barDir: "bar",
    chartColors: [C.blue],
    chartArea: { fill: { color: C.bg } },
    catAxisLabelFontSize: 11, catAxisLabelColor: C.ink, catAxisLabelFontFace: F.text,
    valAxisLabelFontSize: 10, valAxisLabelColor: C.muted, valAxisLabelFontFace: F.text,
    valGridLine: { color: C.hairline, size: 0.5 },
    catGridLine: { style: "none" },
    showValue: true, dataLabelFormatCode: "0\"%\"",
    dataLabelPosition: "outEnd", dataLabelColor: C.ink,
    dataLabelFontSize: 12, dataLabelFontFace: F.text, dataLabelFontBold: true,
    showLegend: false,
    valAxisMaxVal: 100, valAxisMinVal: 0,
  });

  // Right: KPI summary
  const kx = 8.4, ky = 2.85, kw = 4.3;
  s.addShape(pres.shapes.RECTANGLE, {
    x: kx, y: ky, w: kw, h: 3.8,
    fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
  });
  s.addText("핵심 수치", {
    x: kx + 0.35, y: ky + 0.35, w: kw - 0.7, h: 0.3,
    fontSize: 11, fontFace: F.text, color: C.blue, bold: true, charSpacing: 4, margin: 0,
  });
  s.addText("80~95%", {
    x: kx + 0.35, y: ky + 0.7, w: kw - 0.7, h: 1.0,
    fontSize: 56, fontFace: F.display, color: C.ink, bold: true, margin: 0,
  });
  s.addText("KPI 라벨\n(2줄까지)", {
    x: kx + 0.35, y: ky + 1.85, w: kw - 0.7, h: 0.7,
    fontSize: 14, fontFace: F.text, color: C.inkSoft, margin: 0,
  });
  s.addShape(pres.shapes.LINE, {
    x: kx + 0.35, y: ky + 2.7, w: kw - 0.7, h: 0,
    line: { color: C.hairline, width: 0.5 },
  });
  s.addText("강조 인용 italic 1줄", {
    x: kx + 0.35, y: ky + 2.85, w: kw - 0.7, h: 0.4,
    fontSize: 12, fontFace: F.text, color: C.ink, italic: true, margin: 0,
  });
  s.addText("부가 설명 italic muted", {
    x: kx + 0.35, y: ky + 3.2, w: kw - 0.7, h: 0.4,
    fontSize: 12, fontFace: F.text, color: C.muted, italic: true, margin: 0,
  });
  addFooter(s, FOOTER_LEFT, 9);
}

// =========================
// P10. 3-Card Vertical Split (원인/단계 등)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  원인");
  addTitle(s, "3가지 원인");
  addSubtitle(s, "위험은 정확히 어디서 발생하는가.");

  const items = [
    { num: "01", title: "원인 1", sub: "English Sub", desc: "한 줄 설명 텍스트." },
    { num: "02", title: "원인 2", sub: "English Sub", desc: "한 줄 설명 텍스트." },
    { num: "03", title: "원인 3", sub: "English Sub", desc: "한 줄 설명 텍스트." },
  ];

  const cardW = 4.0, gap = 0.25, y = 2.7, h = 3.7;
  items.forEach((c, i) => {
    const x = 0.6 + i * (cardW + gap);
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addText(c.num, {
      x: x + 0.4, y: y + 0.45, w: cardW - 0.8, h: 0.55,
      fontSize: 32, fontFace: F.display, color: C.red, bold: true, margin: 0,
    });
    s.addText(c.title, {
      x: x + 0.4, y: y + 1.15, w: cardW - 0.8, h: 0.55,
      fontSize: 24, fontFace: F.display, color: C.ink, bold: true, margin: 0,
    });
    s.addText(c.sub, {
      x: x + 0.4, y: y + 1.7, w: cardW - 0.8, h: 0.3,
      fontSize: 12, fontFace: F.text, color: C.muted, italic: true, margin: 0,
    });
    s.addShape(pres.shapes.LINE, {
      x: x + 0.4, y: y + 2.15, w: 0.6, h: 0,
      line: { color: C.red, width: 2 },
    });
    s.addText(c.desc, {
      x: x + 0.4, y: y + 2.4, w: cardW - 0.8, h: 1.2,
      fontSize: 13, fontFace: F.text, color: C.inkSoft, margin: 0, valign: "top",
    });
  });
  addFooter(s, FOOTER_LEFT, 10);
}

// =========================
// P11. 4-Step Decision Flow (체크리스트)
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addEyebrow(s, "MODULE  ·  체크리스트");
  addTitle(s, "4단계 검증");
  addSubtitle(s, "단계별 통과 기준. 한 단계라도 실패하면 반려.");

  const steps = [
    { q: "질문 1?", pass: "다음 단계", fail: "반려 사유 1" },
    { q: "질문 2?", pass: "다음 단계", fail: "반려 사유 2" },
    { q: "질문 3?", pass: "다음 단계", fail: "반려 사유 3" },
    { q: "질문 4?", pass: "승인",       fail: "반려 사유 4" },
  ];

  const y = 2.85;
  steps.forEach((st, i) => {
    const x = 0.6 + i * 3.1;
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 2.85, h: 2.0,
      fill: { color: C.bg },
      line: { color: C.hairline, width: 0.75 },
      shadow: cardShadow(),
    });
    s.addText(`Q${i + 1}`, {
      x: x + 0.25, y: y + 0.25, w: 2.35, h: 0.3,
      fontSize: 11, fontFace: F.text, color: C.blue, bold: true, charSpacing: 4, margin: 0,
    });
    s.addText(st.q, {
      x: x + 0.25, y: y + 0.6, w: 2.35, h: 1.3,
      fontSize: 14, fontFace: F.display, color: C.ink, bold: true, margin: 0, valign: "top",
    });

    s.addShape(pres.shapes.RECTANGLE, {
      x, y: y + 2.15, w: 2.85, h: 0.55,
      fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
    });
    s.addText([
      { text: "✓ ",       options: { color: C.green, bold: true } },
      { text: st.pass,    options: { color: C.ink, bold: true } },
    ], {
      x: x + 0.25, y: y + 2.2, w: 2.35, h: 0.45,
      fontSize: 12, fontFace: F.text, margin: 0, valign: "middle",
    });

    s.addShape(pres.shapes.RECTANGLE, {
      x, y: y + 2.8, w: 2.85, h: 0.55,
      fill: { color: C.surface }, line: { color: "FFFFFF", width: 0 },
    });
    s.addText([
      { text: "✕ ",       options: { color: C.red, bold: true } },
      { text: st.fail,    options: { color: C.inkSoft } },
    ], {
      x: x + 0.25, y: y + 2.85, w: 2.35, h: 0.45,
      fontSize: 12, fontFace: F.text, margin: 0, valign: "middle",
    });

    if (i < steps.length - 1) {
      s.addShape(pres.shapes.RIGHT_TRIANGLE, {
        x: x + 2.88, y: y + 0.95, w: 0.12, h: 0.16,
        rotate: 90,
        fill: { color: C.blue }, line: { color: "FFFFFF", width: 0 },
      });
    }
  });

  s.addText("4단계 모두 통과한 산출물만 외부 공유 가능.", {
    x: 0.6, y: 6.5, w: 12.1, h: 0.4,
    fontSize: 13, fontFace: F.text, color: C.blue, italic: true, margin: 0,
  });
  addFooter(s, FOOTER_LEFT, 11);
}

// =========================
// P12. Big Quote / Closing
// =========================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };

  s.addText("Day X", {
    x: 0.6, y: 2.6, w: 12.1, h: 0.45,
    fontSize: 14, fontFace: F.text, color: C.blue, bold: true, charSpacing: 6, align: "center", margin: 0,
  });
  s.addText("앞 문장 (회색)", {
    x: 0.6, y: 3.1, w: 12.1, h: 0.85,
    fontSize: 40, fontFace: F.display, color: C.inkSoft, align: "center", margin: 0,
  });
  s.addText("뒷 문장 (강조 ink bold)", {
    x: 0.6, y: 3.95, w: 12.1, h: 0.85,
    fontSize: 40, fontFace: F.display, color: C.ink, bold: true, align: "center", margin: 0,
  });

  s.addShape(pres.shapes.LINE, {
    x: 5.65, y: 5.3, w: 2, h: 0,
    line: { color: C.blue, width: 2 },
  });

  s.addText("Thank you", {
    x: 0.6, y: 5.55, w: 12.1, h: 0.5,
    fontSize: 18, fontFace: F.text, color: C.muted, align: "center", margin: 0,
  });

  s.addText("강사명   |   다음 차시 멘트", {
    x: 0.6, y: 6.6, w: 12.1, h: 0.3,
    fontSize: 12, fontFace: F.text, color: C.muted, align: "center", margin: 0,
  });
}

pres.writeFile({ fileName: "apple_white_deck.pptx" })
  .then((file) => console.log("OK:", file));
