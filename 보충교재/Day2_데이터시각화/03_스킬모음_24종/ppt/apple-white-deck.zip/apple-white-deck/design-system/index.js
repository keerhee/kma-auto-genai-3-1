// =============================================================
// Apple White Deck — Design System
// 한 번의 require()로 토큰·헬퍼·컴포넌트·패턴을 모두 사용 가능.
//
// 사용법:
//   const ds = require("./design-system");
//   ds.tokens.colors.blue        // → "0071E3"
//   ds.helpers.addEyebrow(...)
//   ds.components.Card(...)
//   ds.patterns.cover(pres, {...})
// =============================================================

const tokens     = require("./tokens");
const helpers    = require("./helpers");
const components = require("./components");
const patterns   = require("./patterns");

module.exports = {
  tokens,
  helpers,
  components,
  patterns,

  // 자주 쓰는 토큰은 최상위에 alias로도 노출
  C: tokens.colors,
  F: tokens.fonts,
  L: tokens.layout,
};
