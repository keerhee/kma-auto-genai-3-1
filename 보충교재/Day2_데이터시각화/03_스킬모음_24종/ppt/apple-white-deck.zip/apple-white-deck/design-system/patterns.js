// =============================================================
// Patterns — 12개 슬라이드 패턴 함수
// 각 패턴은 pres.addSlide()를 내부에서 호출하고 slide를 반환한다.
// 사용자는 ds.patterns.cover({...}) 한 줄로 슬라이드를 추가할 수 있다.
//
// 모든 패턴은 다음 공통 옵션을 받는다:
//   - footerText: footer 좌측 텍스트 (선택)
//   - page: 페이지 번호 (선택)
// =============================================================

const T = require("./tokens");
const H = require("./helpers");
const C = require("./components");

// =========================================================
// P1. cover — 표지
//
// opts:
//   - eyebrow: "Course 2-1  ·  Day 1"
//   - title: "자동차 AI 현황 &" | ["1줄", "2줄"]
//   - subtitle: 한 줄 부제
//   - metaLeft: "이론 3H  ·  실습 5H  ·  오프라인"
//   - metaRight: "강사명   |   2026"
// =========================================================
function cover(pres, opts) {
  const slide = H.setupSlide(pres);

  if (opts.eyebrow) {
    slide.addText(opts.eyebrow, {
      x: T.layout.marginX, y: 2.5, w: T.layout.contentW, h: 0.4,
      fontSize: 14, fontFace: T.fonts.text,
      color: T.colors.blue, bold: true,
      charSpacing: T.charSpacing.coverEye, margin: 0,
    });
  }

  // 제목은 문자열 또는 배열 모두 허용
  const titles = Array.isArray(opts.title) ? opts.title : [opts.title];
  let titleY = 2.95;
  titles.forEach((line) => {
    slide.addText(line, {
      x: T.layout.marginX, y: titleY, w: T.layout.contentW, h: 1.1,
      fontSize: T.fontSize.coverTitle,
      fontFace: T.fonts.display,
      color: T.colors.ink, bold: true,
      margin: 0, valign: "top",
    });
    titleY += 1.05;
  });

  if (opts.subtitle) {
    slide.addText(opts.subtitle, {
      x: T.layout.marginX, y: titleY + 0.05, w: T.layout.contentW, h: 0.4,
      fontSize: 18, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0,
    });
  }

  H.addHairline(slide, { y: 6.4 });
  if (opts.metaLeft) {
    slide.addText(opts.metaLeft, {
      x: T.layout.marginX, y: 6.55, w: 8, h: 0.3,
      fontSize: 12, fontFace: T.fonts.text,
      color: T.colors.muted, margin: 0,
    });
  }
  if (opts.metaRight) {
    slide.addText(opts.metaRight, {
      x: 8.6, y: 6.55, w: 4.1, h: 0.3,
      fontSize: 12, fontFace: T.fonts.text,
      color: T.colors.muted, align: "right", margin: 0,
    });
  }

  return slide;
}

// =========================================================
// P2. agenda — 큰 번호 + 타이틀 + 한 줄 설명, 항목 사이 hairline
//
// opts:
//   - eyebrow, title, subtitle
//   - items: [{num, title, desc}, ...] (4개 권장)
// =========================================================
function agenda(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const startY = 2.7, rowH = 0.95;
  opts.items.forEach((item, i) => {
    const y = startY + i * rowH;
    slide.addText(item.num, {
      x: T.layout.marginX, y, w: 1.0, h: rowH - 0.1,
      fontSize: 36, fontFace: T.fonts.display,
      color: T.colors.blue, bold: true, margin: 0,
    });
    slide.addText(item.title, {
      x: 1.7, y: y + 0.05, w: 4.5, h: 0.45,
      fontSize: 20, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0,
    });
    slide.addText(item.desc, {
      x: 1.7, y: y + 0.5, w: 9, h: 0.35,
      fontSize: T.fontSize.cardBody, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0,
    });
    if (i < opts.items.length - 1) {
      H.addHairline(slide, { y: y + rowH - 0.05, width: 0.5 });
    }
  });
  return slide;
}

// =========================================================
// P3. objectives — 3-Card 목표 (큰 동사 + 짧은 설명)
//
// opts:
//   - eyebrow, title
//   - goals: [{tag, title, desc}, ...] (정확히 3개)
// =========================================================
function objectives(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);

  const cardW = 4.0, gap = 0.25, y = 2.6, h = 3.6;
  opts.goals.forEach((g, i) => {
    const x = T.layout.marginX + i * (cardW + gap);
    C.Card(slide, { x, y, w: cardW, h });
    C.Badge(slide, { x: x + 0.35, y: y + 0.4, w: cardW - 0.7, text: g.tag });
    slide.addText(g.title, {
      x: x + 0.35, y: y + 0.85, w: cardW - 0.7, h: 0.7,
      fontSize: T.fontSize.cardHeadXL, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0,
    });
    C.AccentLine(slide, { x: x + 0.35, y: y + 1.7 });
    slide.addText(g.desc, {
      x: x + 0.35, y: y + 1.95, w: cardW - 0.7, h: 1.4,
      fontSize: T.fontSize.cardBody, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0, valign: "top",
    });
  });
  return slide;
}

// =========================================================
// P4. comparison — 좌우 2분할 (Included vs Excluded)
//
// opts:
//   - eyebrow, title, subtitle
//   - left: {title, badge, items[]}
//   - right: {title, badge, items[]}
// =========================================================
function comparison(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const y = 2.85, h = 3.7;

  function panel(x, panelOpts, accentColor, bulletFilled, textColor) {
    C.SurfaceBox(slide, { x, y, w: 6.05, h });
    C.AccentBar(slide, { x, y, cardW: 6.05, cardH: h, color: accentColor });
    slide.addText(panelOpts.title, {
      x: x + 0.35, y: y + 0.35, w: 5.5, h: 0.5,
      fontSize: T.fontSize.cardHead, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0,
    });
    if (panelOpts.badge) {
      slide.addText(panelOpts.badge, {
        x: x + 0.35, y: y + 0.85, w: 5.5, h: 0.3,
        fontSize: T.fontSize.eyebrow, fontFace: T.fonts.text,
        color: accentColor, bold: true,
        charSpacing: T.charSpacing.badge, margin: 0,
      });
    }
    C.BulletList(slide, {
      x: x + 0.35, y: y + 1.4, w: 5.5, h: 2.2,
      items: panelOpts.items,
      filled: bulletFilled,
      color: textColor,
    });
  }

  panel(T.layout.marginX, opts.left, T.colors.blue, true, T.colors.ink);
  panel(6.85, opts.right, T.colors.muted, false, T.colors.muted);

  return slide;
}

// =========================================================
// P5. dataTable — 헤더 + 본문 테이블
//
// opts:
//   - eyebrow, title, subtitle, callout
//   - headers: string[]
//   - rows: Array<Array<string | {text, color?, bold?, align?}>>
//   - colW: number[]
// =========================================================
function dataTable(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  // 헤더 행: ink 배경 + 흰 글씨
  const headerRow = opts.headers.map((h, i) => ({
    text: h,
    options: {
      bold: true, color: T.colors.bg,
      fill: { color: T.colors.ink },
      fontFace: T.fonts.text, fontSize: 13,
      align: i >= 2 ? "center" : "left",
    },
  }));

  // 본문 행 정규화
  const bodyRows = opts.rows.map((row) =>
    row.map((cell) => {
      if (typeof cell === "string") return cell;
      return {
        text: cell.text,
        options: {
          color: cell.color ?? T.colors.ink,
          bold: cell.bold ?? false,
          align: cell.align ?? "left",
        },
      };
    }),
  );

  slide.addTable([headerRow, ...bodyRows], {
    x: T.layout.marginX, y: 2.7, w: T.layout.contentW,
    colW: opts.colW,
    rowH: opts.rowH ?? 0.5,
    fontSize: 13, fontFace: T.fonts.text, color: T.colors.ink,
    border: { type: "solid", pt: 0.5, color: T.colors.hairline },
    valign: "middle",
  });

  if (opts.callout) H.addCallout(slide, opts.callout, { y: 6.55 });
  return slide;
}

// =========================================================
// P6. fourCardGrid — 2x2 그리드 (큰 번호 + 타이틀 + 본문)
//
// opts:
//   - eyebrow, title, subtitle
//   - items: [{num, title, desc}, ...] (4개)
// =========================================================
function fourCardGrid(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const cardW = 5.95, cardH = 1.85, gap = 0.25;
  opts.items.forEach((it, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = T.layout.marginX + col * (cardW + gap);
    const y = 2.7 + row * (cardH + gap);
    C.Card(slide, { x, y, w: cardW, h: cardH });
    slide.addText(it.num, {
      x: x + 0.4, y: y + 0.35, w: 1.0, h: 0.5,
      fontSize: T.fontSize.cardHeadXL, fontFace: T.fonts.display,
      color: T.colors.blue, bold: true, margin: 0,
    });
    slide.addText(it.title, {
      x: x + 1.5, y: y + 0.35, w: cardW - 1.7, h: 0.5,
      fontSize: T.fontSize.cardHead, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0, valign: "middle",
    });
    slide.addText(it.desc, {
      x: x + 1.5, y: y + 0.95, w: cardW - 1.7, h: 0.85,
      fontSize: T.fontSize.cardBodySm, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0, valign: "top",
    });
  });
  return slide;
}

// =========================================================
// P7. pipeline — 가로 N단계 프로세스 (3-6단계 권장)
//
// opts:
//   - eyebrow, title, subtitle, callout
//   - steps: [{n, t, d, color?}, ...]
//     color는 NumberCircle 색 (default: blue)
// =========================================================
function pipeline(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const steps = opts.steps;
  const n = steps.length;
  const totalW = T.layout.contentW;
  const gap = 0.1;
  const w = (totalW - gap * (n - 1)) / n;
  const y = 3.0, h = 2.2;

  steps.forEach((st, i) => {
    const x = T.layout.marginX + i * (w + gap);
    C.Card(slide, { x, y, w, h });
    C.NumberCircle(slide, {
      x: x + (w - 0.55) / 2, y: y + 0.3,
      num: st.n, color: st.color ?? T.colors.blue,
    });
    slide.addText(st.t, {
      x: x + 0.1, y: y + 1.05, w: w - 0.2, h: 0.45,
      fontSize: 15, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, align: "center", margin: 0,
    });
    slide.addText(st.d, {
      x: x + 0.1, y: y + 1.5, w: w - 0.2, h: 0.65,
      fontSize: 11, fontFace: T.fonts.text,
      color: T.colors.inkSoft, align: "center", margin: 0, valign: "top",
    });
    if (i < n - 1) {
      C.ConnectorArrow(slide, {
        x: x + w + 0.005, y: y + h / 2 - 0.06, size: 0.09,
      });
    }
  });

  if (opts.callout) H.addCallout(slide, opts.callout, { y: 5.6 });
  return slide;
}

// =========================================================
// P8. fourCardConcept — 한 줄 4카드 (상단 액센트 + 예시 박스)
//
// opts:
//   - eyebrow, title, subtitle
//   - items: [{tag, ko, desc, eg}, ...] (4개)
// =========================================================
function fourCardConcept(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const cardW = 2.95, cardH = 4.0, gap = 0.15;
  opts.items.forEach((f, i) => {
    const x = T.layout.marginX + i * (cardW + gap);
    const y = 2.55;
    C.Card(slide, { x, y, w: cardW, h: cardH });
    C.AccentBar(slide, { x, y, cardW, cardH, position: "top" });
    C.Badge(slide, { x: x + 0.3, y: y + 0.35, w: cardW - 0.6, text: f.tag });
    slide.addText(f.ko, {
      x: x + 0.3, y: y + 0.7, w: cardW - 0.6, h: 0.55,
      fontSize: 26, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0,
    });
    slide.addText(f.desc, {
      x: x + 0.3, y: y + 1.35, w: cardW - 0.6, h: 0.4,
      fontSize: T.fontSize.cardBody, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0,
    });
    C.SurfaceBox(slide, { x: x + 0.3, y: y + 1.95, w: cardW - 0.6, h: 1.75 });
    slide.addText("예시", {
      x: x + 0.45, y: y + 2.05, w: cardW - 0.9, h: 0.25,
      fontSize: 10, fontFace: T.fonts.text,
      color: T.colors.muted, charSpacing: 3, bold: true, margin: 0,
    });
    slide.addText(f.eg, {
      x: x + 0.45, y: y + 2.35, w: cardW - 0.9, h: 1.3,
      fontSize: 12, fontFace: T.fonts.text,
      color: T.colors.ink, margin: 0, valign: "top",
    });
  });
  return slide;
}

// =========================================================
// P9. chartKpi — 차트 + KPI 사이드바
//
// opts:
//   - eyebrow, title, subtitle
//   - chart: {type, data, options} — pptxgenjs 차트 설정
//     type: "BAR" | "LINE" | "COLUMN" 등
//   - kpi: {eyebrow, value, label, calloutTop, calloutBottom}
// =========================================================
function chartKpi(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  // 차트 (좌측 70%) — 사용자가 chartType과 data만 넘기면 톤은 자동 적용
  const chartType = opts.chart.type || "BAR";
  const defaultChartOpts = {
    x: T.layout.marginX, y: 2.85, w: 7.5, h: 3.8,
    barDir: "bar",
    chartColors: [T.colors.blue],
    chartArea: { fill: { color: T.colors.bg } },
    catAxisLabelFontSize: 11,
    catAxisLabelColor: T.colors.ink,
    catAxisLabelFontFace: T.fonts.text,
    valAxisLabelFontSize: 10,
    valAxisLabelColor: T.colors.muted,
    valAxisLabelFontFace: T.fonts.text,
    valGridLine: { color: T.colors.hairline, size: 0.5 },
    catGridLine: { style: "none" },
    showValue: true,
    dataLabelPosition: "outEnd",
    dataLabelColor: T.colors.ink,
    dataLabelFontSize: 12,
    dataLabelFontFace: T.fonts.text,
    dataLabelFontBold: true,
    showLegend: false,
  };

  // pres.charts 동적 접근 — chartType이 "BAR"면 pres.charts.BAR
  // pres가 patterns에 직접 노출되지 않으므로 type 문자열을 그대로 전달
  // pptxgenjs는 type을 문자열로도 받는다 ("bar", "line", ...)
  const chartTypeKey = chartType.toLowerCase();
  slide.addChart(chartTypeKey, opts.chart.data, {
    ...defaultChartOpts,
    ...(opts.chart.options || {}),
  });

  // KPI 박스 (우측 30%)
  const kx = 8.4, ky = 2.85, kw = 4.3;
  C.SurfaceBox(slide, { x: kx, y: ky, w: kw, h: 3.8 });
  C.BigStat(slide, {
    x: kx + 0.35, y: ky + 0.35, w: kw - 0.7,
    eyebrow: opts.kpi.eyebrow,
    value: opts.kpi.value,
    label: opts.kpi.label,
  });
  if (opts.kpi.calloutTop || opts.kpi.calloutBottom) {
    H.addHairline(slide, { x: kx + 0.35, y: ky + 2.7, w: kw - 0.7, width: 0.5 });
    if (opts.kpi.calloutTop) {
      slide.addText(opts.kpi.calloutTop, {
        x: kx + 0.35, y: ky + 2.85, w: kw - 0.7, h: 0.4,
        fontSize: 12, fontFace: T.fonts.text,
        color: T.colors.ink, italic: true, margin: 0,
      });
    }
    if (opts.kpi.calloutBottom) {
      slide.addText(opts.kpi.calloutBottom, {
        x: kx + 0.35, y: ky + 3.2, w: kw - 0.7, h: 0.4,
        fontSize: 12, fontFace: T.fonts.text,
        color: T.colors.muted, italic: true, margin: 0,
      });
    }
  }

  return slide;
}

// =========================================================
// P10. threeCardCause — 3개 카드 (큰 번호 + 영문 부제 + 액센트 라인)
//
// opts:
//   - eyebrow, title, subtitle
//   - items: [{num, title, sub, desc}, ...] (3개)
//   - accentColor (default: red)
// =========================================================
function threeCardCause(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const accent = opts.accentColor ?? T.colors.red;
  const cardW = 4.0, gap = 0.25, y = 2.7, h = 3.7;
  opts.items.forEach((c, i) => {
    const x = T.layout.marginX + i * (cardW + gap);
    C.Card(slide, { x, y, w: cardW, h });
    slide.addText(c.num, {
      x: x + 0.4, y: y + 0.45, w: cardW - 0.8, h: 0.55,
      fontSize: 32, fontFace: T.fonts.display,
      color: accent, bold: true, margin: 0,
    });
    slide.addText(c.title, {
      x: x + 0.4, y: y + 1.15, w: cardW - 0.8, h: 0.55,
      fontSize: 24, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0,
    });
    if (c.sub) {
      slide.addText(c.sub, {
        x: x + 0.4, y: y + 1.7, w: cardW - 0.8, h: 0.3,
        fontSize: 12, fontFace: T.fonts.text,
        color: T.colors.muted, italic: true, margin: 0,
      });
    }
    C.AccentLine(slide, { x: x + 0.4, y: y + 2.15, color: accent });
    slide.addText(c.desc, {
      x: x + 0.4, y: y + 2.4, w: cardW - 0.8, h: 1.2,
      fontSize: T.fontSize.cardBodySm, fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0, valign: "top",
    });
  });
  return slide;
}

// =========================================================
// P11. decisionFlow — 4단계 체크리스트 (Q+pass+fail)
//
// opts:
//   - eyebrow, title, subtitle, callout
//   - steps: [{q, pass, fail}, ...] (4개 권장)
// =========================================================
function decisionFlow(pres, opts) {
  const slide = H.setupSlide(pres, opts);
  if (opts.eyebrow) H.addEyebrow(slide, opts.eyebrow);
  H.addTitle(slide, opts.title);
  if (opts.subtitle) H.addSubtitle(slide, opts.subtitle);

  const y = 2.85;
  const cardW = 2.85, cardH = 2.0;
  opts.steps.forEach((st, i) => {
    const x = T.layout.marginX + i * (cardW + 0.25);
    C.Card(slide, { x, y, w: cardW, h: cardH });
    C.Badge(slide, { x: x + 0.25, y: y + 0.25, w: cardW - 0.5, text: `Q${i + 1}` });
    slide.addText(st.q, {
      x: x + 0.25, y: y + 0.6, w: cardW - 0.5, h: 1.3,
      fontSize: T.fontSize.cardBody, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, margin: 0, valign: "top",
    });

    // pass row
    C.SurfaceBox(slide, { x, y: y + 2.15, w: cardW, h: 0.55 });
    slide.addText([
      { text: "✓ ",    options: { color: T.colors.green, bold: true } },
      { text: st.pass, options: { color: T.colors.ink, bold: true } },
    ], {
      x: x + 0.25, y: y + 2.2, w: cardW - 0.5, h: 0.45,
      fontSize: 12, fontFace: T.fonts.text, margin: 0, valign: "middle",
    });

    // fail row
    C.SurfaceBox(slide, { x, y: y + 2.8, w: cardW, h: 0.55 });
    slide.addText([
      { text: "✕ ",    options: { color: T.colors.red, bold: true } },
      { text: st.fail, options: { color: T.colors.inkSoft } },
    ], {
      x: x + 0.25, y: y + 2.85, w: cardW - 0.5, h: 0.45,
      fontSize: 12, fontFace: T.fonts.text, margin: 0, valign: "middle",
    });

    if (i < opts.steps.length - 1) {
      C.ConnectorArrow(slide, {
        x: x + cardW + 0.03, y: y + 0.95, size: 0.12, color: T.colors.blue,
      });
    }
  });

  if (opts.callout) H.addCallout(slide, opts.callout, { y: 6.5 });
  return slide;
}

// =========================================================
// P12. closing — 큰 인용 + Thank you
//
// opts:
//   - eyebrow: "Day 1" 같은 작은 라벨 (선택)
//   - softLine: 회색 첫 문장
//   - boldLine: 굵은 강조 문장
//   - thanks: "Thank you" (default)
//   - signature: "강사명 | 다음 차시 멘트" (선택)
// =========================================================
function closing(pres, opts) {
  const slide = H.setupSlide(pres);

  if (opts.eyebrow) {
    slide.addText(opts.eyebrow, {
      x: T.layout.marginX, y: 2.6, w: T.layout.contentW, h: 0.45,
      fontSize: 14, fontFace: T.fonts.text,
      color: T.colors.blue, bold: true,
      charSpacing: T.charSpacing.coverEye,
      align: "center", margin: 0,
    });
  }
  if (opts.softLine) {
    slide.addText(opts.softLine, {
      x: T.layout.marginX, y: 3.1, w: T.layout.contentW, h: 0.85,
      fontSize: 40, fontFace: T.fonts.display,
      color: T.colors.inkSoft, align: "center", margin: 0,
    });
  }
  if (opts.boldLine) {
    slide.addText(opts.boldLine, {
      x: T.layout.marginX, y: 3.95, w: T.layout.contentW, h: 0.85,
      fontSize: 40, fontFace: T.fonts.display,
      color: T.colors.ink, bold: true, align: "center", margin: 0,
    });
  }

  slide.addShape("line", {
    x: 5.65, y: 5.3, w: 2, h: 0,
    line: { color: T.colors.blue, width: 2 },
  });

  slide.addText(opts.thanks ?? "Thank you", {
    x: T.layout.marginX, y: 5.55, w: T.layout.contentW, h: 0.5,
    fontSize: 18, fontFace: T.fonts.text,
    color: T.colors.muted, align: "center", margin: 0,
  });

  if (opts.signature) {
    slide.addText(opts.signature, {
      x: T.layout.marginX, y: 6.6, w: T.layout.contentW, h: 0.3,
      fontSize: 12, fontFace: T.fonts.text,
      color: T.colors.muted, align: "center", margin: 0,
    });
  }

  return slide;
}

module.exports = {
  cover,
  agenda,
  objectives,
  comparison,
  dataTable,
  fourCardGrid,
  pipeline,
  fourCardConcept,
  chartKpi,
  threeCardCause,
  decisionFlow,
  closing,
};
