// =============================================================
// Apple White Deck — Design Tokens
// 모든 시각 결정의 단일 진실 공급원 (Single Source of Truth).
// 이 파일을 바꾸면 전체 덱의 톤이 일관되게 바뀐다.
// =============================================================

// ---------- 컬러 ----------
const colors = {
  bg:       "FFFFFF",  // pure white — 절대 beige/cream 금지
  ink:      "1D1D1F",  // Apple graphite (제목·본문)
  inkSoft:  "424245",  // secondary text (subtitle)
  muted:    "86868B",  // tertiary · caption · footer
  hairline: "D2D2D7",  // dividers · card borders
  surface:  "F5F5F7",  // subtle card fill (요약/예시 박스)

  // 액센트
  blue:     "0071E3",  // PRIMARY — Apple action blue
  blueDeep: "0040DD",
  green:    "30D158",  // 긍정/완료
  orange:   "FF9F0A",  // 주의/중간 단계
  red:      "FF3B30",  // 경고/금지
  purple:   "AF52DE",
};

// ---------- 폰트 ----------
const fonts = {
  display:  "SF Pro Display",   // 제목
  text:     "SF Pro Text",      // 본문
  fallback: "Helvetica Neue",
};

// ---------- 폰트 크기 (LAYOUT_WIDE 기준) ----------
const fontSize = {
  coverTitle:    54,  // 표지 메인
  pageTitle:     36,  // 페이지 타이틀
  subtitle:      16,  // 페이지 부제
  eyebrow:       11,  // 섹션 라벨
  cardHeadXL:    28,  // 카드 큰 헤드 (3-Card Goals)
  cardHead:      22,  // 카드 헤드 (4-Card Grid)
  cardBody:      14,  // 카드 본문
  cardBodySm:    13,  // 카드 작은 본문
  bigStat:       56,  // 큰 숫자
  footer:        10,
  bullet:        16,
  italic:        13,  // 강조 인용 (italic blue)
};

// ---------- 레이아웃 (LAYOUT_WIDE: 13.3" × 7.5") ----------
const layout = {
  slideW:        13.3,
  slideH:        7.5,
  marginX:       0.6,    // 좌우 마진
  contentW:      12.1,   // 본문 너비 (slideW - 2*marginX)

  // 표준 Y 좌표
  eyebrowY:      0.5,
  titleY:        0.9,
  titleH:        0.95,
  subtitleY:     1.85,
  subtitleH:     0.5,
  bodyStartY:    2.55,    // subtitle 없을 때 본문 시작
  bodyStartYSub: 2.7,     // subtitle 있을 때 본문 시작
  footerY:       7.05,
  bodyMaxY:      6.7,     // 본문이 차지할 수 있는 최대 y (footer 침범 방지)
};

// ---------- 자간 ----------
const charSpacing = {
  eyebrow:    4,
  coverEye:   6,
  badge:      3,
};

// ---------- 그림자 ----------
// ⚠️ pptxgenjs는 shadow 객체를 in-place mutate한다.
// 따라서 매번 새 객체를 반환하는 함수 형태여야 한다.
const cardShadow = () => ({
  type: "outer", color: "000000", blur: 16, offset: 3, angle: 90, opacity: 0.06,
});

// ---------- bullet 코드 ----------
const bullet = {
  filled: "25CF",   // ● 채워진 원 — 포함/긍정
  empty:  "25CB",   // ○ 빈 원 — 제외/제한
};

module.exports = {
  colors,
  fonts,
  fontSize,
  layout,
  charSpacing,
  cardShadow,
  bullet,
};
