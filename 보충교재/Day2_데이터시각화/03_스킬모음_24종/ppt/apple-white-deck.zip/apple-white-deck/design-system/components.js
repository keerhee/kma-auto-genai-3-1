// =============================================================
// Components — 재사용 가능한 시각 컴포넌트
// 패턴 함수들이 내부적으로 호출하지만, 사용자도 직접 호출 가능.
// =============================================================

const T = require("./tokens");

/**
 * Card — 기본 흰색 카드 (hairline border + subtle shadow).
 *
 * @param {Object} opts
 *   - x, y, w, h (필수)
 *   - fill (default: bg) — 배경색 hex
 *   - border (default: hairline) — 보더색 hex, "none"이면 보더 제거
 *   - shadow (default: true) — 그림자 여부
 */
function Card(slide, opts) {
  const fill = opts.fill ?? T.colors.bg;
  const borderColor = opts.border === "none" ? "FFFFFF" : (opts.border ?? T.colors.hairline);
  const borderWidth = opts.border === "none" ? 0 : 0.75;

  const shapeOpts = {
    x: opts.x, y: opts.y, w: opts.w, h: opts.h,
    fill: { color: fill },
    line: { color: borderColor, width: borderWidth },
  };
  if (opts.shadow !== false) {
    shapeOpts.shadow = T.cardShadow();
  }
  slide.addShape("rect", shapeOpts);
}

/**
 * SurfaceBox — 회색 surface(F5F5F7) 박스 (보더 없음).
 * 요약/예시/하이라이트 박스에 사용.
 */
function SurfaceBox(slide, opts) {
  slide.addShape("rect", {
    x: opts.x, y: opts.y, w: opts.w, h: opts.h,
    fill: { color: opts.fill ?? T.colors.surface },
    line: { color: "FFFFFF", width: 0 },
  });
}

/**
 * AccentBar — 카드 좌측/상단 0.08" 컬러 액센트 바.
 *
 * @param {Object} opts
 *   - x, y, cardW, cardH
 *   - position: "left" | "top" (default: "left")
 *   - color (default: blue)
 */
function AccentBar(slide, opts) {
  const pos = opts.position ?? "left";
  const color = opts.color ?? T.colors.blue;
  const w = pos === "left" ? 0.08 : opts.cardW;
  const h = pos === "left" ? opts.cardH : 0.08;
  slide.addShape("rect", {
    x: opts.x, y: opts.y, w, h,
    fill: { color }, line: { color: "FFFFFF", width: 0 },
  });
}

/**
 * NumberCircle — 색깔 원 안에 흰색 숫자.
 * 프로세스 단계, 카드 번호 등에 사용.
 *
 * @param {Object} opts
 *   - x, y (원 좌상단)
 *   - size (default: 0.55)
 *   - num (string)
 *   - color (default: blue)
 *   - fontSize (default: 18)
 */
function NumberCircle(slide, opts) {
  const size = opts.size ?? 0.55;
  const color = opts.color ?? T.colors.blue;
  slide.addShape("ellipse", {
    x: opts.x, y: opts.y, w: size, h: size,
    fill: { color }, line: { color: "FFFFFF", width: 0 },
  });
  slide.addText(`${opts.num}`, {
    x: opts.x, y: opts.y, w: size, h: size,
    fontSize: opts.fontSize ?? 18,
    fontFace: T.fonts.display,
    color: T.colors.bg,
    bold: true,
    align: "center", valign: "middle", margin: 0,
  });
}

/**
 * Badge — 색깔 라벨 (eyebrow보다 작고 카드 내부에서 쓰임).
 */
function Badge(slide, opts) {
  slide.addText(opts.text, {
    x: opts.x, y: opts.y, w: opts.w, h: opts.h ?? 0.3,
    fontSize: T.fontSize.eyebrow,
    fontFace: T.fonts.text,
    color: opts.color ?? T.colors.blue,
    bold: true,
    charSpacing: T.charSpacing.eyebrow,
    margin: 0,
  });
}

/**
 * AccentLine — 짧은 강조 라인 (보통 0.6" 길이, 카드 안 헤드라인 아래).
 */
function AccentLine(slide, opts) {
  slide.addShape("line", {
    x: opts.x, y: opts.y, w: opts.w ?? 0.6, h: 0,
    line: { color: opts.color ?? T.colors.blue, width: opts.width ?? 2 },
  });
}

/**
 * ConnectorArrow — 카드 사이 작은 화살표 (오른쪽 방향).
 * 프로세스 파이프라인, 결정 플로우에 사용.
 */
function ConnectorArrow(slide, opts) {
  slide.addShape("rtTriangle", {
    x: opts.x, y: opts.y,
    w: opts.size ?? 0.12, h: (opts.size ?? 0.12) * 1.33,
    rotate: 90,
    fill: { color: opts.color ?? T.colors.hairline },
    line: { color: "FFFFFF", width: 0 },
  });
}

/**
 * BigStat — 큰 숫자 + 라벨 한 세트 (예: "80~95%" + "리서치 시간 단축률").
 *
 * @param {Object} opts
 *   - x, y, w (필수)
 *   - eyebrow (선택) — 위쪽 작은 블루 라벨
 *   - value — 큰 숫자
 *   - label — 아래 설명 (2줄 가능)
 *   - valueSize (default: 56) — 큰 숫자 폰트 크기
 */
function BigStat(slide, opts) {
  const valueSize = opts.valueSize ?? T.fontSize.bigStat;
  // value 영역 높이는 폰트 크기에 비례 (1pt ≈ 1/72 inch, 한글 line-height ≈ 1.4)
  const valueH = (valueSize / 72) * 1.4;

  let curY = opts.y;
  if (opts.eyebrow) {
    slide.addText(opts.eyebrow, {
      x: opts.x, y: curY, w: opts.w, h: 0.3,
      fontSize: T.fontSize.eyebrow,
      fontFace: T.fonts.text,
      color: T.colors.blue, bold: true,
      charSpacing: T.charSpacing.eyebrow, margin: 0,
    });
    curY += 0.35;
  }
  slide.addText(opts.value, {
    x: opts.x, y: curY, w: opts.w, h: valueH,
    fontSize: valueSize,
    fontFace: T.fonts.display,
    color: T.colors.ink, bold: true, margin: 0,
  });
  curY += valueH + 0.1;

  if (opts.label) {
    slide.addText(opts.label, {
      x: opts.x, y: curY, w: opts.w, h: 0.7,
      fontSize: T.fontSize.cardBody,
      fontFace: T.fonts.text,
      color: T.colors.inkSoft, margin: 0,
    });
  }
}

/**
 * BulletList — 채워진 원 또는 빈 원 bullet 리스트.
 *
 * @param {Object} opts
 *   - x, y, w, h
 *   - items: string[]
 *   - filled (default: true) — true면 ●, false면 ○
 *   - color (default: ink)
 *   - fontSize (default: 16)
 */
function BulletList(slide, opts) {
  const code = opts.filled === false ? T.bullet.empty : T.bullet.filled;
  const color = opts.color ?? T.colors.ink;
  const items = opts.items.map((text, i) => ({
    text,
    options: i < opts.items.length - 1
      ? { bullet: { code }, breakLine: true }
      : { bullet: { code } },
  }));
  slide.addText(items, {
    x: opts.x, y: opts.y, w: opts.w, h: opts.h,
    fontSize: opts.fontSize ?? T.fontSize.bullet,
    fontFace: T.fonts.text,
    color,
    paraSpaceAfter: 8,
    margin: 0,
  });
}

module.exports = {
  Card,
  SurfaceBox,
  AccentBar,
  NumberCircle,
  Badge,
  AccentLine,
  ConnectorArrow,
  BigStat,
  BulletList,
};
