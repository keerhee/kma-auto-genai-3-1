// =============================================================
// Helpers — 가장 자주 쓰는 텍스트 추가 함수들
// =============================================================

const T = require("./tokens");

/**
 * Eyebrow — 섹션 라벨 (블루, 자간 넓게).
 * 보통 페이지 타이틀 위에 둔다.
 */
function addEyebrow(slide, text, opts = {}) {
  slide.addText(text, {
    x: opts.x ?? T.layout.marginX,
    y: opts.y ?? T.layout.eyebrowY,
    w: opts.w ?? 6,
    h: 0.3,
    fontSize: T.fontSize.eyebrow,
    fontFace: T.fonts.text,
    color: opts.color ?? T.colors.blue,
    bold: true,
    charSpacing: T.charSpacing.eyebrow,
    margin: 0,
  });
}

/**
 * 페이지 타이틀 (36pt bold, ink).
 */
function addTitle(slide, text, opts = {}) {
  slide.addText(text, {
    x: T.layout.marginX,
    y: opts.y ?? T.layout.titleY,
    w: T.layout.contentW,
    h: opts.h ?? T.layout.titleH,
    fontSize: opts.size ?? T.fontSize.pageTitle,
    fontFace: T.fonts.display,
    color: T.colors.ink,
    bold: true,
    margin: 0,
    valign: "top",
  });
}

/**
 * 페이지 부제 (16pt, inkSoft).
 */
function addSubtitle(slide, text, opts = {}) {
  slide.addText(text, {
    x: T.layout.marginX,
    y: opts.y ?? T.layout.subtitleY,
    w: T.layout.contentW,
    h: T.layout.subtitleH,
    fontSize: T.fontSize.subtitle,
    fontFace: T.fonts.text,
    color: T.colors.inkSoft,
    margin: 0,
  });
}

/**
 * Footer — 좌측 라벨 + 우측 페이지 번호.
 */
function addFooter(slide, leftText, page) {
  slide.addText(leftText, {
    x: T.layout.marginX,
    y: T.layout.footerY,
    w: 8, h: 0.3,
    fontSize: T.fontSize.footer,
    fontFace: T.fonts.text,
    color: T.colors.muted,
    margin: 0,
  });
  if (page !== undefined) {
    slide.addText(`${page}`, {
      x: 12.4, y: T.layout.footerY, w: 0.4, h: 0.3,
      fontSize: T.fontSize.footer,
      fontFace: T.fonts.text,
      color: T.colors.muted,
      align: "right",
      margin: 0,
    });
  }
}

/**
 * 강조 인용 한 줄 (italic blue) — 본문 아래 강조.
 */
function addCallout(slide, text, opts = {}) {
  slide.addText(text, {
    x: T.layout.marginX,
    y: opts.y ?? 6.5,
    w: T.layout.contentW,
    h: 0.4,
    fontSize: T.fontSize.italic,
    fontFace: T.fonts.text,
    color: opts.color ?? T.colors.blue,
    italic: true,
    margin: 0,
  });
}

/**
 * 수평 hairline — 섹션 구분.
 */
function addHairline(slide, opts = {}) {
  slide.addShape("line", {
    x: opts.x ?? T.layout.marginX,
    y: opts.y ?? 6.4,
    w: opts.w ?? T.layout.contentW,
    h: 0,
    line: { color: T.colors.hairline, width: opts.width ?? 0.75 },
  });
}

/**
 * 슬라이드 표준 setup — 백색 배경 + 푸터(선택).
 * 매 슬라이드 시작 시 호출하면 배경/푸터를 자동 처리.
 */
function setupSlide(pres, opts = {}) {
  const slide = pres.addSlide();
  slide.background = { color: T.colors.bg };
  if (opts.footerText) {
    addFooter(slide, opts.footerText, opts.page);
  }
  return slide;
}

module.exports = {
  addEyebrow,
  addTitle,
  addSubtitle,
  addFooter,
  addCallout,
  addHairline,
  setupSlide,
};
