// =============================================================
// Full Demo Deck — 12개 패턴을 모두 시연
// 패턴 함수 + 컴포넌트 직접 사용 두 가지 모두 보여준다.
//
// 실행:
//   NODE_PATH=$(npm root -g) node examples/full-deck.js
// =============================================================

const pptxgen = require("pptxgenjs");
const ds = require("../design-system");

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";
pres.title = "Apple White Deck — Pattern Showcase";

const FOOTER = "Pattern Showcase";

// ---------- P1 ----------
ds.patterns.cover(pres, {
  eyebrow: "Apple White Deck  ·  v1",
  title: ["12개 슬라이드 패턴", "한 번에 보기"],
  subtitle: "디자인 시스템으로 일관된 톤을 강제한다.",
  metaLeft: "Pattern Showcase",
  metaRight: "2026",
});

// ---------- P2 ----------
ds.patterns.agenda(pres, {
  eyebrow: "AGENDA",
  title: "12개 패턴",
  items: [
    { num: "01", title: "기본 — 표지·목차·목표", desc: "P1, P2, P3 (Cover, Agenda, Objectives)" },
    { num: "02", title: "구조 — 비교·표·그리드",   desc: "P4, P5, P6 (Comparison, DataTable, Grid)" },
    { num: "03", title: "흐름 — 파이프라인·개념",  desc: "P7, P8 (Pipeline, FourCardConcept)" },
    { num: "04", title: "데이터 — 차트·원인·체크", desc: "P9, P10, P11 + P12 Closing" },
  ],
  footerText: FOOTER, page: 2,
});

// ---------- P3 ----------
ds.patterns.objectives(pres, {
  eyebrow: "OBJECTIVES",
  title: "이 덱을 보고 나면",
  goals: [
    { tag: "GOAL 1", title: "발견한다", desc: "12개 패턴 중 어떤 것이 본인 콘텐츠에 맞는지 판단할 수 있다." },
    { tag: "GOAL 2", title: "조합한다", desc: "패턴 함수와 컴포넌트를 자유롭게 조합할 수 있다." },
    { tag: "GOAL 3", title: "확장한다", desc: "토큰을 그대로 사용하면서 새 패턴을 추가할 수 있다." },
  ],
  footerText: FOOTER, page: 3,
});

// ---------- P4 ----------
ds.patterns.comparison(pres, {
  eyebrow: "PATTERN 4  ·  비교",
  title: "Included vs Excluded",
  subtitle: "두 영역을 명확히 대비할 때.",
  left: {
    title: "포함 영역",
    badge: "INCLUDED  ·  본 시스템 범위",
    items: ["디자인 토큰", "헬퍼 함수", "재사용 컴포넌트", "12개 슬라이드 패턴"],
  },
  right: {
    title: "제외 영역",
    badge: "EXCLUDED  ·  별도 처리",
    items: ["커스텀 일러스트", "동영상 임베드", "복잡한 인터랙션", "외부 폰트 임베드"],
  },
  footerText: FOOTER, page: 4,
});

// ---------- P5 ----------
ds.patterns.dataTable(pres, {
  eyebrow: "PATTERN 5  ·  매트릭스",
  title: "패턴별 권장 사용처",
  subtitle: "어느 상황에 어떤 패턴을 쓸지 빠르게 판단.",
  headers: ["패턴", "용도", "복잡도", "권장도"],
  colW: [3.0, 4.6, 2.25, 2.25],
  rows: [
    [
      { text: "P1 Cover",      bold: true },
      "표지 · 큰 한글 제목 1-2줄",
      { text: "★☆☆☆☆", color: ds.C.blue, align: "center", bold: true },
      { text: "필수", color: ds.C.green, align: "center", bold: true },
    ],
    [
      { text: "P2 Agenda",     bold: true },
      "4개 항목 목차",
      { text: "★☆☆☆☆", color: ds.C.blue, align: "center", bold: true },
      { text: "권장", align: "center" },
    ],
    [
      { text: "P9 ChartKpi",   bold: true },
      "차트 + 큰 숫자 KPI",
      { text: "★★★☆☆", color: ds.C.orange, align: "center", bold: true },
      { text: "데이터 슬라이드 표준", align: "center" },
    ],
    [
      { text: "P11 DecisionFlow", bold: true },
      "체크리스트 · 단계별 검증",
      { text: "★★★★☆", color: ds.C.orange, align: "center", bold: true },
      { text: "프로세스 강의", align: "center" },
    ],
  ],
  callout: "패턴은 정해진 12개로 시작하되, 컴포넌트 조합으로 새 패턴을 만들 수 있다.",
  footerText: FOOTER, page: 5,
});

// ---------- P6 ----------
ds.patterns.fourCardGrid(pres, {
  eyebrow: "PATTERN 6  ·  4-Card 그리드",
  title: "디자인 시스템의 4가지 레이어",
  subtitle: "각 레이어는 독립적으로 사용 가능하면서 합쳐서도 동작한다.",
  items: [
    { num: "01", title: "Tokens",     desc: "컬러, 폰트, 사이즈, 여백의 단일 진실 공급원." },
    { num: "02", title: "Helpers",    desc: "addEyebrow, addTitle 등 자주 쓰는 텍스트 함수." },
    { num: "03", title: "Components", desc: "Card, NumberCircle 등 재사용 시각 요소." },
    { num: "04", title: "Patterns",   desc: "12개 슬라이드 빌더 함수." },
  ],
  footerText: FOOTER, page: 6,
});

// ---------- P7 ----------
ds.patterns.pipeline(pres, {
  eyebrow: "PATTERN 7  ·  파이프라인",
  title: "덱 만드는 6단계",
  subtitle: "구조 설계부터 QA까지.",
  steps: [
    { n: "1", t: "구조 설계",  d: "장수·섹션 결정" },
    { n: "2", t: "패턴 선택",  d: "12개 중 매칭" },
    { n: "3", t: "콘텐츠 채움", d: "텍스트 작성" },
    { n: "4", t: "코드 실행",  d: "PPTX 생성" },
    { n: "5", t: "QA",        d: "JPG 변환 검수", color: ds.C.orange },
    { n: "6", t: "출력",      d: "outputs 제공",  color: ds.C.green },
  ],
  callout: "5단계 QA에서 발견한 결함은 코드 수정 후 재실행으로 한 번에 처리.",
  footerText: FOOTER, page: 7,
});

// ---------- P8 ----------
ds.patterns.fourCardConcept(pres, {
  eyebrow: "PATTERN 8  ·  4가지 개념",
  title: "디자인 시스템 = T + H + C + P",
  subtitle: "네 가지 레이어를 모두 갖춰야 일관된 덱이 나온다.",
  items: [
    { tag: "TOKENS",     ko: "토큰",      desc: "단일 진실 공급원", eg: "C.blue\nF.display\nL.marginX" },
    { tag: "HELPERS",    ko: "헬퍼",      desc: "텍스트 추가 유틸", eg: "addEyebrow()\naddTitle()\naddFooter()" },
    { tag: "COMPONENTS", ko: "컴포넌트",  desc: "재사용 시각 요소", eg: "Card()\nNumberCircle()\nBigStat()" },
    { tag: "PATTERNS",   ko: "패턴",      desc: "슬라이드 빌더",    eg: "patterns.cover()\npatterns.agenda()\npatterns.pipeline()" },
  ],
  footerText: FOOTER, page: 8,
});

// ---------- P9 ----------
ds.patterns.chartKpi(pres, {
  eyebrow: "PATTERN 9  ·  차트 + KPI",
  title: "패턴 사용 시 코드 라인 수 감소",
  subtitle: "동일 결과 대비 패턴 함수가 평균 92% 라인 절감.",
  chart: {
    type: "BAR",
    data: [{
      name: "라인 수 (vs raw)",
      labels: ["Cover", "Agenda", "Goals", "Pipeline"],
      values: [88, 90, 92, 95],
    }],
  },
  kpi: {
    eyebrow: "REDUCTION",
    value: "92%",
    label: "평균 라인 수 절감\n패턴 함수 사용 시",
    calloutTop: "토큰 일관성 100% 보장",
    calloutBottom: "디자인 검수 시간 1/10",
  },
  footerText: FOOTER, page: 9,
});

// ---------- P10 ----------
ds.patterns.threeCardCause(pres, {
  eyebrow: "PATTERN 10  ·  3-Card 원인",
  title: "디자인 일관성이 깨지는 3가지 원인",
  subtitle: "디자인 시스템 없이 작업할 때 자주 발생하는 문제.",
  items: [
    { num: "01", title: "토큰 분산",      sub: "Token Drift",         desc: "같은 컬러를 슬라이드마다 다른 hex로 입력하여 미세하게 어긋남." },
    { num: "02", title: "패턴 즉흥 변경", sub: "Pattern Improvisation", desc: "비슷한 슬라이드인데 매번 다른 레이아웃으로 만들어 톤이 흔들림." },
    { num: "03", title: "예외 누적",      sub: "Exception Sprawl",     desc: "한 번 만든 예외가 다음 덱에 그대로 복사되어 시스템이 무력화됨." },
  ],
  footerText: FOOTER, page: 10,
});

// ---------- P11 ----------
ds.patterns.decisionFlow(pres, {
  eyebrow: "PATTERN 11  ·  체크리스트",
  title: "덱 출하 전 4단계 QA",
  subtitle: "한 단계라도 실패하면 출하 불가.",
  steps: [
    { q: "토큰만 사용했는가?",      pass: "다음 단계", fail: "raw hex 제거" },
    { q: "footer가 모든 페이지에?", pass: "다음 단계", fail: "footerText 추가" },
    { q: "텍스트 오버플로 없는가?", pass: "다음 단계", fail: "h 늘림" },
    { q: "JPG 검수 완료?",        pass: "출하",       fail: "PDF→JPG 재실행" },
  ],
  callout: "4단계 모두 통과한 덱만 outputs로 이동.",
  footerText: FOOTER, page: 11,
});

// ---------- 컴포넌트 직접 사용 예시: 커스텀 슬라이드 ----------
// 패턴이 안 맞는 경우, 컴포넌트를 조합해서 직접 슬라이드를 만들 수 있다.
{
  const slide = ds.helpers.setupSlide(pres, { footerText: FOOTER, page: 12 });
  ds.helpers.addEyebrow(slide, "CUSTOM  ·  컴포넌트 조합");
  ds.helpers.addTitle(slide, "패턴 없이도 같은 톤 유지");
  ds.helpers.addSubtitle(slide, "Card + NumberCircle + BigStat 조합으로 커스텀 레이아웃.");

  // 좌측: BigStat 두 개 (surface 박스 안에 정확히 들어가도록 좌표 조정)
  ds.components.SurfaceBox(slide, { x: 0.6, y: 2.85, w: 5.95, h: 3.8 });
  ds.components.BigStat(slide, {
    x: 0.95, y: 3.05, w: 5.25,
    eyebrow: "PATTERNS",
    value: "12",
    label: "내장 슬라이드 패턴",
    valueSize: 44,
  });
  ds.helpers.addHairline(slide, { x: 0.95, y: 4.7, w: 5.25, width: 0.5 });
  ds.components.BigStat(slide, {
    x: 0.95, y: 4.85, w: 5.25,
    eyebrow: "COMPONENTS",
    value: "9",
    label: "재사용 시각 컴포넌트",
    valueSize: 44,
  });

  // 우측: 6개 컴포넌트 NumberCircle 그리드
  const items = [
    { n: "1", t: "Card" },
    { n: "2", t: "SurfaceBox" },
    { n: "3", t: "AccentBar" },
    { n: "4", t: "NumberCircle" },
    { n: "5", t: "Badge" },
    { n: "6", t: "BigStat" },
  ];
  items.forEach((it, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 6.85 + col * 3.05;
    const y = 2.85 + row * 1.27;
    ds.components.Card(slide, { x, y, w: 2.95, h: 1.15 });
    ds.components.NumberCircle(slide, {
      x: x + 0.3, y: y + 0.32, num: it.n, size: 0.5, fontSize: 16,
    });
    slide.addText(it.t, {
      x: x + 1.0, y: y + 0.32, w: 1.85, h: 0.5,
      fontSize: 16, fontFace: ds.F.display,
      color: ds.C.ink, bold: true, valign: "middle", margin: 0,
    });
  });
}

// ---------- P12 ----------
ds.patterns.closing(pres, {
  eyebrow: "Pattern Showcase",
  softLine: "디자인 시스템은",
  boldLine: "\"코드로 강제된 톤\"이다.",
  signature: "Apple White Deck   |   v1",
});

pres.writeFile({ fileName: "full-deck.pptx" })
  .then((file) => console.log("OK:", file));
