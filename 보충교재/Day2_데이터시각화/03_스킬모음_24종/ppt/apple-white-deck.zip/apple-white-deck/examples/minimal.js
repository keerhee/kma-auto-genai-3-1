// =============================================================
// Minimal Example — 5장으로 빠르게 시작하기
// 패턴 함수만 사용하는 가장 간단한 사용 예시.
//
// 실행:
//   NODE_PATH=$(npm root -g) node examples/minimal.js
// =============================================================

const pptxgen = require("pptxgenjs");
const ds = require("../design-system");

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";
pres.title = "Minimal Deck";

const FOOTER = "Demo  ·  Apple White Deck";

// 1. 표지
ds.patterns.cover(pres, {
  eyebrow: "DEMO  ·  Minimal",
  title: ["디자인 시스템", "5장 빠른 데모"],
  subtitle: "패턴 함수 한 줄로 슬라이드 추가",
  metaLeft: "Apple White Deck v1",
  metaRight: "2026",
});

// 2. 목차
ds.patterns.agenda(pres, {
  eyebrow: "AGENDA",
  title: "오늘의 흐름",
  subtitle: "다섯 가지 패턴을 차례로 보여준다.",
  items: [
    { num: "01", title: "목표 카드",      desc: "3-Card Goals 패턴" },
    { num: "02", title: "프로세스",        desc: "Pipeline 패턴" },
    { num: "03", title: "차트",            desc: "Chart + KPI 패턴" },
    { num: "04", title: "마무리",          desc: "Closing 패턴" },
  ],
  footerText: FOOTER, page: 2,
});

// 3. 목표 (3-Card)
ds.patterns.objectives(pres, {
  eyebrow: "OBJECTIVES",
  title: "이 데모를 마치면",
  goals: [
    { tag: "GOAL 1", title: "이해한다", desc: "디자인 시스템 구조를 이해할 수 있다." },
    { tag: "GOAL 2", title: "재사용한다", desc: "패턴 함수로 한 줄에 슬라이드를 추가할 수 있다." },
    { tag: "GOAL 3", title: "확장한다",  desc: "컴포넌트를 조합해 새 패턴을 만들 수 있다." },
  ],
  footerText: FOOTER, page: 3,
});

// 4. 차트 + KPI
ds.patterns.chartKpi(pres, {
  eyebrow: "MODULE  ·  효과",
  title: "한 줄로 추가한 차트",
  subtitle: "KPI 사이드바와 결합된 표준 차트 슬라이드.",
  chart: {
    type: "BAR",
    data: [{
      name: "성능",
      labels: ["A", "B", "C", "D"],
      values: [85, 72, 91, 68],
    }],
  },
  kpi: {
    eyebrow: "AVG",
    value: "79%",
    label: "전체 평균\n샘플 N=4",
    calloutTop: "B 카테고리 개선 필요",
    calloutBottom: "다음 분기 재측정",
  },
  footerText: FOOTER, page: 4,
});

// 5. 마무리
ds.patterns.closing(pres, {
  eyebrow: "DEMO",
  softLine: "디자인 시스템은",
  boldLine: "한 줄 코드로 일관된 톤을 만든다.",
  signature: "Apple White Deck   |   Thank you",
});

pres.writeFile({ fileName: "minimal.pptx" })
  .then((file) => console.log("OK:", file));
