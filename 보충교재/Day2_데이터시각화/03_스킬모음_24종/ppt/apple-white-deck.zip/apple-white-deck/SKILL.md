---
name: apple-white-deck
description: 애플 keynote 톤의 화이트 미니멀 PPT 덱을 생성하는 룰북. "애플 스타일", "애플 톤", "Apple White", "keynote 스타일", "화이트 미니멀 PPT", "흰 배경 깔끔한 슬라이드", "미니멀 강의 자료", "임원 보고용 깔끔한 덱", "ZeroOneAI 강의 PPT", "재직자 과정 PPT", "강의용 슬라이드 만들어줘" 등의 표현이 나오면 반드시 이 스킬을 사용한다. 마크다운 강의노트·기획서·요약 자료를 받아 SF Pro 톤의 화이트 슬라이드(eyebrow + 큰 타이틀 + subtitle + 카드 그리드)로 변환하는 모든 작업에 트리거한다. pptxgenjs 기반 단일 파일 출력.
---

# Apple White Deck — 룰북 v1

### 제목·부제 두 층 규칙 (덱 스킬 공통)

제목 줄은 **두 층**으로 쓴다. 제목이 격식을 맡고, 부제가 친절한 설명을 맡는다.

- **제목** — 표지·섹션 디바이더는 자료의 정체를 밝히는 **명사구**(`평균-분산 포트폴리오 최적화 / 이론과 활용`).
  본문은 완결된 **주장문**이되 문어체 단정형으로 쓴다. 구어체 종결·감탄·의문 부호·과장 수식어는 쓰지 않는다.
- **부제** — 제목을 읽기 위해 필요한 사전 정보를 한 줄로 담는다. 전제·가정, 실험이나 자료 설정,
  처음 나오는 용어의 원어, 표·그림 읽는 법 중 하나. `~한다` 체로 20~35자.
- 표지·디바이더는 부제가 사실상 필수다. 본문에서도 제목의 수치·조건·용어가 본문 어디에도 없으면 반드시 단다.
- 부제를 달면 본문 시작 y가 내려간다. **카드·수식 높이를 그만큼 줄여야** 콘텐츠 하한을 넘지 않는다.


## 0. 이 스킬의 목적

자연어 한두 줄 또는 마크다운 강의노트 입력으로 **항상 같은 톤의** 애플 keynote 풍 화이트 슬라이드를 만든다.

원칙: **"디자인 = 로직"**. 토큰·레이아웃 룰을 고정하면 내용만 갈아끼워도 일관된 톤이 나온다.

대상 용도:
- 강의 자료 (KAIST·ZeroOneAI·재직자 과정·은행권/자동차 산업 고객사)
- 임원 보고용 깔끔한 덱
- 컨퍼런스 발표 (GAIC 등)

---

## 1. Design Tokens — 절대 바꾸지 않는 시각 골격

### 1.1 컬러 팔레트

```js
const C = {
  bg:       "FFFFFF",  // pure white
  ink:      "1D1D1F",  // Apple graphite (제목/본문)
  inkSoft:  "424245",  // secondary text (subtitle)
  muted:    "86868B",  // tertiary / caption / footer
  hairline: "D2D2D7",  // dividers · card borders
  surface:  "F5F5F7",  // subtle card fill (요약 박스)
  blue:     "0071E3",  // Apple action blue (PRIMARY ACCENT)
  blueDeep: "0040DD",
  green:    "30D158",  // 긍정/완료
  orange:   "FF9F0A",  // 주의/중간 단계
  red:      "FF3B30",  // 경고/금지
  purple:   "AF52DE",
};
```

**색 운영 원칙**:
- 배경은 **무조건 순백**. `F5F5DC`(beige), `FAEBD7` 류 warm-neutral 절대 금지.
- 액센트는 **블루 70% + (orange/green/red) 30%** 비율 유지. 4색 이상 동시 사용 금지.
- 텍스트는 ink → inkSoft → muted 3단계만 사용.

### 1.2 타이포그래피

```js
const F = {
  display:  "SF Pro Display",   // 제목
  text:     "SF Pro Text",      // 본문
  fallback: "Helvetica Neue",   // (PowerPoint 자동 폴백)
};
```

**사이즈 규칙** (LAYOUT_WIDE 13.3" × 7.5" 기준):

| 용도 | 크기 | 굵기 | 색상 | 폰트 |
|---|---|---|---|---|
| Cover 메인 타이틀 | 54pt | bold | ink | display |
| Page 타이틀 | 36pt | bold | ink | display |
| Subtitle (제목 아래 1줄) | 16pt | regular | inkSoft | text |
| Eyebrow (섹션 라벨) | 11pt | bold + charSpacing 4 | blue | text |
| 카드 헤드라인 | 22~28pt | bold | ink | display |
| 카드 본문 | 13~14pt | regular | inkSoft | text |
| 큰 숫자 stat | 56~60pt | bold | ink | display |
| Footer | 10pt | regular | muted | text |
| 강조 인용문 (italic) | 13pt | italic | blue | text |

### 1.3 레이아웃 골격

- 슬라이드 비율: **LAYOUT_WIDE (13.3 × 7.5 inch)**
- 좌우 마진: **0.6"** (모든 콘텐츠는 x: 0.6 ~ 12.7 사이)
- 상단 eyebrow: y = 0.5
- 페이지 타이틀: y = 0.9, h = 0.95
- Subtitle: y = 1.85, h = 0.5
- 본문 시작: y = 2.55 ~ 2.85
- Footer: y = 7.05

---

## 2. Frame Spec — 모든 슬라이드 공통 골격

```
┌─────────────────────────────────────────────────────────┐
│ EYEBROW (블루, 11pt, 자간 넓게)                          │  ← y=0.5
│                                                         │
│ 페이지 타이틀 (36pt Bold, ink)                           │  ← y=0.9
│ 부제 한 줄 (16pt, inkSoft)                               │  ← y=1.85
│                                                         │
│  ┌─── Card ───┐  ┌─── Card ───┐  ┌─── Card ───┐         │
│  │             │  │             │  │             │      │
│  │             │  │             │  │             │      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
│                                                         │
│  Day X · 코스명                                  N      │  ← y=7.05 footer
└─────────────────────────────────────────────────────────┘
```

**Eyebrow 텍스트 패턴**:
- `"AGENDA"`, `"OBJECTIVES"`, `"MODULE 1  ·  적용 영역"`, `"PRACTICE 3  ·  하이라이트"`, `"WRAP UP"`, `"NEXT"` 처럼 영어 라벨 + 한글 부제.
- `charSpacing: 4`로 항상 자간을 넓게.

---

## 3. 슬라이드 패턴 12종 — 이 12개로 거의 모든 강의 슬라이드를 만든다

### P1. Cover (표지)
- Eyebrow: 코스 코드 + Day 번호 (가운데 정렬)
- 메인 타이틀: 1~2줄, 54pt
- Subtitle: 한 줄 설명
- 하단: hairline + 메타 정보 (시간·모드 / 강사·연도)

### P2. Agenda
- 좌측 큰 번호 (01, 02, 03...) + 우측 타이틀 + 한 줄 설명
- 항목 사이 hairline 디바이더

### P3. Objectives (3-카드)
- 카드 3개, eyebrow(GOAL N) + 큰 동사("구분한다", "재설계한다") + 짧은 라인 액센트 + 설명

### P4. Two-Column Comparison (Included vs Excluded 등)
- 좌·우 카드 두 개. 각각 surface 배경 + 좌측 0.08" 액센트 바
- INCLUDED는 blue 액센트, EXCLUDED는 muted 액센트
- 본문은 bullet code "25CF"(채워진 원, 포함) vs "25CB"(빈 원, 제외)

### P5. Data Table
- 헤더: ink 배경 + 흰 글씨 13pt bold
- 본문: rowH 0.5~0.55, hairline 보더
- 강조 행은 마지막 줄에 배치하고 red/orange로 색상 구분

### P6. 4-Card Grid (2×2)
- cardW ≈ 5.95", cardH ≈ 1.85", gap 0.25"
- 좌측 큰 번호 (28pt blue) + 우측 타이틀 + 본문

### P7. Process Pipeline (가로 6단계)
- 6개 카드 가로로 배치, 각 카드에 number circle (oval, 0.55") + 타이틀 + 짧은 설명
- 시작·중간 노드는 blue, 검증은 orange, 산출물은 green
- 카드 사이에 작은 RIGHT_TRIANGLE(rotate: 90)로 화살표 암시

### P8. 4-Card Concept (4개 카드 한 줄)
- cardW ≈ 2.95", 카드 상단 0.08" 블루 액센트 바
- Eyebrow 태그(영문) + 큰 한글 단어 + 짧은 설명 + 회색 surface 예시 박스

### P9. Chart + KPI Sandwich
- 좌측 70%: native pptx 차트 (BAR/COLUMN/LINE) - chartColors는 [C.blue]만 사용
- 우측 30%: surface 박스 + 큰 숫자(56pt) + 설명 + hairline + italic 인용

### P10. 3-Card Vertical Split (할루시네이션 3원인, HITL 3단계 등)
- cardW 4.0", gap 0.25"
- 큰 번호 (32pt) + 한글 타이틀 + 영문 부제(italic muted) + 짧은 액센트 라인 + 본문

### P11. 4-Step Decision Flow (체크리스트)
- 4개 큰 카드 가로 배치, 각각 Q1~Q4 라벨
- 카드 아래에 ✓ pass / ✕ fail 두 줄 surface 박스
- 카드 사이 RIGHT_TRIANGLE 화살표

### P12. Big Quote / Closing
- 가운데 정렬 큰 인용문 (40pt)
- 위쪽 작은 라벨 (Day X), 아래쪽 짧은 액센트 라인 + Thank you

추가로 자주 쓰이는 변형:
- **3-Card Top-accent**: HITL 3단계처럼 카드 상단 0.08" 컬러 바로 단계 구분
- **5-Card Pentagon**: Porter's 5 Forces. 가운데 ink oval + 주변 5장 카드
- **Wrap-up List**: 카드 없이 좌측 라벨(blue) + 우측 본문, 사이 hairline

---

## 4. Component Patterns — 자주 쓰는 시각 요소

### 4.1 Card (기본)

```js
slide.addShape(pres.shapes.RECTANGLE, {
  x, y, w, h,
  fill: { color: C.bg },
  line: { color: C.hairline, width: 0.75 },
  shadow: cardShadow(),  // ⚠️ 매번 새 객체 생성 (mutate 방지)
});
```

`cardShadow()`는 **매 호출마다 새 객체를 반환하는 함수**여야 한다. pptxgenjs는 shadow 객체를 in-place mutate하므로 같은 객체 재사용 시 두 번째 도형이 깨진다.

### 4.2 Eyebrow

```js
slide.addText("MODULE 1  ·  적용 영역", {
  x: 0.6, y: 0.5, w: 6, h: 0.3,
  fontSize: 11, fontFace: F.text, color: C.blue, bold: true,
  charSpacing: 4, margin: 0,
});
```

### 4.3 Surface Box (요약/예시)

```js
slide.addShape(pres.shapes.RECTANGLE, {
  x, y, w, h,
  fill: { color: C.surface },
  line: { color: "FFFFFF", width: 0 },  // 보더 없음
});
```

### 4.4 Side Accent Bar (좌측 강조 바)

```js
// 카드 좌측 0.08" 컬러 바
slide.addShape(pres.shapes.RECTANGLE, {
  x: cardX, y: cardY, w: 0.08, h: cardH,
  fill: { color: C.blue }, line: { color: "FFFFFF", width: 0 },
});
```

### 4.5 Number Circle

```js
slide.addShape(pres.shapes.OVAL, {
  x, y, w: 0.55, h: 0.55,
  fill: { color: C.blue }, line: { color: "FFFFFF", width: 0 },
});
slide.addText("1", {
  x, y, w: 0.55, h: 0.55,
  fontSize: 18, fontFace: F.display, color: C.bg, bold: true,
  align: "center", valign: "middle", margin: 0,
});
```

### 4.6 Native Chart Styling

```js
slide.addChart(pres.charts.BAR, [{...}], {
  x: 0.6, y: 2.85, w: 7.5, h: 3.8,
  barDir: "bar",
  chartColors: [C.blue],            // 단일 시리즈는 blue 단색
  chartArea: { fill: { color: C.bg } },
  catAxisLabelFontSize: 11, catAxisLabelColor: C.ink, catAxisLabelFontFace: F.text,
  valAxisLabelFontSize: 10, valAxisLabelColor: C.muted,
  valGridLine: { color: C.hairline, size: 0.5 },
  catGridLine: { style: "none" },
  showValue: true, dataLabelPosition: "outEnd", dataLabelColor: C.ink,
  dataLabelFontSize: 12, dataLabelFontBold: true,
  showLegend: false,
});
```

---

## 5. Anti-Patterns — 반드시 피한다

| ❌ 금지 | ✅ 대안 |
|---|---|
| 제목 아래 컬러 액센트 라인 (AI 슬라이드 슬롭 신호) | 여백으로 구분 |
| Beige/cream 배경 (`F5F5DC`, `FAEBD7`) | 무조건 순백 `FFFFFF` |
| 헤더/푸터 풀폭 컬러 바 | 얇은 hairline 1px |
| 한 슬라이드에 4색 이상 액센트 | 블루 + 1색 보조 |
| 텍스트 박스 안에 unicode "•" 직접 입력 | `bullet: { code: "25CF" }` |
| 이모지 사용 (🚀 등) | 도형/텍스트 라벨로 대체 |
| 둥근 모서리 RECTANGLE에 직사각형 액센트 오버레이 | RECTANGLE으로 통일 |
| shadow 객체 재사용 (`const sh = {...}` 후 여러 도형에) | `cardShadow()` 함수로 매번 새 객체 |
| 한 줄 제목인데 박스 높이 0.9" 미만 (한글 두 줄 wrap 시 잘림) | 큰 폰트는 h: 1.0~1.1 확보 |
| Footer 영역(y > 6.9)까지 카드 침범 | 카드 영역은 y < 6.7 |

---

## 6. Workflow — 슬라이드 만드는 표준 절차

### Step 1. 입력 파악
- 사용자가 마크다운 강의노트를 줬는가? → 헤딩/표/인용문에서 슬라이드 단위 추출
- 자연어 한두 줄만 줬는가? → 분량(5-7 / 10-12 / 15-18장)과 용도 확인
- 사용자가 분량을 명시하지 않았다면 **딱 한 번** 분량/언어 확인 (`ask_user_input_v0` 사용)

### Step 2. 구조 설계
- Cover → Agenda → 본문 (모듈/섹션별 2-4장씩) → 정리 → Closing
- 강의용 15-18장 표준 구성:
  1. Cover
  2. Agenda
  3. Objectives
  4-6. Module 1 (개요 → 비교 → 매트릭스)
  7-9. Module 2 (파이프라인 → 디테일 → 효과)
  10-13. Module 3 (원인 → 체크리스트 → 가이드 → 검토)
  14-15. 실습 개요 + 하이라이트
  16. Wrap-up
  17. Homework + Next preview
  18. Closing

### Step 3. 코드 작성
- `scripts/template.js`를 시작점으로 사용 (헬퍼 함수 + 토큰 + 패턴 12개 주석)
- LAYOUT_WIDE 사용
- 각 슬라이드는 IIFE 블록 `{ const s = pres.addSlide(); ... }`으로 격리

### Step 4. 생성 + QA
```bash
NODE_PATH=$(npm root -g) node deck.js
python /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf output.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 110 output.pdf slide
```
- `view` 도구로 슬라이드 이미지 점검 (특히 1번, 마지막, 차트/테이블 슬라이드)
- 자주 나오는 결함:
  - 큰 폰트 텍스트가 박스 높이에 못 맞춰 두 줄 wrap → h 늘림
  - 카드 행이 footer 영역(y > 6.9) 침범 → rowH 줄임
  - 한글 wrap 때문에 카드 안 텍스트 잘림 → fontSize 1~2pt 줄이거나 cardH +0.2

### Step 5. 출력
- `/mnt/user-data/outputs/` 로 복사 후 `present_files`로 제공
- 응답 끝에 슬라이드 구성 표로 한 페이지 요약 제공

---

## 7. 시작점 — `scripts/template.js`

`scripts/template.js`에는 다음이 포함되어 있다:
- 컬러 토큰 (C), 폰트 토큰 (F)
- 헬퍼: `cardShadow()`, `addEyebrow()`, `addTitle()`, `addSubtitle()`, `addFooter()`
- 12개 슬라이드 패턴의 동작하는 예시 코드 (주석으로 P1~P12 표시)

새 덱을 만들 때는 이 파일을 시작점으로 복사한 뒤, 필요한 슬라이드 패턴만 남기고 내용을 교체한다.

---

## 8. 패키지 의존성

```bash
npm install -g pptxgenjs
```

추가 라이브러리(react-icons, sharp 등)는 이 스킬에서 사용하지 않는다. 아이콘 대신 도형(OVAL, RECTANGLE) + 큰 숫자/문자로 대체하는 것이 애플 톤에 더 잘 맞는다.
