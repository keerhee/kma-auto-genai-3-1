#!/usr/bin/env python3
"""
build_deck.py — 인포그래픽 이미지 여러 장을 비율에 맞춘 풀블리드 PPT로 빌드.

기능
  1) 스크린샷 검은 레터박스(상/하, 필요시 좌/우) 자동 제거
  2) 트림 후 공통(중앙값) 비율 감지 → 슬라이드 크기를 그 비율로 설정
  3) 가장자리 색 샘플링 → 슬라이드 배경색으로 매칭(미세 여백 비가시)
  4) 각 이미지를 contain(잘리지 않게)으로 중앙 풀블리드 배치

사용
  python build_deck.py --images a.jpg b.jpg c.jpg --out deck.pptx
  python build_deck.py --dir ./imgs --pattern "*.jpg" --sort name --out deck.pptx

옵션
  --orientation auto|portrait|landscape  (기본 auto: 비율<1이면 세로, >1이면 가로)
  --max-dim 9.0   슬라이드 긴 변 길이(inch, 기본 9.375의 긴 변 기준 자동)
  --bg auto|FFFFFF  배경색(기본 auto=가장자리 색)
  --no-trim        레터박스 제거 끄기
"""
import argparse, glob, os, statistics, tempfile
from PIL import Image
from pptx import Presentation
from pptx.util import Inches

NEAR_BLACK = 25   # 평균 밝기 이 값 미만이면 검은 띠로 간주
SAMPLE_STEP = 8


def line_brightness(px, w, y):
    xs = range(0, w, SAMPLE_STEP)
    return sum(sum(px[x, y][:3]) / 3 for x in xs) / len(list(xs))


def col_brightness(px, h, x):
    ys = range(0, h, SAMPLE_STEP)
    return sum(sum(px[x, y][:3]) / 3 for y in ys) / len(list(ys))


def trim_letterbox(im):
    im = im.convert("RGB")
    w, h = im.size
    px = im.load()
    top = 0
    while top < h - 1 and line_brightness(px, w, top) < NEAR_BLACK:
        top += 1
    bot = h - 1
    while bot > top and line_brightness(px, w, bot) < NEAR_BLACK:
        bot -= 1
    left = 0
    while left < w - 1 and col_brightness(px, h, left) < NEAR_BLACK:
        left += 1
    right = w - 1
    while right > left and col_brightness(px, h, right) < NEAR_BLACK:
        right -= 1
    return im.crop((left, top, right + 1, bot + 1))


def corner_color(im):
    w, h = im.size
    px = im.load()
    pts = [px[2, 2], px[w - 3, 2], px[2, h - 3], px[w - 3, h - 3]]
    return tuple(round(sum(c[i] for c in pts) / 4) for i in range(3))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", nargs="*", default=[])
    ap.add_argument("--dir")
    ap.add_argument("--pattern", default="*.jpg")
    ap.add_argument("--sort", choices=["name", "none"], default="name")
    ap.add_argument("--out", required=True)
    ap.add_argument("--orientation", default="auto",
                    choices=["auto", "portrait", "landscape"])
    ap.add_argument("--max-dim", type=float, default=9.375)
    ap.add_argument("--bg", default="auto")
    ap.add_argument("--no-trim", action="store_true")
    a = ap.parse_args()

    files = list(a.images)
    if a.dir:
        files = glob.glob(os.path.join(a.dir, a.pattern))
    if a.sort == "name":
        files = sorted(files)
    if not files:
        raise SystemExit("이미지가 없습니다. --images 또는 --dir 확인.")

    tmp = tempfile.mkdtemp()
    prepared, ratios, bgs = [], [], []
    for i, f in enumerate(files):
        im = Image.open(f)
        if not a.no_trim:
            im = trim_letterbox(im)
        else:
            im = im.convert("RGB")
        p = os.path.join(tmp, f"{i:03d}.png")
        im.save(p)
        prepared.append(p)
        ratios.append(im.size[0] / im.size[1])
        bgs.append(corner_color(im))

    ratio = statistics.median(ratios)            # 슬라이드 공통 비율
    if a.orientation == "portrait" and ratio >= 1:
        ratio = 1 / ratio
    if a.orientation == "landscape" and ratio < 1:
        ratio = 1 / ratio

    # 긴 변 = max_dim, 짧은 변 = 비율로 계산
    if ratio < 1:  # 세로
        sh = a.max_dim
        sw = sh * ratio
    else:          # 가로
        sw = a.max_dim
        sh = sw / ratio

    if a.bg == "auto":
        med = tuple(round(statistics.median(c[i] for c in bgs)) for i in range(3))
        bg_hex = "%02X%02X%02X" % med
    else:
        bg_hex = a.bg.lstrip("#").upper()

    prs = Presentation()
    prs.slide_width = Inches(sw)
    prs.slide_height = Inches(sh)
    blank = prs.slide_layouts[6]

    from pptx.dml.color import RGBColor
    bg_rgb = RGBColor.from_string(bg_hex)

    for p in prepared:
        slide = prs.slides.add_slide(blank)
        # 배경색
        fill = slide.background.fill
        fill.solid()
        fill.fore_color.rgb = bg_rgb
        # contain 배치
        iw, ih = Image.open(p).size
        r = iw / ih
        w, h = sw, sw / r
        if h > sh:
            h, w = sh, sh * r
        x, y = (sw - w) / 2, (sh - h) / 2
        slide.shapes.add_picture(p, Inches(x), Inches(y), Inches(w), Inches(h))

    prs.save(a.out)
    print(f"OK  slides={len(prepared)}  ratio={ratio:.3f}  "
          f"size={sw:.2f}x{sh:.2f}in  bg=#{bg_hex}  -> {a.out}")


if __name__ == "__main__":
    main()
