---
name: report-white-deck
description: 미니멀 화이트 "리포트형" 강의·발표 PPT 덱을 생성하는 룰북. "리포트형 PPT", "리포트 스타일 슬라이드", "미니멀 화이트 강의자료", "깔끔한 강의 PPT", "화이트 리포트 덱", "좌우분할 없는 슬라이드", "학술적이고 세련된 강의 슬라이드", "블랙·그레이·블루 슬라이드", "수식 들어간 강의 PPT", "재직자 과정 PPT", "자동차/금융 강의 덱", "강의노트를 PPT로" 등의 표현이 나오면 반드시 이 스킬을 사용한다. 마크다운 강의노트를 받아 큰 굵은 제목 + 얇은 본문 + 얇은 hairline + 상단 섹션 라벨로 구성된, 좌우로 강하게 분할하지 않는 단일 넓은 캔버스 흐름의 슬라이드로 변환한다. apple-white-deck보다 정보 밀도가 높고 표·프롬프트 박스·파이프라인·수식을 자연스럽게 담는 학술 리포트 톤. latex-equation-png와 결합해 수식을 PNG로 얹는다. pptxgenjs 기반 단일 파일 출력.
---

# Report White Deck — 룰북 v1

## 0. 이 스킬의 목적

마크다운 강의노트나 자연어 입력을 받아, **미니멀 화이트 리포트형** 강의 슬라이드로 변환한다. `apple-white-deck`이 keynote 풍의 카드·그림자 중심이라면, 이 스킬은 **카드·그림자 없이** 큰 굵은 제목과 얇은 hairline만으로 구조를 잡는 **학술 리포트 톤**이다. 표·프롬프트 박스·파이프라인·수식을 한 화면에 자연스럽게 흐르게 담아 정보 밀도가 더 높다.

원칙: **"화면을 쪼개지 말고 흐르게 한다."** 좌우 2분할(사이드바+본문) 금지, 세로 구분선 금지. 하나의 넓은 캔버스 안에서 제목 → 핵심 문장 → 표·수식·프롬프트가 위에서 아래로 흐른다.

### 제목·부제 두 층 규칙 (덱 스킬 공통)

제목 줄은 **두 층**으로 쓴다. 제목이 격식을 맡고, 부제가 친절한 설명을 맡는다.

- **제목** — 표지·섹션 디바이더는 자료의 정체를 밝히는 **명사구**(`평균-분산 포트폴리오 최적화 / 이론과 활용`).
  본문은 완결된 **주장문**이되 문어체 단정형으로 쓴다. 구어체 종결·감탄·의문 부호·과장 수식어는 쓰지 않는다.
- **부제** — 제목을 읽기 위해 필요한 사전 정보를 한 줄로 담는다. 전제·가정, 실험이나 자료 설정,
  처음 나오는 용어의 원어, 표·그림 읽는 법 중 하나. `~한다` 체로 20~35자.
- 표지·디바이더는 부제가 사실상 필수다. 본문에서도 제목의 수치·조건·용어가 본문 어디에도 없으면 반드시 단다.
- 부제를 달면 본문 시작 y가 내려간다. **카드·수식 높이를 그만큼 줄여야** 콘텐츠 하한을 넘지 않는다.


대상 용도:
- 강의 자료 (KAIST·재직자 과정·금융기관/자동차 산업 고객사)
- 수식이 핵심인 이론 강의 (금융 시계열·계량 등) — `latex-equation-png`와 결합
- 임원·기관 보고용 리포트형 덱

---

## 1. Design Tokens — 절대 바꾸지 않는 시각 골격

### 1.1 컬러 — 3색만 (블랙·그레이·포인트 블루)

```js
const C = {
  bg:      "FFFFFF",  // 순백 (warm-neutral 절대 금지)
  ink:     "1D1D1F",  // 제목·강조 본문
  inkSoft: "424245",  // 본문
  muted:   "86868B",  // 캡션·푸터·보조
  hair:    "D6D6DB",  // 얇은 구분선·표 보더
  surface: "F5F5F7",  // 프롬프트/코드 블록 배경 (유일하게 허용되는 면)
  blue:    "0071E3",  // 포인트 블루 (PRIMARY ACCENT)
  blueDeep:"0040DD",  // 강조 정의·소제목
};
```

**색 운영 원칙**: 배경 무조건 순백. 액센트는 블루 한 가지 계열만(blue + blueDeep). 빨강·초록·주황 등 추가 색은 쓰지 않는다 — 리포트 톤은 단색 절제에서 나온다.

### 1.2 타이포그래피

```js
const F = { disp: "Helvetica Neue", text: "Helvetica Neue", mono: "Consolas" };
```

| 용도 | 크기 | 굵기 | 색 |
|---|---|---|---|
| Cover 메인 타이틀 | 52pt | bold | ink |
| Page 타이틀 | 36pt | bold | ink |
| Subtitle (제목 아래 1줄) | 18.5pt | regular | inkSoft |
| Nav 라벨 (상단 좌측) | 12pt | bold + charSpacing 3 | blue |
| Nav 과목명 (상단 우측) | 11.5pt | regular | muted |
| 큰 정의 문장 (bigDef) | 24~26pt | bold | ink |
| 소제목 (subhead) | 14pt | bold | blueDeep |
| 본문·bullet | 14.5~15pt | regular | inkSoft |
| 인사이트 한 줄 (tag) | 14.5pt | label bold | blueDeep + inkSoft |
| 표 본문 | 13pt | regular | ink |
| 프롬프트 라벨 / 본문 | 12pt / 13.5pt | label bold | blue / ink(mono) |
| 파이프라인 단계 설명 | 12.5pt | regular | muted |
| Footer | 11pt | regular | muted |

> **v2 방침** — 글씨를 전반적으로 키우고(특히 캡션·푸터 등 작은 글씨도 11pt 이상 확보), 미니멀에 얽매이기보다 **내용을 충실히** 전달한다(단, 난잡 금지). 각 슬라이드에 인사이트·시사점·기대 산출물을 한 줄씩 더하는 `tag()` 헬퍼를 적극 사용한다.

### 1.3 레이아웃 골격 (16:9, 13.3 × 7.5 inch)

- 좌우 마진 `LX = 0.75"` → 콘텐츠 너비 `CW = 11.8"` (넓은 여백)
- 상단 nav 라벨: y = 0.4 (좌측 섹션 라벨, 우측 과목명)
- 헤더 hairline: y = 0.78 (리포트 톤의 핵심 — nav와 본문을 가르는 가로선)
- 페이지 타이틀: y = 0.9
- Subtitle: y = 1.64
- 본문 시작: y = 1.95 ~ 2.2
- Footer hairline + 텍스트: y = 7.0 / 7.06

---

## 2. Frame Spec — 모든 슬라이드 공통 골격

```
┌───────────────────────────────────────────────────────────┐
│ MODULE 01 · 섹션라벨 (blue)                  과목명 (muted) │ ← y=0.4
│ ─────────────────────────────────────────────────────────  │ ← y=0.78 hairline
│ 페이지 타이틀 (34pt Bold, ink)                              │ ← y=0.9
│ 부제 한 줄 (17pt, inkSoft)                                  │ ← y=1.64
│                                                            │
│   (표 · 수식 · 프롬프트 박스 · bullet 이 위→아래로 흐름)     │
│   ── 얇은 hairline 으로만 섹션 구분 (세로선 절대 금지) ──     │
│                                                            │
│ ─────────────────────────────────────────────────────────  │ ← y=7.0 hairline
│ 강의명 · 출처 (muted)                                  N    │ ← y=7.06 footer
└───────────────────────────────────────────────────────────┘
```

**nav 라벨 패턴**: `"MODULE 01  ·  산업 이해"`, `"AGENDA  ·  오늘의 흐름"`, `"MODULE 02  ·  ④ 분석 1"`, `"WRAP UP  ·  핵심 요약"`, `"NEXT  ·  마무리"` — 영문 라벨 + 한글 부제, charSpacing 3.

---

## 3. 슬라이드 패턴 10종 (R1~R10) — 이걸로 강의 슬라이드 대부분을 만든다

| 패턴 | 용도 | 헬퍼 |
|---|---|---|
| **R1 Cover** | 표지: 가운데 큰 제목 + 부제 + 짧은 hairline + 메타 | (cover 직접 작성) |
| **R2 Agenda** | 목차: 좌측 큰 번호(01~) + 타이틀 + 설명, 사이 hairline | `rule` |
| **R3 Concept** | 개념: 큰 정의 문장 강조 + 짧은 bullet | `bigDef`, `bullets` |
| **R4 Table** | 비교표: ink 헤더 행 + hairline 보더 | `table` |
| **R5 Pipeline** | 가로 N단계: 번호 노드 + 얇은 연결선 (박스 없음) | `pipeline` |
| **R6 Prompt Box** | 프롬프트/코드: surface + 좌측 블루 바 + mono | `promptBox` |
| **R7 Equation** | 수식: 중앙 LaTeX PNG + 아래 해석 | `eqC` (latex-equation-png) |
| **R8 Two-Column Flow** | 2단 텍스트 흐름 (세로 구분선 없이) | `subhead`+`bullets` 2회 |
| **R9 Takeaway** | 요약: 번호형 라인 3~5개, 사이 hairline | (S15 예시 참조) |
| **R10 Closing/Next** | 마무리: 큰 문장 + 다음 단계 | `bigDef`, `rule` |
| **+ Insight tag** | 인사이트·용어·시사점·기대 산출물 한 줄 (내용 충실화) | `tag` |

각 헬퍼는 `scripts/template.js`에 구현되어 있다.

---

## 4. Anti-Patterns — 반드시 피한다 (리포트 톤 유지)

| ❌ 금지 | ✅ 대안 |
|---|---|
| 좌우 2분할(사이드바+본문) 강한 레이아웃 | 단일 넓은 캔버스, 위→아래 흐름 |
| 화면을 반으로 가르는 **세로 구분선** | 얇은 **가로** hairline만 |
| 카드 + 그림자 (apple-white의 cardShadow) | 면 없이 텍스트·hairline으로 구조화 |
| 박스·그라데이션·라운드 장식 | surface 면은 프롬프트/코드 블록에만 |
| 4색 이상 액센트 | 블루 단색 계열(blue·blueDeep)만 |
| Beige/cream 배경 | 무조건 순백 `FFFFFF` |
| 제목 아래 컬러 액센트 라인 | 여백 + 헤더 hairline으로 구분 |
| 수식을 텍스트로 풀어쓰기 | `latex-equation-png`로 PNG 렌더 |
| 표를 면 채운 컬러 박스로 | ink 헤더 + hairline 보더 |
| 텍스트 박스 unicode "•" 직접 입력 | `bullet:{code:"2013"}` (en-dash) |

---

## 5. Workflow — 표준 절차

### Step 1. 입력 파악
- 마크다운 강의노트 → 헤딩/표/프롬프트/용어 박스에서 슬라이드 단위 추출
- 수식이 있으면 어떤 식이 어느 슬라이드에 들어갈지 매핑

### Step 2. 구조 설계 (15~18장 표준)
```
Cover → Agenda → 개념/이론 (모듈별 2~4장)
       → 실습 개요(Pipeline) → 단계별(Prompt Box)
       → Takeaway → Closing/Next
```

### Step 3. 수식 PNG 생성 (수식 슬라이드가 있을 때만)
`latex-equation-png` 스킬의 `render_eq.py`로 `eq/*.png` 생성 → 비율(ratio=w/h) 확보.

### Step 4. 코드 작성
`scripts/template.js`를 작업 디렉터리에 복사 → `const D = require("./template.js")` → `D.init(과목명)` 후 각 슬라이드를 IIFE 블록 `{ const s = D.slide(); ... }`로 작성 → `D.save("파일.pptx")`.

### Step 5. 빌드 + QA
```bash
NODE_PATH=$(npm root -g) node deck.js
python /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf out.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 110 out.pdf slide
```
- `view`로 점검. 자주 나오는 결함: 표 행 높이 부족으로 한글 잘림 → `rh` ↑ / 프롬프트 박스 높이 부족 → `h` ↑ / footer(y>6.9) 침범 → 콘텐츠 y 조정.

### Step 6. 출력
`/mnt/user-data/outputs/`로 복사 후 `present_files`. 응답 끝에 슬라이드 구성표 한 페이지 요약.

---

## 6. 결합 스킬

- **`latex-equation-png`** (수식 강의 시 필수) — 식 → PNG → `eqC`로 중앙 배치.
- **`korean-md-standard` / `obsidian-math-md`** — 원본 강의노트 작성 시.
- **`obsidian-infographic`** (선택) — 복잡한 다이어그램이 필요할 때.

---

## 7. 시작점 — `scripts/template.js`

토큰(C·F·LX·CW) + 공통 프레임(nav·title·subtitle·footer) + 콘텐츠 요소(head·subhead·note·bullets·rule·bigDef·table·promptBox·pipeline·eqC)가 모두 구현되어 있다. 새 덱은 이 파일을 복사한 뒤 슬라이드 블록만 채우면 된다.
