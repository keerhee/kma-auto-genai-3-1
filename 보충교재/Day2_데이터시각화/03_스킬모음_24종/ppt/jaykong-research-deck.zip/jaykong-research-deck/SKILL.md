---
name: jaykong-research-deck
description: Jaykong Research 톤의 institutional 리서치 PPT 슬라이드를 생성하는 룰북. "리서치 장표", "IPO 리서치 슬라이드", "Jaykong 톤", "기관 리서치 PPT", "장표 만들어줘", "공모/상장/PER/할인율 차트", "KEY INSIGHT 박스", "dual-panel 비교 차트", "triple-panel", "산점도 R²", "스택바" 등의 표현이 나오면 반드시 이 스킬을 사용한다. 자연어 한두 줄로 헤더·차트·인사이트가 일관된 톤으로 자동 생성되어야 하는 모든 institutional 리서치 슬라이드 작업에 트리거한다. pptxgenjs 기반 단일 파일 출력.
---

# Jaykong Research Deck — 룰북 v3

## 0. 이 스킬의 목적

자연어 한두 줄 입력으로 **항상 같은 톤의** 기관 리서치 슬라이드를 만든다.
원칙: **"디자인 = 로직"**. 룰을 고정하면 자연어로 장표가 떨어진다.

레퍼런스 톤: Jaykong Research IPO Market Review (2026.03 시리즈) — 3장 모두 본 룰북이 커버해야 한다.

---

## 1. Frame Spec — 모든 슬라이드 공통 골격

```
┌─────────────────────────────────────────────────────────┐
│ Jaykong Research │ Section          Confidential        │  ← Header
│                                     YYYY.MM | 문서명     │
│ ─────────────────────────────────────────────────────── │  ← 구분선 ★
│                                                         │
│ 본문 타이틀 (24pt Bold)                                  │
│ 부제 / 데이터 범위·단위·n수 (12pt Gray)                   │
│                                                         │
│  ┌─ Panel ──────────────┐   ┌─ Panel ──────────────┐    │
│  │ 패널타이틀     단위메타│   │ 패널타이틀     단위메타│  │
│  │ ■범례 ■범례          │   │ ■범례 ■범례          │   │
│  │  [Chart]             │   │  [Chart]             │   │
│  └──────────────────────┘   └──────────────────────┘    │
│                                                         │
│ ┌─ KEY INSIGHT ──────────────────────────────────────┐  │
│ │ • 라벨1: 설명 + 숫자근거                            │  │
│ │ • 라벨2: 설명 + 숫자근거                            │  │
│ │ • 라벨3: 설명 + 숫자근거                            │  │
│ └────────────────────────────────────────────────────┘  │
│ Source: 출처. 제외/포함 조건                              │
│                                                    [N]  │
└─────────────────────────────────────────────────────────┘
```

### Header 규약
- 좌상단: `Jaykong Research` — 11pt Bold, Navy `#1E3A8A`
- 좌상단 옆: 섹션명 (`IPO Market Overview`, `IPO Market Analysis`, `Pricing` 등) — 10pt Regular, Gray `#6B7280`
- 우상단 1행: `Confidential` — 8pt Regular, Black `#111827`
- 우상단 2행: `YYYY.MM | 문서명` — 8pt Regular, Gray `#6B7280`
- **헤더 아래 가로 구분선** ★ — 1pt Gray `#D1D5DB`, 좌우 여백 따라 가로 전체

### Title 규약
- 본문 타이틀: 24pt Bold, Black `#111827`
- 타이틀에 방향 강조어(↑, ↓, vs, X) 들어가면 그대로 유지
- 부제: 12pt Regular, Gray `#6B7280`
- 부제에 **반드시** 들어가야 할 것:
  - 데이터 기간 ("2016-2025", "2023.07 이후")
  - 막대/라인 정의 ("공모규모(막대), 상장건수·평균공모규모(꺾은선)")
  - 제외/포함 조건 ("(SPAC 제외)")
  - 통계 메타 — n수, percentile ("(제도변경 이후, n=195~198)", "(25-75th percentile)")

### Footer 규약
- `Source:` 라인 — 8pt, Gray `#9CA3AF`
- 형식 고정: `Source: 데이터출처. 제외/포함 조건(별도 명시 시 포함).`
- 우하단 페이지 번호 — 8pt Bold, Gray `#6B7280`

---

## 2. Color Palette — 절대 다른 색 쓰지 말 것

```javascript
const COLORS = {
  // Navy 시리즈 (구성·카테고리 스택바, 강조 라인)
  navy900:    "1E3A8A",  navy700:    "1D4ED8",
  navy500:    "3B82F6",  navy400:    "60A5FA",
  navy300:    "93C5FD",  navy100:    "DBEAFE",

  // 회색 (시계열 막대 — 추이)
  barGray:    "E5E7EB",  // 단일 시계열 막대 (슬라이드1)
  barLight:   "F3F4F6",  // 박스플롯 박스 fill (슬라이드3)

  // 보조 라인
  beige:      "C9B896",  // 점선 보조 라인

  // 패널 / 인사이트
  panelBg:    "F9FAFB",  // 패널 카드 배경
  panelBd:    "E5E7EB",  // 패널 테두리
  insightBg:  "EFF6FF",  // KEY INSIGHT 배경
  insightBd:  "BFDBFE",  // KEY INSIGHT 테두리

  // 차트 내부 callout
  calloutBg:  "FEF3C7",
  calloutBd:  "FCD34D",

  // 텍스트
  textBlack:  "111827",  textGray: "6B7280",  textLight: "9CA3AF",
  red:        "DC2626",
};
```

### 색상 사용 결정 규칙 (★ 중요)

| 차트 의도 | 색상 |
|---------|------|
| **시계열 단일 막대** (예: 연도별 공모규모) | `barGray` 단일 |
| **카테고리 구성 스택바** (예: PER/EV/EBITDA/PBR/PSR/기타) | `navy` 그라데이션 (큰 카테고리=진한색) |
| **메인 라인** (가장 중요한 지표) | `navy900` 실선 2pt + 마커 |
| **보조 라인** (덜 중요) | `beige` 점선 1.5pt + 마커 |
| **2개 라인 비교** (예: 할인율 상단 vs 하단) | `navy900` + `beige` 둘 다 실선 |
| **박스플롯/밴드** | 박스 fill = `barLight`, 중앙선 = `navy900` |
| **산점도** | 점 = `navy900` 30% 투명, 회귀선 = `beige` 점선 |

---

## 3. Layout Patterns — 6개

| 패턴 | 트리거 키워드 | 용도 | 레퍼런스 |
|------|--------------|------|---------|
| `dual-panel` | "vs", "비교", "좌우" | 좌우 2패널, 같은 차트 종류 | 슬라이드1 |
| `triple-scatter` | "산점도 3개", "R²" | 3패널 산점도+회귀선 | 슬라이드2 |
| `triple-panel-mixed` | "3패널", "구성+밴드+추이" | 3패널, 차트 종류 다름 | 슬라이드3 |
| `bar-line-combo` | "막대+꺾은선" | 단일 차트, 막대+라인 | (dual 내부) |
| `single-hero` | "한 차트", "단일" | 큰 차트 하나 | — |
| `table-insight` | "표", "테이블" | 표 + 인사이트 | — |

---

## 4. Panel Card 규약 ★

3패널 이상 또는 차트 종류가 섞이면 **각 패널을 카드로 감싼다**.

### 카드 스타일
- 배경: `panelBg` (#F9FAFB)
- 테두리: 1pt `panelBd` (#E5E7EB)
- 모서리: 둥근 (radius 0.05 inch ≒ 4px)
- 안쪽 패딩: 0.15 inch

### 카드 내부 구조 (위→아래)
1. **패널 타이틀** (좌측) — 13pt Bold, `textBlack`
2. **단위 메타** (우측, 같은 줄) — 9pt Regular, `textGray`
   예: `건(%)`, `배(x), P25-P75`, `%`
3. **범례** — 한 줄, 색상칩(■) + 8pt 라벨
4. **차트 영역**

### 카드 안 쓰는 경우
2패널이고 같은 차트 종류일 때(슬라이드1/2)는 카드 없이 **패널 타이틀만 굵게**.
카드는 `triple-panel-mixed`에서만 필수.

---

## 5. Chart Grammar

### 5.1 단일 시계열 막대 (슬라이드1)
- 색: `barGray` 단일
- 값 라벨: 막대 위 중앙, 10pt `textBlack`
- 단위 표기 필수

### 5.2 카테고리 구성 스택바 (슬라이드3 좌)
- 색: `navy` 그라데이션 (큰 비중=`navy900`, 작은=`navy100`)
- **2단 라벨** ★: 스택 안에 `숫자 + 비율` 두 줄
  - 1행: `7건` — 11pt Bold
  - 2행: `(8%)` — 9pt Regular
  - 색: 진한 배경 위 → 흰색 / 옅은 배경 위 → `textBlack`

### 5.3 메인 라인
- 색: `navy900` 실선 2pt
- 마커: 동그라미 4×4px
- 값 라벨: 10pt Bold `navy900`

### 5.4 보조 라인
- 색: `beige` 점선 1.5pt
- 마커: 동그라미

### 5.5 박스플롯/밴드 (슬라이드3 가운데)
- 박스 fill: `barLight`
- 박스 외곽선: 없음 또는 `panelBd`
- P25/P75 라벨: 박스 아래/위 9pt `textGray`
- 중앙선(평균): `navy900` 실선 + 마커, 값 라벨 Bold

### 5.6 산점도 (슬라이드2)
- 점: `navy900` alpha 0.3, 4px
- 회귀선: `beige` 점선 1.5pt
- **R² 라벨**: 패널 우상단(차트 영역 안), 11pt Bold `textBlack`
  형식: `R²=0.130` (등호 양쪽 공백 없음)

### 5.7 축
- 그리드 라인 **없음**
- 눈금 최소화 (X축 2~4년 간격, Y축 4~6 눈금)
- Y축 단위는 부제·패널 단위 메타에 표기, 축에는 숫자만

### 5.9 ★ Combo Chart 빌드 패턴 (막대 + 라인 + 보조라인)

pptxgenjs의 multi-type chart는 **secondary axis 비율 자동조정이 안 됨** → 막대가 짜부러짐.
**해결책**: 같은 (x, y, w, h) 좌표에 **3개 차트를 분리해서 z-order 순서대로 겹쳐 그린다.**

순서 (아래→위):
1. **막대 차트** (배경): 카테고리 축만 이 차트가 표시. 자체 Y스케일.
2. **메인 라인 차트**: 모든 축 숨김. 자체 Y스케일로 그려짐 → 라인이 막대 위에 자연스럽게 보임.
3. **보조 라인 차트** (점선): 모든 축 숨김. 자체 Y스케일.

각 차트의 `plotArea.fill = "none"`, `chartArea.fill = "none"`로 배경을 투명하게 만들어야 겹침이 자연스럽다.

자세한 구현 코드는 §9.2의 `addPanelChart()` 함수 참고.

### 5.8 차트 내부 어노테이션 (callout) ★
슬라이드3 가운데의 `'23.6 거래소 시행세칙 개정 / 시초가범위 60-400% 확대` 같은 메모.
- 위치: 차트 영역 안, 관련 시점 위
- 박스: `calloutBg` 배경, `calloutBd` 1pt 테두리, 둥근 모서리
- 텍스트: 9pt `textBlack`, 중앙 정렬, 2줄 이내

---

## 6. KEY INSIGHT Block — 항상 3불릿

### 박스 스타일
- 배경: `insightBg` (#EFF6FF)
- 테두리: 1pt `insightBd` (#BFDBFE)
- 모서리: 둥근 (radius 0.05 inch)
- 패딩: 0.15 inch
- 헤더: `KEY INSIGHT` — 9pt Bold `navy900`

### 불릿 작성 규칙
1. **3개**, 그 이상도 그 이하도 안 됨
2. 형식: `**라벨**: 설명 + 숫자근거`
3. 라벨은 짧고 명확 ("PER 평가 절대다수", "선행지표로서 기관경쟁률")
4. 숫자 필수 (조, 건, 억원, %, 배, R² 등)

### 글꼴
- 라벨만 Bold, 나머지 Regular
- 색은 모두 `textBlack`

### 예시 (3장)
```
[슬라이드1]
• 유가증권시장 대형딜 편중: 2021–22년 카카오뱅크·LG에너지솔루션으로 평균 공모규모 1.2~3.3조 기록. 2023년 이후 0.2조 수준으로 정상화
• 코스닥시장 안정적 물량: 연 49–76건, 평균 공모규모 270–620억원으로 변동 적음
• 2025년 양 시장 동반 회복: 유가증권시장 7건·2.2조, 코스닥시장 69건·2.3조

[슬라이드2]
• 선행지표로서 기관경쟁률: 확정공모가 및 일반청약경쟁률 결과는 기관경쟁률에 의해 좌우됨
• 청약경쟁률과 주가의 상관관계: 일반청약경쟁률에 의해 좌우되는 상장 후 주가
• 기관 대상 IR 중요성: 기관경쟁률이 확정공모가 및 주가 수익률에 큰 영향, 기관 대상 사전 IR 중요성 부각

[슬라이드3]
• PER 평가 절대다수: '25년 PER 비중 79%로 평가방법 중 대부분 차지
• 멀티플 밴드: '23년 이후 IPO 시장 제도 개편 및 Secondary Market 호황으로 가치평가 상향조정
• 할인율: 공격적 Comparable 산출 대비 상대적으로 높은 할인율로 투자자 관심도 고취
```

---

## 7. 자연어 → 슬라이드 매핑 워크플로우

### Step 1: 입력 파싱
- "유가증권 vs 코스닥 공모규모/건수/평균 비교" → `dual-panel` + `bar-line-combo` × 2
- "기관경쟁률 산점도 3개, R² 포함" → `triple-scatter`
- "평가방법별 건수, PER 멀티플 밴드, 할인율 추이" → `triple-panel-mixed`

### Step 2: 데이터 확보
**임의 숫자 만들지 말 것.** 데이터 없으면 사용자에 질문:
- 시계열: 연도, 막대값, 라인값들
- 산점도: x·y 좌표 배열, R² 값
- 스택바: 카테고리×연도 값 + 비율
- 박스플롯: 연도별 P25, P50, P75
- 어노테이션: 시점(연도) + 메모

### Step 3: pptxgenjs 코드 생성
§9 스켈레톤 베이스로 슬라이드 종류 선택해서 생성.

### Step 4: 인사이트 초안
데이터에서 직접 보이는 패턴만 적기 → 사용자 검토.

---

## 8. 체크리스트 (출력 전 매번)

### Header / Title / Footer
- [ ] `Jaykong Research` 11pt Bold Navy
- [ ] 섹션명 (`IPO Market Overview` / `Analysis` / `Pricing` 등)
- [ ] `Confidential` + `YYYY.MM | 문서명` 우상단
- [ ] **헤더 하단 가로 구분선** ★
- [ ] 본문 타이틀 24pt Bold
- [ ] 부제에 기간 + 단위 + 제외 조건 + n수
- [ ] Source 라인 형식 정확
- [ ] 우하단 페이지 번호 Bold

### Panel
- [ ] `triple-panel-mixed`면 카드 (배경+테두리+둥근 모서리)
- [ ] 패널 타이틀(좌 13pt Bold) + 단위 메타(우 9pt Gray)
- [ ] 범례가 패널 타이틀 바로 아래

### Chart
- [ ] 시계열 막대 = 회색, 카테고리 스택바 = navy 그라데이션
- [ ] 메인 라인 = navy 실선, 보조 라인 = beige 점선
- [ ] 그리드 라인 없음
- [ ] 산점도면 R² 우상단 Bold
- [ ] 스택바면 2단 라벨(숫자+비율)
- [ ] callout 어노테이션 필요시 표기

### Insight
- [ ] 박스 배경+테두리+`KEY INSIGHT` 헤더
- [ ] 정확히 3불릿
- [ ] 각 불릿 라벨 Bold + 콜론 + 설명 + 숫자

### Data
- [ ] 임의 숫자 없음

---

## 9. Reference Implementation — pptxgenjs 스켈레톤

### 9.1 공통 함수

```javascript
const PptxGenJS = require("pptxgenjs");

const COLORS = {
  navy900: "1E3A8A", navy700: "1D4ED8", navy500: "3B82F6",
  navy400: "60A5FA", navy300: "93C5FD", navy100: "DBEAFE",
  barGray: "E5E7EB", barLight: "F3F4F6", beige: "C9B896",
  panelBg: "F9FAFB", panelBd: "E5E7EB",
  insightBg: "EFF6FF", insightBd: "BFDBFE",
  calloutBg: "FEF3C7", calloutBd: "FCD34D",
  textBlack: "111827", textGray: "6B7280", textLight: "9CA3AF",
  red: "DC2626",
};
const NAVY_GRADIENT = [COLORS.navy900, COLORS.navy500, COLORS.navy400, COLORS.navy300, COLORS.navy100];

function addHeader(slide, section, docMeta) {
  slide.addText("Jaykong Research", {
    x: 0.4, y: 0.25, w: 1.8, h: 0.25,
    fontSize: 11, bold: true, color: COLORS.navy900, fontFace: "Arial",
  });
  slide.addText(section, {
    x: 2.3, y: 0.25, w: 4.0, h: 0.25,
    fontSize: 10, color: COLORS.textGray, fontFace: "Arial",
  });
  slide.addText("Confidential", {
    x: 11.0, y: 0.18, w: 2.0, h: 0.20,
    fontSize: 8, color: COLORS.textBlack, align: "right",
  });
  slide.addText(docMeta, {
    x: 10.5, y: 0.36, w: 2.5, h: 0.20,
    fontSize: 8, color: COLORS.textGray, align: "right",
  });
  slide.addShape("line", {
    x: 0.4, y: 0.65, w: 12.5, h: 0,
    line: { color: "D1D5DB", width: 1 },
  });
}

function addTitle(slide, title, subtitle) {
  slide.addText(title, {
    x: 0.4, y: 0.78, w: 12.5, h: 0.45,
    fontSize: 24, bold: true, color: COLORS.textBlack, fontFace: "Arial",
  });
  slide.addText(subtitle, {
    x: 0.4, y: 1.25, w: 12.5, h: 0.3,
    fontSize: 12, color: COLORS.textGray, fontFace: "Arial",
  });
}

function addInsightBox(slide, insights, y = 5.5) {
  slide.addShape("roundRect", {
    x: 0.4, y, w: 12.5, h: 1.55,
    fill: { color: COLORS.insightBg },
    line: { color: COLORS.insightBd, width: 1 },
    rectRadius: 0.05,
  });
  slide.addText("KEY INSIGHT", {
    x: 0.6, y: y + 0.08, w: 3, h: 0.22,
    fontSize: 9, bold: true, color: COLORS.navy900,
  });
  insights.forEach((it, i) => {
    slide.addText([
      { text: "• ", options: { color: COLORS.textBlack, bold: true } },
      { text: it.label + ": ", options: { bold: true, color: COLORS.textBlack } },
      { text: it.body, options: { color: COLORS.textBlack } },
    ], {
      x: 0.6, y: y + 0.35 + i * 0.32, w: 12.1, h: 0.3,
      fontSize: 10, fontFace: "Arial",
    });
  });
}

function addFooter(slide, source, pageNum) {
  slide.addText(source, {
    x: 0.4, y: 7.15, w: 11.5, h: 0.25,
    fontSize: 8, color: COLORS.textLight,
  });
  slide.addText(String(pageNum), {
    x: 12.7, y: 7.15, w: 0.3, h: 0.25,
    fontSize: 8, bold: true, color: COLORS.textGray, align: "right",
  });
}

function addPanelCard(slide, x, y, w, h, title, unitMeta, legendItems) {
  slide.addShape("roundRect", {
    x, y, w, h,
    fill: { color: COLORS.panelBg },
    line: { color: COLORS.panelBd, width: 1 },
    rectRadius: 0.05,
  });
  slide.addText(title, {
    x: x + 0.15, y: y + 0.1, w: w * 0.7, h: 0.3,
    fontSize: 13, bold: true, color: COLORS.textBlack,
  });
  slide.addText(unitMeta, {
    x: x + w * 0.7, y: y + 0.13, w: w * 0.28, h: 0.25,
    fontSize: 9, color: COLORS.textGray, align: "right",
  });
  let cx = x + 0.15;
  legendItems.forEach(item => {
    slide.addShape("rect", {
      x: cx, y: y + 0.45, w: 0.1, h: 0.1,
      fill: { color: item.color }, line: { color: item.color },
    });
    slide.addText(item.label, {
      x: cx + 0.13, y: y + 0.42, w: 1.2, h: 0.18,
      fontSize: 8, color: COLORS.textBlack,
    });
    cx += 0.13 + item.label.length * 0.07 + 0.15;
  });
}
```

### 9.2 슬라이드 빌더 — 3장 각각

```javascript
const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE";  // 13.333 x 7.5 inch

// === 슬라이드 1: dual-panel ===
// ★ v3 패턴: 막대/메인라인/보조라인을 3개 독립 차트로 분리, 같은 좌표에 겹쳐 그림

// 패널 헤더 (타이틀 + 한 줄 범례)
function addPanelHeader(slide, x, y, w, panelTitle, legendItems) {
  slide.addText(panelTitle, { x, y, w, h: 0.3, fontSize: 13, bold: true, color: COLORS.textBlack });
  const itemWidth = 1.6;
  legendItems.forEach((item, i) => {
    const cx = x + i * itemWidth;
    slide.addShape("rect", {
      x: cx, y: y + 0.38, w: 0.12, h: 0.12,
      fill: { color: item.color }, line: { color: item.color },
    });
    slide.addText(item.label, {
      x: cx + 0.18, y: y + 0.34, w: itemWidth - 0.2, h: 0.2,
      fontSize: 9, color: COLORS.textBlack,
    });
  });
}

// ★ 3개 차트를 같은 좌표에 겹쳐 그림 — combo chart 짜부러짐 방지
function addPanelChart(pptx, slide, x, y, w, h, labels, barValues, lineValues, avgValues) {
  // 차트1: 막대 (배경) — 카테고리 축만 이 차트가 표시
  slide.addChart(pptx.ChartType.bar,
    [{ name: "공모규모(조원)", labels, values: barValues }],
    {
      x, y, w, h,
      barDir: "col", chartColors: [COLORS.barGray], barGapWidthPct: 60,
      showValue: true, dataLabelFontSize: 9, dataLabelColor: COLORS.textGray,
      dataLabelPosition: "outEnd", dataLabelFormatCode: "0.0",
      catAxisLabelFontSize: 9, catAxisLabelColor: COLORS.textGray,
      valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" },
      plotArea: { fill: { type: "none" } }, showLegend: false,
    }
  );

  // 차트2: 메인 라인 (가운데 z-order) — 자체 Y스케일
  slide.addChart(pptx.ChartType.line,
    [{ name: "상장건수(건)", labels, values: lineValues }],
    {
      x, y, w, h,
      chartColors: [COLORS.navy900], lineSize: 2,
      lineDataSymbol: "circle", lineDataSymbolSize: 7,
      showValue: true, dataLabelFontSize: 10, dataLabelColor: COLORS.navy900,
      dataLabelFontBold: true, dataLabelPosition: "t",
      catAxisHidden: true, valAxisHidden: true,
      valGridLine: { style: "none" }, catGridLine: { style: "none" },
      plotArea: { fill: { type: "none" } }, chartArea: { fill: { type: "none" } },
      showLegend: false,
    }
  );

  // 차트3: 보조 라인 (가장 위 z-order) — 점선
  slide.addChart(pptx.ChartType.line,
    [{ name: "평균공모(억원)", labels, values: avgValues }],
    {
      x, y, w, h,
      chartColors: [COLORS.beige], lineSize: 1.5, lineDash: "dash",
      lineDataSymbol: "circle", lineDataSymbolSize: 6,
      showValue: true, dataLabelFontSize: 8, dataLabelColor: COLORS.beige,
      dataLabelPosition: "t",
      catAxisHidden: true, valAxisHidden: true,
      valGridLine: { style: "none" }, catGridLine: { style: "none" },
      plotArea: { fill: { type: "none" } }, chartArea: { fill: { type: "none" } },
      showLegend: false,
    }
  );
}

function buildSlide1(pptx, data) {
  const s = pptx.addSlide();
  s.background = { color: "FFFFFF" };
  addHeader(s, "IPO Market Overview", "2026.03 | IPO Market Review");
  addTitle(s,
    "대기업 중심의 유가증권시장 vs 기술상장기업 중심의 코스닥시장",
    "2016-2025 유가증권시장/코스닥시장별 공모규모(막대), 상장건수·평균공모규모(꺾은선) (SPAC 제외)"
  );

  const legend = [
    { color: COLORS.barGray, label: "공모규모(조원)" },
    { color: COLORS.navy900, label: "상장건수(건)" },
    { color: COLORS.beige,   label: "평균공모(억원)" },
  ];

  // 좌패널: 유가증권
  addPanelHeader(s, 0.4, 1.7, 6.0, "유가증권시장", legend);
  addPanelChart(pptx, s, 0.4, 2.25, 6.0, 3.0,
    data.years, data.kospi.offering, data.kospi.count, data.kospi.avg);

  // 우패널: 코스닥
  addPanelHeader(s, 7.0, 1.7, 6.0, "코스닥시장", legend);
  addPanelChart(pptx, s, 7.0, 2.25, 6.0, 3.0,
    data.years, data.kosdaq.offering, data.kosdaq.count, data.kosdaq.avg);

  addInsightBox(s, data.insights, 5.5);
  addFooter(s, "Source: KRX KIND, DART 투자설명서. SPAC/합병상장 제외(별도 명시 시 포함).", 1);
}

// === 슬라이드 2: triple-scatter ===
function buildSlide2(pptx, data) {
  const s = pptx.addSlide();
  s.background = { color: "FFFFFF" };
  addHeader(s, "IPO Market Analysis", "2026.03 | IPO Market Review");
  addTitle(s,
    "기관경쟁률은 확정공모가 및 일반청약경쟁률과 동조화, 일반청약경쟁률은 종가수익률과 높은 상관관계",
    "2023.07 이후 기관경쟁률·일반청약경쟁률 vs 밴드대비 공모가·종가수익률·상호 상관 (제도변경 이후, n=195~198)"
  );
  const panels = [
    { x: 0.4, title: "기관경쟁 vs 밴드대비 공모가", r2: 0.130, points: data.scatter1 },
    { x: 4.7, title: "기관경쟁률 vs 일반청약경쟁률", r2: 0.396, points: data.scatter2 },
    { x: 9.0, title: "일반청약경쟁률 vs 종가수익률", r2: 0.278, points: data.scatter3 },
  ];
  panels.forEach(p => {
    s.addText(p.title, { x: p.x, y: 1.65, w: 3.5, h: 0.3, fontSize: 13, bold: true });
    s.addText(`R²=${p.r2.toFixed(3)}`, {
      x: p.x + 2.4, y: 1.95, w: 1.5, h: 0.25,
      fontSize: 11, bold: true, color: COLORS.textBlack, align: "right",
    });
    s.addChart(pptx.ChartType.scatter, p.points, {
      x: p.x, y: 2.1, w: 4.0, h: 3.0,
      chartColors: [COLORS.navy900],
      catAxisLabelFontSize: 8, valAxisLabelFontSize: 8,
    });
  });
  addInsightBox(s, data.insights);
  addFooter(s, "Source: KRX KIND, DART 투자설명서. SPAC/합병상장 제외(별도 명시 시 포함).", 7);
}

// === 슬라이드 3: triple-panel-mixed ===
function buildSlide3(pptx, data) {
  const s = pptx.addSlide();
  s.background = { color: "FFFFFF" };
  addHeader(s, "Pricing", "2026.03 | IPO Market Review");
  addTitle(s,
    "PER 위주 가치평가 ↓, 멀티플 및 할인율 증가추세",
    "2021-2025 평가방법별 건수, PER 멀티플 밴드(25-75th percentile), 할인율 추이"
  );

  // 패널 1: 평가방법별 스택바
  addPanelCard(s, 0.4, 1.65, 4.1, 3.6,
    "평가방법별 건수", "건(%)",
    [
      { color: COLORS.navy900, label: "PER" },
      { color: COLORS.navy500, label: "EV/EBITDA" },
      { color: COLORS.navy400, label: "PBR" },
      { color: COLORS.navy300, label: "PSR" },
      { color: COLORS.navy100, label: "기타" },
    ]
  );
  s.addChart(pptx.ChartType.bar, data.stackData, {
    x: 0.55, y: 2.3, w: 3.8, h: 2.85,
    barDir: "col", barGrouping: "stacked",
    chartColors: NAVY_GRADIENT,
    showValue: true, dataLabelFontSize: 9,
    catAxisLabelFontSize: 9, valAxisHidden: true, showLegend: false,
  });

  // 패널 2: PER 멀티플 밴드 (박스+라인+callout)
  addPanelCard(s, 4.6, 1.65, 4.1, 3.6,
    "PER 멀티플 밴드", "배(x), P25-P75",
    [
      { color: COLORS.barLight, label: "P25~P75" },
      { color: COLORS.navy900, label: "평균" },
    ]
  );
  // 박스플롯은 직접 지원 안 됨 → addShape로 박스 그리고 line chart 오버레이
  s.addShape("roundRect", {
    x: 5.5, y: 2.55, w: 2.0, h: 0.5,
    fill: { color: COLORS.calloutBg },
    line: { color: COLORS.calloutBd, width: 1 },
    rectRadius: 0.03,
  });
  s.addText("'23.6 거래소 시행세칙 개정\n시초가범위 60-400% 확대", {
    x: 5.5, y: 2.55, w: 2.0, h: 0.5,
    fontSize: 8, color: COLORS.textBlack, align: "center", valign: "middle",
  });

  // 패널 3: 할인율 추이 (라인 2개)
  addPanelCard(s, 8.8, 1.65, 4.1, 3.6,
    "할인율 추이 (평균)", "%",
    [
      { color: COLORS.beige, label: "할인율 하단" },
      { color: COLORS.navy900, label: "할인율 상단" },
    ]
  );
  s.addChart(pptx.ChartType.line, [
    { name: "할인율 하단", labels: data.years3, values: data.discountLow },
    { name: "할인율 상단", labels: data.years3, values: data.discountHigh },
  ], {
    x: 8.95, y: 2.3, w: 3.8, h: 2.85,
    chartColors: [COLORS.beige, COLORS.navy900],
    lineSize: 2, showValue: true, dataLabelFontSize: 9,
    catAxisLabelFontSize: 9, valAxisHidden: true, showLegend: false,
  });

  addInsightBox(s, data.insights);
  addFooter(s, "Source: KRX KIND, DART 투자설명서. SPAC/합병상장 제외(별도 명시 시 포함).", 4);
}

pptx.writeFile({ fileName: "/mnt/user-data/outputs/jaykong-deck.pptx" });
```

### 9.3 구현 메모
- **combo chart**: pptxgenjs `addChart([...])`에 type별 객체 배열, secondary axis 옵션 필요할 수 있음
- **박스플롯**: 직접 지원 X. `addShape("rect")`로 박스 그리고 line chart 오버레이로 평균 표시
- **회귀선**: scatter chart `trendline` 옵션 또는 별도 line chart 오버레이
- **2단 라벨** (`7건 / (8%)`): 기본 dataLabel 1줄 → `addText`로 좌표 직접 계산해 그리기

---

## 10. 출력 규약

- 파일명: `jaykong-research-deck-{YYYYMMDD}.pptx` 또는 사용자 지정
- 저장 위치: `/mnt/user-data/outputs/`
- 마지막에 `present_files`로 노출

---

## 10.5 검증 기록

- **v1 → v2**: 슬라이드2(triple-scatter)·슬라이드3(triple-panel-mixed) 패턴, navy 그라데이션, 패널 카드, 헤더 구분선, callout 어노테이션 추가.
- **v2 → v3**: 실제 빌드 테스트 결과 combo chart의 막대 짜부러짐 문제 발견 → §5.9 "3개 차트 분리 패턴"으로 해결. §9.2 `addPanelChart()` 함수가 표준.

## 11. 확장 가이드

지금은 이 SKILL.md 한 파일로 충분. 같은 패턴 3번 이상 반복했을 때만 분리:

- `templates/dual-panel.js`
- `templates/triple-scatter.js`
- `templates/triple-panel-mixed.js`
- `templates/_common.js`
- `assets/logo.png`

지금 미리 만들지 말 것.
