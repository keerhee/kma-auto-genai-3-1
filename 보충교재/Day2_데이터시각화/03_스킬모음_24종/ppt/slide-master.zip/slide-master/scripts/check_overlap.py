#!/usr/bin/env python3
"""slide-master — 변환된 PPTX의 텍스트 박스 겹침 감사.

왜 필요한가:
    변환기는 <text> 하나를 글자 크기의 약 1.2배 높이 프레임으로 만들고,
    PowerPoint는 여기에 상하 여백을 더 붙인다. 그래서 SVG 렌더나 PDF 미리보기에서
    멀쩡해 보여도 PowerPoint에서 열면 제목과 부제가 겹치는 일이 생긴다.
    이 검사는 렌더가 아니라 실제 프레임 좌표를 재므로 그 사고를 결정적으로 잡는다.

사용:
    python3 scripts/check_overlap.py <파일.pptx> [--tol 0.02]

한 건이라도 나오면 SKILL.md 4.6의 베이스라인 간격 규칙으로
    다음_베이스라인 ≥ 이전_베이스라인 + 이전_font-size × 1.35
을 적용해 SVG를 고치고 다시 변환한다.
"""

import argparse
import sys

EMU = 914400


def main() -> int:
    ap = argparse.ArgumentParser(description="PPTX 텍스트 박스 겹침 감사")
    ap.add_argument("pptx", help="검사할 .pptx")
    ap.add_argument("--tol", type=float, default=0.02,
                    help="이 인치 이상 겹칠 때만 보고 (기본 0.02)")
    args = ap.parse_args()

    try:
        from pptx import Presentation
    except ImportError:
        print("[오류] python-pptx가 없다: pip install python-pptx", file=sys.stderr)
        return 1

    prs = Presentation(args.pptx)
    total = 0

    for i, slide in enumerate(prs.slides, 1):
        boxes = []
        for sh in slide.shapes:
            if not sh.has_text_frame:
                continue
            txt = sh.text_frame.text.strip()
            if not txt:
                continue
            boxes.append((
                sh.left / EMU, sh.top / EMU,
                (sh.left + sh.width) / EMU, (sh.top + sh.height) / EMU,
                txt.replace("\n", " ")[:24],
            ))

        hits = []
        for a in range(len(boxes)):
            for b in range(a + 1, len(boxes)):
                A, B = boxes[a], boxes[b]
                ox = min(A[2], B[2]) - max(A[0], B[0])
                oy = min(A[3], B[3]) - max(A[1], B[1])
                if ox > args.tol and oy > args.tol:
                    hits.append((ox, oy, A[4], B[4]))

        if hits:
            print(f"[겹침] slide {i} — {len(hits)}건")
            for ox, oy, ta, tb in hits:
                print(f"    가로 {ox:.3f}in · 세로 {oy:.3f}in | {ta!r} <-> {tb!r}")
        total += len(hits)

    print()
    if total == 0:
        print(f"[통과] {len(prs.slides)}장 · 텍스트 박스 겹침 0건")
        return 0

    print(f"[실패] 총 {total}건. 베이스라인 간격을 "
          f"'이전 font-size × 1.35' 이상으로 벌리고 다시 변환할 것.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
