#!/usr/bin/env python3
"""
fit_text_frames.py — svg_to_pptx.py 직후에 반드시 한 번 돌리는 교정 도구.

왜 필요한가
-----------
변환기는 각 <text>를 텍스트 프레임으로 옮기면서 프레임 폭(cx)을 자체 추정으로
잡는데, 이 추정이 실제 글자 폭보다 좁게 나오는 경우가 많다(실측: 261개 중 250개).
LibreOffice는 이걸 그냥 넘겨 렌더하므로 SKILL.md 6장의 시각 검수에서 안 보이지만,
PowerPoint는 좁은 상자 안에서 줄바꿈을 해버린다 — "MCMC"가 "MCM / C"로 쪼개지고,
넘친 줄이 아래 텍스트와 겹친다. 사용자는 "글씨가 겹친다"로 보고하게 된다.

무엇을 하는가
-------------
1. 설치된 실제 폰트 파일에서 각 프레임의 글자 폭을 측정한다(PIL getlength).
2. cx를 (실측 폭 + 여유)로 다시 쓴다. 넓힌 상자가 오른쪽 이웃 프레임의 글자를
   침범하지 않도록 클램프한다.
3. <a:spAutoFit/>를 <a:noAutofit/>로 바꾼다. autofit이 남아 있으면 렌더러가
   상자를 자기 폰트 계측으로 다시 재면서 좌표가 밀린다(LibreOffice에서
   좌측 정렬 텍스트가 가운데로 밀려 보이는 현상의 원인).

★ 편집은 전부 문자열 단위 정규식이다. slide XML을 ElementTree로 다시 직렬화하면
  네임스페이스 선언(xmlns:r 등)이 유실되어 PowerPoint가 파일을 복구 모드로 연다.
  실제로 그렇게 깨뜨린 적이 있다. 절대 XML 파서로 다시 쓰지 말 것.

사용법
------
    python3 scripts/svg_to_pptx.py <프로젝트> --no-merge -o out.pptx
    python3 scripts/fit_text_frames.py out.pptx            # 제자리 교정
    python3 scripts/fit_text_frames.py out.pptx -o fixed.pptx
    python3 scripts/fit_text_frames.py out.pptx --check    # 진단만, 수정 없음

옵션
----
    --pad-ratio 0.15   실측 폭 대비 여유 비율(기본 0.15). 배포처 폰트 버전이
                       다를 때를 대비한 완충이다. 0.10 밑으로는 내리지 말 것.
    --pad-min 24       최소 여유(px).
    --keep-autofit     spAutoFit을 그대로 둔다(권장하지 않음).
"""
import argparse, html, os, re, shutil, subprocess, sys, tempfile, zipfile

try:
    from PIL import ImageFont
except ImportError:
    sys.exit("Pillow가 필요하다:  pip install Pillow --break-system-packages")

EMU = 9525                      # 1px @ 96dpi
SP  = re.compile(r'<p:sp>.*?</p:sp>', re.S)

# ---------------------------------------------------------------- font lookup
_font_cache, _file_cache = {}, {}

def font_file(family, bold):
    key = (family, bold)
    if key in _file_cache:
        return _file_cache[key]
    pattern = f"{family}:bold" if bold else family
    path = None
    try:
        path = subprocess.run(["fc-match", "-f", "%{file}", pattern],
                              capture_output=True, text=True, timeout=10).stdout.strip()
    except Exception:
        pass
    if not path or not os.path.exists(path):
        path = subprocess.run(["fc-match", "-f", "%{file}", "sans-serif"],
                              capture_output=True, text=True).stdout.strip()
    _file_cache[key] = path
    return path

def measure(text, px, family, bold):
    key = (px, family, bold)
    if key not in _font_cache:
        try:
            _font_cache[key] = ImageFont.truetype(font_file(family, bold), px)
        except Exception:
            _font_cache[key] = ImageFont.load_default()
    return _font_cache[key].getlength(text)

# ------------------------------------------------------------------- geometry
def text_width(blk, default_family):
    """가장 넓은 문단의 폭(px). 텍스트가 없으면 None."""
    widest = 0.0
    for para in re.findall(r'<a:p>.*?</a:p>', blk, re.S):
        w = 0.0
        for rpr, tail in re.findall(r'<a:rPr\b([^>]*)>(.*?)</a:r>', para, re.S):
            m = re.search(r'<a:t>(.*?)</a:t>', tail, re.S)
            if not m:
                continue
            szm = re.search(r'sz="(\d+)"', rpr)
            sz  = int(szm.group(1)) if szm else 1800          # 100분의 1 pt
            fam = re.search(r'<a:latin typeface="([^"]+)"', tail)
            family = fam.group(1) if fam else default_family
            w += measure(html.unescape(m.group(1)),
                         max(1, round(sz / 100 * 4 / 3)), family, 'b="1"' in rpr)
        widest = max(widest, w)
    return widest or None

def parse(blk, default_family):
    off = re.search(r'<a:off x="(-?\d+)" y="(-?\d+)"\s*/>', blk)
    ext = re.search(r'<a:ext cx="(\d+)" cy="(\d+)"\s*/>', blk)
    if not off or not ext or '<a:t>' not in blk:
        return None
    w = text_width(blk, default_family)
    if w is None:
        return None
    am = re.search(r'<a:pPr algn="(\w+)"', blk)
    algn = am.group(1) if am else 'l'
    ox, oy = int(off.group(1)) / EMU, int(off.group(2)) / EMU
    cx, cy = int(ext.group(1)) / EMU, int(ext.group(2)) / EMU
    # 실제 글자가 시작하는 x (정렬을 반영)
    tl = ox if algn == 'l' else (ox + cx / 2 - w / 2 if algn == 'ctr' else ox + cx - w)
    return dict(off=off, ext=ext, w=w, algn=algn, ox=ox, oy=oy, cx=cx, cy=cy, tl=tl,
                texts=re.findall(r'<a:t>(.*?)</a:t>', blk))

def process_slide(xml, family, pad_ratio, pad_min, report, check_only):
    metas = [(m.start(), m.end(), m.group(0), parse(m.group(0), family)) for m in SP.finditer(xml)]
    live  = [d for *_, d in metas if d]

    if check_only:
        for d in live:
            if d['w'] > d['cx'] - 6:
                report['narrow'].append((d['cx'], d['w'], d['texts']))
        return xml

    edits = []
    for s, e, blk, d in metas:
        if not d:
            continue
        want = d['w'] + max(d['w'] * pad_ratio, pad_min)
        if d['algn'] == 'l':
            lim = None
            for o in live:
                if o is d or o['tl'] <= d['tl'] + 2:
                    continue
                if o['oy'] + o['cy'] <= d['oy'] + 2 or d['oy'] + d['cy'] <= o['oy'] + 2:
                    continue                      # 세로 밴드가 안 겹치면 이웃이 아니다
                lim = o['tl'] if lim is None else min(lim, o['tl'])
            if lim is not None:
                want = min(want, max(lim - d['ox'] - 8, d['w'] + 10))
        new_cx, old_cx = int(round(want * EMU)), int(round(d['cx'] * EMU))
        if new_cx == old_cx:
            continue
        ox = int(d['off'].group(1))
        nx = (ox + (old_cx - new_cx) // 2 if d['algn'] == 'ctr'
              else ox + (old_cx - new_cx) if d['algn'] == 'r' else ox)
        nb = blk.replace(d['off'].group(0), f'<a:off x="{nx}" y="{d["off"].group(2)}"/>', 1)
        nb = nb.replace(d['ext'].group(0), f'<a:ext cx="{new_cx}" cy="{d["ext"].group(2)}"/>', 1)
        report['grown' if new_cx > old_cx else 'shrunk'] += 1
        edits.append((s, e, nb))

    if not edits:
        return xml
    out, pos = [], 0
    for s, e, nb in edits:
        out.append(xml[pos:s]); out.append(nb); pos = e
    out.append(xml[pos:])
    return ''.join(out)

# ------------------------------------------------------------------------ cli
def main():
    ap = argparse.ArgumentParser(description="PPTX 텍스트 프레임 폭을 실측 폰트로 교정")
    ap.add_argument("pptx")
    ap.add_argument("-o", "--output", help="생략하면 제자리 교정")
    ap.add_argument("--font", default="Pretendard", help="rPr에 latin typeface가 없을 때 쓸 기본 서체")
    ap.add_argument("--pad-ratio", type=float, default=0.15)
    ap.add_argument("--pad-min", type=float, default=24.0)
    ap.add_argument("--keep-autofit", action="store_true")
    ap.add_argument("--check", action="store_true", help="진단만 하고 파일은 건드리지 않는다")
    a = ap.parse_args()

    dst = a.output or a.pptx
    work = tempfile.mkdtemp(prefix="fitframes_")
    with zipfile.ZipFile(a.pptx) as z:
        names = z.namelist(); z.extractall(work)

    report = {'grown': 0, 'shrunk': 0, 'narrow': [], 'autofit': 0}
    slides = sorted(f for f in os.listdir(os.path.join(work, 'ppt', 'slides')) if f.endswith('.xml'))
    for f in slides:
        p = os.path.join(work, 'ppt', 'slides', f)
        s = open(p, encoding='utf-8').read()
        s = process_slide(s, a.font, a.pad_ratio, a.pad_min, report, a.check)
        if not a.check and not a.keep_autofit:
            report['autofit'] += s.count('<a:spAutoFit/>')
            s = s.replace('<a:spAutoFit/>', '<a:noAutofit/>')
        if not a.check:
            open(p, 'w', encoding='utf-8').write(s)

    if a.check:
        n = len(report['narrow'])
        print(f"[진단] 좁은 프레임 {n}건 / 슬라이드 {len(slides)}장")
        for cx, w, t in report['narrow'][:20]:
            print(f"   ! cx={cx:.0f}px < 글자={w:.0f}px  {t}")
        shutil.rmtree(work, ignore_errors=True)
        sys.exit(1 if n else 0)

    # 재검증
    left = 0
    for f in slides:
        s = open(os.path.join(work, 'ppt', 'slides', f), encoding='utf-8').read()
        for m in SP.finditer(s):
            d = parse(m.group(0), a.font)
            if d and d['w'] > d['cx'] - 6:
                left += 1

    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
        for nm in names:
            z.write(os.path.join(work, nm), nm)
    shutil.rmtree(work, ignore_errors=True)
    print(f"[교정] 넓힘 {report['grown']} · 줄임 {report['shrunk']} · "
          f"autofit 해제 {report['autofit']} · 남은 좁은 프레임 {left}")
    print(f"[저장] {dst}")
    if left:
        print("  ! 좁은 프레임이 남았다. --pad-ratio를 낮추거나 SVG에서 글자를 줄일 것.")
        sys.exit(1)

if __name__ == "__main__":
    main()
