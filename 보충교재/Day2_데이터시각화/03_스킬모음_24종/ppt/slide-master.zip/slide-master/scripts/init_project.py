#!/usr/bin/env python3
"""slide-master — 프로젝트 스캐폴드.

사용:
    python3 scripts/init_project.py <프로젝트경로> [--pages 12]

만드는 것:
    <프로젝트경로>/spec_lock.md      ← pptx_structure.mode: flat (없으면 export가 거부된다)
    <프로젝트경로>/svg_output/       ← 여기에 P01.svg, P02.svg … 를 쓴다
    <프로젝트경로>/exports/          ← svg_to_pptx.py가 결과를 여기에 쓴다
"""

import argparse
from pathlib import Path

SPEC_LOCK = """# spec_lock.md

이 파일은 svg_to_pptx.py가 읽는 기계 계약이다. `## pptx_structure` 섹션이
없거나 mode가 flat/structured가 아니면 export가 거부된다.

## pptx_structure

- mode: flat

<!--
flat       = 자유 설계 / 브랜드 프리셋만 사용. 기본 PowerPoint Master + Blank Layout을
             쓰고, 모든 SVG 객체가 슬라이드 로컬 도형으로 들어간다. 대부분 여기.
structured = 덱/레이아웃 템플릿 경로. 페이지마다 Master/Layout 신원을 SVG에 선언해야
             하며 추가 계약 섹션이 필요하다. 이 스킬의 범위 밖.
-->
"""


def main() -> int:
    ap = argparse.ArgumentParser(description="slide-master 프로젝트 스캐폴드")
    ap.add_argument("project_path", help="만들 프로젝트 디렉터리")
    ap.add_argument("--pages", type=int, default=0,
                    help="빈 페이지 SVG를 N장 미리 만든다 (1280x720, 선택)")
    ap.add_argument("--width", type=int, default=1280,
                    help="캔버스 폭 px (기본 1280 = 표준 13.333in). 96px = 1in")
    ap.add_argument("--height", type=int, default=720,
                    help="캔버스 높이 px (기본 720 = 표준 7.5in)")
    args = ap.parse_args()

    root = Path(args.project_path)
    svg_dir = root / "svg_output"
    svg_dir.mkdir(parents=True, exist_ok=True)
    (root / "exports").mkdir(exist_ok=True)

    lock = root / "spec_lock.md"
    if lock.exists():
        print(f"  spec_lock.md 이미 있음 — 건드리지 않음: {lock}")
    else:
        lock.write_text(SPEC_LOCK, encoding="utf-8")
        print(f"  생성: {lock}")

    W, H = args.width, args.height
    for i in range(1, args.pages + 1):
        f = svg_dir / f"P{i:02d}.svg"
        if f.exists():
            continue
        f.write_text(
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
            f'viewBox="0 0 {W} {H}">\n'
            f'  <rect x="0" y="0" width="{W}" height="{H}" fill="#FFFFFF"/>\n'
            f'</svg>\n',
            encoding="utf-8",
        )
        print(f"  생성: {f}")

    print(f"\n준비 완료. svg_output/ 에 P01.svg 부터 쓰고 아래를 실행한다:")
    print(f"  python3 scripts/svg_quality_checker.py {svg_dir}")
    print(f"  python3 scripts/svg_to_pptx.py {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
