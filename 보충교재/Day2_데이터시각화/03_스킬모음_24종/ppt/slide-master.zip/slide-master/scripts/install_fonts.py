#!/usr/bin/env python3
"""slide-master — 번들 Pretendard를 이 실행 환경에 설치한다.

왜 필요한가:
    PPTX는 폰트를 파일에 내장하지 않는다. 그래서 이 컨테이너에 Pretendard가
    없으면 LibreOffice 검수 렌더가 다른 폰트로 대체되어 찍히고, 실제
    PowerPoint에서 열었을 때와 자간·줄바꿈·굵기가 어긋난다.
    Pretendard로 덱을 만든다면 페이지를 쓰기 전에 한 번 실행한다.

사용:
    python3 scripts/install_fonts.py

되돌리기:
    Linux : rm -rf ~/.fonts/Pretendard && fc-cache -f
    macOS : rm -f ~/Library/Fonts/Pretendard-*.otf
"""

import shutil
import subprocess
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "assets" / "fonts" / "Pretendard"

# 로컬 패치 — macOS는 fontconfig(~/.fonts + fc-cache)를 쓰지 않는다.
# 사용자 폰트는 ~/Library/Fonts 에 평평하게 두어야 시스템이 인식한다.
IS_MAC = sys.platform == "darwin"
DST = (Path.home() / "Library" / "Fonts") if IS_MAC else (Path.home() / ".fonts" / "Pretendard")


def main() -> int:
    if not SRC.is_dir():
        print(f"[오류] 번들 폰트를 찾을 수 없다: {SRC}", file=sys.stderr)
        return 1

    DST.mkdir(parents=True, exist_ok=True)
    n = 0
    for f in sorted(SRC.glob("*.otf")):
        shutil.copy2(f, DST / f.name)
        print(f"  설치: {f.name}")
        n += 1
    lic = SRC / "LICENSE.txt"
    if lic.exists() and not IS_MAC:
        shutil.copy2(lic, DST / "LICENSE.txt")

    if n == 0:
        print("[오류] 복사할 .otf가 없다", file=sys.stderr)
        return 1

    if IS_MAC:
        # macOS는 캐시 갱신이 필요 없다. system_profiler로 등록만 확인한다.
        try:
            out = subprocess.run(["system_profiler", "SPFontsDataType"],
                                 capture_output=True, text=True, check=True).stdout
            ok = "Pretendard" in out
        except (FileNotFoundError, subprocess.CalledProcessError):
            ok = None
        print(f"\n{n}개 설치: {DST}")
        if ok is False:
            print("[안내] 아직 시스템 폰트 목록에 없다 — 앱을 재시작하면 잡힌다.",
                  file=sys.stderr)
        print("\nSVG에서 이렇게 쓴다:")
        print('  font-family="Pretendard" font-weight="700"')
        print('  font-family="Pretendard SemiBold"   (중간 굵기를 이름으로 지정할 때)')
        return 0

    try:
        subprocess.run(["fc-cache", "-f", str(DST.parent)],
                       check=True, capture_output=True)
    except FileNotFoundError:
        print("[경고] fc-cache가 없다. 폰트 캐시를 갱신하지 못했다.", file=sys.stderr)
    except subprocess.CalledProcessError as e:
        print(f"[경고] fc-cache 실패: {e}", file=sys.stderr)

    try:
        out = subprocess.run(["fc-list", ":family"], capture_output=True,
                             text=True, check=True).stdout
        found = sorted({l.strip() for l in out.splitlines()
                        if "Pretendard" in l})
        if found:
            print(f"\n등록된 패밀리 ({n}개 설치):")
            for f in found[:12]:
                print(f"  {f}")
            print("\nSVG에서 이렇게 쓴다:")
            print('  font-family="Pretendard" font-weight="700"')
            print('  font-family="Pretendard SemiBold"   (중간 굵기를 이름으로 지정할 때)')
        else:
            print("\n[경고] fc-list에서 Pretendard를 찾지 못했다.", file=sys.stderr)
            return 1
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("\n[경고] fc-list로 확인하지 못했다. 렌더 결과를 눈으로 확인할 것.",
              file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
