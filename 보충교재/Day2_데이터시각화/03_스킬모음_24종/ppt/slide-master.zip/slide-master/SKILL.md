---
name: slide-master
description: 페이지를 SVG로 그린 뒤 네이티브 DrawingML PPTX로 구워, PowerPoint에서 도형·텍스트 상자 하나하나가 클릭 편집되는 덱을 만드는 스킬. "SVG로 PPT 만들어줘", "네이티브 편집되는 PPT", "slide master", "ppt-master", "SVG를 PPTX로", "svg_to_pptx", "그림이 아니라 진짜 도형으로", "PPT 이미지 말고 편집되는 개체로", "자유 레이아웃 슬라이드", "곡선·그라디언트 있는 슬라이드", "인포그래픽을 편집 가능한 PPT로", "세로형·SNS 비율 슬라이드", "카드뉴스를 PPTX로" 등의 표현이 나오면 반드시 이 스킬을 사용한다. pptxgenjs 기반의 report-navy-deck·apple-white-deck·report-white-deck가 정형 골격(표지·제목·표·패널)을 빠르게 찍어내는 스킬이라면, 이 스킬은 그 골격으로 표현할 수 없는 자유 도형·정밀 좌표·비정형 레이아웃을 SVG로 직접 그려 넣을 때 쓴다. 결과물은 래스터 이미지가 아니라 진짜 PowerPoint 개체다. hugohe3/ppt-master(MIT)의 변환기를 이 환경에 맞게 추려 담았다.
---

# Slide Master — SVG → 네이티브 PPTX 룰북 v1.1

## 0. 이 스킬의 목적

**AI는 SVG를 그리고, 변환기가 DrawingML로 옮긴다.**

SVG와 DrawingML은 둘 다 절대좌표 2D 벡터 언어라, 사각형·경로·그라디언트·그림자가
거의 일대일로 대응한다. 그래서 래스터화 없이 옮길 수 있고, 결과물의 모든 도형과
텍스트 상자가 **PowerPoint에서 클릭해 바로 고쳐지는 진짜 개체**로 남는다.

원칙: **"PowerPoint에서 열어서 고칠 수 없으면 그건 PPT가 아니다."**

### 언제 이 스킬을 쓰고, 언제 안 쓰는가

| 상황 | 스킬 |
|---|---|
| 표지·제목·표·2단 패널·번호 카드 같은 **정형 강의 골격** | `report-navy-deck` 등 pptxgenjs 계열 |
| 임의 좌표의 도형, 곡선·경로, 겹침·회전, 비정형 레이아웃 | **이 스킬** |
| 완성된 인포그래픽 **이미지**를 그대로 슬라이드에 담기 | `image-fullbleed-deck` |
| 강의 덱 안에 들어갈 **한 장짜리 도해** | `svg-infographic-navy-deck` (PNG로 얹음) |
| 세로형·1:1·스토리 등 **비 16:9 캔버스** | **이 스킬** (`-f` 포맷 인자) |

### 디자인은 이 스킬에 묶여 있지 않다

`report-navy-deck`은 네이비·오렌지 색과 카드 골격이 스킬에 고정돼 있다. **이 스킬에는
고정 디자인이 없다.** 색·서체 위계·격자·장식이 전부 SVG 안에서 정해지므로, 페이지를
어떻게 쓰느냐에 따라 완전히 다른 톤이 나온다 — 종이색 배경의 에디토리얼, 다크 테크,
스위스 미니멀, 브랜드 컬러 어느 쪽이든 같은 파이프라인으로 나온다.

덱을 시작할 때 **색 5~6개와 서체 크기 위계를 먼저 정하고 전 페이지에 고정**한다
(예: 배경 / 잉크 / 흐린 글자 / 강조 1색 / 괘선). 강조색은 **하나만** 둔다 — 자유롭게
쓸 수 있다는 것이 많이 써도 된다는 뜻은 아니다. `references/example-page.svg`는
어디까지나 좌표·크기 골격 예시이며, 색은 그 덱에 맞게 새로 정한다.

### `report-navy-deck`과 병행하는 법

경쟁하지 않는다. 저쪽은 골격이 정해진 덱을 빠르고 안전하게 찍어내고, 이쪽은
**골격을 벗어나야 할 때** 쓴다. 세 가지 방식이 가능하다.

| 방식 | 어떻게 | 언제 |
|---|---|---|
| **① 따로 쓴다** | 이 덱 전체를 이 스킬로만 만든다 | 자유 레이아웃이 처음부터 끝까지 필요할 때 |
| **② 도해만 얹는다 (권장)** | 덱은 `report-navy-deck`으로 만들고, 이 스킬로 그린 SVG를 **PNG로 렌더해** `figureSlide`에 넣는다 | 대부분. 강의 덱 안 한두 장이 자유 도해일 때 |
| **③ 두 pptx를 합친다** | 각각 만든 뒤 PowerPoint에서 슬라이드를 복사해 붙인다 | 자유 페이지가 여러 장 몰려 있을 때 |

**③이 성립하려면 슬라이드 규격이 같아야 한다.** `report-navy-deck`은 13.333 × 7.5in
이므로, 이 스킬도 **반드시 1280×720 캔버스**로 그린다(§3). 규격이 다르면 붙여넣을 때
크기가 어긋나고 다시 배치해야 한다.

②는 이미 `svg-infographic-navy-deck` 브리지 스킬이 담당하는 영역이니, 도해 한 장이면
그쪽을 먼저 본다. 이 스킬은 **페이지 자체를 SVG로 짜야 할 때**의 선택지다.

한 슬라이드 안에서 두 스킬을 섞지는 않는다 — 페이지 단위로 어느 쪽인지 정한다.

---

## 1. 전제 조건

```bash
pip install python-pptx XlsxWriter --break-system-packages
python3 scripts/install_fonts.py        # 번들 Pretendard 설치 (한국어 덱이면 사실상 필수)
```

`pip` 두 개면 변환이 돈다. 나머지는 파이썬 표준 라이브러리다.

> **★ 이 맥에서는 (로컬 규칙 — 반드시 지킬 것)**
>
> 이 스킬의 코드는 **Python 3.10+ 문법(`X | None`)** 을 쓰는데, macOS 기본 `python3`는
> 3.9.6이라 `import` 단계에서 `TypeError: unsupported operand type(s) for |`로 죽는다.
> 전용 런타임을 미리 만들어 두었으니 **모든 스크립트를 이 파이썬으로 실행한다.**
>
> ```bash
> PY=~/.venvs/slide-master/bin/python      # Python 3.12 + python-pptx + XlsxWriter
> $PY scripts/init_project.py <프로젝트> --pages 12
> $PY scripts/svg_quality_checker.py <프로젝트>/svg_output
> $PY scripts/svg_to_pptx.py <프로젝트> --no-merge -o <프로젝트>/exports/<Name>.pptx
> $PY scripts/fit_text_frames.py <프로젝트>/exports/<Name>.pptx
> $PY scripts/check_overlap.py <프로젝트>/exports/<Name>.pptx
> ```
>
> 아래 §5 워크플로의 `python3`는 전부 이 `$PY`로 바꿔 읽는다.
> 런타임이 없어졌다면 다시 만든다:
> `uv venv --python 3.12 ~/.venvs/slide-master && uv pip install --python ~/.venvs/slide-master/bin/python python-pptx XlsxWriter`
>
> `install_fonts.py`는 macOS를 인식하도록 로컬 패치되어 있다(`~/.fonts`+`fc-cache` 대신
> `~/Library/Fonts`). 이미 실행해 Pretendard 6종이 설치돼 있으므로 다시 돌릴 필요는 없다.
> 되돌리려면 `rm -f ~/Library/Fonts/Pretendard-*.otf`.

**`install_fonts.py`는 페이지를 쓰기 전에 한 번 돌린다.** PPTX는 폰트를 파일에
내장하지 않으므로, 이 실행 환경에 Pretendard가 없으면 §5의 LibreOffice 검수 렌더가
다른 폰트로 대체되어 찍힌다 — **검수 이미지가 실제 PowerPoint 화면과 달라져
자간·줄바꿈·굵기 사고를 못 잡는다.** `assets/fonts/Pretendard/`에 6종(Light ·
Regular · Medium · SemiBold · Bold · ExtraBold)이 번들되어 있고, 스크립트가
`~/.fonts`로 복사한 뒤 `fc-cache`를 갱신한다.
(원 저장소의 PDF·DOCX 변환, AI 이미지 생성, 라이브 프리뷰 등 부가 도구는
이 패키지에 담지 않았다 — 변환 코어와 품질 검사만 추렸다.)

---

## 2. 프로젝트 구조 (이 형태가 아니면 변환기가 거부한다)

```
<프로젝트>/
├── spec_lock.md          ← 필수. "## pptx_structure" + "- mode: flat"
├── svg_output/           ← 필수. 페이지 SVG를 여기에 P01.svg, P02.svg … 순서대로
└── exports/              ← 변환기가 결과 pptx를 여기에 쓴다
```

스캐폴드는 헬퍼로 만든다:

```bash
python3 scripts/init_project.py /home/claude/deck --pages 12   # 기본 1280x720
```

**`spec_lock.md`의 `- mode: flat` 줄이 없으면 export가 즉시 실패한다.**
자유 설계·브랜드 프리셋 경로는 전부 `flat`이다. `structured`는 덱/레이아웃 템플릿
경로용이고 페이지마다 Master/Layout 신원 선언이 추가로 필요하므로 이 스킬 범위 밖이다.

페이지 순서는 **파일명 정렬 순서**다. `P01`, `P02`, … 두 자리 제로패딩을 쓴다
(`P1`, `P10`, `P2` 순으로 섞이는 사고를 막는다).

---

## 3. 캔버스 — 16:9는 반드시 1280 × 720

**루트 `viewBox`가 슬라이드 치수의 유일한 권위다.** 변환기는 **96px = 1인치**로
캔버스를 슬라이드로 옮긴다. 즉 캔버스 px를 96으로 나눈 값이 슬라이드 인치다.

| 캔버스 | 만들어지는 슬라이드 | 판정 |
|---|---|---|
| **1280 × 720** | **13.333 × 7.5 in** | ✅ 표준 16:9. **기본값** |
| 1600 × 900 | 16.667 × 9.375 in | ❌ 규격 밖. 아래 참고 |
| 1024 × 768 | 10.667 × 8 in | 4:3 |
| 1080 × 1080 | 11.25 × 11.25 in | 정사각(SNS) |
| 1080 × 1920 | 11.25 × 20 in | 세로 스토리 |

**1600×900으로 그리면 안 되는 이유**: 슬라이드가 16.667in로 만들어져 표준 덱보다
25% 크다. 발표할 때는 화면에 맞춰 축소되므로, **같은 pt여도 화면에서는 20% 작게 보인다.**
"그냥 두면 글씨가 작다"의 정확한 원인이 이것이다. 다른 덱과 슬라이드를 섞을 수도 없다.

**`-f`로 뒤늦게 규격을 바꾸지 말 것.** 1600×900 SVG에 `-f ppt169`를 주면 슬라이드
치수만 13.333in로 줄고 **도형 좌표는 따라오지 않아 우측·하단이 잘려 나간다**(검증됨).
`-f`는 처음부터 그 규격으로 그렸을 때만 쓴다. 16:9는 **1280×720으로 그리고 `-f` 없이 변환**한다.

### 폰트 크기 — 1280 캔버스에서 **1px = 0.75pt** (정확히 나눠떨어짐)

| 용도 | 화면 pt | **SVG font-size** |
|---|---|---|
| 페이지 제목 | 32pt | **43px** |
| **본문 · 패널 불릿 · 표 · 배너 (기본값)** | **20pt** | **27px** |
| 캡션 | 18pt | 24px |
| **절대 하한** | **16pt** | **21px** |
| nav 칩 · 푸터 · 페이지번호 (chrome 예외) | 12pt | 16px |
| 코드·명령어 리터럴 (예외) | 15pt | 20px |

**본문은 27px가 기본이다. 21px 미만은 금지다.** 재직자·현장·임원 강의는 예외 없이
27px로 두고, 안 들어가면 글자를 줄이거나 **페이지를 나눈다** — 폰트를 내리지 않는다.
`report-navy-deck`의 `field` 모드(본문 20pt)와 **정확히 같은 실물 크기**로 맞춘 값이다.

27px 본문은 한 줄에 한글 **18~20자**가 들어간다(패널 폭 566px 기준). 그 이상은
`tspan`으로 손수 끊는다.

---

## 4. ★ 검증된 작성 규칙 (이 환경에서 직접 확인한 것)

### 4.1 CSS `<style>` 클래스를 쓰지 말고 인라인 속성으로 쓴다 — 가장 중요

변환기는 `<style>` 블록의 **`font-weight`를 옮기지 않는다.** 클래스로 굵기를 준
제목이 PPTX에서 전부 보통 굵기로 나온다(색은 넘어가므로 눈치채기 어렵다).

```xml
<!-- 안 됨 — 굵기가 유실된다 -->
<style>.ti { font-family:"Noto Sans CJK KR"; font-size:48px; font-weight:700; }</style>
<text class="ti" x="80" y="98">제목</text>

<!-- 맞음 — 인라인 속성 -->
<text x="80" y="98" font-family="Noto Sans CJK KR" font-size="48"
      font-weight="700" fill="#1B2C5E">제목</text>
```

CSS를 쓰면 코드가 짧아지는 유혹이 있으나, **이 변환 경로에서는 인라인이 계약이다.**
길어지더라도 모든 `<text>`에 `font-family` · `font-size` · `font-weight` · `fill`을
직접 붙인다.

### 4.2 HTML 명명 엔티티 금지

`&nbsp;` `&mdash;` `&copy;` 같은 HTML 명명 엔티티는 SVG에서 XML 파싱 오류다.
**유니코드 문자를 그대로 쓴다**(`—`, `©`, `→`, 공백). XML 예약문자만
`&amp;` `&lt;` `&gt;` `&quot;` `&apos;`로 이스케이프한다.

특히 `&`는 반드시 `&amp;`로 — 표 제목·회사명에서 자주 놓친다.

### 4.3 `foreignObject` 금지

HTML을 SVG 안에 끼워 넣는 `foreignObject`는 DrawingML로 옮길 대응물이 없다.
줄바꿈은 `<text>` + `<tspan dy="...">`으로 **직접** 만든다. 자동 줄바꿈은 없다 —
줄을 손으로 끊는다.

```xml
<text x="80" y="300" font-family="Noto Sans CJK KR" font-size="33" fill="#3B4252">
  <tspan x="80" dy="0">첫 줄</tspan>
  <tspan x="80" dy="46">둘째 줄</tspan>
</text>
```

`dy`는 font-size의 1.3~1.4배가 자연스럽다(33px → 44~46).

### 4.4 폰트 — Pretendard 고정

**모든 덱은 `Pretendard` 한 가족으로 통일한다.** 위계는 폰트를 바꿔서가 아니라
**굵기와 크기로** 만든다 — 제목에 다른 서체를 섞지 않는다.

```xml
<text ... font-family="Pretendard" font-weight="700">제목</text>
<text ... font-family="Pretendard" font-weight="400">본문</text>
```

중간 굵기를 정확히 지정하려면 **설치된 패밀리 이름**을 쓴다(`font-weight` 숫자보다
확실하다). `install_fonts.py` 실행 후 등록되는 이름:

| 용도 | font-family | 대안 |
|---|---|---|
| 본문 | `Pretendard` | `font-weight="400"` |
| 소제목·강조 | `Pretendard Medium` / `Pretendard SemiBold` | — |
| 제목·배너 | `Pretendard` + `font-weight="700"` | `Pretendard ExtraBold` |
| 얇은 캡션 | `Pretendard Light` | — |
| 코드·명령어 | `Noto Sans Mono CJK KR` 또는 `Consolas` | Pretendard에 고정폭 없음 |

주의:
- **PPTX는 폰트를 내장하지 않는다.** 만든 덱을 다른 컴퓨터에서 열려면 그쪽에도
  Pretendard가 설치되어 있어야 한다. 없으면 대체 폰트로 찍히며 줄바꿈이 밀린다.
  배포처에 설치가 어려우면 `맑은 고딕`(Windows 기본)으로 통일해 만든다.
- 폰트를 설치하지 않은 채 Pretendard로 쓰면 품질 검사에
  `Font stack exports non-PPT-safe typeface` 경고가 뜬다. **설치 후에는 이 경고가
  사라지고 검사를 완전 통과한다** — 경고가 계속 뜨면 설치가 안 된 것이다.
- Pretendard는 SIL OFL이다. 라이선스 전문은
  `assets/fonts/Pretendard/LICENSE.txt`.

### 4.5 유니코드 첨자 주의

아래첨자 `ᵢ ₀ ₁ ₜ`, 일부 위첨자는 렌더 폰트에 따라 □로 깨진다. 수식 기호는
ASCII로 풀어 쓴다(`wᵢ → wi`, `B₀ → B_0`). 그리스 문자(`σ τ β μ Σ`)와
`² ³ → ↔ < >`는 Noto Sans CJK에서 정상 렌더된다.

### 4.6 텍스트 좌표와 행간 — 겹침의 주범

`<text>`의 `y`는 **베이스라인**이지 박스 상단이 아니다. 박스 안에 세로 중앙으로
넣으려면 `y = 박스중심 + font-size × 0.35` 정도로 잡는다.

**★ 베이스라인 간격은 앞 글자 크기의 1.35배 이상.** 변환기는 각 `<text>`를
글자 크기의 약 1.2배 높이 텍스트 프레임으로 만들고, PowerPoint는 여기에 상하
여백을 더 붙인다. 그래서 **SVG 렌더에서 안 겹쳐도 PowerPoint에서는 겹친다.**

```
다음_베이스라인 ≥ 이전_베이스라인 + 이전_font-size × 1.35
```

| 앞 글자 | 최소 간격 | 실제로 쓸 값 |
|---|---|---|
| 64px (표지 제목) | 87px | **90px** |
| 43px (페이지 제목) | 58px | **60px** |
| 27px (본문) | 37px | **40px** (`tspan dy="40"`) |
| 24px (캡션) | 33px | **36px** |

큰 제목 바로 밑에 작은 부제를 붙일 때가 가장 위험하다 — 간격은 **작은 쪽이 아니라
큰 쪽 글자 크기**로 계산한다. 64px 제목 밑 27px 부제는 50px이 아니라 **90px** 아래다.

### 4.7 줄바꿈을 지키려면 `--no-merge`

변환기는 기본적으로 `dy`로 쌓은 줄들을 **한 문단으로 합친다.** 그러면 PowerPoint가
프레임 폭에 맞춰 제멋대로 다시 줄을 나눈다(줄 끝 단어가 밀려 내려간다).
줄을 손으로 끊은 의도를 그대로 살리려면 **`--no-merge`로 변환**한다 — 각 줄이
독립 텍스트 프레임이 되어 좌표대로 앉는다. 이 스킬은 좌표를 직접 잡는 방식이므로
`--no-merge`가 사실상 기본값이다.

### 4.8 ★ 변환 직후 프레임 폭을 실측으로 교정한다 — 겹침의 진짜 주범

변환기는 각 텍스트 프레임의 폭(`cx`)을 자체 추정으로 잡는데, **실제 글자보다 좁게
나오는 경우가 압도적으로 많다.** 실측 사례: 13장짜리 덱에서 261개 프레임 중 250개가
좁았다. LibreOffice는 이걸 그냥 넘겨 렌더하므로 §6의 시각 검수에서 **보이지 않는다.**
그런데 PowerPoint는 그 좁은 상자 안에서 줄바꿈을 해버린다 — `MCMC`가 `MCM` / `C`로
쪼개지고, 넘친 줄이 아래 텍스트와 겹친다. 사용자에게는 "글씨가 겹친다"로 도착한다.

`wrap="none"`이 붙어 있어도 막지 못한다. 반드시 변환 직후 교정한다:

```bash
python3 scripts/fit_text_frames.py <파일.pptx>          # 제자리 교정
python3 scripts/fit_text_frames.py <파일.pptx> --check  # 진단만
```

이 도구는 설치된 폰트 파일에서 글자 폭을 실측해 `cx`를 다시 쓰고(여유 15%),
넓힌 상자가 오른쪽 이웃의 글자를 침범하지 않도록 클램프하며, `<a:spAutoFit/>`을
`<a:noAutofit/>`으로 바꾼다. autofit이 남아 있으면 렌더러가 상자를 자기 폰트
계측으로 다시 재면서 좌표가 밀린다 — LibreOffice에서 **좌측 정렬 텍스트가 가운데로
밀려 보이는 현상**의 원인이 이것이고, `noAutofit`으로 바꾸면 사라진다.

**★ slide XML을 XML 파서로 다시 직렬화하지 말 것.** `ElementTree`로 읽고 쓰면
`xmlns:r` 같은 네임스페이스 선언이 유실되고 Microsoft 확장 네임스페이스가
`ns2`로 개명되어, PowerPoint가 파일을 복구 모드로 연다(실측 사고). 프레임 좌표를
손볼 일이 있으면 **문자열 단위 정규식 치환만** 쓴다. `fit_text_frames.py`가
그렇게 되어 있다.

---

## 5. 워크플로 (승인 게이트)

0. **폰트 설치** — `python3 scripts/install_fonts.py` (세션당 한 번. 생략하면 6번 검수가 무의미해진다)
1. **구조 합의** — 페이지 수와 각 페이지의 역할을 먼저 outline으로 제시하고 승인받는다.
2. **스캐폴드** — `python3 scripts/init_project.py <프로젝트>`
3. **페이지 작성** — `svg_output/P01.svg`부터 한 장씩. §4 규칙을 지킨다.
   페이지 간 좌표 골격(마진·제목 y·푸터 y)을 **한 번 정해 전 페이지에 고정**한다.
   **`references/`의 예시를 먼저 연다** — `styles/README.md`가 셋 중 무엇을 고를지 안내한다:
   `example-page.svg`(골격 한 장) / `styles/navy/`(네이비 3장) / `styles/editorial/`(종이 톤 3장).
   전부 크기 규칙과 두 검사를 통과한 상태이므로, 복사해서 색·문구·좌표만 바꾼다.
4. **품질 검사 — 오류 0건이어야 다음으로 간다**
   ```bash
   python3 scripts/svg_quality_checker.py <프로젝트>/svg_output
   ```
   XML 적합성·viewBox·폰트·텍스트 넘침·겹침을 검사한다. 경고(WARN)는 판단해서
   넘길 수 있으나 **오류(ERROR)는 반드시 고친다.**

   흔히 뜨는 두 경고는 이 환경에서 정상이다:
   - `Font stack exports non-PPT-safe typeface` — **`install_fonts.py`를 안 돌렸다는
     신호다.** 설치 후 Pretendard로 쓰면 이 경고 없이 완전 통과한다. `Noto Sans CJK KR`을
     쓰면 설치 여부와 무관하게 계속 뜨는데, 그때는 §4.4대로 배포 대상 PC에 그 폰트가
     있는지 따로 확인한다.
   - `page SVG is missing root data-pptx-page-role` — 선택 마커라 없어도 변환된다.
     붙이려면 루트 `<svg>`에 `data-pptx-page-role="cover|toc|section|content|ending"`
     중 하나를 준다(소문자 kebab-case, 빈 값이면 ERROR).
5. **변환** — `--no-merge`를 붙인다(§4.7)
   ```bash
   python3 scripts/svg_to_pptx.py <프로젝트> --no-merge -o <프로젝트>/exports/<Name>.pptx
   ```
6. **프레임 폭 교정 — 생략 금지(§4.8)**
   ```bash
   python3 scripts/fit_text_frames.py <프로젝트>/exports/<Name>.pptx
   ```
   "남은 좁은 프레임 0"이 나와야 한다. 이 단계를 건너뛰면 LibreOffice 검수는
   통과하는데 PowerPoint에서 줄바꿈·겹침이 난다.
7. **시각 자가 검수 — 생략 금지**
   ```bash
   soffice --headless --convert-to pdf --outdir _pdf <프로젝트>/exports/*.pptx
   pdftoppm -jpeg -r 70 _pdf/*.pdf _pdf/s
   ```
   렌더된 이미지를 `view`로 **전 페이지** 확인한다. 굵기 유실(§4.1),
   텍스트 겹침, 캔버스 이탈, □ 깨짐을 여기서 잡는다.
8. **텍스트 박스 겹침 감사 — 이 경로의 필수 게이트**
   렌더 이미지만으로는 §4.6 겹침을 놓친다. 변환된 pptx의 프레임 좌표를 직접 잰다:
   ```bash
   python3 scripts/check_overlap.py <파일.pptx>
   ```
   **한 건이라도 나오면 §4.6 간격으로 베이스라인을 벌리고 다시 만든다.**
   더불어 `unzip`으로 모든 `.xml`·`.rels`가 well-formed인지, `Presentation()`으로
   정상 open 되는지 확인한다.
9. `/mnt/user-data/outputs`로 복사하고 `present_files`. **파일 크기를 함께 안내**한다.

---

## 6. 자주 쓰는 변환 옵션

| 옵션 | 용도 |
|---|---|
| `-o <경로>` | 출력 파일 경로 지정 |
| `-f ppt169` / `story` / `instagram` … | 캔버스 포맷 강제 |
| `-t fade` / `push` / `wipe` / `none` | 페이지 전환 효과 (기본 fade) |
| `-a fade` / `auto` / `none` | 요소 등장 애니메이션 (기본 none) |
| `--conversion-trace` | 요소별 변환 판단을 JSON으로 남긴다 (디버깅) |
| `--no-image-optimize` | 삽입 이미지 재압축을 끈다 |
| `-q` | 조용히 |

`--native-objects`는 `data-pptx-native` 마커가 붙은 표·차트를 데이터가 연결된
진짜 PowerPoint 개체로 뽑는 옵션이다. 마커 작성 규약을 지켜야 하고 스타일이
정규화되므로, **기본은 끈 채로 두고** 필요할 때만 검토한다.

---

## 7. 금지 사항

- **`<style>` 클래스로 `font-weight` 주기 금지** — 유실된다(§4.1). 인라인 속성만.
- `foreignObject` 금지 — `<text>` + `<tspan>`으로 줄을 손으로 끊는다.
- `&nbsp;` `&mdash;` 등 HTML 명명 엔티티 금지 — 유니코드 원문자를 쓴다.
- **본문 27px(20pt) 미만으로 임의로 내리기 금지.** 절대 하한은 21px(16pt)이고,
  그것도 표 행이 많을 때 같은 불가피한 경우뿐이다. 안 들어가면 페이지를 나눈다.
- 16:9 덱을 1280×720이 아닌 캔버스로 그리기 금지 — 슬라이드가 규격 밖으로 나온다.
- 이미 그린 캔버스를 `-f`로 다시 규격 맞추기 금지 — 좌표가 안 따라와 잘린다.
- 페이지마다 다른 viewBox 금지 — 전 페이지 동일 캔버스.
- 품질 검사 ERROR를 남긴 채 변환 금지.
- **시각 검수 생략 금지** — 이 경로의 사고(굵기 유실·베이스라인 오차)는
  코드만 봐서는 안 보이고 렌더 이미지에서만 보인다.
- **`fit_text_frames.py` 생략 금지(§4.8)** — 변환기가 잡은 프레임 폭을 그대로 두면
  PowerPoint에서 줄바꿈·겹침이 난다. 렌더 검수로는 절대 안 잡힌다.
- **slide XML을 XML 파서로 다시 쓰기 금지(§4.8)** — 네임스페이스 선언이 유실되어
  파일이 복구 모드로 열린다. 문자열 정규식 치환만 쓴다.
- 기관 익명화 규칙 준수(실명 클라이언트 노출 금지).
- **★ LibreOffice 정규화 round-trip 금지.** 이 변환기의 출력은 이미 정상 OOXML
  패키지다. `soffice --convert-to pptx`를 태우면 LibreOffice가 **자체 폰트 계측으로
  텍스트 프레임을 다시 재서 줄이고 중앙으로 옮긴다** — 실측 예: 표지 제목 프레임이
  `L=0.604in W=8.953in H=0.974in` → `L=1.632in W=6.896in H=0.764in`로 바뀌어
  가로 위치가 1인치 밀리고 세로 여유가 사라져 **PowerPoint에서 부제와 겹쳤다.**
  `report-navy-deck`(pptxgenjs)에서는 필요한 단계지만 **이 스킬에서는 해가 된다.**
  변환기 직출력을 그대로 출고한다.
- 한 덱에 여러 서체 섞기 금지 — Pretendard 한 가족에서 굵기·크기로만 위계를 만든다.
- **`install_fonts.py`를 건너뛴 채 Pretendard 덱 검수 금지** — 대체 폰트로 렌더된
  이미지를 보고 통과시키면 실제 PowerPoint에서 줄바꿈이 밀린다.
- 산출 파일명은 ASCII(영문)로 — 다운로드 편의.

---

## 8. 출처·라이선스

이 스킬은 [hugohe3/ppt-master](https://github.com/hugohe3/ppt-master) (MIT,
Copyright © Hugo He)의 SVG→DrawingML 변환기와 SVG 품질 검사기를 이 실행 환경에
맞게 추려 담은 것이다. 원 저장소의 전체 워크플로(자료 변환, Strategist 확인 페이지,
라이브 프리뷰, AI 이미지 생성, 아이콘·차트 템플릿 라이브러리)는 Claude Code에서
저장소를 직접 열어야 돌아가며, 여기에는 담기지 않았다. **Pretendard 폰트 6종은
검수 렌더 정확도에 직결되므로 그대로 번들했다**(SIL OFL,
`assets/fonts/Pretendard/LICENSE.txt`).

한국어 커스터마이즈 워크스페이스: [byungjunjang/slide-master](https://github.com/byungjunjang/slide-master)

원 프로젝트의 라이선스 전문은 `LICENSE` 에 있다.
