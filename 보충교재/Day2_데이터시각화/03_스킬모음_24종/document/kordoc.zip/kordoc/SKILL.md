---
name: kordoc
description: "HWP·HWPX·PDF·XLSX·DOCX·이미지 문서를 읽기·렌더·양식채우기·공문서 생성·서식보존 패치·신구대조·표기법 검수할 때 사용. \"한글 파일 읽어줘\", \"hwpx로 만들어줘\", \"공문 기안문 작성\", \"보고서를 한글로\", \"신청서 빈칸 채워줘\", \"hwp를 마크다운으로\", \"두 문서 비교해줘\", \"신구대조표\", \"공문서 표기법 검사\", \"개인정보 가려줘\" 등에 트리거."
---

# kordoc — 한국 문서 처리 CLI

`kordoc`(MIT, chrisryugj/kordoc)은 HWP·HWPX·PDF·XLSX·DOCX·이미지(PNG/JPG/WebP)를 마크다운으로 파싱하고,
반대로 공문서 HWPX를 생성·패치·검수하는 Node CLI다. 설치 불필요 — `npx -y kordoc`으로 바로 실행한다.

**검증 버전 4.22.5 (2026-10-16 배포, 2026-10-17 실행 확인).** 릴리스가 하루에도 여러 번 나오므로,
결과 재현이 필요하면 `npx -y kordoc@4.22.5`처럼 버전을 고정한다. 옵션이 이 문서와 다르면 `--help`를 따른다.

## 언제 쓰는가

- 한글(.hwp/.hwpx) 문서를 읽거나 내용을 추출할 때 (스캔 PDF·사진은 OCR)
- 마크다운 원고를 기안문·보고서·계획서·보도자료 등 **공문서 HWPX**로 만들 때
- 신청서·서식의 빈칸을 채울 때(원본 서식 보존), 도장·서명을 찍을 때
- 원본 HWPX의 서식을 유지한 채 본문 텍스트만 고칠 때(라운드트립 패치)
- 두 판을 비교해 **신구대조**할 때, 공문서 **표기법·문체**를 검수할 때
- 개인정보를 서식 그대로 가릴 때, 레이아웃을 눈으로 확인할 때(SVG/PNG/PDF 렌더)

생성형 산출물이 .docx면 `docx` 스킬, .pptx면 덱 스킬을 쓴다. **HWP 계열이면 kordoc이 우선**이다.

## 기본 흐름

작업 전 원본을 먼저 파싱해 구조를 보고, 산출 뒤에는 `lint` → `validate` → `render`로 확인한다.

```bash
# 1) 읽기 — 무엇이 들어 있는지 먼저 본다
npx -y kordoc input.hwpx -o input.md
npx -y kordoc input.pdf --format json -o input.json        # blocks + metadata
npx -y kordoc report.hwpx --format chunks -o chunks.json   # RAG용 구조 청크

# 2) 원고 검수 — 표기법(날짜·시간·금액·붙임) + 개조식 문체
npx -y kordoc lint draft.md --munche

# 3) 생성 — 마크다운 → 공문서 HWPX
npx -y kordoc generate draft.md -o output.hwpx --preset 보고서

# 4) 검증 — 한컴독스 거부 요인 사전 차단 (납품 전 필수)
npx -y kordoc validate output.hwpx

# 5) 확인 — 레이아웃을 눈으로 본다
npx -y kordoc render output.hwpx --format png --pages 1-2 -d ./preview
```

렌더한 PNG는 직접 열어 확인한 뒤 사용자에게 전달한다.

## 명령별 요점

### 파싱 (기본 명령)

```bash
npx -y kordoc <파일...> [-o out.md | -d ./outdir]
```

- `--format markdown|json|chunks`, `--pages 1-3`
- 다중 파일 병렬 변환은 `--jobs N -d ./out`, 암호 문서는 `--password`
- PDF에서 테두리 박스를 표로 오인해 읽기 순서가 뒤집히면 `--no-tables`, 머리글·바닥글 제거를 끄려면 `--no-header-footer`
- 서식 입력란처럼 **오른쪽 끝 빈 열이 의미 있으면** `--keep-empty-cols`, 빈 문단이 의미 있으면 `--keep-empty-paragraphs`
- 빈 서식의 누름틀 안내문(칸 용도)까지 보려면 `--include-field-placeholders`
- HWP5 레이아웃 표의 반복 머리행 제거는 `--dedupe-headers` (붙임별 재번호 오삭제 주의, 기본 꺼짐)
- **표 출력**
  - 기본은 "보이는 대로" — 테두리 없는 틀 표는 글로, 칸으로 조립한 분수는 수식으로 푼다
  - 원본 표 구조 그대로: `--keep-layout-tables` (**patch용 편집본은 반드시 이 옵션**)
  - 모든 표를 HTML로: `--html-tables`
  - RAG 색인용으로 HTML 없이 GFM 파이프 표만: `--table-format gfm` (`--html-tables`와 함께 못 씀)
- 첨자: HWPX·HWP·DOCX는 기본 `<sup>/<sub>`, PDF는 기본 끔(논문·수식 PDF면 `--script-tags`). 평문은 `--no-script-tags`
- 색인·RAG용 글만 필요하면 `--plain`, 이미지 추출을 건너뛰려면 `--no-images`
- 이미지가 수백 장인 문서의 JSON은 `--image-refs`(바이트 대신 파일 참조), HWP5 이미지를 마크다운에 넣으려면 `--inline-images`
- **OCR (스캔 PDF·이미지)**
  - `--ocr` — 내장 PP-OCRv5 한국어, 모델 ~18MB 첫 사용 시 자동 다운로드, OCR이 필요한 쪽만 인식
  - `--ocr-force` — 텍스트층이 있어도 전 페이지 다시 인식
  - 작은 글자가 많으면 `--ocr-det server`(~88MB) 또는 `--ocr-det-long-side 1600`(느려짐)
  - 읽은 줄의 좌표·신뢰도가 필요하면 `--format json --ocr-lines` (`--ocr-lines-all`은 버린 줄까지)
  - 이미지 파일(PNG/JPG/WebP)은 OCR이 자동 적용된다
  - 수식은 `--formula-ocr`(~155MB)

### generate — 마크다운 → 공문서 HWPX

```bash
npx -y kordoc generate draft.md -o out.hwpx --preset 보고서
```

- **프리셋:** `기안문`(기본)·`보고서`·`계획서`·`통지`·`회의록`·`개조식`(표지·목차·장 헤더 자동)·`업무보고`(중앙부처)·`서울방침`(서울시 방침서)·`보도자료`
- **문체:** 공문서 본문은 '~다' 서술형 대신 명사형·'~함/있음'으로 쓴다. `보고서`는 제목 바로 뒤 인용문(`>`)에 "…하고자 함" 형식의 보고 목적 요약(3줄 이내)을 넣는다. generate 경고와 `lint --munche` 결과를 무시하지 말고 원고를 고쳐 다시 만든다
- **기관 서식:** `--agency 국세청`처럼 중앙행정기관 이름을 주면 실측한 단계 글꼴·크기·항목부호·표 머리·기관 색을 적용한다 (보고서·계획서·업무보고·개조식·보도자료)
- **견본 따라 하기**
  - 항목부호 단계별 글꼴·크기·굵기: `kordoc levels 견본.hwpx`로 확인 → `--levels-from 견본.hwpx`로 바로 적용 (직접 지정은 `--levels '0=HY견고딕/17/bold,1=한컴돋움/15/bold'`)
  - 표 테두리·음영·열폭: `kordoc profile 참조.hwpx -o 서식.json` → `--profile 서식.json`
- **표지·목차·요약**
  - 표지: `--cover`·`--no-cover`, `--org`, `--dept`, `--date`, 보고서 문서정보표 `--doc-info 'docNum=…,date=…,disclosure=공개'`
  - 목차: `--toc`·`--no-toc`
  - 요약 박스: `--summary` (제목 직후 `>` 인용문으로도 지정)
  - 취급 표시('대외주의'·'비공개' 빨간 박스): `--cover-label`
- **장 제목·항목부호**
  - 장 제목 표기: `--h2-marker band|roman|number|box|none`, 띠 색 `--band-color #003366`
  - 2단계 부호: 기안문·공고문은 `--bullet2 ㅇ`, 보고서 양식은 `--bullet2 ○`
  - 단일 항목 부호 생략(편람 규정): `--suppress-single`
- **기안문:** 두문 `--doc-head 'org=…,to=…,title=…'`, 결문 `--doc-foot 'sender=…,drafter=…,phone=…'`, 결재란 `--approval 담당,팀장,과장`, 보고정보 행 `--report-info`
- **공고문·보도자료:** `--notice-head 'no=…,date=…,sender=…'`, `--press-head 'release=…,dept=…,manager=…'`, `--press-sub`, `--press-people`
- **쪽·끝 표시:** 쪽번호 `--page-numbers`·`--no-page-numbers`, 끝표시 `--end-mark`·`--no-end-mark`
- **서체·용지**
  - 글꼴: `--font myeongjo|gothic`, 요소별 `--fonts 'body=…,heading=…'`
  - 크기·줄간격: `--pt`, `--line-spacing`, 개조식 요소별 `--sizes`
  - 용지: `--paper A4|A3|B4|B5|Letter|'210x297'`, `--landscape`, 다단 `--columns`
  - 머리말·꼬리말: `--header`, `--footer`
- **그림·수식:** 마크다운 안 `![](x.png)`는 `--image-dir`로 실제 데이터를 넣는다. 본문 `$…$`를 한글 수식 개체로 만들려면 `--inline-math` (기본은 가격 `$` 오인을 막으려 글자 유지)
- **서울시:** 사전 검토항목 점검표는 `--checklist [해당없음 번호]`
- **공문서 서식 없이:** `--plain`

### lint — 공문서 표기법 검수

```bash
npx -y kordoc lint draft.md                    # 날짜·시간·금액·붙임 표기 (행정업무운영 편람)
npx -y kordoc lint draft.md --munche           # + 개조식 문체 (서술형 종결·당위·수사·항목 길이)
npx -y kordoc lint report.hwpx --numbers --styles
```

- md·txt와 HWPX·HWP·PDF 모두 받는다. error가 있으면 exit 1
- `--numbers`: 본문 수치가 가까운 표에 실제로 있는지 대조한다 (확인 목록이며 exit 코드에는 영향 없음)
- `--styles`: 같은 항목부호 단계인데 글꼴·크기·굵기가 다른 문단을 찾는다 (HWPX)

### compare — 두 문서 비교 (신구대조)

```bash
npx -y kordoc compare 개정전.hwp 개정후.hwpx          # HWP↔HWPX처럼 형식이 달라도 된다
npx -y kordoc compare a.hwpx b.hwpx --json > diff.json
```

- 추가·삭제·변경 블록과 `추가 n · 삭제 n · 변경 n · 동일 n` 요약을 낸다. **차이가 있으면 exit 1**이므로 실패로 오인하지 않는다
- 신구대조표는 `--json` 결과를 받아 표(현행 | 개정안)로 정리한다

### fill — 서식 빈칸 채우기

```bash
npx -y kordoc fill form.hwpx --dry-run                       # 필드 목록 먼저 확인
npx -y kordoc fill form.hwpx -f '성명=홍길동,전화=010-1234-5678' -o filled.hwpx
npx -y kordoc fill form.hwpx -j values.json -o filled.hwpx
npx -y kordoc fill --template gian -j values.json -o gian.hwpx  # 내장 일반기안문 (gian-simple: 간이기안문)
```

- 기본 `--format hwpx-preserve`가 원본 스타일을 보존한다. 바꾸지 않는다
- **항상 `--dry-run`으로 필드명을 먼저 확인**한다. `-j`/`-f`와 함께 주면 값이 들어갈 칸(표·행·열)까지 JSON으로 보여 준다
- 라벨이 반복되는 양식은 `--require-unique`로 오염을 막는다
- 날짜·주민번호 등 값 서식은 `--formats '{"날짜":"yy.mm.dd","주민등록번호":"rrn:masked"}'`
- 내장 서식 목록은 `--list-templates`

### seal — 도장·서명 찍기

```bash
npx -y kordoc seal 신청서.hwpx --image 도장.png --anchor "(인)" -o signed.hwpx
```

- 투명 배경 PNG를 쓴다. 같은 앵커가 여럿이면 `-n 1`(0부터), 위치는 `--mode overlap|right|auto`, 크기 `--size-mm`, 미세조정 `--dx`·`--dy`(mm)

### patch — 서식 보존 라운드트립

```bash
npx -y kordoc original.hwpx --keep-layout-tables -o original.md   # 파싱 (patch용은 반드시 이 옵션)
# original.md 를 편집 (텍스트만 수정)
npx -y kordoc patch original.hwpx edited.md -o patched.hwpx --json
```

- 바뀐 텍스트만 고치고 나머지는 원본 그대로 둔다. 문단 추가·삭제, 표 구조 변경은 적용되지 않는다. HWPX와 HWP 모두 받는다
- 패치 뒤 자동으로 다시 파싱해 검증한다(`--no-verify`로 끔). `--json`은 적용 수·건너뛴 편집·검증 잔차를 낸다
- **미적용 편집이 있으면 exit 2**로 끝난다. 종료 코드를 확인하고 건너뛴 항목을 사용자에게 알린다. 구조를 바꿔야 하면 patch 대신 `generate`로 새로 만든다

### redact — 개인정보 서식 보존 마스킹

```bash
npx -y kordoc redact 명단.hwpx --dry-run                 # 탐지 리포트만
npx -y kordoc redact 명단.hwpx --rules rrn,phone,email,name,address -o masked.hwpx
```

- 기본 규칙: 주민·외국인등록번호, 전화, 이메일, 카드, 계좌, 사업자번호, 여권, 운전면허. 법인번호(`crn`)·`ip`·인명(`name`)·주소(`address`)는 `--rules`로 켠다
- HWPX/HWP는 같은 길이로 가린 파일(본문·표·머리말·각주·글상자·메타데이터 포함), 그 외 형식은 마스킹된 마크다운만 낸다
- 이미지 속 글자는 탐지하지 못한다. **결과는 반드시 사람이 최종 확인한다**

### render — 레이아웃 렌더

```bash
npx -y kordoc render 문서.hwpx --format png --pages 2-4 -d ./pages
npx -y kordoc render 문서.hwpx --format pdf -o 문서.pdf
```

- 형식: `svg`(기본)·`html`·`png`·`jpeg`·`pdf`. 래스터 폭 `--max-width`(기본 1400px), 검색어 형광펜 `--highlight 'a,b'`
- 한컴 저장본은 조판 캐시 그대로, 캐시 없는 생성본·편집본은 자체 조판(reflow, 기본 켬)으로 그린다
- PDF는 Chromium이 필요하다(`--browser` 또는 자동 탐지)

### 그 밖의 명령

| 명령 | 용도 |
|---|---|
| `validate` | HWPX 구조 검증 (ZIP·mimetype·XML·secCnt·manifest). `--json` |
| `levels` | 견본 HWPX의 항목부호 단계별 글꼴·크기·굵기 추출 → `generate --levels-from` |
| `profile` | 참조 문서의 표 서식 프로필 JSON 추출 → `generate --profile` |
| `tables` | 표 추출·의미표/레이아웃 분류 JSON (+ 시각 crop) |
| `crop` | 표·이미지·문단·도형 영역만 잘라내기 |
| `watch` | 디렉토리 감시 — 새 문서 자동 변환 |
| `parse-worker` / `render-worker` | 상주 워커(stdin NDJSON) — 대량 반복 파싱·렌더 시 콜드스타트 제거 |
| `check-ocr-models` / `check-formula-models` | OCR·수식 모델 상태 확인, 없거나 SHA가 다르면 다운로드 |
| `models` | 폐쇄망 반입용 모델 내보내기·가져오기 (SHA-256 검증) |
| `mcp` / `setup` | MCP 서버 실행 / AI 클라이언트 자동 등록 |

## 주의사항

- **HWP 3.x는 읽기 전용**이다. 생성·패치 대상이 아니다. 한컴 DRM 문서는 열 수 없다.
- 한글 파일명은 셸에서 반드시 따옴표로 감싼다. 사용자에게 전달할 산출 파일명은 영어로 짓는 편이 안전하다.
- 첫 실행 때 npx 다운로드에 수십 초가 걸린다. 타임아웃을 넉넉히 잡는다(180초 이상).
- 셸 스크립트에서 `K="npx -y kordoc"; $K …`처럼 변수에 담으면 zsh에서는 단어로 나뉘지 않아 실패한다. 함수(`K(){ npx -y kordoc "$@"; }`)로 감싼다.
- 종료 코드에 뜻이 있다: `compare`는 차이가 있으면 1, `lint`는 error가 있으면 1, `patch`는 미적용 편집이 있으면 2.
- OCR·수식 모델은 첫 사용 때 네트워크에서 내려받는다. 폐쇄망이면 `kordoc models`로 사이드로드한다.

## 참고

- 저장소: https://github.com/chrisryugj/kordoc (MIT) · 변경 이력: 저장소의 `CHANGELOG.md`
- `npx -y kordoc <명령> --help`로 최신 옵션을 확인한다.
