---
name: week13-agent
week: 13
title: Automotive AI Agent Team 구축
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [NotebookLM, Claude Code, Google Veo 3.1, Google Opal]
---

# Week 13 — Automotive AI Agent Team 구축

## 학습 목표
- Claude Code Agent Team 아키텍처(Orchestrator + Sub-Agent) 이해
- Agent 파일 5개 + Skill 파일 3개 작성 및 실행
- EV 전략 보고서 병렬 자동 생성

---

## Agent Team 아키텍처

```
CLAUDE.md (공유 컨텍스트)
    ↓
Orchestrator Agent (전체 조율)
    ├── Market Analyst Agent (시장 분석)
    ├── Competitor Intel Agent (경쟁사 분석)
    ├── Tech Trend Agent (기술 트렌드)
    └── Report Writer Agent (보고서 작성)
```

**폴더 구조:**
```
.claude/
├── CLAUDE.md          # 프로젝트 공유 컨텍스트
└── agents/
    ├── orchestrator.md
    ├── market-analyst.md
    ├── competitor-intel.md
    ├── tech-trend.md
    └── report-writer.md
```

---

## 실습 1: NotebookLM으로 Agent 설계 리서치

NotebookLM에 Claude Code Agent 관련 문서 업로드 → 설계 인사이트 추출

## 실습 2: Agent Team 구축 및 실행

```
[Claude Code에 입력]
"Automotive AI Agent Team을 구성해줘.
- CLAUDE.md: 자동차 산업 분석 프로젝트 컨텍스트
- orchestrator.md: 병렬 작업 조율 역할
- market-analyst.md: EV 시장 분석 전담
- competitor-intel.md: 경쟁사 모니터링 전담
- report-writer.md: 최종 보고서 통합 작성
각 파일을 .claude/agents/ 폴더에 생성해줘."
```

실행:
```
[Plan Mode 활성화 후]
"EV 전략 보고서를 Agent Team으로 병렬 생성해줘."
```

## 실습 3: Agent 소개 영상 제작

Gemini에서 Veo 3.1로:
```
"AI Agent들이 협업해서 분석 보고서를 만드는 모습을 시각화한 영상, 30초"
```

---

## 산출물
- [ ] Agent 파일 5개 (`.claude/agents/`)
- [ ] Skill 파일 3개
- [ ] Agent Team 결과 보고서
- [ ] `Agent_Intro.mp4`
