---
name: week09-notebooklm
week: 9
title: 자동차 산업 뉴스 분석 + NotebookLM 지식베이스
duration: 3H | 이론 1H · 실습 2H
mode: 온라인
tools: [Perplexity, NotebookLM, Claude Code, Google Docs]
---

# Week 9 — 뉴스 분석 + NotebookLM 지식베이스

## 학습 목표
- NotebookLM으로 자동차 산업 지식베이스 구축
- Audio Overview 한국어 팟캐스트 자동 생성
- Research → NotebookLM → Claude Code → Docs 워크플로 완성

---

## 워크플로 구조

```
Perplexity (뉴스 수집)
    ↓
NotebookLM (지식베이스 + 인사이트 추출)
    ↓
Claude Code (보고서 작성)
    ↓
Google Docs (저장·공유)
```

---

## 실습 1: NotebookLM 지식베이스 구축

**Step 1: 뉴스 수집 (Perplexity)**
```
"최근 3개월 자동차 산업 주요 뉴스 10개를 수집해줘.
EV 전환, 자율주행, 배터리 기술, 공급망 이슈 포함.
각 뉴스: 제목, 날짜, 출처, 요약 200자 형식."
```

**Step 2: NotebookLM 업로드**
1. notebooklm.google.com 접속
2. New Notebook 생성
3. 수집한 뉴스 10개 소스 추가

**Step 3: 인사이트 추출**
```
[NotebookLM 채팅창]
"이 뉴스들에서 핵심 트렌드 7개를 추출하고
슬라이드 5장 구성안을 만들어줘."
```

**Step 4: Audio Overview 생성**
- NotebookLM → Audio Overview → 한국어 선택 → 생성

## 실습 2: 트렌드 보고서 작성

```
[Claude Code에 입력]
"NotebookLM에서 추출한 다음 트렌드를 바탕으로
자동차 산업 동향 보고서를 작성해줘:
[트렌드 7개 붙여넣기]
파일명: W09_Industry_Trends.md"
```

---

## 산출물
- [ ] NotebookLM 지식베이스 (소스 10개+)
- [ ] `W09_Industry_Trends.docx`
- [ ] 트렌드 팟캐스트 (Audio Overview)
