---
name: week16-graduation
week: 16
title: 최종 발표 및 과정 마무리
duration: 3H | 전체 프로젝트
mode: 오프라인
tools: [Claude Code, NotebookLM, Google Slides]
---

# Week 16 — 최종 발표 및 과정 마무리

## 발표 형식
- 개인당 10분 발표 + 5분 Q&A
- 발표 구성: 문제 정의 → AI 파이프라인 → 핵심 결과물 데모 → 현업 적용 계획

---

## 실습 1: 임원 발표용 슬라이드 생성

```
[Claude Code에 입력]
"최종 프로젝트 발표용 슬라이드 7장을 작성해줘.
구성:
1. 문제 정의 및 목적
2. AI 파이프라인 구조
3. 핵심 데이터 및 분석 결과
4. 시스템 데모 스크린샷
5. 비즈니스 임팩트 (정량적 효과)
6. 현업 적용 계획
7. Q&A
파일명: Final_Presentation.md"
```

## 실습 2: 발표 연습용 영상 생성

NotebookLM → Video Overview로 발표 연습용 영상 생성

## 실습 3: 현업 적용 90일 로드맵 수립

```
[Claude Code에 입력]
"캠프 수료 후 현업에 AI를 적용하는 90일 로드맵을 작성해줘.
- Day 1~30: 기반 구축 (환경 설정, 첫 번째 자동화)
- Day 31~60: 확장 (팀 공유, Skill 라이브러리 확장)
- Day 61~90: 내재화 (Agent Team 운영, ROI 측정)
파일명: 90day_Roadmap.md"
```

---

## 최종 산출물
- [ ] `Final_Presentation.md` (7장)
- [ ] `90day_Roadmap.docx`
- [ ] 최종 제출물 일체 (Google Drive `03_Reports/` 폴더)

---

## 수료 후 Next Step

> 수료가 아니라 시작이다.

- 본인 팀에 이번 캠프 커리큘럼 전파
- Skill 라이브러리를 팀 공유 자산으로 확장
- 매 분기 AI 파이프라인 업데이트 및 개선
