---
name: week07-market
week: 7
title: 자동차 시장 데이터 분석
duration: 3H | 이론 1H · 실습 2H
mode: 온라인
tools: [Claude Code, Google Docs, Google Sheets]
---

# Week 7 — 자동차 시장 데이터 분석

## 학습 목표
- 자동차 시장 분석 4가지 핵심 질문 적용
- EV 시장 분석 보고서 자동 생성
- Google Sheets KPI 탭 수식 자동 구성

---

## 시장 분석 4가지 핵심 질문

1. **시장 규모**: 전체 TAM·SAM·SOM은?
2. **경쟁 구도**: Top 5 플레이어 점유율 변화는?
3. **세그먼트**: 어느 세그먼트가 성장하는가?
4. **지역 전략**: 어느 지역이 우선순위인가?

---

## 실습 1: EV 시장 분석 보고서

```
[Claude Code에 입력]
"D1_EV_Sales.csv를 분석해서 EV 시장 보고서를 작성해줘.
- Top 5 브랜드 점유율 및 YoY 성장률
- 세그먼트별 판매 분포
- 핵심 인사이트 5개
- 파일명: W07_EV_Market_Report.md"
```

## 실습 2: Google Sheets KPI 탭 구축

```
[Claude Code에 입력]
"D1_EV_Sales.xlsx의 KPI 탭에 들어갈 수식을 만들어줘.
- 브랜드별 시장점유율 = 브랜드 판매량 / 전체 판매량
- YoY 성장률 = (당해 판매량 - 전년 판매량) / 전년 판매량
- EV 침투율 = EV 판매량 / 전체 자동차 판매량
Google Sheets 수식 형태로 알려줘."
```

---

## 산출물
- [ ] `W07_EV_Market_Report.docx`
- [ ] `D1_EV_Sales.xlsx` (KPI 탭 추가)
