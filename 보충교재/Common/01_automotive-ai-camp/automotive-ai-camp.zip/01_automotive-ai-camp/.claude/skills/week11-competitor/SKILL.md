---
name: week11-competitor
week: 11
title: 경쟁사 분석 자동화
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, Google Docs, Google Sheets]
---

# Week 11 — 경쟁사 분석 자동화

## 학습 목표
- 자동차 경쟁사 분석 7가지 비교 축 적용
- Tesla vs BYD vs Hyundai 심층 비교 보고서 생성
- Value Index(가격 대비 스펙 효율) 분석

---

## 경쟁사 분석 7가지 비교 축

1. **제품**: 라인업, 스펙, 주행거리
2. **기술**: 배터리, 소프트웨어, 자율주행
3. **가격**: 세그먼트별 포지셔닝
4. **생산**: 생산량, 공장, 공급망
5. **시장**: 점유율, 진출 지역
6. **재무**: 매출, 이익률, R&D 투자
7. **고객 인식**: 브랜드 호감도, VOC

---

## 실습 1: 경쟁사 벤치마크 보고서

```
[Claude Code에 입력]
"Tesla vs BYD vs Hyundai EV 사업을 심층 비교해줘.
7가지 비교 축 전체 포함.
SWOT 분석 각 1개씩.
Value Index: (주요 스펙 합산) / 기본가격 × 100 계산.
전략 A(현대 관점)/B(Tesla 관점)/C(BYD 관점) 각각 제시.
파일명: W11_Competitor_Analysis.md"
```

## 실습 2: 경쟁사 전략 발표자료 생성

```
[Claude Code에 입력]
"위 분석을 바탕으로 임원 보고용 발표자료 5장을 작성해줘.
구성: 경쟁 지형 요약, 3사 비교표, Value Index, 시사점, 권고안
파일명: W11_Competitive_Strategy.md"
```

---

## 산출물
- [ ] `W11_Competitor_Analysis.docx`
- [ ] `D2_Competitor_Benchmark.xlsx`
- [ ] `W11_Competitive_Strategy.md`
