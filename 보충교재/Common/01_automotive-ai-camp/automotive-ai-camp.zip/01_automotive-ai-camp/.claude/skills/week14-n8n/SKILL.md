---
name: week14-n8n
week: 14
title: 업무 자동화 — n8n 워크플로
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, n8n, Gmail, Google Docs]
---

# Week 14 — 업무 자동화: n8n 워크플로

## 학습 목표
- n8n 자동화 3대 패턴 이해
- 주간 뉴스 자동 수집 → 분석 → Gmail 발송 워크플로 구축

---

## n8n 자동화 3대 패턴

| 패턴 | 구조 | 자동차 업무 예시 |
|------|------|-----------------|
| **수집→분석→보고** | 데이터 수집 후 AI 분석 | 주간 EV 뉴스 리포트 |
| **트리거→실행** | 조건 발생 시 자동 실행 | 가격 변동 감지 알림 |
| **알림→대응** | 이벤트 발생 시 대응 | 경쟁사 동향 즉시 알림 |

---

## 실습 1: 워크플로 요구사항 작성

```
[Claude Code에 입력]
"자동차 산업 주간 뉴스 자동화 워크플로 요구사항 문서를 작성해줘.
- 목적: 매주 월요일 오전 9시, EV 관련 뉴스 자동 수집·분석·발송
- 수신자: 팀장 + 관련 팀원
- 운영 가이드 포함
파일명: W14_Workflow_Docs.md"
```

## 실습 2: n8n 워크플로 자동 생성 및 실행

```
[Claude Code에 입력]
"다음 n8n 워크플로 JSON을 생성해줘:
1. Cron 트리거 (매주 월요일 09:00)
2. RSS/HTTP → 자동차 뉴스 수집 (상위 5개)
3. Claude API → 뉴스 요약 및 인사이트 분석
4. Google Docs → 보고서 자동 생성
5. Gmail → 지정 수신자에게 자동 발송
파일명: W14_Weekly_Report_Workflow.json"
```

**n8n에서 실행:**
1. n8n 접속 → Import Workflow
2. 생성된 JSON 붙여넣기
3. 테스트 실행 → Gmail 수신 확인

---

## 산출물
- [ ] `W14_Weekly_Report_Workflow.json`
- [ ] `W14_Workflow_Docs.md`
