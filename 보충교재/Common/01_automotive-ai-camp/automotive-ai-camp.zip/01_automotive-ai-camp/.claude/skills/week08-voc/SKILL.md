---
name: week08-voc
week: 8
title: 고객 리뷰(VOC) 분석 자동화
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, Google Colab, Google Docs, Google Sheets]
---

# Week 8 — 고객 리뷰(VOC) 분석 자동화

## 학습 목표
- VOC 분석 3단계(감성·키워드·클러스터링) 이해
- 분석 노트북 자동 생성 및 실행
- VOC 보고서 자동 생성

---

## VOC 분석 방법론

| 단계 | 내용 | AI 처리 |
|------|------|---------|
| **감성 분석** | 긍정/부정/중립 분류 | 1,000개 리뷰 10분 |
| **키워드 추출** | 자주 언급된 단어 Top 20 | 자동 빈도 분석 |
| **주제 클러스터링** | 유사 리뷰 그룹화 | 토픽 모델링 |

---

## 실습 1: VOC 분석 노트북 생성

```
[Claude Code에 입력]
"D4_Customer_Reviews.csv를 분석하는 노트북을 만들어줘.
1. 모델별 감성 분류 (긍정/부정/중립 비율)
2. 키워드 Top 20 워드클라우드
3. 모델별 만족도 비교 바차트
파일명: W08_VOC_Analysis.ipynb"
```

## 실습 2: VOC 보고서 자동 생성

```
[Claude Code에 입력]
"VOC 분석 결과를 바탕으로 제품팀용 보고서를 작성해줘.
- 불만 Top 5 (개선 우선순위)
- 만족 Top 5 (강점 유지 전략)
- 모델별 개선 권고사항
파일명: W08_VOC_Report.md"
```

---

## 산출물
- [ ] `W08_VOC_Analysis.ipynb`
- [ ] `W08_VOC_Report.docx`
- [ ] `D4_Reviews_Analyzed.xlsx`
