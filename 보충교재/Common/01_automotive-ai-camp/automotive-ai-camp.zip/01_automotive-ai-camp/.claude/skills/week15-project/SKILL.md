---
name: week15-project
week: 15
title: 최종 프로젝트 개발
duration: 3H | 전체 실습
mode: 오프라인
tools: [Claude Code, NotebookLM, n8n, Google Docs, Google Sheets, Google Slides]
---

# Week 15 — 최종 프로젝트 개발

## 학습 목표
- 1~14주 학습 내용을 통합한 실무 AI 시스템 구축
- QA 체크리스트 자동 생성 및 완성도 점검

---

## 프로젝트 옵션 (택 1)

### Option A: EV Market Intelligence System
EV 시장 데이터를 자동 수집·분석·보고하는 통합 시스템
- 데이터 파이프라인 (Perplexity → Claude → Google Sheets)
- 주간 자동 보고서 (n8n 워크플로)
- 경영진용 대시보드 슬라이드

### Option B: Customer VOC Intelligence System
고객 리뷰를 실시간 분석해 제품팀에 인사이트를 전달하는 시스템
- 리뷰 자동 수집 및 감성 분석
- 불만 우선순위 자동 분류
- 개선 권고 보고서 자동 생성

### Option C: Competitive Strategy Monitor
경쟁사 동향을 모니터링해 전략팀에 알림을 보내는 시스템
- 경쟁사 뉴스·가격·제품 변화 자동 추적
- 전략적 위협 자동 감지 및 알림
- 대응 전략 보고서 자동 생성

---

## 실습: 프로젝트 개발 (2.5H)

**Step 1: QA 체크리스트 생성**
```
[Claude Code에 입력]
"[선택한 옵션] 프로젝트의 QA 체크리스트를 만들어줘.
완성도 점검 항목, 수정 제안 포함."
```

**Step 2: 발표 Q&A 준비**
NotebookLM에 프로젝트 결과물 업로드:
```
"이 프로젝트에 대해 경영진이 질문할 수 있는 Q&A 10개를 생성해줘."
```

---

## 산출물
- [ ] 분석 노트북 (`.ipynb`)
- [ ] 전략 보고서 (`.docx`)
- [ ] 발표 슬라이드 (`.md`)
- [ ] 자동화 워크플로 설계서
