---
name: week06-notebook
week: 6
title: Claude Code로 데이터 분석 노트북 생성
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Claude Code, Google Colab, Google Docs]
---

# Week 6 — Claude Code로 데이터 분석 노트북 생성

## 학습 목표
- "노트북을 직접 짜지 않는다" 원칙 이해 및 적용
- Claude Code로 분석 노트북 자동 생성
- Google Colab 실행 → Docs 보고서 변환

---

## 핵심 원칙

> **수강생: 요구사항·해석·판단 / AI: 코드·생성·수정**

직접 Python을 쓰지 않는다. 무엇을 분석할지 말하면, Claude Code가 코드를 짠다.

---

## 실습: EV 시장 분석 노트북 자동 생성

**Step 1: 노트북 생성 요청**
```
[Claude Code에 입력]
"D1_EV_Sales.csv를 분석하는 Jupyter 노트북을 생성해줘.
분석 내용:
1. 브랜드별 시장 점유율 파이차트
2. 연도별 성장률 라인 차트
3. 국가별 판매량 비교 바차트
노트북 파일명: W06_EV_Market_Analysis.ipynb"
```

**Step 2: Google Colab에서 실행**
1. Colab(colab.research.google.com) 접속
2. 생성된 `.ipynb` 파일 업로드
3. 런타임 → 모두 실행

**Step 3: 보고서 변환**
```
[Claude Code에 입력]
"방금 실행한 노트북의 분석 결과를 바탕으로
경영진용 분석 보고서를 작성해줘.
파일명: W06_EV_Analysis_Report.md"
```

---

## 산출물
- [ ] `W06_EV_Market_Analysis.ipynb`
- [ ] `W06_EV_Analysis_Report.docx`
