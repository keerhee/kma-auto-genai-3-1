---
name: week10-tech
week: 10
title: 자동차 기술 트렌드 분석 + NotebookLM 심화
duration: 3H | 이론 1H · 실습 2H
mode: 오프라인
tools: [Perplexity, NotebookLM, Claude Code, Google Docs, Google Slides]
---

# Week 10 — 자동차 기술 트렌드 분석

## 학습 목표
- CASE 4대 기술 전환 분석 프레임워크 적용
- 배터리 기술 비교 분석 보고서 생성
- NotebookLM Audio Overview로 기술 팟캐스트 생성

---

## CASE 프레임워크

| 구분 | 내용 | 핵심 플레이어 |
|------|------|--------------|
| **C**onnected | 차량 인터넷 연결, OTA 업데이트 | Tesla, BMW |
| **A**utonomous | 자율주행 레벨 1~5 | Waymo, Mobileye |
| **S**hared | 카셰어링, 모빌리티 서비스 | Uber, 카카오T |
| **E**lectric | 배터리 EV, 수소차 | 현대, BYD |

---

## 실습 1: 배터리 기술 비교 분석

```
[Claude Code에 입력]
"LFP vs NMC vs 전고체 배터리를 비교 분석해줘.
비교 항목: 에너지밀도, 안전성, 비용, 수명, 상용화 시점
한국 기업(삼성SDI·LG에너지솔루션·SK온) 포지셔닝 포함
파일명: W10_Battery_Tech_Report.md"
```

## 실습 2: NotebookLM 기술 팟캐스트 생성

1. Week 9 지식베이스에 기술 자료 3개 추가
2. Audio Overview → CASE 기술 중심 팟캐스트 생성

## 실습 3: 자율주행 슬라이드 자동 생성

```
[Claude Code에 입력]
"자율주행 기술 현황 발표용 슬라이드 7장을 마크다운으로 작성해줘.
구성: 개요, 레벨 정의, 주요 기업, 한국 현황, 기회와 위협, 전망, 결론
파일명: W10_Autonomous_Slides.md"
```

---

## 산출물
- [ ] `W10_Battery_Tech_Report.docx`
- [ ] `W10_Autonomous_Slides.md`
- [ ] CASE 기술 팟캐스트
