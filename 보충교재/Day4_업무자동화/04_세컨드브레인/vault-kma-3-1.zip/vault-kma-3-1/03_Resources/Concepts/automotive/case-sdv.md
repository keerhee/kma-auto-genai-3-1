---
type: concept
status: draft
tags: [concept, automotive, case, sdv]
field: automotive
related: ["[[tps-andon]]", "[[six-step-workflow]]", "[[raas]]", "[[tesla-2008]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_3_Main_자동차시장및트렌드이해.pdf|Day1 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_2_Front2H_Intro_deck.pdf|Day1 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# CASE와 SDV — 자동차 산업의 4대 변화와 그 토대

## 정의
- **CASE**: 자동차 산업의 4대 변화. Connected(연결), Autonomous(자율주행), Shared(공유), Electric(전동화).
- **SDV(Software-Defined Vehicle, 소프트웨어 중심 자동차)**: 차의 성능·기능이 하드웨어가 아니라 소프트웨어로 정의되는 자동차. 출고 후에도 OTA(무선 소프트웨어 업데이트)로 기능이 추가·개선된다 — "바퀴 달린 스마트폰".

## 왜 필요한가
CASE의 네 변화는 서로 분리되지 않고 모두 소프트웨어 위에서 작동한다. SDV는 이 넷을 묶는 토대이며, 완성차 경쟁의 무게중심이 "기계 제조"에서 "SW·데이터"로 이동하는 지점이다. 부품사에게는 전장·SW 부품 수주 기회와 내연기관 전용 부품 물량 축소 압력이 함께 온다.

## 판단 기준
| 축 | 의미 | 현장 예시 (덱 기준) |
|---|---|---|
| Connected | 차가 인터넷·기기와 연결 | 실시간 내비, 차량 데이터 전송 |
| Autonomous | 운전 보조·자율주행 | 차선 유지, 자동 주차 (ADAS가 전 단계) |
| Shared | 소유 대신 공유 | 카셰어링, 차량 호출 |
| Electric | 내연기관 → 전기 | 배터리 전기차(BEV) |
| SDV (토대) | SW가 차의 가치를 정의 | OTA, SW 구독이라는 새 수익원 |

## 예시
- 에피소드 "밤새 빨라진 차": 하드웨어는 그대로인데 밤사이 무선 업데이트로 가속이 좋아지고 새 기능이 생겼다.
- 테슬라 모델 S(2012)는 OTA로 진화하는 차 — 덱이 말하는 SDV의 원형([[tesla-2008]]).
- 자동차는 대당 이익률이 한 자릿수인 박리다매 산업이어서, SDV의 "SW 구독"이 새 수익원으로 주목받는다(Front 덱).
- 현대차그룹의 SDV 전환 선언 — SW 조직에 대규모 투자. "고객사(OEM)의 전략 전환 = 부품사의 사업 환경 전환".

## 관련 개념
- [[tps-andon]] — 이전 전환(품질·효율 혁신)의 상징. CASE·SDV는 세 번째 전환(전동화·SW).
- [[raas]] — 판매 1회 수익에서 운영·구독 지속 수익으로 가는 같은 흐름이 로봇에서도 나타난다.
- [[six-step-workflow]] — 1일차 실습에서 CASE 분석·SDV 대응전략 비교를 6단계로 수행.

## 쓰인 곳
- [[day1-market-trends]] (본 강의 4장 CASE·4.1 SDV, 실습 ②·⑤)
- [[tesla-2008]] (Hook 케이스)
- [[day6-final-project]] (통합 보고서 ② 시장 현황)
