---
type: concept
status: draft
tags: [concept, automotive, tps, andon, quality]
field: automotive
related: ["[[case-sdv]]", "[[automation-fit-matrix]]", "[[rag-chatbot]]", "[[smart-factory-4-processes]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_3_Main_자동차시장및트렌드이해.pdf|Day1 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day4/Day4_2_Front2H_Intro_deck.pdf|Day4 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# TPS와 안돈 — 이상하면 사람이 즉시 멈춘다

## 정의
- **TPS(Toyota Production System, 도요타 생산방식)**: 낭비 제거·표준화로 품질과 효율의 기준을 다시 세운 생산방식. 자동차 산업 100년의 두 번째 전환(품질·효율 혁신)의 중심.
- **안돈(Andon)**: 불량·설비 이상이 생기면 라인을 즉시 멈춰 그 자리에서 해결하게 하는 품질관리 시스템.
- **안돈 줄(Andon Cord)**: 그 시스템을 작동시키는 도구. 작업자가 당기면 관리자에게 전달되고 라인이 멈춘다. "누구든 문제를 발견하면 라인을 멈출 수 있다."

## 왜 필요한가
불량을 뒤 공정으로 흘려보내지 않고 그 자리에서 잡는 것이 TPS의 핵심 철학이다. 이 과정에서는 안돈을 공장 밖으로 확장해 쓴다 — 사무 자동화·AI 챗봇·협동로봇 모두 "사람이 멈출 수 있는 지점"이 있어야 신뢰받는다.

## 판단 기준
| 공장 자동화의 유산 (Day4 Front) | 사무·AI 자동화로의 번역 |
|---|---|
| 표준(SOP) 없는 자동화는 없다 | 업무를 표준 절차로 적을 수 있어야 자동화된다 |
| 안돈 줄 — 이상하면 사람이 즉시 멈춘다 | AI 산출물에 검토 게이트(사람이 멈추는 지점)를 둔다 |
| 작은 개선(카이젠)의 누적 | 복잡한 것 말고 작은 반복부터 자동화 |

## 예시
- 1일차 에피소드 대비: 포드 "검은색이기만 하다면 어떤 색이든"(선택지를 줄인 대량생산) ↔ 도요타 "안돈 줄"(불량을 그 자리에서).
- 1일차 인트로: 재고를 최소화하는 JIT(적시생산)는 차량용 반도체 대란 때 칩 몇 개에 라인이 서는 약점을 드러냈다 — 효율의 극한은 충격에 약하다.
- 4일차 보강 실습: 보류 업무 운영 런북에 안돈 원칙을 문장으로 옮기고, "사람이 멈출 수 있는 자동화가 신뢰받는 자동화"로 정리.
- 로봇 특강: 협동로봇은 사람 접근 시 감속·정지 — "이상하면 사람이 즉시 멈춘다, 안돈의 정신은 여기서도 유효하다".

## 관련 개념
- [[automation-fit-matrix]] — 무엇을 자동화할지 고를 때 "판단·관계는 사람" 원칙과 짝.
- [[rag-chatbot]] — "모르면 담당자 연결" 한계 처리 = 챗봇의 안돈.
- [[case-sdv]] — 다음 전환(전동화·SW).
- [[smart-factory-4-processes]] — 도요타(프로세스 혁신)·테슬라(AI 자동화)·팔란티어(데이터 플랫폼) 비교.

## 쓰인 곳
- [[day1-market-trends]] (1.1 에피소드), [[day4-job-automation]] (Front 업의 유산, Back 런북), [[day5-predictive-maintenance]] (제조 혁신 비교), [[robot-special]] (안전)
