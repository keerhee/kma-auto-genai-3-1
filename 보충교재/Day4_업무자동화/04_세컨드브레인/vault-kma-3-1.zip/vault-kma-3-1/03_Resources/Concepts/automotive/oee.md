---
type: concept
status: draft
tags: [concept, automotive, oee, kpi, manufacturing]
field: automotive
related: ["[[smart-factory-4-processes]]", "[[maintenance-4-stages]]", "[[anomaly-2-sigma]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_2_Front2H_Intro_deck.pdf|Day5 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# OEE — 설비종합효율 (Overall Equipment Effectiveness)

## 정의
설비가 계획 시간 동안 얼마나 제대로 일했는지를 하나의 숫자로 나타낸 지표. 가용률(Availability) · 성능률(Performance) · 품질률(Quality)의 곱이다.

## 왜 필요한가
공장·보전 관리자는 이 지표로 생각한다. 예지보전의 성과도 결국 현장 지표로 말해야 통한다 — "MTBF가 늘고 계획 외 정지가 줄었다". 오후 보고서의 독자가 쓰는 언어로 결과를 말하기 위해 미리 익힌다.

## 핵심 수식
$$
\text{OEE} = \text{가용률} \times \text{성능률} \times \text{품질률}
$$

세 항목의 일반적 의미(덱은 곱의 구조만 제시): 가용률은 계획 시간 중 실제로 돌아간 비율(정지 손실), 성능률은 돌아간 시간 동안 목표 속도 대비 실제 속도(속도 손실), 품질률은 만든 것 중 양품 비율(불량 손실). 세 항목이 곱해지므로 하나만 낮아도 OEE 전체가 크게 떨어진다.

## 판단 기준
설비의 언어 — 현장이 매일 쓰는 네 가지 지표 (Front 덱):

| 지표 | 뜻 | 왜 보나 |
|---|---|---|
| 가동률 | 계획 시간 중 실제로 돌아간 비율 | 정지가 얼마나 있었나 |
| OEE | 가용성 × 성능 × 품질의 곱 | 세계적 기준 — 85%면 최상급 (덱 기준) |
| 택트타임 | 한 대(개)를 만드는 목표 주기 | 라인 속도의 기준 박자 |
| MTBF · MTTR | 고장 간 평균 시간 · 평균 복구 시간 | 길수록 튼튼 · 짧을수록 빠른 복구 |

## 예시
- 인트로 정리: "택트타임·가동률·OEE — 공장은 이 박자로 산다. 분석도 이 언어로 보고해야 통한다."
- 예지보전 보고서의 효과 서술: 예방→예측 정비 전환 효과를 "비용"과 "라인 정지" 두 측면으로 쓰고, 성과는 MTBF·계획 외 정지로 말한다(5일차 실습과제 3).
- 로봇 특강 90일 파일럿: 2교대 단계(61~90일)에서 가동률·TCO를 추정 대비로 점검해 확대 승인 또는 중단 보고.

## 관련 개념
- [[maintenance-4-stages]] — OEE의 가용률을 깎는 계획 외 정지를 줄이는 방법.
- [[smart-factory-4-processes]] — 택트타임이 정지 1분의 손실을 키우는 이유.
- [[anomaly-2-sigma]]

## 쓰인 곳
- [[day5-predictive-maintenance]] (인트로 · 설비의 언어)
- [[robot-special]] (파일럿 가동률 점검)
