---
type: concept
status: draft
tags: [concept, finance, financial-analysis, operating-margin]
field: finance
related: ["[[positioning-map]]", "[[scenario-analysis]]", "[[gm-bankruptcy-2009]]", "[[automaker-financials]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_3_Main_경쟁사재무와전략분석.pdf|Day3 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_2_Front2H_Intro_deck.pdf|Day3 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 재무 3대 지표 — 매출 추이 · 영업이익률 · R&D 비율

## 정의
경쟁사의 체력을 숫자로 읽는 세 지표. **매출 추이(성장률)** — 시장에서 덩치가 커지는가, **영업이익률(Operating Margin)** — 팔아서 남기는 힘, **R&D 투자 비율** — 미래 기술에 얼마나 베팅하는가. 1차 출처는 DART(금융감독원 전자공시)와 IR(투자자 대상 실적·전략 자료).

## 왜 필요한가
덩치가 다른 회사는 절대 금액으로 비교할 수 없다(도요타 이익이 부품사의 100배여도 "더 잘한다"는 뜻이 아님). 그래서 매출 대비 %로 바꾼다. 또 한 지표만 보면 위험을 놓친다 — 세 지표를 조합해야 전략이 보인다.

## 핵심 수식
$$
\text{영업이익률} = \frac{\text{영업이익}}{\text{매출액}},\qquad
\text{R\&D 비율} = \frac{\text{R\&D 비용}}{\text{매출액}},\qquad
\text{매출 성장률} = \frac{\text{매출}_t - \text{매출}_{t-1}}{\text{매출}_{t-1}}
$$

영업이익은 손익계산서 계단에서 나온다: 매출액 − 매출원가 = 매출총이익, 매출총이익 − 판관비(판매·관리·R&D) = 영업이익.

## 예시
조합으로 읽는 네 유형 (Main 덱):

| 조합 | 유형 | 해석 |
|---|---|---|
| 매출↑ · 이익률↓ | 박리다매형 | R&D까지 낮으면 가격 경쟁에 갇힐 위험 |
| 이익률↓ · R&D↑ | 미래 투자형 | 전환기 완성차에서 자주 보임 |
| 매출↑ · 이익률↑ | 고수익 성장형 | 프리미엄·브랜드 우위 가능성 |
| 매출→ · 이익률↑ | 안정 수익형 | 성장 동력 확보가 다음 과제 |

- 실습과제 1 모범답안: 매출 +12%, 영업이익률 4%, R&D 9% → "성장 중이나 수익성은 약하고 R&D가 높아 미래에 베팅하는 미래 투자형".
- 업계 감각(개략치, 덱 기준): 완성차 영업이익률은 대략 한 자릿수(5~10%면 양호), R&D 비율은 대략 3~7%이고 전환기엔 더 높아진다.
- 함정: 흑자도산 — 장부상 이익은 나는데 현금이 돌지 않아 무너진다. 환율 착시 — 원화 약세면 앉아서 이익이 늘므로 실력(원가·믹스)과 바람(환율)을 나눠 읽는다. 비교 시 통화·연결/별도 기준을 통일한다.

## 관련 개념
- [[positioning-map]] — 같은 영업이익률도 R&D·매출 추이를 함께 보면 정반대 전략일 수 있어 두 축 위치로 본다.
- [[scenario-analysis]] — 판매량·원자재가 바뀌면 영업이익률이 얼마나 흔들리나.
- [[pyramid-principle]] — 보고서 바닥의 근거 수치(예: 영업이익률 6%).

## 쓰인 곳
- [[day3-competitor-finance]] (2. 재무 분석, 실습 ②~④, 실습과제 1)
- Hook 케이스 [[gm-bankruptcy-2009]] — 매출 추이·수익성·현금이 몰락의 신호
- 데이터셋 [[automaker-financials]]
