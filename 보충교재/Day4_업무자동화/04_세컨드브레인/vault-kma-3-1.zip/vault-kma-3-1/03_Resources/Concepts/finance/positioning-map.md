---
type: concept
status: draft
tags: [concept, finance, strategy, positioning]
field: finance
related: ["[[three-core-metrics]]", "[[chart-matching]]", "[[scenario-analysis]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_3_Main_경쟁사재무와전략분석.pdf|Day3 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf|Day2 Main 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 포지셔닝 맵 (Positioning Map)

## 정의
가로·세로에 두 기준(예: 가격, 기술 수준)을 놓고 각 기업의 위치를 점으로 찍은 그림. 차트로는 산점도(scatter plot)다.

## 왜 필요한가
한 지표(예: 영업이익률)만으로는 같아 보이는 기업도, 두 축 위에 놓으면 전략의 차이가 위치로 드러난다. "누가 고가-고기술 구역에 있는가"가 한눈에 보이고, **빈 구역(아무도 없는 자리)이 곧 기회의 공간**이다. 재무가 "결과"라면 전략은 "방향"이고, 포지셔닝 맵은 그 방향을 보여 준다.

## 판단 기준
| 단계 | 기준 |
|---|---|
| 축 고르기 | 전략 비교 축 3가지 중 선택 — 가격 대비 기술 수준, 지역별 공략 방식, 핵심 역량(엔지니어링·SW·브랜드·원가) |
| 점수화 | 각 축 1~5점 척도 |
| 근거 | 점수마다 한 줄 근거 — 점수만 있고 근거가 없으면 감점 |
| 읽기 | 어느 구역에 몰려 있고 어디가 비었는가 |

## 예시
- 3일차 실습 ④: Claude로 5개사를 [가격대 / 기술 수준] 1~5점 좌표표로 만들고 Google Sheets 산점도로 그린다.
- 모범답안 예: 테슬라 — 가격 4, 기술 5 (OTA·자율주행 선도, 프리미엄 가격대).
- 케이스 "숫자 뒤의 전략": A사는 R&D 비율이 높아 이익을 아낀 미래 투자형, B사는 R&D를 줄여 이익을 지킨 이익 방어형 — 같은 영업이익률이 정반대 전략일 수 있다.
- 케이스 독일 e-모빌리티 전환: 엔지니어링·대량생산 강점 대 전환 속도·SW 내재화 약점 — "어떤 축으로 비교할까"를 연습하기 좋은 사례.
- 임원용 보고서 5단 골격에서 ③ 전략 포지셔닝 칸을 채운다.

## 관련 개념
- [[three-core-metrics]] — 한 지표의 한계가 포지셔닝 맵이 필요한 이유.
- [[chart-matching]] — "두 기준 위치 → 산점도".
- [[scenario-analysis]]

## 쓰인 곳
- [[day2-crawling-viz]] (용어 소개)
- [[day3-competitor-finance]] (3. 전략 분석, 실습 ④, 실습과제 2)
- [[day6-final-project]] (통합 보고서 5사 비교)
