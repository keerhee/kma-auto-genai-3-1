---
type: concept
status: draft
tags: [concept, robotics, raas, business-model, tco]
field: robotics
related: ["[[robot-value-chain]]", "[[case-sdv]]", "[[maintenance-4-stages]]", "[[robot-pilot-cases]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_3_Main_로봇과스마트팩토리특강.pdf|Robot 특강 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_4_Back2H_Practice_deck.pdf|Robot 특강 Back 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# RaaS — 로봇을 파는 게 아니라 빌려준다

## 정의
**RaaS(Robot-as-a-Service, 서비스형 로봇)**: 로봇을 판매하는 대신 운영하며 구독료를 받는 사업 모델. 자동차는 제조 → 판매 → 1회 수익(팔면 끝)이지만, RaaS는 제조 → 운영 → 월 구독 → 지속 수익이다. 덱의 쉬운 비유는 정수기 렌탈.

## 왜 필요한가
도입하는 쪽은 자본 투자 없이 바로 시작하고 위험을 줄인다. RaaS의 진짜 가치는 가격보다 "위험을 줄이고 빠르게 시작"하는 데 있다 — 단, 오래 쓰면 직접 구매가 쌀 수 있다. 공급하는 쪽은 가치사슬의 운영·서비스 층에서 로봇이 늘수록 커지는 반복 수익을 얻는다.

## 판단 기준
구매 vs RaaS 선택은 **TCO(총소유비용)** — 가격 + 유지보수·배터리·전기·교육 — 로 판단한다.

| 항목 | 덱 수치 (Main 덱 기준) |
|---|---|
| 상업용 구독료 | 월 \$2,000~8,000 (시간당 약 \$2~5) |
| 입문형 전망 | 2027년 월 \$300 수준 (중소기업도) |
| 초기 부담 | 0 — 자본 투자 없이 도입 |
| 상업용 로봇 TCO | 연 \$5,000~15,000 수준 |

보강 실습의 TCO 검토 포함 항목: ① 구매 vs RaaS 구독의 선택 논리 ② 유지보수·교육 등 숨은 비용. 흔한 감점: 사람의 남는 역할("유지·훈련할 사람") 누락, 휴머노이드 만능론.

## 예시
- 현대차의 네 가지 수익모델: Robot OEM(만들어 판다), RaaS(빌려준다), Factory OS(공장 운영 SW를 판다), Physical AI 플랫폼(AI+로봇 생태계 운영).
- 실제 고객: DHL·네슬레·머스크. Stretch는 2023년 이후 상자 2,000만 개+를 옮겼다 — 판매가 아니라 운영·구독으로 전환 중(덱 기준).
- 같은 흐름의 다른 사례: 항공 엔진사가 "가동 시간당 요금" 계약으로 바꾼 것(5일차 인트로), SDV의 SW 구독(1일차).
- 90일 파일럿 보강 실습: 구매 대신 RaaS로 시작할 때의 차이와 사람의 역할(감독·복구)을 한 문단으로.

## 관련 개념
- [[robot-value-chain]] — RaaS는 세 번째 층(운영·서비스)의 핵심.
- [[case-sdv]] — 1회 판매에서 구독 수익으로.
- [[maintenance-4-stages]] — 정비가 원가에서 서비스 상품으로 바뀌는 논리.

## 쓰인 곳
- [[robot-special]] (⑥ Robot Economy, 보강 실습 A·B TCO 검토)
- 케이스 [[hyundai-boston-dynamics]]
- 데이터셋 [[robot-pilot-cases]]
