---
type: concept
status: draft
tags: [concept, workflow, no-code, common]
field: common
related: ["[[prompt-4-elements]]", "[[ai-crawling]]", "[[chart-matching]]", "[[anomaly-2-sigma]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day0/Day0_1_강의소개및개요.pdf|Day0 강의소개 및 개요]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_3_Main_자동차시장및트렌드이해.pdf|Day1 Main 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# AI 노코드 6단계 워크플로우

## 정의
과정의 모든 날이 반복하는 실습 틀: **환경 → 데이터 → 전처리(preprocessing) → 분석1 → 분석2 → 평가**. 코드 없이 프롬프트만으로 완주하며, 매 단계에서 입력(프롬프트)과 출력(산출물)을 구분한다.

## 왜 필요한가
같은 틀을 매일 반복하면 분석 습관이 몸에 밴다. 주제(시장·데이터·재무·자동화·예지보전)가 바뀌어도 순서가 같으므로, 수강생은 "지금 어느 단계인가"만 확인하면 된다. 각 날의 산출물은 6일차 통합 보고서의 조각이 된다.

## 판단 기준
| 단계 | 하는 일 | 1일차 예 (시간) |
|---|---|---|
| ① 환경 | 목적별 도구 준비 — 최신 사실은 Perplexity, 깊은 분석·표는 Claude, 발상은 ChatGPT, 정리·계산은 Google Sheets | 15분 |
| ② 데이터 | 분석할 원자료 수집·생성 | 테슬라 CASE 성공요인 후보 10개, EV 뉴스 10건 (40분) |
| ③ 전처리 | 중복 제거·분류·핵심 추출 | 뉴스를 기술/시장/정책으로 분류 (30분) |
| ④ 분석1 | 첫 번째 핵심 산출물 | 성공요인 5가지 비교표 (45분) |
| ⑤ 분석2 | 두 번째 관점의 산출물 | SDV 관련 뉴스 3건 대응전략 비교 (40분) |
| ⑥ 평가 | "그래서 무엇을 알았나" 종합 | 전략적 시사점 3가지 (30분) |

평가 단계의 **좋은 시사점 세 조건**: ① 데이터에 근거가 있다 ② 비교 대상이 분명하다 ③ 다음 행동으로 이어진다.

## 예시
- 2일차: 국내 EV 판매 Top5 수집 → 막대 차트 → 아이오닉5 VOC 감정분석.
- 3일차: 5개사 재무 수집 → 영업이익률 막대·매출 선 차트 → 포지셔닝 맵 → 임원 보고서 초안.
- 4일차: 직무 업무 진단 → ROI 구조화 → 수집-요약-정리 파이프라인 → RAG CS 챗봇.
- 5일차: 센서 데이터 → 평균 ± 2σ 정제 → 노이즈/추세 판별 → 정비 권고 보고서.
- 단계별 시간 배분은 날마다 다르다(예: 3일차 분석1 60분).

## 관련 개념
- [[prompt-4-elements]] — 각 단계의 [입력] 프롬프트를 쓰는 규칙.
- [[ai-crawling]], [[chart-matching]], [[voc-sentiment-analysis]] (2일차 단계 내용)
- [[three-core-metrics]], [[positioning-map]] (3일차)
- [[automation-fit-matrix]], [[collect-summarize-organize]], [[rag-chatbot]] (4일차)
- [[anomaly-2-sigma]], [[noise-vs-trend]] (5일차)

## 쓰인 곳
- [[day0-orientation]], [[day1-market-trends]], [[day2-crawling-viz]], [[day3-competitor-finance]], [[day4-job-automation]], [[day5-predictive-maintenance]]
