---
type: concept
status: draft
tags: [concept, data-analysis, voc, sentiment]
field: data-analysis
related: ["[[ai-crawling]]", "[[chart-matching]]", "[[pyramid-principle]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf|Day2 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_2_Front2H_Intro_deck.pdf|Day2 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# VOC 감정분석

## 정의
- **VOC(Voice of Customer)**: 리뷰·문의·설문 등 고객이 남긴 목소리.
- **감정분석(sentiment analysis)**: 텍스트가 긍정인지 부정인지 판단하는 분석. 실습에서는 Claude로 리뷰를 긍·부정으로 분류하고 키워드 Top 5를 빈도와 함께 뽑는다.
- **페르소나(persona)**: 전형적 고객을 한 인물로 정리한 것.

## 왜 필요한가
판매 숫자는 "무엇이" 팔렸는지를, VOC는 "왜 좋아하고 싫어하는가"를 말한다. 정량(판매)과 정성(VOC)을 함께 봐야 시장과 고객이 입체적으로 보인다. 리뷰는 비정형 데이터라 예전엔 분석이 어려웠지만, 이제 AI가 분류·요약해 표로 바꿔 준다.

## 판단 기준
| 단계 | 하는 일 | 점검 |
|---|---|---|
| 수집 | 리뷰·커뮤니티·설문에서 VOC 확보 | 실데이터인지 가상인지 표기 |
| 분류 | 리뷰별 긍정/부정 판정 | 판정 기준이 일관된가 |
| 키워드 | 긍정·부정 키워드 Top 5 + 빈도 | 빈도 근거가 표에 있는가 |
| 시각화 | 비율·구성 → 누적 막대 | [[chart-matching]] 원칙 |
| 제안 | 데이터 → 해석 → 행동 | 개선 우선순위 1가지를 근거와 함께 |

## 예시
- 케이스 "리뷰가 먼저 알려준 신호": 한 전기차 출시 초기 판매는 무난했지만 리뷰에서 "충전" 부정 키워드가 급증 — 판매 데이터만 봤다면 놓칠 신호를 일찍 잡아 충전 안내·SW 개선.
- 모범답안 흐름: 부정 키워드 중 '충전'이 최다(데이터) → 충전 경험이 불만 핵심(해석) → 개선 1순위는 충전 안내·앱 사용성(행동). 가상 데이터 미표기는 감점.
- 인트로 사례: 현대차가 품질조사 지표를 전사 관리 지표로 삼아 신뢰를 회복 — "VOC 감정분석은 그 축소판"(Front 덱).
- 실습 데이터: 아이오닉5 VOC 리뷰 30건(가상) → [[voc-reviews-synthetic]].

## 관련 개념
- [[ai-crawling]] — VOC 수집·가상 VOC 생성 도구 선택.
- [[chart-matching]] — 긍·부정 빈도는 누적 막대.
- [[pyramid-principle]] — 6일차 보고서의 헤드라인 예: "부정 키워드 1위는 충전 — 개선 1순위 후보".

## 쓰인 곳
- [[day2-crawling-viz]] (4. VOC, 실습 ⑤ 분석2, 실습과제 3)
- [[day6-final-project]] (통합 보고서의 고객 조각)
