---
type: concept
status: draft
tags: [concept, data-analysis, anomaly, statistics, sensor]
field: data-analysis
related: ["[[noise-vs-trend]]", "[[maintenance-4-stages]]", "[[anscombe-quartet]]", "[[sensor-log-synthetic]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_2_Front2H_Intro_deck.pdf|Day5 Front 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_3_Main_자동차예지보전AI활용.pdf|Day5 Main 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 평균 ± 2σ 평상 범위와 이상 후보

## 정의
센서 변수마다 평균과 표준편차(σ)를 구해 **평균 ± 2σ**를 평상 범위로 잡고, 그 밖의 값을 "이상 후보(anomaly candidate)"로 표시하는 방법. **이상 패턴(anomaly)**은 평소와 크게 다른 값이나 흐름이다.

## 왜 필요한가
평균만으로는 "얼마나 벗어났는지" 판단할 수 없다. 표준편차라는 평상 출렁임의 폭을 기준으로 삼으면 이상 후보를 객관적으로 표시할 수 있다. 정상이라면 값의 약 95%가 이 안에 들어가므로, 밖의 값은 정상일 때 20번에 1번꼴로만 나온다 — 그래서 "이상 후보"라 부를 자격이 생긴다. "±2σ는 마법이 아니라 상식이다."

## 핵심 수식
$$
\mu = \frac{1}{n}\sum_{i=1}^{n} x_i,\qquad
\sigma = \sqrt{\frac{1}{n}\sum_{i=1}^{n} (x_i - \mu)^2}
$$

$$
\text{평상 범위} = [\,\mu - 2\sigma,\ \mu + 2\sigma\,] \quad(\text{약 } 95\%),\qquad
\mu \pm 3\sigma \quad(\text{약 } 99.7\%)
$$

(약 95%·99.7%는 정규분포를 가정한 값. 표본 표준편차는 분모를 $n-1$로 쓰기도 한다.)

## 판단 기준
| 개념 | 직관 | 실습에서 |
|---|---|---|
| 평균 | 값들의 무게중심 | 센서의 평상 수준 |
| 표준편차 σ | 평균에서 벗어나는 보통의 폭 | 센서의 평상 출렁임 |
| 평균 ± 2σ | 정상이면 약 95%가 든다 | 평상 범위 — 밖이면 이상 후보 |
| ±3σ | 약 99.7%가 드는 보수적 기준 | 오탐을 줄이고 싶을 때 |

범위 밖이라는 것은 "후보"일 뿐이다 — 정비 신호인지는 [[noise-vs-trend]]로 다시 판정한다. 측정 주기·단위를 먼저 확인하고, 교대·요일 등 주기성 출렁임을 이상으로 오인하지 않는다.

## 예시
- 5일차 실습 ③ 전처리: 센서 데이터를 [시간 / 진동 / 온도 / 압력] 표로 정리하고 변수별 평균·표준편차·평상 범위를 계산해 범위 밖 값을 "이상 후보"로 표시(설비센서 50건, 가상).
- 다변수의 힘: 진동(mm/s)은 베어링·회전체 마모, 온도(℃)는 마찰·과부하·윤활 부족, 압력(bar)은 유압·공압 누출·막힘 — 한 변수가 놓친 이상을 세 변수를 함께 보면 잡는다.
- 점검용 함정 데이터: 단위가 섞이면 이상 판단이 흔들린다(설비센서 단위혼재 함정, 가상).

## 관련 개념
- [[noise-vs-trend]] — 이상 후보 중 진짜 정비 신호 고르기.
- [[anscombe-quartet]] — 요약통계량만으로는 구조가 안 보인다: 표와 함께 선 차트로 그린다.
- [[maintenance-4-stages]] — 예측 정비의 "징후" 판정 도구.

## 쓰인 곳
- [[day5-predictive-maintenance]] (Front 통계 몸풀기, 실습 ③ 전처리, 미니 프로젝트)
- 데이터셋 [[sensor-log-synthetic]]
