---
type: concept
status: draft
tags: [concept, data-analysis, visualization, statistics]
field: data-analysis
related: ["[[chart-matching]]", "[[anomaly-2-sigma]]", "[[noise-vs-trend]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_5_보조_시각화의두고전_나이팅게일과앤스컴.pdf|Day2 보조 · 시각화의 두 고전]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf|Day2 Main 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 앤스컴의 사중주 (Anscombe's Quartet)

## 정의
영국 통계학자 Francis J. Anscombe가 1973년 논문 *Graphs in Statistical Analysis*에서 제시한 네 개의 데이터 묶음. 각 묶음은 관측치 11개이고 평균·분산·상관계수·회귀직선이 (반올림하면) 같지만, 점으로 찍으면 전혀 다른 구조가 드러난다. 덱은 "평균의 함정"보다 **"요약통계량의 함정"**이 정확한 이름이라고 짚는다.

## 왜 필요한가
회귀표·요약표만 보면 네 묶음 모두 "선형회귀가 잘 맞는다"고 결론 내리게 된다. 그림은 숫자가 숨긴 구조(곡선·이상치·레버리지)를 보여 주고, 어떤 모형이 맞는지 알려 준다 — "숫자만 보지 말고 그려 보라. 회귀표를 내기 전에 산점도부터."

## 핵심 수식
네 묶음이 공유하는 요약통계량 (보조 덱 표 기준):

$$
\bar{x} = 9.00,\qquad \bar{y} = 7.50,\qquad s_y^2 \approx 4.12\text{–}4.13,\qquad r \approx 0.816\text{–}0.817
$$

회귀직선 $\hat{y} = a + b\,x$ 도 네 묶음이 거의 같다(보조 덱은 계수 값을 따로 적지 않음).

## 예시
| 패널 | 실제 모습 | 분석할 때의 의미 |
|---|---|---|
| I | 직선 주변에 흩어짐 | 선형회귀가 비교적 적절 |
| II | 곡선을 따라 배열 | 직선으로는 관계의 형태를 놓침 |
| III | 한 점만 크게 벗어남 | 이상치가 회귀 결과를 왜곡 |
| IV | x=8에 몰리고 한 점만 멂 | 그 한 점(레버리지)이 기울기를 좌우 |

- 짝을 이루는 고전: 나이팅게일의 장미 도표(1858)는 "행동의 우선순위"를, 앤스컴은 "숨은 구조"를 보인다.
- 자동차 실무로 옮기면: 두 공장 센서의 평균·분산이 같아도 한쪽은 추세적 상승, 한쪽은 한 번 튄 값일 수 있다 — 5일차 [[noise-vs-trend]]와 같은 교훈(일반적 적용 설명).

## 관련 개념
- [[chart-matching]] — 왜 시각화인가의 근거.
- [[anomaly-2-sigma]] — 평균·표준편차만으로 판단하는 것의 한계와 보완.
- [[noise-vs-trend]] — 한 점보다 흐름을 그려서 본다.

## 쓰인 곳
- [[day2-crawling-viz]] (3.1 왜 시각화인가)
- 보조자료: [[day2-nightingale-anscombe]]
