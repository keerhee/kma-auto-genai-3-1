---
type: concept
status: draft
tags: [concept, data-analysis, time-series, predictive-maintenance]
field: data-analysis
related: ["[[anomaly-2-sigma]]", "[[maintenance-4-stages]]", "[[anscombe-quartet]]", "[[chart-matching]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_3_Main_자동차예지보전AI활용.pdf|Day5 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_2_Front2H_Intro_deck.pdf|Day5 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 노이즈인가, 추세인가 (Noise vs Trend)

## 정의
- **노이즈(noise)**: 한 번 튀고 곧 정상으로 돌아오는 일시적 값. 측정 오류·순간 외란일 수 있다.
- **추세(trend)**: 임계선(threshold)을 향해 꾸준히 오르는 흐름. 이 상승의 **시작점**이 진짜 정비 신호다.

## 왜 필요한가
임계선을 넘는 한 점에 반응하면 오탐으로 불필요한 정비를 하고, 흐름을 놓치면 고장을 맞는다. 꾸준한 상승의 시작점을 잡아야 "고장 전 계획 정비"가 가능하다. 시계열은 한 점보다 흐름으로 봐야 한다 — "스냅샷은 상태를, 시계열은 운명을 보여준다."

## 판단 기준
| 구분 | 모양 | 판정 | 행동 |
|---|---|---|---|
| 노이즈 | 한 번 튀고 곧 복귀 | 정비 신호 아님 | 관찰 유지 |
| 추세 | 임계선을 향해 꾸준히 상승 | 정비 신호 | 상승 시작점을 "정비 필요 시점"으로 |
| 주기성 | 교대·요일·계절 따라 반복 출렁임 | 이상으로 오인 금지 | 주기를 먼저 확인 |

시계열의 세 얼굴(Front 덱): 추세 · 주기성 · 이상치.

## 예시
5일차 실습과제 2 — 어느 쪽이 정비 신호인가:

$$
\text{A}: 1.0 \to 1.1 \to 0.9 \to 3.5 \to 1.0 \qquad
\text{B}: 1.0 \to 1.3 \to 1.7 \to 2.2 \to 2.9
$$

정답은 B. A의 3.5는 한 번 튀고 곧 정상으로 돌아온 일시적 노이즈다. B는 임계선을 향해 꾸준히 오르는 추세적 상승이다. "한 번 높았으니 위험"은 노이즈와 추세를 혼동한 답으로 감점.

- 5일차 실습 ④: 이상 후보가 노이즈인지 추세인지 구분하고, 추세가 시작된 시점을 정비 필요 시점으로 표시 → Google Sheets 선 차트(시간축 + 변수 + 임계선).
- 정비 권고 보고서의 개선안 = 점검 주기·임계값을 데이터에 맞게 조정하는 것.
- 베어링의 일생: 진동이 추세적으로 오르는 ② 단계를 잡으면 ④ 파손 전에 정비할 수 있다.

## 관련 개념
- [[anomaly-2-sigma]] — 이상 후보를 먼저 고르는 단계.
- [[anscombe-quartet]] — 같은 요약통계량, 다른 모양: 그려 봐야 안다.
- [[maintenance-4-stages]] — 예측 정비의 핵심 판정.
- [[chart-matching]] — 시간 흐름은 선 차트.

## 쓰인 곳
- [[day5-predictive-maintenance]] (4. 신호 읽기, 실습 ④, 실습과제 2)
- 데이터셋 [[sensor-log-synthetic]]
