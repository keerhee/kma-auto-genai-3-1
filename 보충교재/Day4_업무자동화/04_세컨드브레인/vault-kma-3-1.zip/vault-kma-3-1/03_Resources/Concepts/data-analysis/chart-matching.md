---
type: concept
status: draft
tags: [concept, data-analysis, visualization, chart]
field: data-analysis
related: ["[[anscombe-quartet]]", "[[positioning-map]]", "[[voc-sentiment-analysis]]", "[[ai-crawling]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf|Day2 Main 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 데이터→차트 매칭

## 정의
"무엇을 보여줄 것인가"가 차트를 결정한다는 원칙. 데이터의 성격(순위·흐름·구성·위치)에 맞춰 차트 종류를 고른다 — 순위는 막대, 흐름은 선, 구성은 원형, 위치는 산점도.

## 왜 필요한가
숫자만 나열하면 의미가 전달되지 않고, 차트를 잘못 고르면 메시지가 흐려지거나 왜곡된다. 무조건 막대·원형만 쓰지 않고 데이터 성격에서 출발해야 보는 사람이 한 번에 읽는다.

## 판단 기준
| 데이터 성격 | 적합한 차트 | 덱 예시 |
|---|---|---|
| 순위·크기 비교 | 막대 차트 | 국내 EV 판매 Top5 |
| 시간 흐름 | 선 차트 | 월별 판매 추이, 매출 추이(3일차) |
| 비율·구성 | 원형 · 누적 막대 | 긍·부정 리뷰 비율, VOC 키워드 빈도 |
| 두 기준 위치 | 산점도 (포지셔닝 맵) | 가격 대비 기술(3일차) |

좋은 차트의 네 원칙:
1. **한 메시지** — 한 차트에 하나의 메시지만.
2. **y축 보존** — y축을 함부로 자르면 작은 차이를 과장하는 착시.
3. **정확한 비교** — 3D·화려한 효과보다 정확히 비교되는 것.
4. **색은 강조만** — 모든 것을 강조하면 아무것도 강조되지 않는다.

## 예시
- 2일차 실습: 국내EV판매_Top5를 Google Sheets 막대 차트로 — 1위와 5위의 격차, 제조사별 분포.
- 2일차 실습: 아이오닉5 VOC 긍·부정 키워드 빈도를 누적 막대로.
- 3일차: 수익성(영업이익률)은 막대, 성장(매출 추이)은 선 차트.
- 5일차: 센서 시계열은 선 차트(시간축 + 변수 + 임계선).
- Hook 케이스 머니볼: "어떤 지표를 볼 것인가"가 지표 선택·차트 매칭의 원형([[moneyball]]).

## 관련 개념
- [[anscombe-quartet]] — 왜 그려야 하는가: 요약통계량이 같아도 그림은 다르다.
- [[positioning-map]] — "두 기준 위치" 칸의 대표 차트.
- [[voc-sentiment-analysis]], [[noise-vs-trend]]

## 쓰인 곳
- [[day2-crawling-viz]] (3. 시각화, 실습과제 1 차트 선택)
- [[day3-competitor-finance]], [[day5-predictive-maintenance]]
- 보조자료: [[day2-nightingale-anscombe]]
