---
type: concept
status: draft
tags: [concept, data-analysis, crawling, perplexity]
field: data-analysis
related: ["[[chart-matching]]", "[[voc-sentiment-analysis]]", "[[six-step-workflow]]", "[[collect-summarize-organize]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf|Day2 Main 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_2_Front2H_Intro_deck.pdf|Day2 Front 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# AI 크롤링 — 질문 → 검색 → 출처 선별 → 요약·정리

## 정의
**크롤링(crawling)**: 인터넷에 흩어진 자료를 자동으로 찾아 모으는 작업. 원래는 코드로 했지만, 이제는 Perplexity 같은 AI 도구에 자연어로 요청해 수집·정리까지 맡긴다. 네 단계가 프롬프트 한 번에 일어난다: ① 질문 → ② 검색(실시간 웹) → ③ 출처 선별(링크 남김) → ④ 요약·정리(표·문장).

## 왜 필요한가
기사·통계를 뒤져 반나절 걸리던 수집이 몇 분으로 줄고, 줄어든 시간을 "그래서 무엇을 할까"라는 해석에 쓴다. 대신 AI도 틀린다 — 오래된 수치를 최신처럼 말하거나 출처 없이 지어낼 수 있으므로, 빨라진 만큼 검증이 더 중요해진다.

## 판단 기준
수집 목적별 도구 선정 (Day2 Main):

| 목적 | 추천 도구 | 이유 |
|---|---|---|
| 최신 시장 데이터·뉴스 | Perplexity | 실시간 웹 검색 + 출처 표기 |
| 가상 데이터·페르소나 생성 | ChatGPT | 그럴듯한 예시·리뷰 생성 |
| 분석·구조화·표 작성 | Claude | 긴 자료 정리·비교표 |
| 표·차트 정리 | Google Sheets | 시각화·계산 |

검증 습관: 판매량·점유율 같은 숫자는 출처와 기준 시점을 반드시 확인하고, "출처 링크를 붙여줘", "근거가 뭐야"라고 한 번 더 묻는다. 가상 데이터는 가상이라고 표기한다(미표기는 감점).

## 예시
- 에피소드 "반나절이 5분으로": "국내 전기차 판매 상위 5종" 정리가 한 번의 프롬프트로 표와 출처 링크까지.
- 2일차 실습: Perplexity로 국내 EV 판매 Top5 수집(실데이터), ChatGPT로 아이오닉5 가상 VOC 리뷰 생성.
- 1일차: Perplexity로 최근 1개월 글로벌 EV 뉴스 10건을 출처 링크와 함께 수집.
- 정형 데이터(판매량·가격)와 비정형 데이터(리뷰·기사)를 함께 모은다 — AI가 비정형을 정형(표)으로 바꿔 준다(Front 덱).

## 관련 개념
- [[chart-matching]] — 모은 데이터를 성격에 맞는 차트로.
- [[voc-sentiment-analysis]] — 비정형 데이터(리뷰) 분석.
- [[collect-summarize-organize]] — 같은 수집을 매일 자동으로 돌리는 파이프라인(4일차).
- [[six-step-workflow]] — ② 데이터 단계의 주된 기법.

## 쓰인 곳
- [[day2-crawling-viz]] (1. 크롤링, 2. 도구 선정)
- [[day1-market-trends]] (② 데이터 · EV 뉴스 수집)
- 데이터셋: [[domestic-ev-sales]], [[auto-ev-news]]
