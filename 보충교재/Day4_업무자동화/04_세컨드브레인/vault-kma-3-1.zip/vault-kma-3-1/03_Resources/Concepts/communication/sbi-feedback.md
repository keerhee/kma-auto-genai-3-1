---
type: concept
status: draft
tags: [concept, communication, feedback, mentoring]
field: communication
related: ["[[pyramid-principle]]", "[[pixar-braintrust]]"]
source: ["[[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_2_Front2H_Intro_deck.pdf|Day6 Front 덱]]", "[[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_1_Hook_Case_Pixar_Braintrust_deck.pdf|Day6 Hook 덱]]"]
created: 2026-10-19
updated: 2026-10-19
---

# SBI 피드백 — 상황 · 행동 · 영향

## 정의
사실에 붙는 피드백 공식. **Situation**(어느 장면에서) → **Behavior**(무엇을 했는데) → **Impact**(어떤 영향이 있었나). 사람이 아니라 관찰 가능한 행동과 산출물에 대해 말한다.

## 왜 필요한가
듣기 좋은 말만 오가는 검토는 검토가 아니지만, 솔직함은 규칙이 있을 때만 안전하다. SBI는 "작품에 대해서만 말하고, 해법은 강요하지 않는다"는 규칙을 문장 형식으로 만든 것이다. 6일차 상호 평가는 이 과정의 숨은 목적인 멘토 양성 — 설명하고 피드백하는 기술 — 의 첫 연습이다. "평가는 점수를 남기고, 피드백은 성장을 남긴다."

## 판단 기준
| 요소 | 질문 | 덱 예시 |
|---|---|---|
| Situation | 어느 장면에서? | 3번째 슬라이드에서 |
| Behavior | 무엇을 했는데? | 출처 없이 수치를 말해서 |
| Impact | 어떤 영향이? | 신뢰가 흔들렸다 |

멘토의 세 가지 습관:
1. 강점 먼저 — 잘한 것을 구체적으로 짚고 시작한다.
2. 사람이 아니라 산출물에 대해 말한다.
3. "다음엔 이렇게"까지 — 대안 없는 지적은 반쪽이다.

자가 점검 질문: "나는 지금 작품을 말하는가, 사람을 말하는가."

## 예시
- Hook 케이스 픽사 브레인트러스트([[pixar-braintrust]]): 몇 달마다 감독들이 모여 서로의 미완성작을 검토 — 규칙 ① 철저히 솔직하게 문제를 말한다 ② 해법을 강요하지 않는다(결정은 그 작품의 감독이). 덱은 이를 "SBI의 원형"이라 부른다.
- 토이스토리 2: "그럭저럭"한 완성 직전 상태에서 냉정한 진단을 받고 사실상 처음부터 다시 만들어 명작이 됐다 — 덱은 재제작 기간을 9개월로 제시(공개 저서·보도 기준 개략치).
- 6일차 2부: 15분 발표 + 5분 Q&A 후 강사·수강생 상호 피드백, 평가표(도메인 적합성·검증 절차·차별성)에 점수·코멘트 기록.

## 관련 개념
- [[pyramid-principle]] — 피드백 대상인 보고서·발표의 구조.
- [[pixar-braintrust]] — 규칙 두 개짜리 회의가 피드백을 시스템으로 만든 사례.

## 쓰인 곳
- [[day6-final-project]] (Front 피드백의 기술, Main 발표·상호 평가·멘토링 방법론)
- 평가: [[final-presentation-rubric]]
