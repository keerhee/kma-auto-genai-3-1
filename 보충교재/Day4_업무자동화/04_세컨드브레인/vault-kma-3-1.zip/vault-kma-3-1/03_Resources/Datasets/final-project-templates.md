---
type: dataset
status: fresh
kind: template
location: "01_Projects/kma-auto-genai-3-1/repo/data/Day6/"
source: "강의용 빈 템플릿 — 01_Projects/kma-auto-genai-3-1/repo/data/_build/make_synthetic_data.py 생성"
last_refresh: 2026-10-17
refresh_cycle: 변경 시
used_in: ["[[day6-final-project]]"]
tags: [dataset, template, capstone, rubric]
related: ["[[final-presentation-rubric]]", "[[pyramid-principle]]", "[[sbi-feedback]]", "[[pixar-braintrust]]", "[[auto-ev-news]]", "[[domestic-ev-sales]]", "[[automaker-financials]]", "[[cs-manual-hanbit-synthetic]]", "[[sensor-log-synthetic]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 최종 프로젝트 템플릿 (Day6)

결론: 6일차 통합 마스터 표와 발표 상호 평가에 쓰는 **빈 템플릿** 3종. 값은 수강생이 1~5일차 산출물에서 채운다.

## 내용
| 파일 | 구분 | 행 | 쓰는 곳 |
|---|---|---|---|
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day6/Day6_5사x5축_마스터표_템플릿.csv\|Day6_5사x5축_마스터표_템플릿.csv]] | 템플릿 | 5 (현대·도요타·폭스바겐·테슬라·BYD) | 본 강의 통합 마스터 표, 캡스톤 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day6/Day6_5사x5축_마스터표_작성요령.md\|Day6_5사x5축_마스터표_작성요령.md]] | 템플릿 | — | 마스터 표 작성 규칙 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day6/Day6_발표평가표_템플릿.csv\|Day6_발표평가표_템플릿.csv]] | 템플릿 | 20 (5팀 × 4행: 기준 3개 + 합계) | 발표 상호 평가, 보강 실습 A |

- 마스터 표 열(8): 경쟁사·시장(1일차)·제품·고객(2일차)·재무(3일차)·업무혁신(4일차)·제조역량(5일차)·한 줄 요약·출처.
- 발표 평가표 열(7): 발표팀·평가기준·핵심질문·배점·점수·코멘트(강점)·코멘트(보완). 배점은 도메인 적합성 40 · 검증 절차 30 · 차별성 30.
- 기준일: 해당 없음(템플릿). 생성일은 repo 최초 커밋 2026-10-17 기준.

## 출처와 수집 방법
- 마스터 표 각 칸은 1~5일차 산출물에서 가져온다: 시장 [[auto-ev-news]], 제품·고객 [[domestic-ev-sales]]·[[voc-reviews-synthetic]], 재무 [[automaker-financials]], 업무혁신 [[cs-manual-hanbit-synthetic]], 제조역량 [[sensor-log-synthetic]].

## 주의 (함정·표기)
- kind: template.
- 데이터가 없으면 칸을 비우지 말고 "데이터 없음"이라고 쓴다. 빈 칸이 곧 보완 수집 목록이다.
- 숫자에는 기준 연도와 연결/별도 여부를 함께 쓴다.
- 2·4·5일차 가상 데이터(아이오닉5 VOC, 한빛모터스 매뉴얼, 설비 센서 등)에서 온 내용은 "예시"로 표기하고 실제 회사의 사실처럼 쓰지 않는다.
- 행은 3일차 5사(현대·도요타·폭스바겐·테슬라·BYD) 기준이다. 6일차 본 강의 12장 프롬프트는 "현대·기아·테슬라·BYD·도요타"이므로 반에서 정한 5사에 맞춰 행 이름을 바꿔도 된다.
- 열 이름은 본 강의 12장의 [시장 위치 / 제품·고객 / 재무 / 운영 / 제조]와 같은 뜻이다(운영 = 업무혁신).
- 강사용 정답 메모 있음: [[01_Projects/kma-auto-genai-3-1/repo/data/_강사용_정답메모.md|_강사용_정답메모.md]] (수강생 비공개).

## 갱신 이력
| 날짜 | 변경 | 사용처 |
|---|---|---|
| 2026-10-07 | 3-1 기준 템플릿 (repo 최초 커밋 2026-10-17) | [[day6-final-project]] |
