---
type: dataset
status: fresh
kind: real
location: "01_Projects/kma-auto-genai-3-1/repo/data/Day1/"
source: "기사 원문(Automotive World, Electrek, CnEVPost, NPR 등) — 행마다 출처URL"
last_refresh: 2026-10-07
refresh_cycle: 차수마다
used_in: ["[[day1-market-trends]]", "[[day4-job-automation]]"]
tags: [dataset, ev, news, sdv, china-ev]
related: ["[[case-sdv]]", "[[ai-crawling]]", "[[tesla-2008]]", "[[china-ev-price-war-case]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 자동차 EV 뉴스 (Day1)

결론: 1일차 시장·트렌드 실습의 **백업용 실데이터** 두 파일. 수강생이 Perplexity로 직접 모은 뉴스와 대조하는 검증용으로도 쓴다.

## 내용
| 파일 | 구분 | 행 | 열 | 쓰는 곳 |
|---|---|---|---|---|
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day1/Day1_EV뉴스_최근1개월_실데이터.csv\|Day1_EV뉴스_최근1개월_실데이터.csv]] | 실데이터 | 10 | 9 (번호·날짜·제목(원문)·매체·한줄요약·핵심키워드·분류(기술/시장/정책)·SDV관련(Y/N)·출처URL) | 본 강의 ② 데이터·③ 전처리, SDV 관련 뉴스 고르기 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day1/Day1_중국EV가격공세_완성차원가대응_실데이터.csv\|Day1_중국EV가격공세_완성차원가대응_실데이터.csv]] | 실데이터 | 10 | 7 (구분·날짜·기업·제목(원문)·매체·한줄요약·출처URL) | 보강 실습 B(가격 공세 대응 브리프), 4일차 BYD 뉴스 파이프라인 입력 |

- 기준일: 2026-10-07 (data/README.md)
- EV 뉴스 기사 날짜: 2026-09-24 ~ 2026-10-06. SDV 관련 Y 5건, N 5건.
- 가격 공세 파일: 구분 "중국EV가격전략" 5건, "완성차원가대응" 5건. 기사 날짜 2025-08-12 ~ 2026-09-17.

## 출처와 수집 방법
- 실제 기사·보도자료에서 옮긴 자료. 행마다 원문 제목, 매체, 출처URL, 날짜가 있다.
- 매체: Automotive World, Applied Intuition(회사 블로그), MarkLines, NPR, Electrek, CnEVPost, Carscoops, Ford Authority, GM Authority 등.
- 기본 수집은 수강생이 Perplexity로 직접 하고, 이 파일은 수집이 막히거나 시간이 부족할 때 쓰는 백업이다.

## 주의 (함정·표기)
- kind: real(실데이터). 기준일 이후 기사가 바뀌거나 링크가 끊길 수 있으니 수업 직전에는 수강생이 모은 최신 자료를 우선한다.
- EV 뉴스 7번의 영국 판매 수치는 SMMT 신차 **등록** 기준이다. 판매와 등록을 섞지 않는다.
- 완성차 원가 대응 기사 중 포드·폭스바겐 중국·GM-현대 3건은 2025년 하반기 기사다. "최근 1개월" 파일과 기간이 다르다.
- CSV는 UTF-8(BOM). Google Sheets에서는 `파일 → 가져오기`로 연다.
- 강사용 정답 메모 있음: [[01_Projects/kma-auto-genai-3-1/repo/data/_강사용_정답메모.md|_강사용_정답메모.md]] (수강생 비공개).

## 갱신 이력
| 날짜 | 변경 | 사용처 |
|---|---|---|
| 2026-10-07 | 3-1 기준 실데이터 수집 (기준일) | [[day1-market-trends]], [[day4-job-automation]] |
