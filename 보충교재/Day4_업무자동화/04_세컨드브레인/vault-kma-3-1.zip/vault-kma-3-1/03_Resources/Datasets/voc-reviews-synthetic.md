---
type: dataset
status: fresh
kind: synthetic
location: "01_Projects/kma-auto-genai-3-1/repo/data/Day2/"
source: "가상 데이터 — 01_Projects/kma-auto-genai-3-1/repo/data/_build/make_synthetic_data.py (고정 시드 20261007)로 생성"
last_refresh: 2026-10-17
refresh_cycle: 변경 시
used_in: ["[[day2-crawling-viz]]", "[[day2-nightingale-anscombe]]"]
tags: [dataset, synthetic, voc, review, chart-clinic]
related: ["[[voc-sentiment-analysis]]", "[[chart-matching]]", "[[anscombe-quartet]]", "[[domestic-ev-sales]]", "[[moneyball]]"]
created: 2026-10-19
updated: 2026-10-19
---

# VOC 리뷰·차트 클리닉 가상 데이터 (Day2)

결론: 2일차 VOC 감정분석, 차트 클리닉, 가격 프로모션 수집 실습에 쓰는 **가상 데이터(실습용)** 묶음. 실제 고객 의견이 아니며, 보고서에 쓸 때는 반드시 "가상 데이터(실습용)"로 표기한다.

## 내용
| 파일 | 구분 | 행 | 열 | 쓰는 곳 |
|---|---|---|---|---|
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_아이오닉5_VOC리뷰30건_가상.csv\|Day2_아이오닉5_VOC리뷰30건_가상.csv]] | 가상 | 30 | 6 (번호·고객유형(페르소나)·리뷰·주제·감정·비고) | 본 강의 VOC 생성·전처리·감정분석, 실습과제 3 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_모델Y_VOC리뷰20건_가상.csv\|Day2_모델Y_VOC리뷰20건_가상.csv]] | 가상 | 20 | 6 (같은 구조) | 미니 프로젝트(아이오닉5와 비교) |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_차트클리닉_원본데이터_가상.csv\|Day2_차트클리닉_원본데이터_가상.csv]] | 가상 | 36 | 7 (월·브랜드·EV판매대수·EV시장전체·점유율·집계기준·비고) | 보강 실습 A(차트 클리닉) — 진단할 원본 데이터 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_차트클리닉_나쁜차트예시_가상.png\|Day2_차트클리닉_나쁜차트예시_가상.png]] | 가상 | — | — | 보강 실습 A — 진단할 원본 차트 |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_차트클리닉_고친차트예시_가상.png\|Day2_차트클리닉_고친차트예시_가상.png]] | 가상 | — | — | 보강 실습 A 해설(강사용 예시) |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Day2/Day2_주간EV가격프로모션_시범수집_예시_가상.csv\|Day2_주간EV가격프로모션_시범수집_예시_가상.csv]] | 가상 | 8 | 8 (수집주차·브랜드·모델명·변경내용·적용일·출처·확인상태·비고) | 보강 실습 B(수집 레시피) — 시범 수집 결과의 형식 예시 |

- VOC 주제는 충전·주행·디자인·서비스·가격 5종, 감정은 긍정·부정·중립. 페르소나 10종(20대 사회초년생 ~ 60대 은퇴 부부).
- 차트 클리닉: 가상 브랜드 A사·B사·C사 × 2025-01~2025-12 (12개월 × 3사 = 36행).
- 가격 프로모션: 2026-W40(09-28~10-04) 한 주, 가상 브랜드 A~D 8행.
- 기준일: 해당 없음(가상). 생성일은 repo 최초 커밋 2026-10-17 기준.

## 출처와 수집 방법
- 리뷰·가격 기록처럼 원래 회사 내부 자료라 공개본이 없는 것을 대신하는 가상 데이터.
- `_build/make_synthetic_data.py`로 다시 만들 수 있다(시드 고정, 같은 파일이 나온다).

## 주의 (함정·표기)
- kind: synthetic. 보고서·발표에 쓰면 "가상 데이터(실습용)"로 표기한다. 모든 행의 비고 열에 "실습용 가상 데이터(생성 리뷰, 실제 고객 의견 아님)"가 적혀 있다.
- 아이오닉5·모델Y라는 실제 모델명을 쓰지만 리뷰 내용은 생성된 것이다. 실제 브랜드 평가로 인용하지 않는다.
- 본 강의는 VOC 10건 기준이다. 앞 10건만 써도 되고 30건을 다 쓰면 빈도 근거가 단단해진다.
- 차트 클리닉 원본에는 집계기준 열이 있다. 진단 시 기준 열을 끝까지 확인하게 한다(세부 의도는 강사용 메모 참조).
- 가격 프로모션 예시는 "확인 필요"·"변경 없음" 행을 일부러 넣었다. 추측으로 빈칸을 채우지 않는 수집 규칙을 보여 주는 형식 예시다.
- 강사용 정답 메모 있음: [[01_Projects/kma-auto-genai-3-1/repo/data/_강사용_정답메모.md|_강사용_정답메모.md]] (수강생 비공개).

## 갱신 이력
| 날짜 | 변경 | 사용처 |
|---|---|---|
| 2026-10-07 | 3-1 기준 가상 데이터 (시드 20261007, repo 최초 커밋 2026-10-17) | [[day2-crawling-viz]] |
