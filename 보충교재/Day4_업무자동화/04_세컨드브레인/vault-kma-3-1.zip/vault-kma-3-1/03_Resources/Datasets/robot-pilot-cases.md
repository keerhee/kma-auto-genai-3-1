---
type: dataset
status: fresh
kind: mixed
location: "01_Projects/kma-auto-genai-3-1/repo/data/Robot_Special/"
source: "현장 파일럿 사례는 BMW·현대차그룹·DHL·GXO·메르세데스-벤츠 등 보도자료·기사 실데이터(행마다 출처URL). 평가 매트릭스는 빈 템플릿"
last_refresh: 2026-10-07
refresh_cycle: "차수마다 (파일럿 사례 실데이터) / 변경 시 (템플릿)"
used_in: ["[[robot-special]]"]
tags: [dataset, robotics, humanoid, pilot, template]
related: ["[[robot-value-chain]]", "[[raas]]", "[[automation-fit-matrix]]", "[[amazon-kiva]]", "[[hyundai-boston-dynamics]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 휴머노이드·물류로봇 파일럿 사례 (Robot_Special)

결론: 로봇 특강 보강 실습용 실데이터 1종(현장 파일럿 사례 10건)과 빈 평가 템플릿 1종. 공개 KPI가 있는 사례는 3건뿐이며, BMW의 요구조건 수치를 달성치로 쓰면 안 된다.

## 내용
| 파일 | 구분 | 행 | 열 | 쓰는 곳 |
|---|---|---|---|---|
| [[01_Projects/kma-auto-genai-3-1/repo/data/Robot_Special/Robot_휴머노이드·물류로봇_현장파일럿사례_실데이터.csv\|Robot_휴머노이드·물류로봇_현장파일럿사례_실데이터.csv]] | 실데이터 | 10 | 8 (로봇, 도입기업·현장, 시작시기, 기간, 작업, 공개된KPI·성과, 확대조건·다음단계, 출처URL) | 보강 실습 B(90일 파일럿 계획 — 사례의 기간·KPI·확대 조건 참고) |
| [[01_Projects/kma-auto-genai-3-1/repo/data/Robot_Special/Robot_작업후보5_평가매트릭스_템플릿.csv\|Robot_작업후보5_평가매트릭스_템플릿.csv]] | 템플릿 | 5 | 9 (작업후보, 반복성, 위험·중량, 작업의 정형성, 사람 협업 필요도, 실패 시 영향, 대안 로봇 검토(AMR·비전AI·코봇), 종합 순위, 평가 근거) | 보강 실습 A(휴머노이드 도입 진단) |

- 파일럿 사례 10건: Figure 02(BMW 스파르탄버그) 2건, Figure 03(BMW), Atlas(현대차그룹 HMGMA), Spot(기아 오토랜드 광명·화성) 2건, Stretch(DHL), Digit(GXO) 2건, Apollo(메르세데스-벤츠 베를린).
- 평가 매트릭스 작업후보 5개: 부품 정렬(시퀀싱), 중량물 운반, 나사 체결 보조, 외관 검사 보조, 공정 간 부품 이동. 평가 항목은 상·중·하로 채운다.
- 기준일: 2026-10-07 (data/README.md).

## 출처와 수집 방법
- 파일럿 사례: 각사 보도자료·기사에서 옮겼고 행마다 출처URL이 있다. 시작 시기가 기사에 없으면 "확인 불가"로 적었다.
- 평가 매트릭스: 강의용 빈 템플릿(`_build/make_synthetic_data.py` 생성).

## 주의 (함정·표기)
- kind: mixed — 파일럿 사례는 real, 평가 매트릭스는 template.
- 공개 KPI가 있는 사례는 Figure 02(BMW), Stretch(DHL), Digit(GXO)뿐이다. 나머지는 KPI 미공개로 다룬다.
- Figure 02의 84초 사이클·99% 정확도는 BMW의 **요구조건**으로 보도된 수치다. 달성치로 쓰지 않는다.
- 기준일 이후 파일럿 상태가 바뀔 수 있으니 수업 직전에는 최신 보도를 우선한다.
- 강사용 정답 메모 있음: [[01_Projects/kma-auto-genai-3-1/repo/data/_강사용_정답메모.md|_강사용_정답메모.md]] (수강생 비공개).

## 갱신 이력
| 날짜 | 변경 | 사용처 |
|---|---|---|
| 2026-10-07 | 3-1 기준 파일럿 사례 실데이터 수집 + 평가 템플릿 | [[robot-special]] |
