---
type: tool
status: active
category: "HTML 대시보드"
version: "기준일 2026-10-07"
location: "01_Projects/kma-auto-genai-3-1/repo/HTML/auto_world_dashboard.html"
tags: [tool, dashboard, automotive]
related: ["[[day1-market-trends]]", "[[github-pages-ops]]", "[[domestic-ev-sales]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 세계 자동차 산업 3D 지도

## 무엇을 하나
국가별 자동차 생산·전기차 판매·주요 완성차 그룹을 3D 지구본에 보여 주고, 생산국 통화의 오늘 환율을 함께 띄운다. 덱에 사용 위치가 명시돼 있지 않다 — Day1 시장 강의의 산업 지도로 쓰기를 제안한다.

## 데이터 (data/dashboard/auto_world.json)
| 묶음 | 범위 | 출처 |
|---|---|---|
| countries | 36개국 — OICA 2025 생산 20만 대 이상 30개국 + EV 시장 6개국 | OICA 2025 생산 통계표 |
| ev_sales · ev_share_pct | 2025 전기 승용차(BEV+PHEV) 판매·신차 비중 | IEA Global EV Outlook 2026 |
| oems | 17개 그룹, 2025 판매 | 각 그룹 보도자료·공시 |

## 주의 (수업에서 짚을 것)
- OICA 수치는 국가별 정의가 다르다 (독일 등은 승용차만, 프랑스 등은 승용+LCV).
- 그룹 판매 정의가 회사마다 다르다 (도요타 다이하쓰·히노 포함, 포드 도매, 테슬라 인도, 혼다 회계연도). 순위는 참고용.
- 현대차그룹 값은 현대차 도매 + 기아 합산이며 그룹 단일 공시치가 아니다.
- 승용차 생산(`production_passenger`)은 전 국가 null — 원 표를 찾지 못함.
- 판매 vs 등록 같은 정의 차이는 Day2 [[domestic-ev-sales]] 토론과 연결된다.

## 설치·위치
- 파일 하나(48KB)로 브라우저에서 바로 열림. 사이트에서도 실행 → [[github-pages-ops]]
- 다시 만들기: `python3 _build/build_dashboard.py` (템플릿 + json)

## 추천 사용처
- [[day1-market-trends]]

## 변경 이력
| 버전 | 날짜 | 변경 |
|---|---|---|
| 1 | 2026-10-07 | 2025 데이터 기준 작성 |
