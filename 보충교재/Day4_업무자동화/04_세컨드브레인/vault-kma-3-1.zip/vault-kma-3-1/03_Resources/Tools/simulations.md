---
type: tool
status: active
category: "HTML 교육용 시뮬레이션"
version: "3-1 공개본"
location: "01_Projects/kma-auto-genai-3-1/repo/HTML/"
tags: [tool, simulation, ev, robotics]
related: ["[[robot-special]]", "[[day5-predictive-maintenance]]", "[[smart-factory-4-processes]]", "[[robot-value-chain]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 교육용 시뮬레이션 4종

## 무엇을 하나
브라우저에서 바로 여는 단일 HTML(각 32~36KB). 부품 구성과 공정 흐름을 클릭하며 익힌다. 덱에는 사용 위치가 명시돼 있지 않다 — 아래 사용처는 제안이다.

| 파일 | 제목 | 다루는 것 | 추천 사용처 |
|---|---|---|---|
| `ev_parts.html` | EV 부품 학습 시뮬레이션 | 전기차 부품 구성 | [[day1-market-trends]] · [[robot-special]] |
| `ev_factory.html` | EV 스마트팩토리 시뮬레이션 | 공정 흐름·스마트팩토리 | [[day5-predictive-maintenance]] |
| `humanoid_parts.html` | 휴머노이드 부품 학습 시뮬레이션 | 눈·뇌·근육(액추에이터) | [[robot-special]] |
| `humanoid_factory.html` | 휴머노이드 로봇 조립 시뮬레이션 | 조립 공정 | [[robot-special]] |

## 연결
- 특강의 "자동차와 로봇은 쌍둥이" 논리(카메라·모터·배터리·두뇌·대량 조립) → EV 부품과 휴머노이드 부품을 나란히 보여 주면 이해가 빠르다.
- 개념: [[smart-factory-4-processes]] · [[robot-value-chain]]

## 설치·위치
`repo/HTML/` — 사이트에서 실행 ([[github-pages-ops]]).

## 변경 이력
| 버전 | 날짜 | 변경 |
|---|---|---|
| 1 | 2026-10-17 | 3-1 공개 |
