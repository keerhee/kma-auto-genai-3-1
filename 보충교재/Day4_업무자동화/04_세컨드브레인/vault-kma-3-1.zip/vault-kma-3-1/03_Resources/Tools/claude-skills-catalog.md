---
type: tool
status: active
category: "Claude 스킬 묶음"
version: "2026-10-17"
location: "01_Projects/kma-auto-genai-3-1/repo/x_skills/"
tags: [tool, skills, claude]
related: ["[[kma-auto-genai-3-1]]", "[[media]]", "[[deck-standards]]"]
created: 2026-10-19
updated: 2026-10-19
---

# Claude 스킬 카탈로그 (x_skills)

## 무엇을 하나
수강생에게 배포하는 스킬 24종(저장소에는 zip 23개 — Anthropic 기본 `pptx`는 라이선스상 제외). zip 하나에 스킬 폴더 하나, 안에 `SKILL.md`가 있어 그대로 설치한다.

| 분야 | 개수 | 스킬 |
|---|---|---|
| PPT 덱 (스타일 고정) | 8 | zeroone-pitch-deck · report-navy-deck · report-white-deck · apple-white-deck · jj-brief-deck · jaykong-research-deck · bj-deck · auto-ppt |
| PPT 편집·변환 | 3 | pptx(기본 제공) · slide-master · image-fullbleed-deck |
| HTML 슬라이드 | 2 | html-ppt · web-slides |
| 인포그래픽 | 3 | svg-infographic · obsidian-infographic · latex-svg-render |
| 모션·영상 | 7 | motion-studio · showreel · remotion-motion-catalog · flow-diagram-video · concept-explainer-video · motion-lecture · ic-webtoon-short |
| 한글 문서 | 1 | kordoc (+ 예제 zip) |

## 부르는 말 (트리거)
"제로원 덱", "네이비 리포트 덱", "bj덱", "인포그래픽", "모션그래픽 만들어줘", "쇼릴", "한글 파일 읽어줘" 등 — 스킬 설명에 있는 표현으로 부른다.

## 설치·위치
```bash
unzip ppt/zeroone-pitch-deck.zip -d ~/.claude/skills/     # 모든 프로젝트
unzip ppt/zeroone-pitch-deck.zip -d .claude/skills/       # 이 프로젝트만
```
claude.ai·데스크톱 앱(Chat)은 설정 → 기능 → 스킬에서 zip 업로드. 필요한 도구(Node.js·pptxgenjs, cairosvg, Remotion·ffmpeg)는 처음 쓸 때 Claude Code가 설치를 제안한다.

## 주의
- 덱 스킬은 워드마크·기관명·로고를 넣지 않는다 (요청 시만).
- 나레이션 영상 스킬의 기본 음성은 강사 PC의 Voicebox 복제음성 — 다른 PC에서는 edge-tts 등으로 바꾸게 지시한다.
- kordoc은 CLI 4.22.5(2026-10-16) 기준.

## 쓴 곳
- [[kma-auto-genai-3-1]] — Hook 영상 제작([[media]]), 덱 제작([[deck-register]])
- [[day2-crawling-viz]] — Day2 Claude Code 실습 폴더(`x_day2/Day2_클로드코드/.claude/skills/`)의 과정 전용 스킬 5종은 별도

## 변경 이력
| 버전 | 날짜 | 변경 |
|---|---|---|
| 2026-10-17 | 2026-10-17 | 24종 정리, kordoc 4.22.5 반영 |
