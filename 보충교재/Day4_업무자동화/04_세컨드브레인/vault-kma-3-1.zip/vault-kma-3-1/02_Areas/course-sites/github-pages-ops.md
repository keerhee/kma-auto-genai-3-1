---
type: area
status: active
tags: [site, github-pages, ops]
related: ["[[kma-auto-genai-3-1]]", "[[deck-register]]", "[[deck-standards]]", "[[auto-world-dashboard]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 강의 사이트 운영 (GitHub Pages)

3-1 사이트: https://keerhee.github.io/kma-auto-genai-3-1/ — 덱 PDF 열람과 HTML 시뮬레이션 실행.

## 구조
| 파일 | 역할 |
|---|---|
| `index.html` | 첫 화면. 손으로 고치지 않고 스크립트로 다시 만든다 |
| `_build/make_site.py` | Day 폴더의 PDF를 읽어 `index.html` 생성. 회차 제목·Hook 이름은 스크립트 안 `DAYS` 표에 있다 |
| `_build/build_dashboard.py` + `auto_world_dashboard.template.html` | `data/dashboard/auto_world.json`으로 3D 지도 생성 → [[auto-world-dashboard]] |
| `.nojekyll` | GitHub Pages가 `_build` 같은 밑줄 폴더를 무시하지 않게 함 |

## 배포 절차
```bash
cd 01_Projects/kma-auto-genai-3-1/repo
python3 _build/make_site.py          # 덱 추가·이름 변경 후
git add -A && git commit -m "site: <변경>" && git push
```
- 덱 파일명이 [[deck-standards]]의 규칙(`DayN_<순서>_<역할>_...`)을 벗어나면 사이트에서 분류가 틀어진다.
- 새 차수 저장소를 만들면 `DAYS` 표의 제목·Hook 이름부터 고친다.

## 장애·메모
| 날짜 | 증상 | 조치 |
|---|---|---|
| | | |
