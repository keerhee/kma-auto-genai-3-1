---
type: area
status: active
tags: [kma, series, teaching]
related: ["[[kma-auto-genai-3-1]]", "[[kma]]", "[[deck-standards]]", "[[github-pages-ops]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 능률협회 자동차 AI 시리즈

차수와 무관하게 유지하는 것: 공통 커리큘럼, 덱 규칙, 데이터 갱신 기준, 개선 이력. 차수별 진도·회고는 각 프로젝트 허브에 둔다.

## 차수
| 차수 | 프로젝트 | 상태 | 저장소 |
|---|---|---|---|
| 3-1 | [[kma-auto-genai-3-1]] | active | keerhee/kma-auto-genai-3-1 |

```dataview
TABLE status, deadline, repo
FROM "01_Projects" OR "04_Archive"
WHERE type = "project" AND contains(area, [[kma-auto-ai-series]])
```

## 공통 커리큘럼 (6일 48H + 특강)
수집(Day1) → 시각화(Day2) → 분석(Day3) → 자동화(Day4) → 예측(Day5) → 통합(Day6). 매일 같은 6단계([[six-step-workflow]])를 반복하고, 하루는 Hook 1H · Front 2H · Main 8H · Back 2H로 짠다 → [[deck-standards]].

| 일차 | 주제 | Hook 케이스 | 핵심 개념 |
|---|---|---|---|
| 1 | 시장·트렌드 | [[tesla-2008]] | [[case-sdv]] · [[tps-andon]] |
| 2 | 크롤링·시각화 | [[moneyball]] | [[ai-crawling]] · [[chart-matching]] · [[voc-sentiment-analysis]] |
| 3 | 재무·전략 | [[gm-bankruptcy-2009]] | [[three-core-metrics]] · [[positioning-map]] · [[scenario-analysis]] |
| 4 | 업무 자동화 | [[model3-production-hell]] | [[automation-fit-matrix]] · [[collect-summarize-organize]] · [[rag-chatbot]] |
| 5 | 예지보전 | [[posco-lighthouse]] | [[maintenance-4-stages]] · [[anomaly-2-sigma]] · [[noise-vs-trend]] |
| 6 | 통합·발표 | [[pixar-braintrust]] | [[pyramid-principle]] · [[sbi-feedback]] |
| 특강 | 로봇·스마트팩토리 | [[amazon-kiva]] | [[robot-value-chain]] · [[raas]] |

## 데이터 갱신 기준
- 실데이터는 **차수 시작 2주 전**에 갱신하고 데이터셋 카드의 `last_refresh`를 고친다.
- 가상 데이터는 내용이 바뀔 때만 고치고, 보고서에는 "가상 데이터(실습용)"로 표기하게 한다.
- 현황은 [[home]]의 "데이터 갱신 필요" 표에서 본다.

## 아이디어
```dataview
TABLE status, target, updated
FROM "02_Areas/teaching/ideas"
SORT status DESC
```

## 개선 이력
| 날짜 | 차수 | 변경 | 근거 |
|---|---|---|---|
| 2026-10-19 | 3-1 | 볼트 정리 시작, 영상 호스팅 방침 결정 | [[video-hosting-youtube]] |
