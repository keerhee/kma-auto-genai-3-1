---
type: idea
status: adopted
target: "kma 시리즈 전체 영상"
tags: [idea, media]
related: ["[[media]]", "[[kma-auto-genai-3-1]]", "[[github-pages-ops]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 영상은 YouTube 일부 공개로

## 착상
mp4 3개(약 138MB)가 저장소 용량의 약 70%를 차지한다. 영상이 늘면 저장소가 계속 무거워진다.

## 결정 (2026-10-19)
- 기존 3개는 저장소에 그대로 둔다 (지워도 git 이력에 남아 용량이 줄지 않음).
- 새 영상부터 YouTube **일부 공개(unlisted)**로 올리고 [[media]]에 링크만 남긴다.
- 원본 다운로드나 수강생 한정 공개가 필요하면 Google Drive를 쓴다.

## 근거
| 방식 | 장점 | 단점 |
|---|---|---|
| 저장소 | 사이트에서 바로 재생 | 저장소가 커짐, 파일당 100MB 제한 |
| YouTube 일부 공개 | 스트리밍·임베드 쉬움, 용량 부담 없음 | 재업로드 시 링크 변경 |
| Google Drive | 다운로드·접근 제어 | 재생 품질·임베드 불편, 저장 용량 차감 |

## 다음 행동
- [ ] Day3~6·특강 Hook 영상을 만들면 YouTube로 올리고 [[media]] 외부 링크 표에 기입
