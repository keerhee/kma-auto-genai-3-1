---
type: idea
status: seed
target: "다음 차수 Day1 보강 실습 또는 Day3 Hook"
tags: [idea, case, kma]
related: ["[[auto-ev-news]]", "[[day1-market-trends]]", "[[day3-competitor-finance]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 중국 EV 가격 공세 케이스

## 착상
3-1에는 BYD 가격 공세가 Day1 보강 실습 B(대응 브리프)와 Day4 뉴스 파이프라인 재료로만 쓰였다. 이를 Hook 케이스 한 편(장면 4개 + 숫자로 보기)으로 키울 수 있다.

## 왜 필요한가
- 기존 Hook 7편은 대부분 과거 사례다. 진행 중인 사건 하나가 있으면 "지금 우리 회사" 관점으로 넘어가기 쉽다.
- 재무(Day3)의 원가·이익률 논의와 바로 이어진다.

## 근거·자료
- [[auto-ev-news]] — `Day1_중국EV가격공세_완성차원가대응_실데이터.csv` (10행, 출처 포함)

## 넣을 자리
- 과정·차수·Day: 다음 차수 Day1 Back 또는 Day3 Hook 교체 후보

## 다음 행동
- [ ] 기사 10건을 장면 4개로 나눠 보기
- [ ] 숫자로 보기에 쓸 수치와 출처 확인
