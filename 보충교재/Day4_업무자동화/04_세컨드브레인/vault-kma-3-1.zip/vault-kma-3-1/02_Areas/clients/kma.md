---
type: contact
status: active
org: "한국능률협회"
role: "교육 주관 기관"
last_contact: 2026-10-19
tags: [contact, client, kma]
related: ["[[kma-auto-ai-series]]", "[[kma-auto-genai-3-1]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 한국능률협회 (KMA)

자동차특화 AI융합 전문가 육성 과정의 주관 기관. 담당자 이름·연락처는 볼트에 적지 않고 회사 연락처에서 관리한다.

## 관계
- 함께한 일: [[kma-auto-genai-3-1]] (자동차산업과 생성형 AI 3-1)
- 시리즈 허브: [[kma-auto-ai-series]]

## 협의 이력 (결정 요약만)
| 날짜 | 내용 | 회의록 |
|---|---|---|
| | | |

## 다음 연락
- [ ] 3-1 강의 일정 확정
- [ ] 사전·사후평가 운영 방식 확인 (문항 제공 주체)
