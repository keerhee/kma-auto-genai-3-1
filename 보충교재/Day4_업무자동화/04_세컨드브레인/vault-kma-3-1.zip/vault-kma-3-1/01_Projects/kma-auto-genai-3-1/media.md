---
type: media
status: active
project: "[[kma-auto-genai-3-1]]"
tags: [media]
related: ["[[video-hosting-youtube]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 3-1 영상 목록

현재 영상 3개는 모두 저장소 안 mp4다 (합계 약 138MB, 저장소 용량의 약 70%). 새 영상은 YouTube 일부 공개로 올리고 링크만 남긴다 → [[video-hosting-youtube]].

| 회차 | 영상 | 길이 | 크기 | 위치 | 쓰는 곳 |
|---|---|---|---|---|---|
| Day1 | Tesla 2008 · Motion Lecture | 4분 34초 | 70MB | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_1_Hook_Case_Tesla2008_MotionLecture.mp4\|repo/Day1]] | [[day1-market-trends]] Hook · [[tesla-2008]] |
| Day1 | Tesla 2008 · Motion Studio | 3분 19초 | 33MB | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_1_Hook_Case_Tesla2008_MotionStudio.mp4\|repo/Day1]] | [[day1-market-trends]] Hook |
| Day2 | Moneyball · Motion Studio | 3분 36초 | 35MB | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_1_Hook_Case_Moneyball_MotionStudio.mp4\|repo/Day2]] | [[day2-crawling-viz]] Hook · [[moneyball]] |

## 외부 링크 (새 영상)
| 회차 | 영상 | YouTube 링크 | 길이 |
|---|---|---|---|
| | | | |

## 메모
- Motion Lecture는 나레이션 강의영상, Motion Studio는 모션그래픽 요약 영상 ([[claude-skills-catalog]]의 motion-lecture · motion-studio 스킬).
- Day3~6·특강 Hook은 영상 없음 → 만들 후보는 [[kma-auto-ai-series]]의 개선 이력에 적는다.
