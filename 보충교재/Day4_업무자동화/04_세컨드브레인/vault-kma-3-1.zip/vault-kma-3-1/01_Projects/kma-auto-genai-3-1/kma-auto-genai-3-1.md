---
type: project
status: active
tags: [kma, course, automotive]
related: ["[[kma-auto-ai-series]]", "[[kma]]"]
area: "[[kma-auto-ai-series]]"
deadline:
deliverable: "6일 48H 강의 + 로봇 특강, 수강생 통합 경쟁사 분석 보고서"
repo: "https://github.com/keerhee/kma-auto-genai-3-1"
site: "https://keerhee.github.io/kma-auto-genai-3-1/"
created: 2026-10-19
updated: 2026-10-19
---

# 능률협회 자동차산업과 생성형 AI 3-1

**자동차특화 AI융합 전문가 육성 과정** — 6일 48시간(이론 21H · 실습 19H · 프로젝트 8H) + 로봇·스마트팩토리 특강. 매일 같은 6단계 워크플로우([[six-step-workflow]])를 돌리고, 1~5일차 산출물 다섯 조각을 6일차에 통합 보고서 하나로 묶는다.

## 목표·결과물
- 수강생: 자동차 산업의 구조·재무·스마트팩토리·예지보전을 AI 도구로 분석·시각화·자동화하는 역량
- 산출물: 일차별 실습 산출물 → 6일차 **통합 경쟁사 분석 보고서** + 발표 + 90일 로드맵
- 부가 목적: 재직자 과정에 투입할 **멘토 양성** (6일차 발표·상호 피드백)

## 운영 개요
| 항목 | 내용 |
|---|---|
| 대상 | AI·SW 개발자·컨설턴트 등 (코딩·AI 경험 보유) |
| 정원 | 25명 (중도이탈 대비 초과 모집) |
| 운영 | 오프라인 + 실시간 온라인 병행 |
| 장소 | 서울 영등포구 이룸센터 10층 |
| 수료 | 총 출석률 80% 이상 |
| 평가 | 사전평가 · 사후평가 · 출석 → [[pre-test]] · [[post-test]] · [[final-presentation-rubric]] |
| 일정 | 원본 자료에 날짜 없음 — 확정 시 기입 |

## 회차
| 회차 | 노트 | 주제 | Hook 케이스 | 통합 보고서 조각 |
|---|---|---|---|---|
| Day0 | [[day0-orientation]] | 과정 안내·프롬프트·과제집·설치 | — | — |
| Day1 | [[day1-market-trends]] | 시장 및 트렌드 (CASE·SDV) | [[tesla-2008]] | 시장 위치 |
| Day2 | [[day2-crawling-viz]] | 데이터 크롤링 및 시각화 | [[moneyball]] | 제품·고객 |
| Day3 | [[day3-competitor-finance]] | 경쟁사 재무와 전략 | [[gm-bankruptcy-2009]] | 재무 체력 |
| Day4 | [[day4-job-automation]] | 직무별 업무 자동화 | [[model3-production-hell]] | 업무 혁신 |
| Day5 | [[day5-predictive-maintenance]] | 예지보전 AI | [[posco-lighthouse]] | 제조 역량 |
| Day6 | [[day6-final-project]] | 최종 프로젝트·발표 | [[pixar-braintrust]] | 통합 |
| 특강 | [[robot-special]] | 로봇과 스마트팩토리 | [[amazon-kiva]] · [[hyundai-boston-dynamics]] | — |

하루 구성: Hook 케이스 1H → Front 인트로 2H → Main 본 강의 8H → Back 보강 실습 2H (+ 보조자료).

## 자료
- 덱 목록·버전: [[deck-register]] · 영상: [[media]]
- 보조자료: [[day2-nightingale-anscombe]] · [[mini-project-workbook]]
- 데이터: [[auto-ev-news]] · [[domestic-ev-sales]] · [[voc-reviews-synthetic]] · [[automaker-financials]] · [[cs-manual-hanbit-synthetic]] · [[sensor-log-synthetic]] · [[final-project-templates]] · [[robot-pilot-cases]]
- 도구: [[claude-skills-catalog]] · [[auto-world-dashboard]] · [[simulations]]
- 원본 저장소: `repo/` (별도 git, 볼트 git 제외) · 사이트 운영: [[github-pages-ops]]

## 현황
- [x] 덱 33개 PDF 공개 (저장소 기준 2026-10-17)
- [x] 실습 데이터 기준일 2026-10-07
- [ ] 강의 일정 확정·기입
- [ ] 사전·사후평가 문항 확정 ([[pre-test]] · [[post-test]] 초안 검토)
- [ ] 실데이터 차수 시작 2주 전 갱신 여부 확인 ([[kma-auto-ai-series]] 기준)

## 결정 기록
<!-- /meeting 이 회의록에서 추출한 결정을 날짜순으로 쌓는다 -->
- 2026-10-19 · 영상 호스팅: 기존 mp4 3개는 저장소 유지, 새 영상부터 YouTube 일부 공개 → [[video-hosting-youtube]]

## 회고 (종료 시)
- 잘된 점:
- 고칠 점:
- 다음 차수에 넘길 것:
