---
type: deck
status: published
project: "[[kma-auto-genai-3-1]]"
style: "Hook·Front·Back: 11쪽 케이스/인트로/실습 덱 · Main: 33~43쪽 본 강의 덱"
deadline:
file: "repo/ (PDF만 공개)"
pages: 397
tags: [deck, register]
related: ["[[deck-standards]]", "[[github-pages-ops]]"]
created: 2026-10-19
updated: 2026-10-19
---

# 3-1 덱 등록부

공개 덱 33개(397쪽) + Claude 가이드 덱 3개. 모두 PDF로만 공개하며 원본 편집 파일(pptx 등)은 저장소에 없다. 구성 규칙은 [[deck-standards]].

| 회차 | 순서 | 덱 | 쪽 | 크기(KB) | 상태 |
|---|---|---|---|---|---|
| Day0 | 안내 | [[01_Projects/kma-auto-genai-3-1/repo/Day0/Day0_1_강의소개및개요.pdf\|Day0_1_강의소개및개요]] | 21 | 492 | published |
| Day0 | 안내 | [[01_Projects/kma-auto-genai-3-1/repo/Day0/Day0_2_기초_프롬프트작성법.pdf\|Day0_2_기초_프롬프트작성법]] | 14 | 376 | published |
| Day0 | 안내 | [[01_Projects/kma-auto-genai-3-1/repo/Day0/Day0_3_실전미니프로젝트_과제집.pdf\|Day0_3_실전미니프로젝트_과제집]] | 9 | 212 | published |
| Day0 | 안내 | [[01_Projects/kma-auto-genai-3-1/repo/Day0/Day0_4_Claude_설치가이드.pdf\|Day0_4_Claude_설치가이드]] | 11 | 688 | published |
| Day1 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_1_Hook_Case_Tesla2008_deck.pdf\|Day1_1_Hook_Case_Tesla2008_deck]] | 11 | 176 | published |
| Day1 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_2_Front2H_Intro_deck.pdf\|Day1_2_Front2H_Intro_deck]] | 11 | 212 | published |
| Day1 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_3_Main_자동차시장및트렌드이해.pdf\|Day1_3_Main_자동차시장및트렌드이해]] | 35 | 452 | published |
| Day1 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day1/Day1_4_Back2H_Practice_deck.pdf\|Day1_4_Back2H_Practice_deck]] | 11 | 236 | published |
| Day2 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_1_Hook_Case_Moneyball_deck.pdf\|Day2_1_Hook_Case_Moneyball_deck]] | 11 | 176 | published |
| Day2 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_2_Front2H_Intro_deck.pdf\|Day2_2_Front2H_Intro_deck]] | 11 | 208 | published |
| Day2 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_3_Main_자동차데이터크롤링및시각화.pdf\|Day2_3_Main_자동차데이터크롤링및시각화]] | 34 | 432 | published |
| Day2 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_4_Back2H_Practice_deck.pdf\|Day2_4_Back2H_Practice_deck]] | 11 | 236 | published |
| Day2 | 보조 | [[01_Projects/kma-auto-genai-3-1/repo/Day2/Day2_5_보조_시각화의두고전_나이팅게일과앤스컴.pdf\|Day2_5_보조_시각화의두고전_나이팅게일과앤스컴]] | 11 | 740 | published |
| Day3 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_1_Hook_Case_GM_Bankruptcy_deck.pdf\|Day3_1_Hook_Case_GM_Bankruptcy_deck]] | 11 | 176 | published |
| Day3 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_2_Front2H_Intro_deck.pdf\|Day3_2_Front2H_Intro_deck]] | 11 | 204 | published |
| Day3 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_3_Main_경쟁사재무와전략분석.pdf\|Day3_3_Main_경쟁사재무와전략분석]] | 33 | 408 | published |
| Day3 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day3/Day3_4_Back2H_Practice_deck.pdf\|Day3_4_Back2H_Practice_deck]] | 11 | 236 | published |
| Day4 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day4/Day4_1_Hook_Case_Model3_ProductionHell_deck.pdf\|Day4_1_Hook_Case_Model3_ProductionHell_deck]] | 11 | 184 | published |
| Day4 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day4/Day4_2_Front2H_Intro_deck.pdf\|Day4_2_Front2H_Intro_deck]] | 11 | 208 | published |
| Day4 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day4/Day4_3_Main_자동차직무별업무분석및실습.pdf\|Day4_3_Main_자동차직무별업무분석및실습]] | 34 | 420 | published |
| Day4 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day4/Day4_4_Back2H_Practice_deck.pdf\|Day4_4_Back2H_Practice_deck]] | 11 | 236 | published |
| Day5 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_1_Hook_Case_POSCO_Lighthouse_deck.pdf\|Day5_1_Hook_Case_POSCO_Lighthouse_deck]] | 11 | 172 | published |
| Day5 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_2_Front2H_Intro_deck.pdf\|Day5_2_Front2H_Intro_deck]] | 11 | 208 | published |
| Day5 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_3_Main_자동차예지보전AI활용.pdf\|Day5_3_Main_자동차예지보전AI활용]] | 34 | 404 | published |
| Day5 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day5/Day5_4_Back2H_Practice_deck.pdf\|Day5_4_Back2H_Practice_deck]] | 11 | 240 | published |
| Day6 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_1_Hook_Case_Pixar_Braintrust_deck.pdf\|Day6_1_Hook_Case_Pixar_Braintrust_deck]] | 11 | 176 | published |
| Day6 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_2_Front2H_Intro_deck.pdf\|Day6_2_Front2H_Intro_deck]] | 11 | 204 | published |
| Day6 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_3_Main_최종프로젝트구현및발표.pdf\|Day6_3_Main_최종프로젝트구현및발표]] | 34 | 416 | published |
| Day6 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Day6/Day6_4_Back2H_Practice_deck.pdf\|Day6_4_Back2H_Practice_deck]] | 11 | 240 | published |
| 특강 | Hook | [[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_1_Hook_Case_Amazon_Kiva_deck.pdf\|Robot_Special_1_Hook_Case_Amazon_Kiva_deck]] | 11 | 180 | published |
| 특강 | Front | [[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_2_Front2H_Intro_deck.pdf\|Robot_Special_2_Front2H_Intro_deck]] | 11 | 208 | published |
| 특강 | Main | [[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_3_Main_로봇과스마트팩토리특강.pdf\|Robot_Special_3_Main_로봇과스마트팩토리특강]] | 43 | 3588 | published |
| 특강 | Back | [[01_Projects/kma-auto-genai-3-1/repo/Robot_Special/Robot_Special_4_Back2H_Practice_deck.pdf\|Robot_Special_4_Back2H_Practice_deck]] | 11 | 252 | published |
| 설치 | 가이드 | [[01_Projects/kma-auto-genai-3-1/repo/x_code_manual/Claude_설치가이드_간단판.pdf\|Claude_설치가이드_간단판]] | 11 | 688 | published |
| Day2 가이드 | 가이드 | [[01_Projects/kma-auto-genai-3-1/repo/x_day2/Day2_가이드덱/Claude_Code_기초지식.pdf\|Claude_Code_기초지식]] | 21 | 628 | published |
| Day2 가이드 | 가이드 | [[01_Projects/kma-auto-genai-3-1/repo/x_day2/Day2_가이드덱/Claude_Code_시작가이드.pdf\|Claude_Code_시작가이드]] | 20 | 468 | published |

## 버전
| 버전 | 날짜 | 변경 |
|---|---|---|
| 3-1 | 2026-10-17 | 저장소 마지막 커밋 기준 공개본 |

## 검토 메모
- [ ] 특강 Main 덱만 3.6MB로 큼 (그림 다수) — 사이트 로딩 확인
- [ ] 차수 변경 시 이 표의 버전 열에 차수·날짜를 추가한다
