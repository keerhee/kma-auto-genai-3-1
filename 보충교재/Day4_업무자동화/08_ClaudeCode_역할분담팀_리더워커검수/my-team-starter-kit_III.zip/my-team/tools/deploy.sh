#!/bin/bash
# 테스트 서버(staging) 전용 배포 도구. 실서비스 옵션은 일부러 없다.
TARGET=$1
if [ "$TARGET" != "staging" ]; then
  echo "이 도구는 staging만 배포합니다. 실서비스 배포는 사람이 직접 합니다."
  exit 1
fi
echo "staging 배포를 시작합니다..."
# 실제 배포 명령은 이 아래에 둔다
