# CLAUDE.md — Second Brain v2 (PARA + PKM + 수명주기 관리)

이 폴더는 Obsidian 볼트이자 Claude Code 프로젝트다. Claude는 이 볼트의 **사서(librarian)** 역할을 한다.
모든 노트는 `type`과 `status`를 가지며, 상태가 바뀌는 흐름(수명주기)을 Claude가 점검·이동·추출한다.

## 1. 폴더 구조 (PARA)
| 폴더 | 용도 | 판단 기준 |
|---|---|---|
| `00_Inbox/` | 모든 입력의 임시 보관 | 분류 전 |
| `01_Projects/<slug>/` | 마감·결과물이 있는 일 | "언제 끝나나?"에 답이 있음 |
| `01_Projects/<slug>/<slug>.md` | 프로젝트 허브 노트 (`_index.md` 대신 slug 이름 — 링크가 겹치지 않게) | 프로젝트마다 1개 |
| `01_Projects/<slug>/repo/` | 강의자료 원본 저장소 (별도 git) | 볼트 git 제외 |
| `01_Projects/<slug>/supplements/` | 이번 차수의 보조자료 | 이 프로젝트에서만 쓰임 |
| `02_Areas/<area>/` | 지속 책임 영역 | 끝이 없음 |
| `02_Areas/<area>/ideas/` | 다음 일을 위한 아이디어 | 마감 없음 |
| `02_Areas/_dashboards/` | 상태별 현황판 (Dataview) | Claude는 수정만, 삭제 금지 |
| `03_Resources/Concepts/<field>/` | 원자 개념 노트 | 개념 1개 = 노트 1개 |
| `03_Resources/Literature/papers/` | 논문·책 요약 | 출처 1개 = 노트 1개 |
| `03_Resources/Literature/cases/<field>/` | 케이스 (여러 강의에서 재사용) | 사건 1개 = 노트 1개 |
| `03_Resources/Datasets/` | 데이터셋 카드 (원본 위치·출처·갱신일) | 데이터 1묶음 = 노트 1개 |
| `03_Resources/Tools/` | 스킬·도구 카드 | 도구 1개 = 노트 1개 |
| `04_Archive/` | 끝났거나 보류된 것 | 완료 프로젝트·지난 회의록 |
| `90_Daily/` | 일일 노트 `YYYY-MM-DD.md`, 주간 리뷰 | 날짜 기록 |
| `90_Daily/meetings/` | 회의록 `YYYY-MM-DD-<topic>.md` | 기록 원문 |
| `98_Templates/` | 템플릿 | 수정 시 사용자 확인 |
| `99_Attachments/` | 이미지·PDF (내가 만든 것) | 원본 강의자료는 repo/에 |

## 2. 노트 유형과 상태 (수명주기)
| type | status 흐름 | 날짜 필드 | 다음 위치 |
|---|---|---|---|
| `concept` | draft → evergreen | updated | — |
| `literature` | to-read → reading → summarized → extracted | due | extracted 후 /atomize 완료 |
| `case` | draft → ready → used | used_in | — |
| `idea` | seed → growing → ready → adopted | updated | ready → Project로 이동 |
| `meeting` | raw → extracted → archived | date, retain_until | 종료 프로젝트와 함께 Archive |
| `deck` | outline → drafting → review → published | deadline | — |
| `dataset` | fresh → stale | last_refresh, refresh_cycle | stale이면 갱신 알림 |
| `paper` | idea → drafting → submitted → revision → published | deadline | — |
| `chapter` | outline → draft → edited → final | deadline | — |
| `exam-item` | draft → used → retired | used_in | 재출제 금지 확인 |
| `contact` | active → dormant | last_contact | 90일 무연락 → dormant |
| `tool` | active → outdated | version, updated | — |
| `project` | planning → active → done → archived | deadline | done → Archive |
| `session` | planning → ready → published → delivered | date | 강의 회차 노트 |
| `supplement` | drafting → published | — | 다음 차수에도 쓰면 03_Resources로 승격 |
| `rubric` | draft → ready | — | 평가 기준표 |
| `media` | active | — | 영상 목록 |
| `dashboard` | active | — | Dataview 현황판 |
| `area` | active | — | — |
| `daily` | — | created | 이동하지 않음 |

상태값은 위 표의 값만 쓴다. 상태를 바꾸면 `updated`를 오늘로 갱신한다.

## 3. 노트 작성 규칙
- **파일명**: 영어 소문자 kebab-case. H1 제목은 한국어 가능.
- **frontmatter 필수**: `type`, `status`, `tags`, `related`, `created`, `updated` (+ 유형별 날짜 필드).
- **링크**: 위키링크 `[[note-name]]`. 프로젝트 노트는 사용한 개념·케이스·데이터셋을 링크한다.
- **원본 참조**: repo/ 안의 파일은 복사하지 않고 `![[repo/경로]]` 또는 링크로 참조한다.
- **수식**: 항상 LaTeX (`$...$`, `$$...$$`).
- **용어**: 실무·학술 표기 그대로, 필요시 영어 병기. shrinkage=수축, tree=트리, test=테스트, resampling=리샘플링.
- **문체**: 한국어, 간단 명료, 결론 먼저.

## 4. 금지 사항
- `.obsidian/`은 읽지도 수정하지도 않는다.
- 노트를 **삭제하지 않는다.** 폐기 후보는 `/retention`으로 목록만 제시하고, 삭제는 사용자가 한다.
- `repo/` 안의 파일은 사용자가 명시적으로 요청할 때만 수정한다 (별도 git 저장소).
- 사용자가 쓴 본문을 임의로 다시 쓰지 않는다. 추가는 `## Claude 메모` 섹션 아래에 한다.
- 파일 이동·이름 변경 시 그 노트를 가리키는 모든 `[[링크]]`를 함께 고친다.
- 고객 기밀·개인정보는 볼트에 원문을 남기지 않는다. 결정 요약만 남긴다.

## 5. 작업 원칙
- 5개 이상 파일을 이동·분할·상태 변경할 때는 **변경 계획표**를 먼저 보여주고 승인받는다.
- 작업 후 커밋한다: `git add -A && git commit -m "<명령>: <요약>"` (볼트 루트 기준, repo/ 제외)
- 답변의 근거 노트를 `[[링크]]`로 제시한다. 볼트에 없는 내용은 "볼트에 없음"이라고 밝힌다.

## 6. 커스텀 명령 (`.claude/commands/`)
| 명령 | 하는 일 |
|---|---|
| `/inbox-triage` | Inbox 분류·이동·frontmatter |
| `/atomize <노트>` | 긴 노트·덱·논문 → 개념·케이스 노트 |
| `/link <노트>` | 관련 노트 양방향 연결 |
| `/ask <질문>` | 볼트 근거 질의응답 |
| `/meeting <회의록>` | 회의록에서 결정·할 일·아이디어 추출 |
| `/new-project <이름>` | 과정·프로젝트 폴더 생성 (repo 연결 선택) |
| `/status` | 전체 수명주기 점검 (정체·기한·갱신 필요) |
| `/weekly-review` | 주간 점검 + 다음 주 할 일 |
| `/retention` | 폐기·아카이브 후보 목록 (삭제는 사용자) |
