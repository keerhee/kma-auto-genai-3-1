---
description: 볼트 전체의 수명주기 점검 — 기한 임박·정체·갱신 필요 항목을 유형별로 보고한다
argument-hint: [type | 프로젝트 slug] (비우면 전체)
---

범위: $ARGUMENTS (비우면 전체, `.obsidian/`·`repo/` 제외)

오늘 날짜 기준으로 frontmatter를 읽어 아래를 점검하고 표로 보고한다. **결론(가장 급한 3개)을 먼저** 쓴다.

| type | 점검 |
|---|---|
| project | deadline 14일 이내 / 지남, 14일 이상 변경 없음, done인데 Archive 안 감 |
| session | 다음 강의일 7일 이내인데 status가 planning |
| deck | deadline 7일 이내인데 outline·drafting |
| paper·chapter | deadline 30일 이내, 30일 이상 정체 |
| literature | due 지남인데 to-read·reading, summarized인데 extracted 아님 |
| idea | ready인데 30일 이상 adopted 안 됨, seed가 90일 이상 정체 |
| meeting | raw가 3일 이상 (→ /meeting) |
| dataset | last_refresh + refresh_cycle 지남 → stale로 바꿀 후보 |
| exam-item | 같은 과정 최근 차수에 used → 재출제 주의 |
| contact | last_contact 90일 이상 → dormant 후보 |
| tool | 90일 이상 updated 없음 |
| concept·case | draft가 60일 이상 |

- 상태를 바꿔야 할 항목은 **변경 계획표**로 제시하고, 승인받으면 frontmatter를 갱신한다.
- 결과를 저장하라고 하면 `02_Areas/_dashboards/status-YYYY-MM-DD.md`로 저장한다.
