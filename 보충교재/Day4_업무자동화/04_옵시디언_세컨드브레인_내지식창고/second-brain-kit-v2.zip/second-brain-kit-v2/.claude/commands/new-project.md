---
description: 새 과정·프로젝트 폴더를 만들고, 선택적으로 강의자료 저장소를 repo/로 연결한다
argument-hint: <project-slug> [GitHub URL] [이전 차수 slug]
---

인자: $ARGUMENTS

1. `01_Projects/<slug>/`를 만들고 `98_Templates/project.md`로 허브 노트 `<slug>.md`를 생성한다.
   - `area`에 소속 영역 허브(`02_Areas/...`)를 링크한다. 허브가 없으면 만들지 제안한다.
2. GitHub URL이 있으면:
   - `git clone <URL> 01_Projects/<slug>/repo`
   - 허브 노트 `<slug>.md`의 `repo`에 URL을 적는다.
   - `.gitignore`에 `01_Projects/*/repo/`가 있는지 확인한다.
   - repo의 폴더 구조를 읽어 회차(Day·Week) 목록을 제안한다.
3. 회차마다 `98_Templates/course-session.md`로 세션 노트를 만든다. 원본 자료는 `![[repo/...]]`로 링크만 건다.
4. 이전 차수 slug가 있으면:
   - 이전 차수의 세션 노트를 복사해 시작점으로 쓴다 (`## 차수 메모`는 비운다).
   - 이전 차수 허브 노트 `<slug>.md`의 `## 회고`와 `02_Areas/<area>/ideas/`의 `status: ready` 아이디어를 반영 후보로 보여준다.
5. 계획표를 먼저 보여주고 승인 후 만든다.
6. 커밋: `new-project: <slug>`
