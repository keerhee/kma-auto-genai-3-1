---
description: 00_Inbox의 노트를 유형(type)별로 판별해 PARA 폴더로 분류·이동하고 frontmatter를 채운다
---

`00_Inbox/`의 모든 파일을 처리한다. CLAUDE.md §1·§2의 규칙을 따른다.

1. 각 노트를 읽고 **type**을 판별한다.
   | 판별 | type | 이동 위치 |
   |---|---|---|
   | 마감 있는 일의 계획·현황 | project | `01_Projects/<slug>/<slug>.md` (없으면 /new-project 제안) |
   | 강의 회차 계획 | session | `01_Projects/<slug>/` |
   | 이번 차수 보조자료 | supplement | `01_Projects/<slug>/supplements/` |
   | 다음 일을 위한 착상 | idea | `02_Areas/<area>/ideas/` |
   | 회의 기록 | meeting | `90_Daily/meetings/YYYY-MM-DD-<topic>.md` |
   | 사람·기관 관계 | contact | `02_Areas/clients/` 또는 `02_Areas/network/` |
   | 개념 하나 | concept | `03_Resources/Concepts/<field>/` |
   | 논문·책 요약 | literature | `03_Resources/Literature/papers/` |
   | 사건·기업 케이스 | case | `03_Resources/Literature/cases/<field>/` |
   | 데이터 설명 | dataset | `03_Resources/Datasets/` |
   | 스킬·도구 설명 | tool | `03_Resources/Tools/` |
   | 덱 기획 | deck | 해당 프로젝트 폴더 |
   | 논문 집필 | paper | `01_Projects/<paper-slug>/` |
   | 책 원고 장 | chapter | `01_Projects/<book-slug>/` |
   | 시험 문항 | exam-item | `02_Areas/teaching/exam-bank/` |
   | 판단 불가 | — | Inbox에 두고 이유 기록 |
2. **변경 계획표**를 먼저 출력한다: | 현재 파일 | type | 새 경로 | 새 파일명 | 이유 |
3. 승인받으면 실행한다.
   - 파일명을 영어 kebab-case로 바꾼다.
   - `98_Templates/<type>.md`의 frontmatter 필드를 채운다. 상태는 각 유형의 첫 단계로 둔다.
   - 기존 노트 중 관련된 것 2~5개를 `related`에 넣는다.
   - 이동한 파일을 가리키는 `[[링크]]`를 모두 고친다.
4. 커밋: `inbox-triage: N개 분류`
5. 한 줄로 보고한다 (이동 N, 보류 N, 유형별 개수).
