---
description: 아카이브·폐기 후보를 목록으로 제시한다 — 이동은 승인 후, 삭제는 사용자가 직접
---

1. **아카이브 후보** (승인 시 Claude가 이동)
   - `type: project`, `status: done` → `04_Archive/<slug>/` (폴더째, repo/ 포함)
   - 그 프로젝트에 연결된 `meeting` → `04_Archive/meetings/<연도>/`
   - `idea` 중 `status: adopted` → 그대로 두되 표시만
2. **폐기 후보** (Claude는 삭제하지 않는다)
   - `meeting` 중 `retain_until`이 지났고 `status: extracted`인 것
   - `00_Inbox`에 180일 이상 머문 파일
   - 확인할 점: 결정·할 일이 프로젝트 노트에 옮겨졌는지 대조해 표에 표시한다.
3. 출력: | 파일 | 사유 | 추출 완료 여부 | 권장 (아카이브/삭제/보류) |
4. 삭제 안내: 사용자가 옵시디언에서 직접 지우거나, 승인 시 `_to_delete/` 폴더로 모아 둔다.
   볼트 git 이력에는 남는다는 점을 함께 알린다.
5. 커밋 (이동했을 때만): `retention: 아카이브 N`
