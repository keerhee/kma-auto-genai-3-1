---
description: 긴 노트·강의 덱(PDF)·논문 요약을 개념·케이스 노트로 분해하고 링크로 연결한다
argument-hint: <노트 또는 PDF 경로>
---

대상: $ARGUMENTS

1. 대상을 읽는다. PDF면 텍스트를 추출해 읽는다 (repo/ 안의 원본은 수정하지 않는다).
2. 재사용할 단위를 뽑는다.
   - **개념** (정의가 있는 용어·원리·방법) → `03_Resources/Concepts/<field>/`
   - **케이스** (기업·사건 이야기) → `03_Resources/Literature/cases/<field>/`
3. 각 단위가 이미 있는지 확인한다.
   - 있으면 → 새로 만들지 않고, 빠진 내용을 `## Claude 메모` 아래에 덧붙이도록 제안한다.
   - 없으면 → `98_Templates/concept.md` 또는 `case.md` 형식으로 만든다. status는 `draft`.
4. **계획표**를 먼저 보여준다: | 단위 | 종류 | 신규/기존 | 파일명 | 한 줄 정의 |
5. 승인받으면 만든다. `source`에 원본을 링크한다. 케이스의 숫자에는 출처와 기준일을 적는다.
6. 원본 노트는 지우지 않는다. 원본이 md면 개념이 처음 나오는 곳을 `[[개념노트]]`로 바꾼다.
   원본이 literature면 status를 `extracted`로 바꾼다.
7. 커밋: `atomize: <원본> → 개념 N, 케이스 N`
