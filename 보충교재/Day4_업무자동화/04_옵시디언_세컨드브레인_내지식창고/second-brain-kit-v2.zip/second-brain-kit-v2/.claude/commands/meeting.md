---
description: 회의록에서 결정·할 일·아이디어를 뽑아 프로젝트·영역 노트로 옮기고 회의록을 extracted로 바꾼다
argument-hint: <회의록 경로 | 비우면 status=raw 전체>
---

대상: $ARGUMENTS (비어 있으면 `90_Daily/meetings/`에서 `status: raw`인 회의록 전체)

1. 회의록을 읽는다. 녹취·메모를 붙여 넣은 원문이면 먼저 `98_Templates/meeting.md` 형식(논의·결정·할 일·아이디어)으로 정리한다.
2. 추출 계획표를 보여준다.
   | 항목 | 종류 | 옮길 곳 |
   |---|---|---|
   | 결정 | decision | `project` 노트의 `## 결정 기록` (날짜·회의록 링크와 함께) |
   | 할 일 | task | 프로젝트 `## 현황` 체크리스트 (담당·기한) |
   | 아이디어 | idea | `02_Areas/<area>/ideas/` 새 idea 노트 (status: seed) |
   | 상대방 정보 | contact | `contact` 노트의 `## 협의 이력` + `last_contact` 갱신 |
3. 승인받으면 옮긴다. 원문은 그대로 두고 회의록 frontmatter를 갱신한다.
   - `status: extracted`
   - `retain_until`이 비어 있으면: 연결된 프로젝트 deadline + 1년
4. 기밀·개인정보가 보이면 원문 보관 여부를 사용자에게 묻는다 (볼트 밖 보관 권장).
5. 커밋: `meeting: <회의록> → 결정 N, 할 일 N, 아이디어 N`
