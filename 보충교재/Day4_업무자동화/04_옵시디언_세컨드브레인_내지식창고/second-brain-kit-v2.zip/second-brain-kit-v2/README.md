# Second Brain Kit v2 — 설치·사용법

v1 대비 추가: 노트 유형 15종의 상태(수명주기) 관리, 템플릿 15종, 명령 9개, 홈 대시보드, 강의자료 저장소(repo/) 연결.

## 1. 설치
1. 이 폴더의 **내용물**을 옵시디언 볼트 루트에 복사한다 (숨김 파일 `.claude/`, `.gitignore` 포함).
   ```bash
   cp -R ~/Downloads/second-brain-kit-v2/. ~/Documents/Vault/
   ```
2. 볼트 루트에서 Git 시작과 Claude Code 실행:
   ```bash
   cd ~/Documents/Vault
   git init && git add -A && git commit -m "init second brain v2"
   claude
   ```

## 2. 옵시디언 설정
| 설정 | 값 |
|---|---|
| 파일 및 링크 → 새 노트 위치 | `00_Inbox` |
| 파일 및 링크 → 첨부파일 위치 | `99_Attachments` |
| 파일 및 링크 → 모든 파일 확장자 감지 | 켬 |
| 파일 및 링크 → 제외 파일 | `01_Projects/*/repo/*/render*`, `*.mp4` (검색 속도) |
| 코어 플러그인 → 템플릿 → 폴더 | `98_Templates` |
| 코어 플러그인 → 일일 노트 → 폴더 / 템플릿 | `90_Daily` / `98_Templates/daily` |
| 커뮤니티 플러그인 | Dataview(필수), Templater, Obsidian Git |

## 3. 명령
| 명령 | 언제 |
|---|---|
| `/new-project <slug> [GitHub URL] [이전 차수]` | 새 과정·차수 시작 |
| `/inbox-triage` | 주 1~2회, Inbox 정리 |
| `/meeting` | 회의 직후 또는 하루 끝 |
| `/atomize <노트·PDF>` | 덱·논문에서 개념·케이스 추출 |
| `/link <노트>` | 새 노트 연결 |
| `/ask <질문>` | 내 지식으로 답 찾기 |
| `/status` | 수시, 급한 것 확인 |
| `/weekly-review` | 주말 |
| `/retention` | 월 1회 또는 프로젝트 종료 시 |

## 4. 하루·한 주의 흐름
- **매일**: 일일 노트(`90_Daily`)에 기록 → 따로 키울 것은 `00_Inbox`로 → 회의록은 `meeting` 템플릿
- **주 1회**: `/inbox-triage` → `/meeting` → `/weekly-review`
- **차수 종료**: 허브 노트 `<slug>.md` 회고 작성 → `/retention`으로 Archive

## 5. 대시보드
`02_Areas/_dashboards/home.md`를 옵시디언에서 열면 프로젝트·덱·아이디어·회의록·논문·데이터·집필·문항·관계·도구 현황이 자동으로 표시된다. 즐겨찾기(북마크)에 등록해 두면 편하다.
