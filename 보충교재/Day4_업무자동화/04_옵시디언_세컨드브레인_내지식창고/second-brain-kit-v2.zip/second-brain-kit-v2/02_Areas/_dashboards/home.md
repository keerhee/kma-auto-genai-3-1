---
type: dashboard
status: active
tags: [dashboard]
created: 2026-10-19
updated: 2026-10-19
---

# 홈 대시보드
> Dataview 플러그인이 필요하다. 표는 노트의 frontmatter에서 자동으로 만들어진다.

## 진행 중 프로젝트
```dataview
TABLE status, deadline, area
FROM "01_Projects"
WHERE type = "project" AND status != "done"
SORT deadline ASC
```

## 이번 주 강의 회차
```dataview
TABLE project, date, status
FROM "01_Projects"
WHERE type = "session" AND date >= date(today) AND date <= date(today) + dur(14 days)
SORT date ASC
```

## 덱 제작
```dataview
TABLE project, status, deadline
WHERE type = "deck" AND status != "published"
SORT deadline ASC
```

## 아이디어 (ready 우선)
```dataview
TABLE status, target, updated
WHERE type = "idea" AND status != "adopted"
SORT choice(status = "ready", 0, choice(status = "growing", 1, 2)) ASC, updated DESC
```

## 회의록 — 추출 대기
```dataview
TABLE project, date
FROM "90_Daily/meetings"
WHERE status = "raw"
SORT date DESC
```

## 읽을 논문·책
```dataview
TABLE status, priority, due
WHERE type = "literature" AND (status = "to-read" OR status = "reading" OR status = "summarized")
SORT due ASC
```

## 데이터 갱신 필요
```dataview
TABLE kind, last_refresh, refresh_cycle, location
WHERE type = "dataset"
SORT last_refresh ASC
```

## 논문·책 집필
```dataview
TABLE type, status, deadline
WHERE (type = "paper" OR type = "chapter") AND status != "published" AND status != "final"
SORT deadline ASC
```

## 시험 문항 뱅크
```dataview
TABLE course, topic, status, used_in
WHERE type = "exam-item"
SORT status ASC
```

## 연락이 뜸한 관계
```dataview
TABLE org, role, last_contact
WHERE type = "contact" AND last_contact <= date(today) - dur(90 days)
SORT last_contact ASC
```

## 스킬·도구
```dataview
TABLE category, version, updated
WHERE type = "tool"
SORT updated ASC
```
