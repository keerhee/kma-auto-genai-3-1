---
type: session
status: planning
project: "[[ ]]"
session: ""
date:
tags: []
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 목표
- 

## 구성
| 순서 | 자료 | 시간 | 원본 |
|---|---|---|---|
| 1 | Hook 케이스 | | ![[repo/ ]] |
| 2 | 인트로 | | |
| 3 | 본 강의 | | |
| 4 | 보강 실습 | | |

## 핵심 메시지
1. 
2. 
3. 

## 사용 개념·케이스·데이터
- 케이스: [[ ]]
- 개념: [[ ]]
- 데이터: [[ ]]

## 산출물 (수강생)

## 차수 메모
<!-- 진도·질문·수강생 반응·오류. 차수 공통 사항은 03_Resources 노트로 옮긴다 -->
