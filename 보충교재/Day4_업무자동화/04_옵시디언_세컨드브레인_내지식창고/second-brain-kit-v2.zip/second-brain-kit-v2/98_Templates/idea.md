---
type: idea
status: seed
target: ""
tags: [idea]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 착상

## 왜 필요한가

## 근거·자료
- [[ ]]

## 넣을 자리
- 과정·차수·Day:

## 다음 행동
- [ ]
