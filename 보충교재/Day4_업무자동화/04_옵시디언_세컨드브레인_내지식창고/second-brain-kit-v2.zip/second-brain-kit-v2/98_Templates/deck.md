---
type: deck
status: outline
project: "[[ ]]"
style: ""
deadline:
file: ""
pages:
tags: [deck]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 목적·청중

## 흐름 (슬라이드 개요)
1. 
2. 

## 재료
- 케이스: [[ ]]
- 개념: [[ ]]
- 데이터: [[ ]]

## 검토 메모
- [ ]

## 버전
| 버전 | 날짜 | 변경 |
|---|---|---|
