---
type: exam-item
status: draft
course: "[[ ]]"
topic: "[[ ]]"
format: 서술형
used_in: []
tags: [exam]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 문항
<!-- 케이스 수치를 주고 실무 판단·해석을 묻는다. 자체 완결형. 수업에서 다룬 내용만. -->

## 모범답안

## 채점 기준
| 요소 | 배점 |
|---|---|

## 출제 이력
| 과정·차수 | 날짜 | 정답률·반응 |
|---|---|---|
