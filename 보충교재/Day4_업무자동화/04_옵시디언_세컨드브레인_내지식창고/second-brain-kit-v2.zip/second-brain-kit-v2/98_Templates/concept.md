---
type: concept
status: draft
tags: []
field: ""
related: []
source: ""
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 정의

## 왜 필요한가

## 핵심 수식

$$
$$

## 예시

## 관련 개념
- [[ ]]
