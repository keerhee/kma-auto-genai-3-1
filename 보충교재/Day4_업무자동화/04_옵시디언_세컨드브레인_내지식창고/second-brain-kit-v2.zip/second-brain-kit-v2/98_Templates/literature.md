---
type: literature
status: to-read
priority: normal
due:
tags: []
related: []
source: ""
authors: ""
year:
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 한 줄 요약

## 문제 제기

## 방법·핵심 수식

## 결과

## 내 생각·활용처
- 쓸 강의·논문: [[ ]]

## 뽑아낸 개념
- [[ ]]
