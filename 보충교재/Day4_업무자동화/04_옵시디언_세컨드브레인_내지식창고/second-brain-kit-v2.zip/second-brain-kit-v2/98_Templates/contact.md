---
type: contact
status: active
org: ""
role: ""
last_contact: {{date:YYYY-MM-DD}}
tags: [contact]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 관계
- 함께한 일: [[ ]]

## 협의 이력 (결정 요약만)
| 날짜 | 내용 | 회의록 |
|---|---|---|

## 다음 연락
- [ ]
