---
type: paper
status: idea
venue: ""
deadline:
coauthors: []
repo: ""
tags: [paper]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 연구 질문

## 기여

## 핵심 수식·모형

## 진행
| 단계 | 상태 | 메모 |
|---|---|---|
| 초고 | | |
| 투고 | | |
| 리비전 | | |

## 근거 문헌
- [[ ]]

## 리뷰어 코멘트·대응
