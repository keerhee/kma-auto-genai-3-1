---
type: supplement
status: drafting
project: "[[ ]]"
session: "[[ ]]"
file: ""
tags: [supplement]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 왜 이 보조자료가 필요한가

## 핵심 내용

## 원본
- 

## 다음 차수에도 쓸까?
- [ ] 쓴다 → 03_Resources로 승격
- [ ] 이번만
