---
type: meeting
status: raw
project: "[[ ]]"
attendees: []
date: {{date:YYYY-MM-DD}}
retain_until:
tags: [meeting]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 논의

## 결정
- 

## 할 일
- [ ] 내용 (담당, ~기한)

## 아이디어
- 
