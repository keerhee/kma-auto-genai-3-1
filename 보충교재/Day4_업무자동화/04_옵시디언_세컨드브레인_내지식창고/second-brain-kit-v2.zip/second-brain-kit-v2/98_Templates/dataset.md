---
type: dataset
status: fresh
kind: real
location: ""
source: ""
last_refresh: {{date:YYYY-MM-DD}}
refresh_cycle: 차수마다
used_in: []
tags: [dataset]
related: []
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 내용
- 행·열:
- 기준일:

## 출처와 수집 방법

## 주의 (함정·표기)
- kind: real(실데이터) / synthetic(가상, "실습용" 표기 필수) / template

## 갱신 이력
| 날짜 | 변경 | 사용처 |
|---|---|---|
