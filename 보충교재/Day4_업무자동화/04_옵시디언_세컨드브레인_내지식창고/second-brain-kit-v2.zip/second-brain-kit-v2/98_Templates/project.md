---
type: project
status: planning
tags: []
related: []
area: "[[ ]]"
deadline: YYYY-MM-DD
deliverable: ""
repo: ""
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 목표·결과물

## 일정

## 현황
- [ ]

## 사용하는 개념·케이스·데이터
- [[ ]]

## 결정 기록
<!-- /meeting 이 회의록에서 추출한 결정을 여기에 날짜순으로 쌓는다 -->

## 회고 (종료 시)
- 잘된 점:
- 고칠 점:
- 다음 차수에 넘길 것:
