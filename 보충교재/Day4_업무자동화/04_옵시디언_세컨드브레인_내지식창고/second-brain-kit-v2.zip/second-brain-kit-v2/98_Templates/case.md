---
type: case
status: draft
field: ""
year:
used_in: []
tags: [case]
related: []
source: ""
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
---

# {{title}}

## 한 줄 요약

## 장면
1. 
2. 
3. 
4. 

## 핵심 숫자 (출처·기준일)
| 숫자 | 의미 | 출처 |
|---|---|---|

## 교훈
1. 
2. 
3. 

## 연결되는 개념
- [[ ]]

## 쓸 수 있는 강의
- 
