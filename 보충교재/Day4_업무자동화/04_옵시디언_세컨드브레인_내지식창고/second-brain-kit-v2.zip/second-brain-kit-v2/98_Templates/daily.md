---
type: daily
status: active
tags: [daily]
created: {{date:YYYY-MM-DD}}
---

# {{date:YYYY-MM-DD}}

## 오늘 할 일
- [ ]

## 메모·캡처

## 결정

## 내일로
