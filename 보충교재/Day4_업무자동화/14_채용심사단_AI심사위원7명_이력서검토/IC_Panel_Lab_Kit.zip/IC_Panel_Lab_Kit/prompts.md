# IC 심사단 프롬프트 실습 — 붙여 넣을 문장 모음

> 모든 인물 · 기관 · 펀드는 실습용 가상이다. 실제 투자 판단에 쓰지 않는다.

## PART 1 · 준비
**STEP 1 — 터미널** `claude --version`

**STEP 2 — 터미널**
```
mkdir ~/ic-lab && cd ~/ic-lab && claude
```

**STEP 3 — 클로드 코드**
```
다운로드 폴더에 있는 IC_Panel_Lab_Kit.zip 파일을 지금 이 폴더에 풀어 줘.
다 풀었으면 폴더 안의 파일 목록을 트리 모양으로 보여 줘.
```

## PART 2 · IC 심사단 만들기
**STEP 4**
```
data 폴더의 ips_garam.md 와 portfolio_garam.md 를 읽고,
IPS 한도 여섯 개를 한 줄씩 «지금 남은 여유가 얼마인지» 표로 정리해 줘. 계산식도 같이 적어 줘.
```

**STEP 5 — 설계만 먼저**
```
투자 메모를 투자위원회에 올리기 전에 점검하는 ic-panel 스킬을 만들려고 한다. 파일은 만들지 말고 설계표만 보여 줘.
· 관문 1명: IPS 한도 검사를 먼저 혼자 한다. 넘으면 멈춘다
· 위원 6명: CIO · 운용 PM · CRO · 반대 투자자 · 수익자 대표 · ODD, 동시에 따로 읽는다
· 판정: 관문 ELIGIBLE/CONDITIONAL/REJECT, 위원 APPROVE/CONDITIONAL/DECLINE
· 수정본은 메모에 없는 숫자를 지어내지 말고 [ADD: ]로 남긴다
```

**STEP 6 — 만들기**
```
설계대로 ~/.claude/skills/ic-panel/SKILL.md 를 만들어 줘.
규칙 세 개는 꼭 넣어 줘: 위원은 서로의 의견을 보지 않는다 / 숫자는 계산식과 함께 쓴다 / 결정은 사람이 한다.
다 만들면 SKILL.md 의 일하는 순서 부분만 보여 줘.
```

**STEP 7 — 다시 열기** `/exit` → `claude` → `/ic-panel` 이 목록에 보이는지 확인

## PART 3 · 심사와 수정
**STEP 8 — 약점 먼저 예상**
```
data/memo_northsea_wind.md 를 읽고, 내가 투자위원이라면 무엇을 가장 먼저 물을지 세 문장으로 말해 줘.
```

**STEP 9 — 심사단 실행**
```
/ic-panel data/memo_northsea_wind.md IPS: data/ips_garam.md 포트폴리오: data/portfolio_garam.md
```

**STEP 10 — 관문에서 멈춘 이유 읽기**
```
관문이 REJECT 한 한도를 번호 · 계산식 · 넘은 금액으로 표로 정리하고,
모든 한도를 지키는 최대 약정 금액을 계산해 줘.
```

**STEP 11 — 금액을 고쳐 다시 실행**
```
메모의 제안 금액을 1,500억 원으로 고친 사본 memo_northsea_wind_1500.md 를 만들고,
그 사본으로 /ic-panel 을 다시 실행해 줘. 원본 메모는 고치지 마.
```

**STEP 12 — 결과 정리**
```
.ic-panel 폴더의 최신 IC_PANEL.md 를 읽고, 위원 여섯 명의 판정을 표로 정리한 뒤
딜 브레이커와 조건부 승인 조건을 심각한 순서로 나눠 보여 줘.
```

**STEP 13 — 사실 검증**
```
MEMO-REVISED.md 에서 원본 메모에 없던 숫자와 주장을 모두 골라내고,
data/facts_northsea_wind.md 에 있는 것과 없는 것으로 나눠 표로 보여 줘.
없는 것은 [ADD: …] 빈칸으로 바꿔 줘.
```

**STEP 14 — 다시 심사**
```
사실 파일로 고친 MEMO-REVISED.md 를 같은 IPS · 포트폴리오로 /ic-panel 에 다시 넣어 줘.
처음 결과와 위원별 판정이 어떻게 바뀌었는지 전후 표로 보여 줘.
```

## PART 4 · 다른 안건과 모범 답안
**STEP 15**
```
data/memo_seoul_logistics.md 도 같은 IPS · 포트폴리오로 /ic-panel 에 넣어 줘.
북해풍력과 비교해 관문 결과와 위원 판정이 무엇이 다른지 세 줄로 말해 줘.
```

**STEP 16**
```
reference/ic-panel/SKILL.md 는 모범 답안이다. 내가 만든 ~/.claude/skills/ic-panel/SKILL.md 와 비교해서
모범 답안에만 있는 규칙을 표로 보여 주고, 필요한 것만 내 스킬에 넣어 줘.
```

## 막혔을 때
- 스킬이 목록에 안 보인다: "ic-panel 스킬이 명령 목록에 보이지 않아. 위치와 SKILL.md 첫 부분 name 줄을 점검하고 고쳐 줘."
- 한도 숫자가 이상하다: "한도 검사의 계산식을 한 줄씩 보여 주고, IPS 파일의 숫자와 다르면 고쳐 줘."
- 수정본에 모르는 숫자가 있다: "이 숫자가 어느 파일 몇째 줄에 있는지 보여 줘. 없으면 [ADD: ]로 바꿔 줘."
