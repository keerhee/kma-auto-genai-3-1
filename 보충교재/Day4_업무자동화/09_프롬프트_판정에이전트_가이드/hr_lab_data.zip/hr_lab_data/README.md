# HR Parental AI Agent — 실습용 가상 데이터

모든 직원·회사·연락처는 가상이다. 실제 개인정보를 넣지 않는다.

| 파일 | 내용 |
|---|---|
| data/employees.json | 가상 직원 8명(직원 7, 인사담당자 1). 테스트 사례 A~H와 연결 |
| data/regulations/parental-leave.json | 육아휴직 법령 요약(남녀고용평등법 제19조) |
| data/regulations/reduced-working-hours.json | 육아기 근로시간 단축(제19조의2) |
| data/regulations/maternity-leave.json | 출산전후휴가(근로기준법 제74조) |
| data/company-policy.json | 가상 회사 '가온전자' 내부 규정 |
| data/test-cases.csv | 판정 엔진 자동 테스트용 기대 결과 8건 |
| data/sample-questions.md | AI 상담 테스트 질문 10개 |
| prompts/ | 단계별 프롬프트 원문(복사용) |

법령 요약은 2026-10-24 기준으로 정리했다. `verification` 항목이 "검증 필요"인 내용은 STEP 4에서
Claude Code가 고용노동부·국가법령정보센터 원문과 대조하도록 되어 있다.
판정 기준일은 2026-12-01(휴직 개시 예정일)이다.
