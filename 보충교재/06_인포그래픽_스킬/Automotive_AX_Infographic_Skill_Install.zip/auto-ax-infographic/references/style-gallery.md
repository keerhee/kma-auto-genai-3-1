# 자동차 AX 11가지 스타일 이미지 갤러리

> 독립 제작된 교육용 시각적 레퍼런스. 예시의 숫자·기업 관계는 실제 사실로 사용하지 마세요.

## 01. EV 구동계 개념
![스타일 01 예시](../assets/style-reference/style-01.png)

## 02. 국내 EV 등록 데이터
![스타일 02 예시](../assets/style-reference/style-02.png)

## 03. 제조·예지보전 프로세스
![스타일 03 예시](../assets/style-reference/style-03.png)

## 04. EV·ICE 비교
![스타일 04 예시](../assets/style-reference/style-04.png)

## 05. AX 실행 로드맵
![스타일 05 예시](../assets/style-reference/style-05.png)

## 06. OEM·Tier 계층
![스타일 06 예시](../assets/style-reference/style-06.png)

## 07. 자동차 산업 온톨로지
![스타일 07 예시](../assets/style-reference/style-07.png)

## 08. 예지보전 의사결정 트리
![스타일 08 예시](../assets/style-reference/style-08.png)

## 09. AX 과제 우선순위
![스타일 09 예시](../assets/style-reference/style-09.png)

## 10. 품질 개선 KPI
![스타일 10 예시](../assets/style-reference/style-10.png)

## 11. SDV·EV 연구 근거
![스타일 11 예시](../assets/style-reference/style-11.png)
