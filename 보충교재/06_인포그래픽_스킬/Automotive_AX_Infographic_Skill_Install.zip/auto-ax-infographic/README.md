# auto-ax-infographic · 자동차 산업 AX 인포그래픽 스킬

## 설치 (macOS/Linux)

이 ZIP은 `auto-ax-infographic/SKILL.md` 구조입니다. 다음을 실행하세요.

```bash
mkdir -p ~/.claude/skills
unzip Automotive_AX_Infographic_Skill_Install.zip -d ~/.claude/skills/
```

## 설치 (Windows PowerShell)

```powershell
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Expand-Archive -Path .\Automotive_AX_Infographic_Skill_Install.zip -DestinationPath "$HOME\.claude\skills" -Force
```

Claude Code를 다시 열고 `/skills`로 스킬을 확인합니다.

## 사용 예

`/auto-ax-infographic 한국 자동차 기업의 OEM–Tier1–Tier2 관계를 16:9 강의용 인포그래픽으로 설계해줘. 확인되지 않은 공급관계는 표시하지 마.`

## GitHub로 사용

기본 지침은 https://github.com/keerhee/kma-auto-genai-3-1/tree/main/.claude/skills/auto-ax-infographic 에도 공개되어 있습니다. 이 ZIP은 별도 참고 이미지 11장과 갤러리 안내까지 포함해 오프라인에서도 사용할 수 있도록 구성한 버전입니다.

금융교육용 `finance-infographic`과 독립적으로 설치되며 서로 파일을 덮어쓰지 않습니다.
