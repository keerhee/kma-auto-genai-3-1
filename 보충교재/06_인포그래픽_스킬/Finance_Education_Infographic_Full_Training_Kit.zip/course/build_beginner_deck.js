const pptxgen = require('pptxgenjs');
const path = require('path');
const pptx = new pptxgen();
pptx.layout='LAYOUT_WIDE';
pptx.author='Finance & Education Infographic';
pptx.subject='초보자용 11가지 인포그래픽 스타일과 AI 프롬프트 실습';
pptx.title='AI 인포그래픽 첫걸음: 11가지 스타일을 직접 써보기';
pptx.lang='ko-KR';
pptx.company='Finance and Education';
pptx.theme={headFontFace:'Noto Sans CJK KR',bodyFontFace:'Noto Sans CJK KR',lang:'ko-KR'};
const S=pptx.ShapeType;
const W=13.333,H=7.5;
const C={navy:'172B47', ink:'172B47', teal:'008B93', blue:'1969A6', orange:'E57E3B', violet:'7356B8', coral:'C75662', grass:'358667', bg:'F6F8FB', white:'FFFFFF', muted:'586982', line:'DFE6EE', pastel:'E7F5F4', pale:'E9EFF7', warm:'FFF1E5', lavender:'F0ECF9', faint:'F9FBFE'};
const font='Noto Sans CJK KR';
const srcDir='/mnt/data/finance_infographic_kit/assets';
const result='/mnt/data/AI_Infographic_11Styles_Beginner_Workshop.pptx';
let index=0;
function R(s,x,y,w,h,color,r=0.18,line=null){s.addShape(r?S.roundRect:S.rect,{x,y,w,h,rectRadius:r,fill:{color},line:{color:line||color,width:line?1:0}})}
function line(s,x1,y1,x2,y2,color=C.line,width=1.2,dash='solid'){s.addShape(S.line,{x:x1,y:y1,w:x2-x1,h:y2-y1,line:{color,width,dashType:dash}})}
function txt(s,t,x,y,w,h,sz=20,color=C.ink,bold=false,opts={}){s.addText(t,{x,y,w,h,margin:0,fontFace:font,fontSize:sz,color,bold,breakLine:false,valign:'mid',align:'left',...opts})}
function pill(s,text,x,y,w,color=C.teal,fg=C.white,sz=13){R(s,x,y,w,.37,color,.12);txt(s,text,x+.11,y+.02,w-.22,.32,sz,fg,true,{align:'center'})}
function header(s,unit,title,subtitle=''){
  s.background={color:C.bg};
  R(s,0,0,W,.12,C.teal,0);
  txt(s,unit.toUpperCase(),.62,.32,11,.26,11,C.teal,true,{charSpacing:2});
  txt(s,title,.62,.68,12.2,.56,27,C.ink,true);
  if(subtitle)txt(s,subtitle,.64,1.27,12,.35,15,C.muted);
  line(s,.64,6.96,12.68,6.96,C.line,1);
  txt(s,'AI INFOGRAPHIC WORKSHOP  ·  초보자 실습용',.64,7.04,9,.24,10,C.muted);
  txt(s,`${String(index).padStart(2,'0')}`,12.05,7.035,.63,.24,11,C.muted,true,{align:'right'});
}
function sl(unit,title,subtitle=''){let s=pptx.addSlide();index++;header(s,unit,title,subtitle);return s}
function notes(s,a){if(typeof s.addNotes==='function')s.addNotes(typeof a==='string'?a:a.join('\n'))}
function boxText(s,hd,body,x,y,w,h,col=C.white,accent=C.teal,hdSz=19,bodySz=17){R(s,x,y,w,h,col,.17);R(s,x,y,.06,h,accent,0);txt(s,hd,x+.2,y+.14,w-.4,.35,hdSz,C.ink,true);txt(s,body,x+.2,y+.57,w-.4,h-.69,bodySz,C.muted,false,{breakLine:false,valign:'top',lineSpacingMultiple:1.05});}
function bullet(s,text,x,y,w,sz=19,color=C.ink,accent=C.teal){R(s,x,y+.14,.105,.105,accent,.052);txt(s,text,x+.25,y,w-.24,.6,sz,color,false,{valign:'top',breakLine:false})}
function img(s,f,x,y,w,h){s.addImage({path:path.join(srcDir,f),x,y,w,h})}
function block(s,hd,body,x,y,w,h,color=C.pale){R(s,x,y,w,h,color,.15);txt(s,hd,x+.16,y+.11,w-.32,.4,18,C.ink,true);txt(s,body,x+.16,y+.56,w-.32,h-.64,16,C.muted,false,{valign:'top'});}
const styles=[
{n:'01',kr:'개념 설명형',en:'Teacher Explainer',file:'style-01-explainer.png',brand:C.grass,kind:'원본에서 확인',when:'“이게 무엇인가요?”를 설명할 때',what:'정의 → 직관 → 핵심 요소 → 예제',topic:'CAPM: 베타는 무엇일까?',prompt:'주제=CAPM · 대상=금융 초보 · 핵심요소=4개',check:'정의와 예제가 서로 일치하나요?'},
{n:'02',kr:'데이터 스토리형',en:'Data Story',file:'style-02-data-story.png',brand:C.orange,kind:'원본에서 확인',when:'숫자와 차트로 메시지를 전달할 때',what:'핵심 숫자 + 적절한 차트 + 출처',topic:'가상 자산배분 60/30/10',prompt:'데이터=주식60·채권30·대체10(가상)',check:'합계는 100%인가요? 단위는 있나요?'},
{n:'03',kr:'프로세스형',en:'Process / How-It-Works',file:'style-03-process.png',brand:C.violet,kind:'원본에서 확인',when:'“어떤 순서로 하나요?”를 알려줄 때',what:'시작 → 단계 → 결과 → 피드백',topic:'초보자용 백테스트 5단계',prompt:'단계=아이디어·데이터·구현·검증·보고',check:'빠진 단계와 되돌아갈 지점은?'},
{n:'04',kr:'비교 분석형',en:'Comparison / Trade-off',file:'style-04-comparison.png',brand:C.blue,kind:'독자 확장',when:'두 방법의 차이를 결정할 때',what:'공통 평가 기준으로 나란히 비교',topic:'적금과 ETF 비교',prompt:'대안=적금·ETF · 기준=위험·유동성·수익',check:'각 대안의 비교 기준이 같나요?'},
{n:'05',kr:'연대기형',en:'Timeline Journey',file:'style-05-timeline.png',brand:C.coral,kind:'원본에서 확인',when:'역사·발전·프로젝트 일정을 볼 때',what:'연도 + 사건 + 의미를 시간순으로',topic:'포트폴리오 이론 발전사',prompt:'연도=1952·1964·1976·1993·2015',check:'날짜와 사건을 정확히 확인했나요?'},
{n:'06',kr:'계층 구조형',en:'Hierarchy / Architecture',file:'style-06-architecture.png',brand:C.grass,kind:'독자 확장',when:'조직이나 시스템의 큰 구조를 볼 때',what:'상위 개념 → 하위 구성요소',topic:'자동차 산업 밸류체인',prompt:'계층=완성차·1차 협력사·2차 협력사',check:'포함 관계와 업무 흐름을 구별했나요?'},
{n:'07',kr:'지식그래프형',en:'Knowledge Graph / Ontology',file:'style-07-ontology.png',brand:C.orange,kind:'독자 확장',when:'기업·사물 사이 관계를 보여줄 때',what:'노드(대상) + 관계명 + 화살표',topic:'자동차 부품 공급망(가상 예시)',prompt:'노드=기업A·B·C · 관계=소재/부품 공급',check:'실제 거래 증거가 없으면 “가상” 표기'},
{n:'08',kr:'의사결정 트리형',en:'Decision Tree',file:'style-08-decision-tree.png',brand:C.blue,kind:'독자 확장',when:'조건에 따라 행동이 달라질 때',what:'질문 → 예/아니요 → 다음 행동',topic:'투자 리스크 대응 흐름',prompt:'조건=한도 초과 여부 · 행동=재검토/유지',check:'모든 갈림길에 결과가 있나요?'},
{n:'09',kr:'매트릭스형',en:'Matrix / Heatmap',file:'style-09-matrix.png',brand:C.violet,kind:'독자 확장',when:'두 가지 기준으로 분류할 때',what:'가로축 × 세로축 → 영역별 의미',topic:'위험 가능성 × 영향도',prompt:'가로=발생가능성 · 세로=영향도',check:'축 기준과 구간 정의가 명확한가요?'},
{n:'10',kr:'전후 비교형',en:'Before–After / Case Study',file:'style-10-before-after.png',brand:C.orange,kind:'독자 확장',when:'개선 전과 후의 변화를 보여줄 때',what:'Before → 바뀐 점 → After',topic:'수작업 보고서 vs 자동 보고서',prompt:'전=수기 2시간 · 후=자동화 예시(가정)',check:'비교 대상과 조건이 동일한가요?'},
{n:'11',kr:'연구 근거형',en:'Research Evidence / Uncertainty',file:'style-11-research-evidence.png',brand:C.grass,kind:'독자 확장',when:'연구 결과와 그 한계를 함께 볼 때',what:'주장 → 근거 → 한계 → 다음 검증',topic:'새 투자전략의 백테스트 결과',prompt:'주장=성과 개선 · 근거=표본외 검증 결과',check:'실증 결과와 추측을 구분했나요?'},
];
// 1 Cover
{
  let s=pptx.addSlide();index++;s.background={color:C.navy};
  R(s,.55,.54,1.45,.43,C.teal,.12);txt(s,'입문 실습',.66,.59,1.21,.32,15,C.white,true,{align:'center'});
  txt(s,'AI 인포그래픽\n첫걸음',.68,1.22,6.55,1.84,42,C.white,true,{breakLine:false});
  txt(s,'11가지 스타일을 보고, 선택하고, 직접 만들기',.72,3.18,6.2,.72,23,'D7E7F0');
  txt(s,'초보자용 · 90분 워크숍 · 실습 2회 · 바로 복사하는 프롬프트',.73,4.38,6.1,.62,17,'C1D1E0');
  R(s,7.60,1.13,5.03,5.15,C.white,.14);img(s,'11-styles-overview.png',7.8,1.35,4.61,4.23);
  txt(s,'금융·교육·연구 · 공통 활용',8.17,5.78,3.96,.45,16,C.navy,true,{align:'center'});
  txt(s,'11종 스타일 예시는 새로 제작한 참고 자료입니다.',.74,6.78,11,.3,12,'A7BBCB');
  notes(s,'도입 2분: PPT 전체 수업 목표를 소개합니다. 참가자가 AI 도구 사용 경험이 없어도 괜찮음을 알립니다.');
}
// 2 Goals
{
  let s=sl('START · 5분','오늘 수업에서 할 수 있게 되는 것','디자인 전공·코딩 경험은 필요하지 않습니다.');
  const arr=[['① 고르기','11가지 스타일 중 상황에 맞는 유형을 선택'],['② 요청하기','AI에게 목적·독자·내용·형식을 명확하게 전달'],['③ 검증하기','숫자·수식·출처·오탈자를 확인'],['④ 활용하기','PPT와 Obsidian에 이미지 삽입']];
  arr.forEach((a,i)=>boxText(s,a[0],a[1],.75+(i%2)*6.15,2.04+Math.floor(i/2)*1.95,5.72,1.62,i%2?C.white:'EBF6F5',i%2?C.blue:C.teal,22,19));
  notes(s,'간단한 손들기 질문: 이미 생성형 AI에 사진이나 그림을 요청해본 적 있는지 확인합니다.');
}
// 3 class map
{
  let s=sl('START · 진행 순서','90분 수업 안내','개념 15분 → 유형 보기 25분 → 실습 40분 → 발표·검수 10분');
  const rows=[['01','기본 개념','인포그래픽과 좋은 프롬프트 이해','15분'],['02','11종 스타일 보기','“언제 무엇을 쓰나요?” 구분','25분'],['03','따라 하기 실습','주제 선택 → 프롬프트 → 결과 검수','25분'],['04','직접 만들기','내 주제로 제작하고 개선하기','15분'],['05','서로 피드백','잘된 점과 수정할 점 확인','10분']];
  rows.forEach((r,i)=>{let y=1.9+i*.94;R(s,.85,y,11.65,.75,i%2?C.white:'E9F2F5',.15);pill(s,r[0],1.0,y+.2,.6,i%2?C.blue:C.teal);txt(s,r[1],1.82,y+.17,2.15,.37,20,C.ink,true);txt(s,r[2],4.05,y+.18,6.5,.35,18,C.muted);txt(s,r[3],11.46,y+.17,.7,.35,16,C.teal,true,{align:'right'});});
  notes(s,'강의 시간에 맞춰 조정할 수 있습니다. 예제는 중간중간 실습으로 연결합니다.');
}
// 4 intro
{
  let s=sl('FOUNDATION','인포그래픽은 “예쁜 그림”만이 아닙니다','정보를 이해하기 쉽도록 재구성한 시각적 설명입니다.');
  block(s,'일반 문장','“주식과 채권은\n수익률과 위험이 다릅니다.”',.81,2.05,5.35,2.1,C.pale);
  txt(s,'→',6.32,2.67,.7,.72,46,C.teal,true,{align:'center'});
  block(s,'인포그래픽','비교표 + 숫자 + 아이콘으로\n차이를 한눈에 설명',7.17,2.05,5.32,2.1,C.pastel);
  R(s,.95,4.8,11.48,1.26,C.white,.19);txt(s,'핵심 원칙',1.21,5.08,1.6,.36,19,C.teal,true);txt(s,'많은 정보를 넣는 것보다 “독자가 무엇을 이해해야 하는가”가 중요합니다.',2.95,5.07,8.95,.4,20,C.ink,true);
  notes(s,'수강생에게 “설명해야 하는 주제”를 한 가지 생각하도록 합니다. 개념, 수치, 절차 중 무엇인지 묻습니다.');
}
// 5 gallery overview
{
  let s=sl('STYLE GUIDE','11가지 스타일, 먼저 전체를 살펴봅시다','네 가지는 원본 화면에서 확인 · 일곱 가지는 교육·연구용 독자 확장');
  img(s,'11-styles-overview.png',.75,1.67,6.3,4.98);
  const groups=[['설명하기','① 개념  ③ 절차  ⑤ 연대기',C.teal],['비교·판단','② 수치  ④ 비교  ⑧ 의사결정  ⑨ 매트릭스',C.blue],['구조·연결','⑥ 구조  ⑦ 관계',C.violet],['결과·검증','⑩ 전후 변화  ⑪ 연구 근거',C.orange]];
  groups.forEach((g,i)=>{const y=1.9+i*1.16;R(s,7.43,y,5.08,.95,C.white,.17);R(s,7.43,y,.08,.95,g[2],0);txt(s,g[0],7.68,y+.11,4.6,.32,20,C.ink,true);txt(s,g[1],7.68,y+.51,4.58,.32,15,C.muted);});
  notes(s,'전체 11종을 모두 외울 필요는 없습니다. “목적→유형” 기준으로 선택하는 것이 핵심입니다.');
}
// 6 selection guide
{
  let s=sl('STYLE GUIDE','어떤 스타일을 고를까요?','주제명보다 “전달하려는 질문”이 중요합니다.');
  const qs=[['무엇인가요?','① 개념 설명'],['숫자가 무엇을 말하나요?','② 데이터 스토리'],['어떤 순서로 하나요?','③ 프로세스'],['어떤 점이 다르죠?','④ 비교 분석'],['언제 무슨 일이 있었죠?','⑤ 연대기'],['무엇이 무엇과 연결되죠?','⑦ 지식그래프'],['상황에 따라 어떻게 하죠?','⑧ 결정 트리'],['결과를 믿어도 될까요?','⑪ 연구 근거']];
  qs.forEach((r,i)=>{const col=i%2,rr=Math.floor(i/2);let x=.82+col*6.15,y=1.87+rr*1.16;R(s,x,y,5.73,.93,col?C.white:'EBF5F5',.16);txt(s,r[0],x+.18,y+.11,3.75,.34,18,C.ink,true);pill(s,r[1],x+3.83,y+.29,1.72,col?C.blue:C.teal,C.white,13);});
  notes(s,'수강생 2~3명에게 본인의 주제로 바로 유형을 선택해보라고 합니다. 답은 하나가 아닐 수 있습니다.');
}
// 7 prompt ingredients
{
  let s=sl('PROMPT BASICS','잘되는 프롬프트의 6가지 재료','괄호 [ ] 안의 값을 내 수업·보고서 내용으로 바꿉니다.');
  const a=[['1','주제','무엇을 설명?','예: CAPM'],['2','독자','누가 읽나요?','예: 금융 초보'],['3','목적','무엇을 이해?','예: 베타 개념'],['4','구조','몇 단계/요소?','예: 4개 카드'],['5','스타일','어떤 모습?','예: 개념형, 파스텔'],['6','검증','무엇을 확인?','예: 수식·출처']];
  a.forEach((v,i)=>{let x=.78+(i%3)*4.26,y=1.88+Math.floor(i/3)*2.18;R(s,x,y,3.96,1.92,C.white,.17);pill(s,v[0],x+.14,y+.18,.46,i<3?C.teal:C.blue,C.white,14);txt(s,v[1],x+.76,y+.22,2.9,.38,22,C.ink,true);txt(s,v[2],x+.22,y+.82,3.45,.36,17,C.muted);txt(s,v[3],x+.22,y+1.25,3.47,.38,18,C.blue,true);});
  notes(s,'프롬프트는 마법의 문장이 아닙니다. 빈칸을 정확한 내용으로 채우는 것이 품질을 결정합니다.');
}
// 11 style slides
styles.forEach((st,i)=>{
 const s=sl('STYLE '+st.n,`${st.n}. ${st.kr}`,st.en+ '  ·  '+st.kind);
 R(s,.72,1.72,5.07,4.80,C.white,.17);pill(s,st.kind,1,1.95,st.kind==='원본에서 확인'?1.54:1.23,st.brand,C.white,12);
 txt(s,'언제 사용하나요?',1,2.54,4.55,.37,19,st.brand,true);
 txt(s,st.when,1,2.99,4.53,.7,19,C.ink,true,{breakLine:false,valign:'top'});
 line(s,1,3.8,5.53,3.8,C.line,1);
 txt(s,'그림의 핵심 구성',1,4.02,4.6,.32,17,C.muted,true);
 txt(s,st.what,1,4.4,4.55,.65,18,C.ink,false,{valign:'top'});
 R(s,.96,5.28,4.54,.86,'EDF6F6',.13);txt(s,'예시  '+st.topic,1.15,5.48,4.14,.5,17,C.teal,true);
 R(s,6.07,1.72,6.54,4.28,C.white,.13);img(s,st.file,6.16,1.85,6.35,4.12);
 txt(s,'프롬프트 입력값: '+st.prompt,6.19,6.13,6.27,.3,14,C.ink,true);
 txt(s,'검수 포인트: '+st.check,6.19,6.51,6.25,.25,13,C.muted);
 notes(s,`이 슬라이드는 ${st.kr}의 참고 이미지입니다. ${st.when}. 주제 예시: ${st.topic}. 먼저 이미지를 20초 관찰한 뒤 학생에게 적합한 이유를 설명해 보라고 합니다. 검수 질문: ${st.check}. 사진의 수치·관계는 실제 자료가 아닌 예시일 수 있으므로 사용 전 확인해야 합니다.`);
});
// 19 practice quiz 1
{
 let s=sl('CHECKPOINT','1분 퀴즈: 어떤 유형이 좋을까요?','오른쪽의 답을 보기 전, 스스로 4문제를 풀어봅니다.');
 const a=[['A','“고객이 대출을 받는 5단계”를 설명'],['B','“작년과 올해 매출”을 비교'],['C','“금융이론의 70년 발전 과정”을 소개'],['D','“두 기업의 공급 관계”를 시각화']];
 a.forEach((v,i)=>{let y=1.83+i*1.14;R(s,.94,y,11.46,.91,i%2?C.white:'EAF3F4',.16);pill(s,v[0],1.19,y+.26,.52,i%2?C.blue:C.teal);txt(s,v[1],2.05,y+.22,9.98,.43,21,C.ink,true);});
 notes(s,'학생들이 A=3, B=4 또는 2, C=5, D=7을 답할 수 있도록 유도합니다. B는 숫자 비교의 목적에 따라 #2 또는 #4 모두 가능합니다.');
}
// 20 answers
{
 let s=sl('CHECKPOINT','정답과 선택 이유','같은 주제라도 설명 목적에 따라 여러 유형을 조합할 수 있습니다.');
 const a=[['A','③ 프로세스형','단계의 순서를 알려주기 때문'],['B','④ 비교형 또는 ② 데이터형','두 시점의 차이 혹은 수치 메시지를 강조'],['C','⑤ 연대기형','연도별 중요한 사건을 이어 보여주기 때문'],['D','⑦ 지식그래프형','기업 사이의 관계 종류와 방향이 중요']];
 a.forEach((v,i)=>{let y=1.82+i*1.15;R(s,.94,y,11.49,.94,C.white,.13);pill(s,v[0],1.17,y+.29,.52,C.teal);txt(s,v[1],2.04,y+.18,4.03,.46,19,C.ink,true);txt(s,v[2],6.03,y+.19,5.94,.45,17,C.muted);});
 notes(s,'둘 이상의 정답이 가능할 수 있다는 점을 강조합니다. 무엇을 전달하는지 먼저 정하는 것이 핵심입니다.');
}
// 21 walkthrough
{
 let s=sl('LIVE DEMO · 10분','AI에게 어떻게 요청할까요?','실습 주제: “CAPM의 베타를 금융 초보에게 설명”');
 const st=[['1','도구 열기','ChatGPT 또는 Claude의 새 대화'],['2','요청 입력','주제·독자·형식·내용·검증 규칙을 적기'],['3','결과 확인','구조가 맞는지 먼저 확인하기'],['4','수정 요청','어려운 용어와 오류를 고쳐달라고 하기'],['5','저장·삽입','PNG/PPT에 넣고 별도 보관하기']];
 st.forEach((v,i)=>{let y=1.81+i*.95;R(s,.86,y,11.57,.78,i%2?C.white:'E7F5F4',.15);pill(s,v[0],1.04,y+.20,.48,C.teal);txt(s,v[1],1.73,y+.15,2.5,.45,21,C.ink,true);txt(s,v[2],4.35,y+.18,7.76,.37,18,C.muted);});
 notes(s,'AI 도구의 버튼 이름은 버전에 따라 다를 수 있습니다. 반드시 “무엇을 입력·어디서 확인” 위주로 지도하세요. 이미지 출력 기능은 도구·플랜에 따라 다릅니다.');
}
// 22 prompt template
{
 let s=sl('LIVE DEMO','복사해서 사용하는 기본 프롬프트','[대괄호] 부분만 바꾸면 됩니다.');
 R(s,.84,1.78,11.64,4.51,'172B47',.19);
 const lines=[
 '초보자를 위한 교육용 인포그래픽을 설계해주세요.',
 '주제: [CAPM의 베타]   대상: [금융 초보]',
 '독자가 이해할 핵심: [베타의 의미와 직관]',
 '유형: [① 개념 설명형]  섹션: [4개]',
 '구성: 제목 → 쉬운 정의 → 핵심 개념 → 가상 예제 → 주의점',
 '디자인: 흰 배경 · 네이비/민트 · 큰 글씨 · 간단한 아이콘',
 '먼저 내용과 수식을 텍스트로 보여주고, 검수 후 이미지화하세요.',
 '확인되지 않은 수치·출처는 만들어내지 마세요.'
 ];
 lines.forEach((x,i)=>txt(s,x,1.20,2.08+i*.49,11,.44,i===0?23:18,i===0?'A8F0E6':'F1F5FA',i===0));
 txt(s,'TIP  이미지 제작 전에 “내용만 먼저 검토해줘”라고 요청하면 오류를 줄일 수 있습니다.',1.0,6.44,11.2,.33,17,C.teal,true);
 notes(s,'이 프롬프트는 그대로 복사한 뒤 문구를 바꿔 다른 주제에도 적용할 수 있습니다. 도구가 이미지 생성 지원시 다음 턴에 이미지를 생성하도록 요청합니다.');
}
// 23 step example
{
 let s=sl('LIVE DEMO','좋은 결과를 얻는 두 번의 요청','1차는 정확한 내용, 2차는 보기 좋은 이미지에 집중합니다.');
 block(s,'1차 요청: 설계','“제목·4개 항목·예시·수식을\n먼저 텍스트로 정리해줘.”',.80,1.96,5.52,2.16,C.pale);
 block(s,'2차 요청: 시각화','“방금 확인한 내용 그대로,\n16:9 인포그래픽으로 만들어줘.”',6.91,1.96,5.52,2.16,C.pastel);
 line(s,6.41,2.72,6.74,2.72,C.teal,4);
 R(s,.85,4.72,11.56,1.22,C.white,.15);txt(s,'수정 예시',1.14,4.98,1.73,.43,20,C.blue,true);
 txt(s,'“글자가 너무 작아요. 항목을 4개로 줄이고 중요한 단어만 굵게 해주세요.”',2.93,4.97,9.1,.49,19,C.ink);
 notes(s,'AI 생성 이미지의 글자는 잘못 생성될 수 있어 반드시 읽어야 합니다. 수치·수식은 편집가능한 텍스트/도표로 최종 삽입하는 방식을 소개합니다.');
}
// 24 verification
{
 let s=sl('QUALITY CHECK','생성된 그림은 반드시 검수합니다','특히 수치·수식·출처·기업 간 관계는 그림만 보고 믿지 않습니다.');
 const arr=[['숫자','합계·단위·기간·분모가 맞는가?'],['개념','핵심 정의와 예시가 정확한가?'],['수식','기호·지수·부호가 변하지 않았는가?'],['출처','실제로 존재하는 자료인가?'],['글자','한글 오탈자와 잘림이 없는가?'],['가독성','글씨·색 대비·여백이 적절한가?']];
 arr.forEach((r,i)=>{let x=.80+i%2*6.13,y=1.8+Math.floor(i/2)*1.61;R(s,x,y,5.73,1.32,C.white,.15);R(s,x+.18,y+.31,.35,.35,'CDEFE8',.12);txt(s,'✓',x+.215,y+.305,.28,.34,17,C.teal,true,{align:'center'});txt(s,r[0],x+.72,y+.2,4.64,.35,20,C.ink,true);txt(s,r[1],x+.72,y+.67,4.56,.42,16,C.muted);});
 notes(s,'특히 이미지 생성 모델은 수식을 잘못 그릴 수 있고, 예제 통계에 없는 수치를 생성할 수 있습니다. 데이터로 재현 가능한 차트를 따로 제작하는 방법이 안전합니다.');
}
// 25 practical first
{
 let s=sl('PRACTICE A · 15분','실습 ① 함께 만들기','일반 교육 주제와 금융 주제 중 하나만 선택하세요.');
 block(s,'선택 A · 생활 주제','재활용 분리배출 4단계\n→ ③ 프로세스형',.79,1.88,5.57,2.18,C.pastel);
 block(s,'선택 B · 금융 주제','베타(β)는 무엇인가?\n→ ① 개념 설명형',6.98,1.88,5.56,2.18,C.pale);
 R(s,.85,4.49,11.63,1.5,C.white,.15);
 txt(s,'수강생 미션',1.12,4.72,2.4,.43,21,C.teal,true);
 txt(s,'① 주제·독자 설정     ② 내용 4개 작성     ③ AI 결과 생성     ④ 오류 1개 점검',1.13,5.24,10.74,.4,19,C.ink);
 notes(s,'실습을 도와줄 때는 도구 UI보다는 “어떤 입력을 넣을지”를 점검하세요. 교실 수준에 맞춰 인포그래픽 이미지를 직접 생성하거나 청사진만 산출해도 됩니다.');
}
// 26 Obsidian
{
 let s=sl('SAVE & REUSE','Obsidian Markdown에도 이미지를 넣을 수 있나요?','네. 이미지 파일을 노트와 함께 보관하고 임베드 문법으로 삽입합니다.');
 R(s,.80,1.87,5.48,3.83,'172B47',.17);
 txt(s,'폴더 구조',1.11,2.15,4.69,.37,21,'A8F0E6',true);
 ['My-Vault/','  ├─ Infographic-Guide.md','  └─ assets/','       └─ style-01-explainer.png'].forEach((r,i)=>txt(s,r,1.18,2.74+i*.52,4.65,.4,18,C.white,false,{fontFace:'Noto Sans Mono CJK KR'}));
 R(s,6.65,1.87,5.85,3.83,C.white,.17);
 txt(s,'Markdown 노트 안에 입력',7.01,2.2,5.1,.41,20,C.ink,true);
 R(s,6.95,2.78,5.2,1.05,'EFF5FA',.12);
 txt(s,'![[assets/style-01-explainer.png|800]]',7.15,3.09,4.85,.45,16,C.blue,true,{fontFace:'Noto Sans Mono CJK KR'});
 txt(s,'또는 일반 Markdown 문법',7.01,4.27,5.1,.37,18,C.ink,true);
 txt(s,'![설명](assets/style-01-explainer.png)',7.02,4.74,5.26,.37,16,C.muted);
 txt(s,'※ 이 이미지는 제공한 ZIP 속 assets 폴더에 들어 있습니다.',.88,6.34,11.6,.33,15,C.teal,true);
 notes(s,'Obsidian에서는 파일 이름 경로가 Vault 구조와 맞는지 확인하세요. 임베드 이미지가 보이지 않으면 파일이 그 경로에 있는지 먼저 확인합니다.');
}
// 27 Skills intro
{
 let s=sl('NEXT STEP','Claude Code 스킬은 무엇인가요?','같은 작업 규칙을 반복해서 사용하는 “재사용 가능한 작업 설명서”입니다.');
 const arr=[['한 번 설치','ZIP의 finance-infographic 폴더를\n사용자 skills 폴더에 복사'],['자연어 요청','“이 주제를 개념형으로 정리해줘”\n같이 요청'],['품질 검수','11개 유형 선택 및\n검증 규칙 참조']];
 arr.forEach((r,i)=>block(s,r[0],r[1],.84+i*4.22,2.02,3.9,2.27,i===1?C.pale:C.white));
 R(s,.87,4.81,11.5,1.04,C.white,.14);txt(s,'설치 위치 예: ~/.claude/skills/finance-infographic/',1.18,5.1,11.1,.46,20,C.blue,true);
 txt(s,'입문자는 먼저 ChatGPT/Claude 채팅만으로 연습해도 충분합니다.',.9,6.25,11.4,.36,18,C.teal,true);
 notes(s,'Claude Code CLI와 일반 Claude 채팅의 차이를 간단히 알려줍니다. 실제 설치는 환경에 따라 관리자 권한 또는 폴더 접근이 필요할 수 있습니다.');
}
// 28 practice B
{
 let s=sl('PRACTICE B · 15분','실습 ② 나만의 인포그래픽 만들기','주제를 하나 선정하고 프롬프트 빈칸을 직접 채워보세요.');
 const rows=[['1','주제 정하기','예: 부채비율, AI 검색, 나의 업무 절차'],['2','독자 정하기','예: 고등학생, 동료, 투자위원회'],['3','유형 고르기','11가지 중 하나 선택'],['4','핵심 내용 3~5개','사실과 가상 예시를 구분'],['5','생성 후 수정하기','오류·글씨·출처를 한 번 더 확인']];
 rows.forEach((r,i)=>{let y=1.83+i*.95;R(s,.84,y,11.61,.77,i%2?C.white:'E9F3F3',.15);pill(s,r[0],1.04,y+.19,.49,C.teal);txt(s,r[1],1.79,y+.17,2.85,.43,20,C.ink,true);txt(s,r[2],4.67,y+.19,7.42,.4,18,C.muted);});
 notes(s,'숙제 후보: CAPM, Box–Jenkins, 자동차 공급망, Private Credit 위험, 자산배분 비중. 수강생 수준에 따라 일반 주제도 허용합니다.');
}
// 29 feedback
{
 let s=sl('SHOW & REVIEW','서로의 작품을 평가하는 5가지 질문','학생 2명이 짝을 지어 2분씩 피드백해 보세요.');
 const checks=[['주제','제목만 봐도 무엇을 설명하는지 알 수 있나요?'],['구조','선택한 스타일이 질문에 맞나요?'],['정확성','숫자·연도·수식·관계를 확인했나요?'],['가독성','글씨와 색상이 읽기 쉬운가요?'],['개선','한 가지만 고친다면 무엇인가요?']];
 checks.forEach((r,i)=>{let y=1.85+i*.96;R(s,.9,y,11.45,.79,C.white,.14);R(s,1.12,y+.23,.31,.31,'DAF1EB',.08);txt(s,String(i+1),1.17,y+.245,.22,.23,13,C.teal,true,{align:'center'});txt(s,r[0],1.74,y+.18,1.64,.4,19,C.ink,true);txt(s,r[1],3.35,y+.16,8.49,.46,18,C.muted);});
 notes(s,'모든 항목을 강박적으로 검사하기보다, 다음 수정 단계로 연결되는 구체적 피드백 1개를 요청합니다.');
}
// 30 mistakes
{
 let s=sl('TROUBLESHOOT','초보자가 자주 하는 실수 TOP 4','문제가 생기면 프롬프트와 데이터부터 다시 확인하세요.');
 const arr=[['실수 1','“멋지게 만들어줘”만 요청','누구에게·무엇을·몇 개로 설명할지 지정'],['실수 2','한 장에 글자를 너무 많이 넣기','핵심 내용 3~5개로 줄이고 2장으로 분할'],['실수 3','AI가 쓴 숫자와 출처를 그대로 믿기','원자료 대조, 임의 생성 금지 요청'],['실수 4','그림 파일만 받고 내용 저장 안 하기','원본 데이터·MD·편집 파일 함께 보관']];
 arr.forEach((r,i)=>{let y=1.82+i*1.18;R(s,.78,y,11.75,1.02,C.white,.16);pill(s,r[0],1.0,y+.31,1.05,i%2?C.orange:C.coral);txt(s,r[1],2.28,y+.13,4.35,.77,18,C.ink,true,{valign:'mid'});line(s,6.69,y+.2,6.69,y+.82,C.line,1.5);txt(s,r[2],6.9,y+.13,5.25,.79,17,C.teal,true,{valign:'mid'});});
 notes(s,'AI 출력은 초안이며 검증된 사실 자체가 아닙니다. 비주얼이 화려해도 수치 오류가 있으면 폐기해야 합니다.');
}
// 31 conclusion
{
 let s=pptx.addSlide();index++;s.background={color:C.navy};
 R(s,.72,.64,2.05,.43,C.teal,.10);txt(s,'오늘의 핵심',.93,.70,1.64,.28,15,C.white,true,{align:'center'});
 txt(s,'스타일은 목적에 맞게,\n내용은 반드시 검증!',.79,1.43,11.5,1.53,37,C.white,true);
 const a=['① 질문에 맞는 11가지 유형 중 하나 선택','② 주제·독자·구조·데이터를 프롬프트에 명시','③ 텍스트 설계 → 이미지 생성 → 검수 → 저장'];
 a.forEach((v,i)=>{R(s,.89,3.39+i*.84,11.39,.65,i%2?'233D5C':'1B4053',.12);txt(s,v,1.2,3.51+i*.84,10.89,.4,20,'F5FAFF',true);});
 txt(s,'다음 단계: 내가 만든 인포그래픽 1장을 Obsidian 또는 PPT에 넣어 보기',.87,6.35,11.73,.45,18,'C0DFE3');
 notes(s,'종료 3분: 강의 중 만들었던 작품의 원본 자료와 이미지 모두 저장하도록 안내합니다. 수강생에게 30초 발표 기회를 제공합니다.');
}
// 32 extra resources
{
 let s=sl('TAKE HOME','함께 제공되는 실습 자료','PPT + 11개 스타일 이미지 + Obsidian MD + Claude Code 스킬');
 const a=[['PPT 파일','이 강의자료 · 이미지와 텍스트 편집 가능'],['종합 Markdown','11개 유형의 자세한 프롬프트와 금융 예제'],['스타일 이미지','PNG 및 SVG · 각 유형을 참고하는 갤러리'],['Obsidian Vault','11개 참고 이미지가 내장된 노트'],['Claude Code Skill','SKILL.md · 유형 선택기 · 검증 지침']];
 a.forEach((r,i)=>{let y=1.79+i*.93;R(s,.88,y,11.54,.74,C.white,.14);txt(s,r[0],1.12,y+.15,2.75,.41,20,C.ink,true);txt(s,r[1],4.0,y+.17,8.1,.4,17,C.muted);});
 txt(s,'※ 11개 스타일 이미지는 교육용 재구성 예시이며, 원본 포스터의 복제본이 아닙니다.',.99,6.55,11.65,.30,14,C.teal,true);
 notes(s,'패키지의 README를 열어 각 파일을 확인하도록 안내하세요. 4개 유형은 원본 스크린샷에서 확인되었고 나머지는 독자 확장입니다.');
}

pptx.writeFile({fileName:result}).then(()=>console.log('SAVED',result,'SLIDES',index)).catch(err=>{console.error(err);process.exit(1)});
