from pathlib import Path
import re, shutil, zipfile
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'
VAULT=ROOT/'Obsidian-Vault'/'Finance-Infographic'
VAULT_ASSETS=VAULT/'assets'
SKILL=ROOT/'finance-infographic'
SKILL_IMAGES=SKILL/'assets'/'style-reference'
VAULT_ASSETS.mkdir(parents=True,exist_ok=True)
SKILL_IMAGES.mkdir(parents=True,exist_ok=True)
STEMS=['style-01-explainer','style-02-data-story','style-03-process','style-04-comparison','style-05-timeline','style-06-architecture','style-07-ontology','style-08-decision-tree','style-09-matrix','style-10-before-after','style-11-research-evidence']
KO=['개념 설명형','데이터 스토리형','프로세스형','비교 분석형','연대기형','계층/아키텍처형','지식그래프/온톨로지형','의사결정 트리형','위험 매트릭스형','개선 사례형','연구 근거형']
for p in [ASSETS/'11-styles-overview.png']+[ASSETS/(s+'.png') for s in STEMS]+[ASSETS/(s+'.svg') for s in STEMS]:
 shutil.copy2(p,VAULT_ASSETS/p.name)
 if p.name.startswith('style-'):
  shutil.copy2(p,SKILL_IMAGES/p.name)

source=ROOT/'Finance_Education_Infographic_Master_Guide.md'
md=source.read_text(encoding='utf-8')
md=md.replace('version: "1.0"','version: "1.1 — 11종 참고 이미지 포함"')
md=md.replace('참고 이미지는 사용자가 직접 제공한 캡처다.','원본 캡처는 사용자가 제공했으며, 아래의 11개 스타일 참고 이미지는 이번 자료를 위해 **새로 제작한 교육용 예시**로서 원저자의 포스터를 복제한 것이 아니다.')
md=md.replace('## 1. 원본에서 확인된 디자인 원칙', '''## 시각화 스타일 한눈에 보기 — 11종 이미지 갤러리

![11가지 인포그래픽 유형 개요](assets/11-styles-overview.png)

> **참고 이미지 주의**: 아래 이미지는 디자인 구조를 이해하기 위한 독자 제작 예시이며, 표시된 배분비중·위험 구분·기업 A/B/C 등은 실제 사실이나 투자 조언이 아니다. #1·#2·#3·#5는 제공 스크린샷에서 확인된 디자인 **유형**을 재구성했고 나머지는 독자적으로 확장했다. SVG 원본도 함께 제공한다.

## 1. 원본에서 확인된 디자인 원칙''')
for i,stem in enumerate(STEMS,1):
 pattern=r'(?m)^(### '+f'{i:02d}'+r'\. [^\n]*\n)'
 replacement=lambda m,st=stem,j=i:m.group(1)+f'\n![{j:02d}. {KO[j-1]} 참고 스타일](assets/{st}.png)\n\n*스타일 예시 · 독자 제작 · 편집 가능한 SVG: `assets/{st}.svg`*\n'
 md,count=re.subn(pattern,replacement,md,count=1)
 if count!=1: raise RuntimeError(f'Missing header {i}')
source.write_text(md,encoding='utf-8')

obs=md.replace('![11가지 인포그래픽 유형 개요](assets/11-styles-overview.png)','![[11-styles-overview.png|1000]]')
for stem in STEMS:
 obs=re.sub(r'!\[([^\]]+)\]\(assets/'+stem+r'\.png\)',f'![[{stem}.png|940]]',obs)
obs=obs.replace('version: "1.1 — 11종 참고 이미지 포함"','version: "1.1-obsidian"\ntags: [infographic, finance, education, claude-code]')
obs=obs.replace('# Finance & Education Infographic Master Guide','# Finance & Education Infographic Master Guide — Obsidian Edition')
obs += '''\n\n## Obsidian 이미지 관리 팁\n\n- 이 `Finance-Infographic` 폴더를 Obsidian Vault 안에 **통째로 복사**합니다. 이미지가 화면에 나오려면 `assets/` 폴더도 같은 위치에 있어야 합니다.\n- `![[style-01-explainer.png|940]]`는 넓이 940px의 **위키링크 임베드**입니다. 이미지 이름이 Vault 내에서 중복되면 `![[Finance-Infographic/assets/style-01-explainer.png|940]]`처럼 경로를 명시합니다.\n- Obsidian에 위키링크가 아닌 표준 Markdown을 쓰려면 `![01 스타일](assets/style-01-explainer.png)` 형식도 가능합니다.\n- SVG는 편집 가능한 원본 그림이며 PNG는 공유·미리보기용입니다.\n- 웹에 옮길 때는 이미지 경로가 상대경로로 유지되는지 확인합니다.\n'''
(VAULT/'Infographic-Master-Guide.md').write_text(obs,encoding='utf-8')

# modify docx with 11 reference images near matching headings and contact sheet in the intro.
docfile=ROOT/'Finance_Education_Infographic_Master_Guide.docx'
d=Document(docfile)

def insert_after(parent,text=None,image=None,width=Inches(6.4),caption=False):
 newp=OxmlElement('w:p');parent._p.addnext(newp)
 p=Paragraph(newp,parent._parent)
 if image:
  p.alignment=WD_ALIGN_PARAGRAPH.CENTER
  p.paragraph_format.space_after=Pt(4)
  p.add_run().add_picture(str(image),width=width)
 if text:
  r=p.add_run(text);r.font.size=Pt(8.5 if caption else 10);r.font.color.rgb=None
  if caption:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 return p

for par in list(d.paragraphs):
 m=re.match(r'^(\d\d)\. (Teacher Explainer|Data Story|Process / How-It-Works|Comparison / Trade-off|Timeline Journey|Hierarchy / Architecture|Knowledge Graph / Ontology|Decision Tree / Logic|Matrix / Heatmap|Before–After / Case Study|Research Evidence / Uncertainty)',par.text)
 if m:
  num=int(m.group(1));par.paragraph_format.keep_with_next=True
  im=insert_after(par,image=ASSETS/(STEMS[num-1]+'.png'),width=Inches(6.55))
  insert_after(im,f'그림 {num:02d}  |  {KO[num-1]} · 새로 제작한 참고 스타일 · 예시값/가상 관계 포함',caption=True)

# Appended intro gallery after main title to orient user.
for par in d.paragraphs:
 if par.text.strip()=='Finance & Education Infographic Master Guide':
  im=insert_after(par,image=ASSETS/'11-styles-overview.png',width=Inches(6.35))
  insert_after(im,'11가지 인포그래픽 스타일 썸네일 갤러리 (각 유형의 확대 그림은 본문 참조)',caption=True)
  break

d.core_properties.title='Finance & Education Infographic Master Guide — Illustrated v1.1'
d.core_properties.subject='11가지 스타일 이미지, 금융 강의 및 Claude Code 스킬'
d.save(docfile)

# skill gallery and docs
(SKILL/'references'/'style-gallery.md').write_text('''# 11-Type Style Image Reference Gallery

The images in `../assets/style-reference/` are **original illustrative mockups**, not reproductions of the social-media author's posters. All figures labeled examples are illustrative, not sourced financial data. Keep the gallery and actual data separate.

| No. | Design | Illustration filename | Meaning |
|---|---|---|---|
'''+''.join(f'| {i:02d} | {KO[i-1]} | `style-reference/{stem}.png` | '+('Screenshot-confirmed category, newly drawn example' if i in (1,2,3,5) else 'Independently extended category')+' |\n' for i,stem in enumerate(STEMS,1))+'''\n## How to apply

1. Look at the PNG for visual structure; open the SVG for an editable drawing scaffold.
2. Keep the information architecture, not the sample statistics or placeholder organizations.
3. Validate supplied facts before creating a new finance-related image.
4. Embed output in an Obsidian note using `![[your-image.png|940]]` with the file inside the same vault.
5. Prefer chart-from-data for numerical presentations; preserve exact chart units and source dates.
''',encoding='utf-8')
sp=SKILL/'SKILL.md'
sk=sp.read_text(encoding='utf-8')
sk=sk.replace('## Non-negotiable steps','''## Visual style references

For all 11 types, see [style gallery](references/style-gallery.md) with local **PNG + editable SVG** illustrations in `assets/style-reference/`. The infographic examples are original visual samples; preserve only their design grammar, never treat example data as external facts. For an Obsidian delivery, provide a standalone Markdown note and its local `assets/` attachments together; prefer `![[image.png|940]]` and verify paths resolve inside the vault.

## Non-negotiable steps''')
sp.write_text(sk,encoding='utf-8')
readme=SKILL/'README.md';s=readme.read_text(encoding='utf-8');s+='\n## 스타일 이미지 참고\n\n각 유형별 PNG·SVG 11쌍은 `assets/style-reference/`에 있습니다. 이미지/데이터는 **예시**입니다. Obsidian Vault용 배포본은 ZIP 내 `Obsidian-Vault/Finance-Infographic/`를 사용하세요.\n';readme.write_text(s,encoding='utf-8')
(ROOT/'START_HERE.md').write_text('''# Finance & Education Infographic Kit — Visual Edition v1.1

## 패키지 내용

- `Finance_Education_Infographic_Master_Guide.md`: **표준 Markdown**, 이미지 11종을 상대경로로 포함
- `Finance_Education_Infographic_Master_Guide.docx`: **Word / Google Docs 호환 문서**, 그림 11종 + 개요 이미지 직접 삽입
- `Obsidian-Vault/Finance-Infographic/Infographic-Master-Guide.md`: Obsidian 이미지 위키 임베드 버전
- `Obsidian-Vault/Finance-Infographic/assets/`: PNG 11종 + SVG 11종 + 갤러리 개요
- `finance-infographic/SKILL.md`: Claude Code 스킬
- `finance-infographic/assets/style-reference/`: 스킬에서 재사용할 이미지 11종 PNG/SVG
- `finance-infographic/references/`: 유형 가이드, 데이터·수식 검증 규칙, 스타일 이미지 설명
- `finance-infographic/scripts/build_prompt.py`: 유형별 제작 프롬프트 생성기
- `finance-infographic/scripts/test_build_prompt.py`: 테스트
- `finance-infographic/examples/`: 산업 온톨로지·연구 검증 예제

## Obsidian에 설치 (Windows/macOS 공통)

1. Obsidian에서 사용할 Vault 폴더를 엽니다.
2. ZIP의 `Obsidian-Vault/Finance-Infographic/` 폴더 전체를 Vault에 복사합니다.
3. `Finance-Infographic/Infographic-Master-Guide.md`를 엽니다.
4. Reading View 또는 Live Preview로 전환하면 이미지가 보입니다.
5. 이미지가 보이지 않으면 `assets` 폴더가 그대로 들어왔는지 확인하고 중복 파일 이름을 점검합니다.

## Claude Code 스킬 설치

ZIP의 `finance-infographic` 폴더 전체를 아래 경로로 복사합니다.

- macOS/Linux: `~/.claude/skills/finance-infographic/`
- Windows: `%USERPROFILE%\\.claude\\skills\\finance-infographic\\`

## 기능 검사

```bash
python finance-infographic/scripts/build_prompt.py --list
python -m unittest discover -s finance-infographic/scripts -p 'test_*.py'
```

## 출처 범위

원본 제공 SNS 캡처로 확인된 유형은 #1/#2/#3/#5이며, #4/#6~#11은 독자적 확장안입니다. **11개 참고 이미지는 모두 이 패키지를 위해 새로 제작한 이미지로, 원저자의 포스터 원본이 아닙니다.** 이미지에 등장하는 통계값과 가상 거래관계는 설명을 위한 예시이며 최신 사실 자료가 아닙니다.

## Google Docs

https://docs.google.com/document/d/1L1Mtj76oo2W-a0u8KJPh-UFO3zYrS8XjEa1dm4AGfh8/edit
''',encoding='utf-8')

# Pack avoid pycache & QA files; include docs, gallery, skill, Obsidian vault and reproducible authoring script.
ZIP=ROOT.parent/'Finance_Education_Infographic_Visual_Obsidian_Skill_Kit.zip'
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for path in ROOT.rglob('*'):
  if not path.is_file(): continue
  rel=path.relative_to(ROOT)
  if any(p in ('__pycache__','qa') for p in rel.parts):continue
  z.write(path,arcname=str(rel))
print('Generated',ZIP,ZIP.stat().st_size,'bytes; docx',docfile.stat().st_size, 'Obsidian', (VAULT/'Infographic-Master-Guide.md').stat().st_size)
