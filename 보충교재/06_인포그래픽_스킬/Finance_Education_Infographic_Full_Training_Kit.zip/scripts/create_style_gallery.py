"""Render 11 original illustrative, finance-aware reference infographic cards.
All depicted quantities are either historical theoretical dates or clearly marked demo data.
Run: python scripts/create_style_gallery.py
"""
from pathlib import Path
import math
import svgwrite
import cairosvg
from PIL import Image, ImageOps, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'assets'
OUT.mkdir(parents=True, exist_ok=True)
W,H=1200,780
NAVY='#172D4D'; INK='#20304C'; MUTED='#65738C'; WHITE='#FFFFFF'; BG='#F5F7FC'; LINE='#DCE4EE'
FONT='Noto Sans CJK KR, NanumSquare, sans-serif'

STYLES=[
 (1,'Teacher Explainer','개념 설명형','CAPM: 위험과 기대수익','#15966C','원본 캡처 기반'),
 (2,'Data Story','데이터 스토리형','가상 포트폴리오 자산배분','#ED7A2C','원본 캡처 기반'),
 (3,'Process / How-It-Works','프로세스형','Box–Jenkins 시계열 분석','#6558D9','원본 캡처 기반'),
 (4,'Comparison / Trade-off','비교 분석형','변수 중요도: MDI · MDA · SFI','#2479D4','독자 확장 예시'),
 (5,'Timeline Journey','연대기형','자산가격결정이론의 발전','#D74B78','원본 캡처 기반'),
 (6,'Hierarchy / Architecture','아키텍처형','NeoQuant 연구·운용 플랫폼','#238A76','독자 확장 예시'),
 (7,'Knowledge Graph / Ontology','지식그래프형','자동차 공급망 온톨로지 예시','#A06F3B','독자 확장 예시'),
 (8,'Decision Tree / Logic','의사결정형','전략 검증 의사결정 트리','#157FA4','독자 확장 예시'),
 (9,'Matrix / Heatmap','리스크 매트릭스형','Private Credit 위험 분류 예시','#8C64B7','독자 확장 예시'),
 (10,'Before–After / Case Study','개선 사례형','메타레이블링 도입 전후','#DC7356','독자 확장 예시'),
 (11,'Research Evidence / Uncertainty','연구 근거형','전략 주장과 증거 수준','#4C6798','독자 확장 예시'),
]

def svg(n, en, ko, topic, accent, origin):
 d=svgwrite.Drawing(size=(W,H),viewBox=f'0 0 {W} {H}')
 d.add(d.rect(insert=(0,0),size=(W,H),fill=BG))
 d.add(d.rect(insert=(0,0),size=(W,130),fill=NAVY))
 d.add(d.rect(insert=(0,0),size=(13,H),fill=accent))
 text(d,60,54,f'{n:02d}  {ko}',45,WHITE,700)
 text(d,62,100,en,20,'#B9D0ED',400)
 text(d,1140,54,origin,18,'#B7C7D9',400,anchor='end')
 text(d,52,189,topic,32,INK,700)
 d.add(d.line(start=(52,216),end=(1146,216),stroke=LINE,stroke_width=2))
 return d

def text(d,x,y,s,size=23,color=INK,weight=400,anchor='start'):
 d.add(d.text(str(s), insert=(x,y), fill=color, font_size=size,font_family=FONT,font_weight=weight,text_anchor=anchor))

def rect(d,x,y,w,h,fill=WHITE,stroke=LINE,r=18,sw=2):
 d.add(d.rect(insert=(x,y),size=(w,h),rx=r,ry=r,fill=fill,stroke=stroke,stroke_width=sw))

def line(d,x1,y1,x2,y2,color=LINE,width=3,dash=None):
 opts={'stroke':color,'stroke_width':width,'stroke_linecap':'round'}
 if dash:opts['stroke_dasharray']=dash
 d.add(d.line(start=(x1,y1),end=(x2,y2),**opts))

def circle(d,x,y,r,fill,stroke=None,width=2):
 d.add(d.circle(center=(x,y),r=r,fill=fill,stroke=stroke or fill,stroke_width=width))

def arrow(d,x1,y1,x2,y2,color=MUTED,width=4):
 line(d,x1,y1,x2,y2,color,width)
 a=math.atan2(y2-y1,x2-x1); length=13
 points=[(x2,y2),(x2-length*math.cos(a-.55),y2-length*math.sin(a-.55)),(x2-length*math.cos(a+.55),y2-length*math.sin(a+.55))]
 d.add(d.polygon(points,fill=color))

def pill(d,x,y,s,fill,color=WHITE,w=None):
 w=w or (40+len(s)*13)
 rect(d,x,y,w,38,fill,fill,18,1);text(d,x+w/2,y+26,s,17,color,700,'middle')

def cardtitle(d,x,y,s,accent):
 circle(d,x+20,y-8,14,accent); text(d,x+20,y-2,'✓',16,WHITE,700,'middle');text(d,x+49,y,s,22,INK,700)

def footer(d,msg,accent):
 rect(d,48,695,1104,53,'#EAF0F8','#EAF0F8',10,1)
 text(d,70,729,msg,21,MUTED,400)

def draw1(d,a):
 rect(d,52,247,1098,104,'#DFF5EC','#DFF5EC',16)
 text(d,78,294,'CAPM = 무위험수익률 + 베타 × 시장위험프리미엄',28,NAVY,700)
 text(d,78,328,'E[Rᵢ] = Rf + βᵢ (E[Rm] − Rf)',22,INK)
 names=[('01','베타 (β)','시장 수익률에 대한 민감도'),('02','시장위험프리미엄','시장 포트폴리오의 초과 기대수익'),('03','기대수익률','위험 보상의 수준을 나타내는 이론값')]
 for i,(k,t,s) in enumerate(names):
  x=52+i*376;rect(d,x,377,350,251)
  circle(d,x+52,430,29,a);text(d,x+52,439,k,22,WHITE,700,'middle')
  text(d,x+31,497,t,27,INK,700);text(d,x+31,548,s,17,MUTED)
  line(d,x+31,574,x+315,574,'#E7ECF3',2)
  text(d,x+31,603,['시장 전체 변동에 반응','초과수익의 대가','모형의 가정에 유의'][i],17,a)
 footer(d,'학습 구조: 정의 → 변수 → 직관 → 공식 → 가정과 한계',a)

def draw2(d,a):
 rect(d,52,250,690,410)
 text(d,78,291,'가상 자산배분 · 구성비',24,INK,700)
 center=(305,466);r=128;st=-90
 for frac,col in [(0.6,'#F2914D'),(.3,'#327DC2'),(.1,'#30A68C')]:
  ed=st+360*frac
  path=f'M {center[0]} {center[1]} L {center[0]+r*math.cos(math.radians(st))} {center[1]+r*math.sin(math.radians(st))} A {r} {r} 0 {int(frac>0.5)} 1 {center[0]+r*math.cos(math.radians(ed))} {center[1]+r*math.sin(math.radians(ed))} Z'
  d.add(d.path(d=path,fill=col,stroke=WHITE,stroke_width=4));st=ed
 circle(d,center[0],center[1],74,WHITE,WHITE)
 text(d,305,464,'100%',32,INK,700,'middle');text(d,305,498,'가상 예제',18,MUTED,400,'middle')
 for j,(lab,val,col) in enumerate([('주식','60%','#F2914D'),('채권','30%','#327DC2'),('대체','10%','#30A68C')]):
  circle(d,503,387+j*65,13,col);text(d,530,394+j*65,lab,22,INK);text(d,697,394+j*65,val,24,col,700,'end')
 rect(d,773,250,377,410)
 text(d,798,293,'핵심 KPI',25,INK,700)
 for i,(label,val,sub) in enumerate([('비중 합계','100%','구성비 검증'),('항목 수','3개','중복 없는 분류'),('데이터 상태','예시','실제 운용자료 아님')]):
  y=325+i*100;rect(d,795,y,330,89,'#F6F8FC','#F6F8FC',11)
  text(d,811,y+30,label,18,MUTED);text(d,811,y+69,val,29,a,700);text(d,944,y+68,sub,16,MUTED)
 footer(d,'차트 원칙: 단위 · 기준시점 · 출처 · 합계 100% 여부 표시',a)

def draw3(d,a):
 steps=[('01','시계열 탐색','추세 · 계절성 · 이상치'),('02','정상성 점검','ADF · 변환 · 차분'),('03','모형 식별','ACF · PACF'),('04','모형 추정','ARIMA · AIC/BIC'),('05','잔차 진단','Ljung–Box → 예측')]
 xs=[85,310,535,760,985]
 for i,(k,t,s) in enumerate(steps):
  x=xs[i];rect(d,x-30,313,210,260,WHITE,LINE,16);circle(d,x+70,350,25,a);text(d,x+70,358,k,19,WHITE,700,'middle')
  text(d,x-10,430,t,24,INK,700);text(d,x-10,482,s,17,MUTED)
  if i<4:arrow(d,x+182,439,x+218,439,a,4)
 rect(d,180,610,842,55,'#EDEBFB','#EDEBFB',12)
 text(d,603,646,'잔차 진단 실패 → 모형 식별 단계로 되돌아감',21,a,700,'middle')
 arrow(d,1040,582,1040,638,a,3)
 footer(d,'입력→처리→검증→피드백의 실제 순서를 표시',a)

def draw4(d,a):
 widths=[180,285,285,285];xs=[55,235,520,805];ys=278
 headers=['평가항목','MDI','MDA','SFI']
 for j in range(4):
  rect(d,xs[j],ys,widths[j]-4,64,a if j==0 else '#E7F1FC',a if j==0 else '#E7F1FC',9)
  text(d,xs[j]+20,ys+42,headers[j],23,WHITE if j==0 else NAVY,700)
 rows=[('기본 원리','트리 불순도 감소','변수 셔플 성능 변화','단변수 모델 성능'),('상관 변수','중요도 편향 가능','중요도 분산 가능','결합효과 누락'),('모델 의존','트리 기반','학습된 모델 필요','단독 변수 모델')]
 for i,row in enumerate(rows):
  y=356+i*98
  for j,field in enumerate(row):
   rect(d,xs[j],y,widths[j]-4,88,WHITE,LINE,6,1)
   text(d,xs[j]+15,y+42,field,19,INK if j>0 else a,700 if j==0 else 400)
 footer(d,'같은 질문 · 같은 데이터 · 같은 평가 지표로 비교',a)

def draw5(d,a):
 years=[1952,1964,1976,1993,2015];xvals=[110,345,580,815,1050]
 line(d,96,419,1091,419,'#B3BDD0',6,dash='11,10')
 for i,(y,x) in enumerate(zip(years,xvals)):
  circle(d,x,419,29,a if i%2 else NAVY);text(d,x,427,str(i+1),20,WHITE,700,'middle')
  text(d,x,348,str(y),29,a,700,'middle')
  labs=[('Markowitz','평균–분산'),('CAPM','시장 베타'),('APT','다요인 위험'),('FF3','3요인'),('FF5','5요인')]
  text(d,x,500,labs[i][0],24,INK,700,'middle');text(d,x,536,labs[i][1],20,MUTED,400,'middle')
 rect(d,92,583,1015,57,'#FCE8EF','#FCE8EF',11)
 text(d,600,622,'이정표는 논문 발표 연도를 기준으로 작성한 개략적 역사',21,INK,400,'middle')
 footer(d,'검증 원칙: 연도 · 발표 논문 · 선후관계 · 역사적 기여',a)

def draw6(d,a):
 names=[('사용자 인터페이스','강의 · 리포트 · 대시보드'),('연구·지식 레이어','논문 RAG · 온톨로지 · 전략 카드'),('분석·운용 엔진','백테스트 · 리스크 · 최적화'),('데이터·거버넌스','시장데이터 · 계보 · 접근권한')]
 for i,(t,s) in enumerate(names):
  y=254+i*101
  rect(d,129+i*29,y,944-i*58,78,['#DAF3EC','#E9F4F9','#EEF0FA','#F8F1E6'][i],LINE,12,1)
  text(d,169+i*29,y+31,t,25,NAVY,700)
  text(d,169+i*29,y+60,s,19,MUTED)
  if i<3:arrow(d,602,y+78,602,y+95,a,3)
 footer(d,'아키텍처는 계층·권한·데이터 흐름을 구분해서 표시',a)

def draw7(d,a):
 nodes=[(125,347,218,105,'2차 소재업체 C','#FDF0E0'),(483,342,243,118,'1차 협력사 B','#E8F6F2'),(867,347,230,105,'완성차 업체 A','#ECF0FB')]
 for x,y,w,h,t,col in nodes:
  rect(d,x,y,w,h,col,LINE,14,2);text(d,x+w/2,y+50,t,23,NAVY,700,'middle');text(d,x+w/2,y+79,'기업 노드 · 가상',16,MUTED,400,'middle')
 arrow(d,347,399,475,399,a,6);arrow(d,729,399,860,399,a,6)
 pill(d,354,329,'소재 공급','#F4E5D1',NAVY,100);pill(d,741,329,'부품 공급','#E5E9FA',NAVY,104)
 rect(d,117,530,987,98,WHITE,LINE,13)
 text(d,147,566,'관계 스키마',24,INK,700)
 text(d,147,605,'(주체 기업) — [관계 유형 / 방향 / 기준일 / 근거] → (대상 기업)',21,MUTED)
 footer(d,'실제 기업 간 거래 관계는 확인 자료 없이는 생성하지 않음',a)

def draw8(d,a):
 rect(d,442,260,322,80,'#E0EDF6','#BDD5E7',14)
 text(d,603,308,'표본외 검증 완료?',26,NAVY,700,'middle')
 arrow(d,542,343,342,435,a,4);arrow(d,680,343,876,435,a,4)
 pill(d,430,373,'아니요','#F6D4D8','#A33A4A',105);pill(d,745,373,'예','#DDF4E7','#1F8067',77)
 rect(d,102,439,454,113,'#FEECED','#EFCED4',14)
 text(d,329,484,'추가 검증',29,'#9F3A54',700,'middle');text(d,329,523,'누출·과적합·표본기간 점검',19,INK,400,'middle')
 rect(d,650,439,454,113,'#E0F6EA','#BEE9D0',14)
 text(d,877,484,'리스크 승인 심사',29,'#187D60',700,'middle');text(d,877,523,'손실한도·유동성·운영위험 검토',18,INK,400,'middle')
 rect(d,352,602,520,60,'#E8F0FB','#DAE6F8',11)
 text(d,610,643,'승인 전에는 실거래로 연결하지 않음',22,NAVY,700,'middle')
 footer(d,'분기 조건과 책임자를 반드시 함께 기록',a)

def draw9(d,a):
 labs=['낮음','보통','높음','매우 높음'];colors=['#D9F3E7','#DCECF8','#FDE9C8','#F9D7D6']
 text(d,88,278,'영향도 ↑',22,INK,700)
 for i in range(4):
  for j in range(4):
   risk=(4-i)*(j+1)
   k=0 if risk<=3 else 1 if risk<=6 else 2 if risk<=10 else 3
   rect(d,294+j*169,270+i*84,155,73,colors[k],WHITE,10,2)
   text(d,371+j*169,315+i*84,['L','M','H','VH'][k],25,INK,700,'middle')
 for i,x in enumerate(labs):text(d,370+i*169,626,x,19,MUTED,400,'middle')
 for i,x in enumerate(reversed(labs)):text(d,254,318+i*84,x,19,MUTED,400,'end')
 text(d,638,671,'발생가능성 →',21,INK,700,'middle')
 footer(d,'범례는 예시 등급이며 실제 섹터별 위험 수치를 의미하지 않음',a)

def draw10(d,a):
 rect(d,68,267,478,337,'#FFF0E8','#F7D4C3',18,2)
 rect(d,654,267,478,337,'#E8F7EF','#C9E9DB',18,2)
 pill(d,103,288,'BEFORE','#E69A72',WHITE,120);pill(d,688,288,'AFTER','#45A88A',WHITE,112)
 for x,items in [(100,['전략 신호 발생','모든 신호에 진입','기초 성과만 평가']), (685,['전략 신호 발생','ML 메타 필터 적용','표본외 성과·위험 검증'])]:
  for i,t in enumerate(items):
   rect(d,x,359+i*74,412,61,WHITE,'#E1E6EE',9)
   circle(d,x+32,390+i*74,15,a)
   text(d,x+32,397+i*74,str(i+1),16,WHITE,700,'middle')
   text(d,x+62,396+i*74,t,21,INK,700)
 arrow(d,561,452,642,452,a,7)
 footer(d,'개선 효과는 실증 전에는 확정하지 않음 · 이중 과적합 주의',a)

def draw11(d,a):
 rect(d,62,252,695,405,WHITE,LINE,15)
 text(d,95,305,'연구 주장',26,NAVY,700)
 text(d,95,357,'“이 전략이 위험조정 성과를 개선한다”',23,INK)
 for i,(tt,ss) in enumerate([('자료','표본기간 · 자산 · 빈도 · 누락'),('설계','거래비용 · 워크포워드 · 누출'),('결과','OOS 성과 · 구간 · 불확실성')]):
  y=389+i*82;rect(d,97,y,626,72,['#EAF2FC','#F5EFFD','#E8F6F1'][i],'#E2EAF2',10)
  text(d,120,y+27,tt,20,a,700);text(d,120,y+54,ss,19,INK)
 rect(d,784,252,360,405,'#EAF0F7','#EAF0F7',15)
 text(d,814,305,'증거 상태',26,NAVY,700)
 states=[('IS 백테스트','탐색용','#F5D59F'),('OOS 검증','추가 증거','#A8D4EA'),('실거래 관측','실행 근거','#A4DAC9')]
 for i,(t,s,c) in enumerate(states):
  y=345+i*95;rect(d,809,y,307,78,WHITE,'#E5EAF2',10);circle(d,837,y+39,15,c);text(d,867,y+31,t,21,INK,700);text(d,867,y+59,s,17,MUTED)
 footer(d,'결론은 증거 수준에 비례 · 확률/확신도는 임의로 꾸미지 않음',a)

DRAW=[draw1,draw2,draw3,draw4,draw5,draw6,draw7,draw8,draw9,draw10,draw11]
paths=[]
for item,drawer in zip(STYLES,DRAW):
 n,en,ko,topic,accent,origin=item
 dr=svg(n,en,ko,topic,accent,origin);drawer(dr,accent)
 name=f'style-{n:02d}-{en.split(" /")[0].lower().replace(" ","-").replace("/", "-")}'
 stem={1:'style-01-explainer',2:'style-02-data-story',3:'style-03-process',4:'style-04-comparison',5:'style-05-timeline',6:'style-06-architecture',7:'style-07-ontology',8:'style-08-decision-tree',9:'style-09-matrix',10:'style-10-before-after',11:'style-11-research-evidence'}[n]
 dr.saveas(str(OUT/f'{stem}.svg'))
 cairosvg.svg2png(url=str(OUT/f'{stem}.svg'),write_to=str(OUT/f'{stem}.png'),output_width=1200,output_height=780)
 paths.append(OUT/f'{stem}.png')

thumbs=[]
for p in paths:
 im=Image.open(p).convert('RGB')
 im.thumbnail((520,338))
 canvas=Image.new('RGB',(550,378),'#FFFFFF'); canvas.paste(im,((550-im.width)//2,15));thumbs.append(canvas)
contact=Image.new('RGB',(3*550,4*378),'#F0F3FA')
for i,t in enumerate(thumbs):contact.paste(t,((i%3)*550,(i//3)*378))
d=ImageDraw.Draw(contact)
d.rectangle((1100,1134,1649,1511),fill='#E5EAF4')
font=ImageFont.truetype('/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',34)
d.text((1155,1290),'11 TYPES\nREFERENCE',fill='#20304C',font=font,spacing=12)
contact.save(OUT/'11-styles-overview.png',optimize=True)
print('Created',len(paths),'styles and contact sheet',OUT)
