# Financial infographic truthfulness and QA

## Provenance status

- `verified`: primary-source/clearly cited fact, valid for stated date/context.
- `user-provided`: given by user, not independently checked.
- `illustrative`: invented only for explicitly labeled teaching example.
- `uncertain`: incomplete/outdated/unverifiable; never turn into an assertion.

## Numerical checks

1. If showing composition: check categories are mutually exclusive and sum to ~100%, noting any rounding.
2. Show units, denominator, return definition, time zone as applicable, base period, and currency.
3. For comparisons: use common sample, horizon, aggregation level; note differences explicitly.
4. Chart axes must show appropriate zero baseline when comparing magnitudes via bars; if truncated for trends, label it visibly.
5. Distinguish annualized vol, realized return, expected return, Sharpe, and drawdown.
6. Do not create synthetic performance results as if they were achieved.

## Quant method checks

- Derive formula from a verified definition and display the assumptions.
- For GARCH(1,1), distinguish `ω > 0`, `α ≥ 0`, `β ≥ 0`, covariance-stationary case `α+β < 1` under standard assumptions.
- Never claim a backtest or forward-testing success is a deployed/live result.
- State purge/embargo/transaction costs when evaluating ML signals where relevant.
- Distinguish statistical significance, economic materiality, and causality.
- If citing findings, include author/date/source locator and note any unverifiable details.

## Ontology/industry graph checks

- The edge `(Company)-[:OPERATES_IN]->(ValueChainStage)` denotes classification; it does not assert an actual buyer-supplier trade.
- The edge `(Company)-[:SUPPLIES_TO]->(Company)` needs evidence for the specific link and scope/time.
- Equity interests need date/percentage if supplied and clearly dated source.
- Use `source_id`, `observed_at`, `valid_from`, `valid_to`, `status` properties when feasible.
- Never use model similarity, textual cooccurrence, or value-chain adjacency as sufficient proof of a commercial relationship.

## Rendering QA

- Compare final image to the content blueprint for exact numbers and labels.
- Check Korean text visually for missing glyphs and unintended line wraps.
- Ensure color-blind readability and high contrast.
- Keep editable data/document if requested. Treat final PNG as noncanonical.
- Show missing values explicitly. Avoid silent assumptions and invented references.
