# 11-Type Style Image Reference Gallery

The images in `../assets/style-reference/` are **original illustrative mockups**, not reproductions of the social-media author's posters. All figures labeled examples are illustrative, not sourced financial data. Keep the gallery and actual data separate.

| No. | Design | Illustration filename | Meaning |
|---|---|---|---|
| 01 | 개념 설명형 | `style-reference/style-01-explainer.png` | Screenshot-confirmed category, newly drawn example |
| 02 | 데이터 스토리형 | `style-reference/style-02-data-story.png` | Screenshot-confirmed category, newly drawn example |
| 03 | 프로세스형 | `style-reference/style-03-process.png` | Screenshot-confirmed category, newly drawn example |
| 04 | 비교 분석형 | `style-reference/style-04-comparison.png` | Independently extended category |
| 05 | 연대기형 | `style-reference/style-05-timeline.png` | Screenshot-confirmed category, newly drawn example |
| 06 | 계층/아키텍처형 | `style-reference/style-06-architecture.png` | Independently extended category |
| 07 | 지식그래프/온톨로지형 | `style-reference/style-07-ontology.png` | Independently extended category |
| 08 | 의사결정 트리형 | `style-reference/style-08-decision-tree.png` | Independently extended category |
| 09 | 위험 매트릭스형 | `style-reference/style-09-matrix.png` | Independently extended category |
| 10 | 개선 사례형 | `style-reference/style-10-before-after.png` | Independently extended category |
| 11 | 연구 근거형 | `style-reference/style-11-research-evidence.png` | Independently extended category |

## How to apply

1. Look at the PNG for visual structure; open the SVG for an editable drawing scaffold.
2. Keep the information architecture, not the sample statistics or placeholder organizations.
3. Validate supplied facts before creating a new finance-related image.
4. Embed output in an Obsidian note using `![[your-image.png|940]]` with the file inside the same vault.
5. Prefer chart-from-data for numerical presentations; preserve exact chart units and source dates.
