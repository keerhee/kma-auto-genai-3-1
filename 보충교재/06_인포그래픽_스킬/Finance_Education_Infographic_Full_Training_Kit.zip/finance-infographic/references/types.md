# 11-type catalog and composition rules

| Type | Kind | Main visual objects | Required input | Typical risk |
|---|---|---|---|---|
| 01 Teacher Explainer | Screenshot-confirmed | definition + 3–6 concept cards | topic, audience, short definitions | oversimplification |
| 02 Data Story | Screenshot-confirmed | KPI + supported charts + citation | data, unit, period, source | false numbers/axes |
| 03 Process | Screenshot-confirmed | ordered boxes, arrows, loops | steps and branching | omitted feedback |
| 04 Comparison | Original extension | side-by-side grid, condition labels | alternatives, shared dimensions | unfair comparison |
| 05 Timeline | Screenshot-confirmed | dated milestone nodes | verified date-event pairs | invented dates |
| 06 Hierarchy | Original extension | layers, modules, boundaries | layers, components, flows | conflating ownership and data flow |
| 07 Knowledge Graph | Original extension | typed nodes/edges, evidence | triples, timestamp, evidence | fabricated supply/equity relations |
| 08 Decision Tree | Original extension | diamonds, branches, action nodes | decision criteria, thresholds | pretending rules are validated |
| 09 Matrix | Original extension | row × column cells, legend | measurements and units | false color precision |
| 10 Before–After | Original extension | paired plots/panels | comparable before/after data | causal overstatement |
| 11 Research Evidence | Original extension | question–method–result–limits | paper, methods, sample, evidence | in-sample promoted to live |

## Design style defaults

- 16:9 slide: title 30–36pt, body 20–24pt, annotations readable.
- A4 report: constrained margins, body 10–11pt, table and data footnotes.
- 4:5 social: one primary message, no microtext or crowded plots.
- Color coding: use color for **meaning**, not cosmetic randomness.
- Include a non-color label/key for any risk/confidence distinction.
- Keep all visual nodes and connections semantically labeled.

## Finance use cases

1. CAPM, GARCH, VaR: 01 + 03
2. Pension TPA, private credit mix: 02 + 09
3. Box–Jenkins pipeline: 03
4. MDI vs MDA vs SFI: 04
5. Asset pricing historical timeline: 05
6. NeoQuant research architecture: 06
7. Korean auto supply chain ontology: 07 (evidence required)
8. Loan covenant monitoring: 08
9. Private credit sector × risk matrix: 09
10. Meta-labeling backtest comparison: 10 + 11
11. Factor research paper evidence card: 11

## Workflow selection

Use `content-first` when visual source data is not yet approved; `prompt-only` when the user requests prompts; `editable` when the user requires a working document/slide or ability to update charts; `render` only for an explicitly requested image. If no data is given, ask for it or create a clearly marked toy demonstration only if that would satisfy the user.
