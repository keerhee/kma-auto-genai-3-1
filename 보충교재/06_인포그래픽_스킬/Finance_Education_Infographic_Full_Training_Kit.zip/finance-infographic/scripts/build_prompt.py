#!/usr/bin/env python3
"""Generate finance/education infographic specifications using Python stdlib only."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
from typing import Any

TYPES = {
    1: ("Teacher Explainer", "개념 설명형", "한 문장 정의 → 직관 → 3~6개 아이콘 카드 → 쉬운 예제 → 핵심 요약", "흰 배경, 파스텔, 플랫 벡터. 카드별 10~15단어 수준의 짧은 한국어 설명."),
    2: ("Data Story", "통계·데이터형", "메인 KPI → 보조 통계 → 비교/추이 차트 → 수치의 의미 → 단위·기간·출처", "배타적인 구성비에만 도넛을 사용하고 비교는 막대, 추이는 선 그래프를 사용."),
    3: ("Process / How-It-Works", "프로세스형", "시작/입력 → 4~7개 번호 단계 → 조건/피드백 분기 → 결과", "단계와 단계 사이 화살표, 검정 실패 시 복귀 경로를 정확히 표시."),
    4: ("Comparison / Trade-off", "비교형", "비교 질문 → 2~4개 대안 → 공통 평가축 → 조건부 선택 가이드", "동일 단위/기간/표본 기반의 나란한 비교표와 장단점 표시."),
    5: ("Timeline Journey", "연대기형", "시작/종료 연도 → 5~8개 확인된 연도·이정표 → 발전 흐름 요약", "수평 점선 타임라인, 아이콘 노드, 연도는 세리프, 본문은 산세리프."),
    6: ("Hierarchy / Architecture", "계층/아키텍처형", "최상위 목표 → 레이어 3~5개 → 모듈 → 데이터 흐름·시스템 경계", "박스와 연결 유형을 구분, 데이터 흐름과 조직 포함 관계를 혼동하지 말 것."),
    7: ("Knowledge Graph / Ontology", "관계/온톨로지형", "노드 유형 → 방향과 관계명 → 근거가 있는 삼중항 → 출처/시점 범례", "기업 공급관계·자본관계는 실제 증거가 없으면 연결하지 말 것."),
    8: ("Decision Tree / Logic", "의사결정형", "입력 → 조건 노드(임계값/단위) → 예/아니요 분기 → 행동/예외", "마름모 판단 노드와 분기 라벨 사용; 규칙은 검증 상태를 표기."),
    9: ("Matrix / Heatmap", "매트릭스형", "행·열 기준과 측정척도 → 3×3/4×4 셀 → 핵심 위험/기회 2~3개", "색상 범례와 숫자/기호를 함께 사용; 정성/정량 점수를 혼합하지 말 것."),
    10: ("Before–After / Case Study", "전후 사례형", "문제/기준선 → 개입 → 전후 동일 척도 비교 → 한계/교훈", "전후 패널 축/단위를 일치시키고 인과관계 단정을 피할 것."),
    11: ("Research Evidence / Uncertainty", "논문근거/불확실성형", "연구질문 → 자료·설계 → 주요 결과/신뢰구간 → 한계·검증상태", "연구근거 카드에 OOS, 거래비용, 데이터 누출, 출처 정보를 적을 것."),
}
SCREENSHOT_CONFIRMED = {1, 2, 3, 5}

ROUTING = [
    (7, ("온톨로지", "지식그래프", "기업관계", "공급망", "neo4j", "graph", "network")),
    (11, ("논문", "연구", "근거", "검증", "uncertainty", "evidence", "backtest")),
    (8, ("의사결정", "규칙", "분기", "승인", "decision", "threshold")),
    (9, ("매트릭스", "히트맵", "heatmap", "matrix", "노출도")),
    (10, ("전후", "사례", "개선 효과", "before", "after")),
    (5, ("역사", "발전사", "연대기", "이정표", "timeline")),
    (4, ("비교", "차이", "장단점", "versus", "vs ", "tradeoff")),
    (3, ("절차", "워크플로", "파이프라인", "과정", "프로세스", "workflow")),
    (6, ("아키텍처", "계층", "모듈", "구조도", "architecture")),
    (2, ("비중", "통계", "데이터", "수익률", "실적", "수치", "chart", "성과")),
]

def guess_type(topic: str) -> int:
    """Lightweight heuristic only; unambiguous user type overrides routing."""
    low = topic.lower()
    for num, words in ROUTING:
        if any(word in low for word in words):
            return num
    return 1


def build(config: dict[str, Any], mode: str = "md") -> str:
    topic = str(config.get("topic") or "[주제 입력]").strip()
    audience = str(config.get("audience") or "[대상 입력]").strip()
    rawtype = config.get("type", "auto")
    type_num = guess_type(topic) if str(rawtype).lower() == "auto" else int(rawtype)
    if type_num not in TYPES:
        raise ValueError("type must be 'auto' or integer 1..11")
    en, ko, structure, style = TYPES[type_num]
    ratio = str(config.get("ratio") or "16:9")
    language = str(config.get("language") or "ko")
    items = config.get("items") or []
    sources = config.get("sources") or []
    notes = str(config.get("notes") or "")
    if isinstance(items, str):
        items = [items]
    if isinstance(sources, str):
        sources = [sources]
    if not isinstance(items, list) or not isinstance(sources, list):
        raise ValueError("items and sources must be arrays or single strings")
    def rows(prefix: str, vals: list[Any]) -> str:
        return "\n".join(f"- {prefix}{str(v)}" for v in vals) or "- [내용 미제공: 확인 필요]"
    provenance = "스크린샷 확인 유형" if type_num in SCREENSHOT_CONFIRMED else "독자 확장 유형 (원본에서 확인되지 않음)"
    body = f"""# 인포그래픽 제작 프롬프트 — {type_num:02d} {ko}

**주제:** {topic}
**대상:** {audience}
**화면비:** {ratio} · **언어:** {language}
**선택 유형:** {en} · {provenance}

## 콘텐츠 입력
{rows('', items)}

## 제공 출처
{rows('', sources)}

## 제작 지시
당신은 금융·교육 전문 시각화 디자이너다.
주제 '{topic}'을(를) '{audience}'에 적합한 {ko} 인포그래픽으로 설계하라.
우선 제목/핵심 주장/항목/사실표(수치·단위·기간·출처·검증상태)를 제시한다.
이후 구성: {structure}
스타일: {style}
화면비 {ratio}, 언어 {language}. 강의 슬라이드라면 제목 28~36pt, 본문 20pt 이상 권장.
허위 수치, 출처, 기업관계, 연도, 수식 변형을 금지한다.
제공되지 않은 세부 사항은 [확인 필요], 가상 사례는 [교육용 가상 예시]로 표기한다.
한글 표기와 영문 약어, 수식 부호·단위, 차트 축, 합계, 인과/상관 구분을 검수한다.
해석 가능하고 편집 가능한 레이아웃/자료 원본을 우선하라.
필요한 출력이 이미지인지 편집 파일인지 불분명하면 제작 전 확인한다.

## 추가 메모
{notes or '[추가 메모 없음]'}

## 완료 전 QA
- [ ] 근거, 기준일, 단위 확인
- [ ] 수치 합계, 표본기간과 차트 축 확인
- [ ] 편집 가능 여부 및 결과물 종류 확인
- [ ] 한국어 오탈자, 글자 크기, 접근성 확인
- [ ] 추론·예제·검증된 사실 구분
"""
    if mode == "json":
        return json.dumps({"type": type_num, "type_english": en, "type_korean": ko, "provenance": provenance, "prompt": body}, ensure_ascii=False, indent=2)
    if mode == "text":
        return re.sub(r"(?m)^#{1,3} ", "", body).replace("**", "")
    return body


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--list", action="store_true", help="Show all 11 supported formats")
    ap.add_argument("--type", default="auto", help="1..11 or auto")
    ap.add_argument("--topic", default="", help="Topic in Korean or English")
    ap.add_argument("--audience", default="", help="Target audience")
    ap.add_argument("--ratio", default="16:9", help="16:9, A4, 4:5, etc")
    ap.add_argument("--language", default="ko")
    ap.add_argument("--input", type=Path, help="UTF-8 JSON input (overrides CLI fields when present)")
    ap.add_argument("--output", type=Path, help="Save prompt to UTF-8 file")
    ap.add_argument("--format", choices=["md", "text", "json"], default="md")
    args = ap.parse_args()
    if args.list:
        for n, (en, ko, _, _) in TYPES.items():
            suffix = "[원본 확인]" if n in SCREENSHOT_CONFIRMED else "[독자 확장]"
            print(f"{n:02d}. {en} / {ko} {suffix}")
        return
    cfg: dict[str, Any] = {"type": args.type, "topic": args.topic, "audience": args.audience,
                            "ratio": args.ratio, "language": args.language}
    if args.input:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            ap.error("JSON input must be an object")
        cfg.update(data)
    try:
        result = build(cfg, args.format)
    except (ValueError, TypeError) as exc:
        ap.error(str(exc))
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
        print(f"Saved: {args.output}")
    else:
        print(result)

if __name__ == "__main__":
    main()
