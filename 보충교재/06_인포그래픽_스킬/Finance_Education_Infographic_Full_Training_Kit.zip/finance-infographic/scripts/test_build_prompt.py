import importlib.util
from pathlib import Path
import unittest

script = Path(__file__).with_name("build_prompt.py")
spec = importlib.util.spec_from_file_location("build_prompt", script)
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

class TestPromptBuilder(unittest.TestCase):
    def test_count_and_origin(self):
        self.assertEqual(len(b.TYPES), 11)
        self.assertEqual(b.SCREENSHOT_CONFIRMED, {1, 2, 3, 5})
    def test_auto_ontology(self):
        self.assertEqual(b.guess_type("한국 자동차 산업 온톨로지 그래프"), 7)
    def test_incorrect_type(self):
        with self.assertRaises(ValueError):
            b.build({"type": 12, "topic": "test"})
    def test_finance_safety(self):
        result = b.build({"type": 11, "topic": "factor research", "audience": "MBA"})
        self.assertIn("허위 수치", result)
        self.assertIn("독자 확장", result)
    def test_json(self):
        import json
        obj = json.loads(b.build({"type": 2, "topic": "allocation"}, "json"))
        self.assertEqual(obj["type"], 2)

if __name__ == "__main__":
    unittest.main()
