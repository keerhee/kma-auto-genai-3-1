---
name: finance-infographic
description: Design evidence-aware, Korean/English educational and finance infographics. Use for concept explainers, data stories, workflows, comparisons, timelines, architectures, ontologies/knowledge graphs, decision trees, matrices/heatmaps, before-after cases, and research-evidence cards. Select an appropriate one of 11 formats, verify claims, and prepare editable production specs.
---

# Finance & Education Infographic Designer

## When to invoke

Use this skill if a user asks for an infographic, a visual lesson handout, a visual investment/research report, a process diagram, a knowledge graph or ontology graphic, or a slide infographic in finance/education/AI. Do not assume image generation is requested when the user only requests planning, explanation, source code, or an editable artifact.

## Visual style references

For all 11 types, see [style gallery](references/style-gallery.md) with local **PNG + editable SVG** illustrations in `assets/style-reference/`. The infographic examples are original visual samples; preserve only their design grammar, never treat example data as external facts. For an Obsidian delivery, provide a standalone Markdown note and its local `assets/` attachments together; prefer `![[image.png|940]]` and verify paths resolve inside the vault.

## Non-negotiable steps

1. Determine the **real deliverable** (design prompt vs static image vs editable Slides/PPT/HTML/SVG vs data visualization). If unclear and materially different, ask one concise question.
2. Choose the appropriate format from [type catalog](references/types.md). `#1/#2/#3/#5` appeared in the provided screenshot; `#4/#6–#11` are our own extensions, not claimed to be from the original creator.
3. Identify target audience, key question, main assertion, media ratio, and evidence. If a required datum or relationship is not in the inputs, leave it as `[확인 필요]`—**never invent**.
4. Draft a **content blueprint** before visual layout: title, takeaway, blocks, numeric values/units/time range, claim/source references, known limitations.
5. Apply the verification rules in [finance QA](references/finance-qa.md). For business links distinguish membership, supply, equity, and hypothesis. For research distinguish in-sample/backtest/OOS/live.
6. Make a layout spec with typographic sizes, color roles, object hierarchy, chart and data mapping, legends, alternate text, and editable output plan.
7. Produce the requested deliverable using available tools **only**. Do not claim to have generated an image, queried Neo4j, deployed Slides, or validated cited facts when that operation has not occurred.
8. Finish with brief QA results, unresolved claims and instructions to reproduce/update the artifact.

## Modes

- `prompt-only` — reusable copy-paste AI prompt plus data placeholders.
- `content-first` — content blueprint and a compact review table; no image.
- `editable` — create actual PPT/Slides/HTML/SVG through available tools; keep data source.
- `render` — create image only when explicitly requested, after appropriate content handling.
- `research` — evidence/uncertainty card with limitations and provenance, not merely a persuasive poster.

## Fast routing

| User goal | Type |
|---|---|
| 정의·기초개념 | 01 Teacher Explainer |
| 통계·배분·성과 | 02 Data Story |
| 절차·튜토리얼·파이프라인 | 03 Process |
| 대안·장단점 비교 | 04 Comparison |
| 역사·이정표·로드맵 | 05 Timeline |
| 모듈·책임·계층·아키텍처 | 06 Hierarchy |
| 기업 간 관계·엔터티·온톨로지 | 07 Knowledge Graph |
| 조건·임계값·규칙·승인 | 08 Decision Tree |
| 위험 매트릭스·교차노출 | 09 Matrix |
| 전후 변화·성과 사례 | 10 Before–After |
| 논문·OOS 검증·출처·불확실성 | 11 Research Evidence |

For composite work, use 1 **primary** and at most 1 complementary type per page. Split pages if concept+chart+graph+table become unreadable.

## Standard response sequence

```text
[선택 유형/선택 이유]
[대상 독자와 메시지]
[콘텐츠 청사진: 제목 + 핵심 3~6개 + 중요한 수식/숫자]
[사실/출처/검증 상태: confirmed / user-provided / illustrative / unknown]
[제작 프롬프트 또는 제작 실행]
[디자인 사양: 16:9/A4/4:5, 글꼴, 팔레트, 도표/화살표]
[QA/수정 필요 사항]
```

## Tools and safe fallbacks

- For evidence-based charts: create charts from CSV/Python and place into Slides/HTML; generated imagery is not a source of numeric truth.
- For formulas: preserve TeX/OMML/MathJax or render formulas separately and visually verify.
- For ontologies: prefer verified triples CSV/Neo4j Cypher/Graphviz over AI-imagined lines. Maintain source ID and effective date on each edge.
- For Korean teaching: Korean descriptions; English label in parentheses first time; good spacing; 20pt+ in slide bodies if practical.
- Do not silently fetch proprietary data or send source documents to outside services.
- If renderer/tool is unavailable, deliver precise content specification, not a pretend finished visual.

## Local prompt builder

With Python 3 standard library:

```bash
python scripts/build_prompt.py --list
python scripts/build_prompt.py --type 7 --topic "한국 자동차 산업지도" --audience "금융 리서처" --format md
python scripts/build_prompt.py --type auto --topic "포트폴리오 섹터 비중" --audience "MBA"
python scripts/build_prompt.py --type 11 --input examples/research_case.json --output prompt.md
python -m unittest discover -s scripts -p 'test_*.py'
```

This script creates a **prompt**, not a rendered infographic. For sample tasks see [examples](examples/) and full content in the accompanying master guide.
