# 금융·교육 인포그래픽 Claude Code 스킬 설치

## 설치 (macOS/Linux)

ZIP 압축을 해제하여 생기는 `finance-infographic` 폴더 전체를 `~/.claude/skills/`에 복사합니다.

```bash
mkdir -p ~/.claude/skills
unzip Finance_Education_Infographic_Skill_Install.zip -d ~/.claude/skills/
```

## 설치 (Windows PowerShell)

```powershell
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Expand-Archive -Path .\Finance_Education_Infographic_Skill_Install.zip -DestinationPath "$HOME\.claude\skills" -Force
```

## 호출 예제

Claude Code에서 `/skills`로 설치 목록을 확인하고, 다음을 입력하세요.

`/finance-infographic CAPM을 11가지 유형 중 적합한 형식으로 학부생용 인포그래픽으로 만들어줘. 수식과 실습 예제 포함.`

## 범위

11가지 원본/확장 디자인 유형, PNG와 SVG 참고 이미지, 금융 자료 QA 규칙, Python 프롬프트 생성기. 자동차 산업 전용 스킬과 별개입니다.
