# finance-infographic · Claude Code Skill

Skill for creating finance/education infographic briefs and production prompts from **11 formats**, with evidence and diagram correctness safeguards.

## Install

Unzip, then copy the `finance-infographic` directory as a single folder:

- **macOS / Linux (global)**: `~/.claude/skills/finance-infographic/`
- **Windows (global)**: `%USERPROFILE%\.claude\skills\finance-infographic\`
- **Per-project**: `<project>/.claude/skills/finance-infographic/`

`SKILL.md` must be at the immediate root of that skill folder. Restart Claude Code if it does not discover an added skill; check version-dependent skill discovery UI/commands.

## Sample prompt

> finance-infographic 스킬로 CAPM과 SML의 관계를 학부생에게 설명하는 16:9 교육용 인포그래픽을 만들어줘. 핵심 공식·수치 예제·출처 및 검증 단계도 포함해줘.

## Standalone CLI

`python scripts/build_prompt.py --list` for all formats. `--type auto` for keyword-based routing (manual review recommended), or `--type 1`–`11` for explicit selection. `--input` reads UTF-8 JSON; `--output` writes prompt. No third-party dependency.

## Why the catalog has provenance labels

Screenshots identify #1, #2, #3, #5. The remaining seven types are original additions by this kit; they are not reconstructed or claimed to be authored by the source account.

## Safety and scope

The script only produces prompts. Visual rendering and integrations require separate tools, permission, datasets, and human review of source authenticity.

## 스타일 이미지 참고

각 유형별 PNG·SVG 11쌍은 `assets/style-reference/`에 있습니다. 이미지/데이터는 **예시**입니다. Obsidian Vault용 배포본은 ZIP 내 `Obsidian-Vault/Finance-Infographic/`를 사용하세요.
