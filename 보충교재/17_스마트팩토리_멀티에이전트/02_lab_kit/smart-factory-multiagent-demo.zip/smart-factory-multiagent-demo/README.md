# 스마트 팩토리 예지보전 — Claude Code 멀티에이전트 시범

설비 이상 감지 → 원인 분석 → 정비 작업지시까지를 서브에이전트 5개가 나눠 맡는 예시다. 합성 데이터로 바로 돌릴 수 있다.

## 1. 시나리오
가공 라인 CNC 4대의 14일치 센서 데이터(진동·온도·전류·rpm)에 두 사건이 숨어 있다.
- **CNC-03**: 10-09부터 스핀들 베어링 마모가 진행 (진짜 이상)
- **CNC-01**: 10-11 14시 진동 단발 튐 (센서 접촉 불량 — 오경보)

에이전트 팀이 둘을 구별하고, 정비이력에서 원인 경로를 찾고, 승인 대기 상태의 작업지시서를 만든다.

## 2. 에이전트 구성

| 단계 | 에이전트 | 역할 | 모델 |
|---|---|---|---|
| 0 | 오케스트레이터 (메인 세션, `CLAUDE.md`) | 분배·분기·재시도·요약 | – |
| 1 | `anomaly-detector` | 데이터 품질 점검, 이상탐지 스크립트 실행 | sonnet |
| 2a | `root-cause-analyst` | 매뉴얼·정비이력 대조, 원인 가설 순위 | opus |
| 2b | `parts-planner` | 부품 재고·리드타임, 정비 시간대 | sonnet |
| 3 | `work-order-writer` | 작업지시서 초안 (승인 대기) | sonnet |
| 4 | `reviewer` | 원자료 재계산, 독립 검토, 승인 의견 | opus |

```mermaid
flowchart LR
    S[센서 CSV] --> A[1 anomaly-detector]
    A --> R[2a root-cause-analyst]
    A --> P[2b parts-planner]
    R --> W[3 work-order-writer]
    P --> W
    W --> V[4 reviewer]
    V -->|반려| W
    V -->|승인·조건부| H[사람 승인]
```

2a와 2b는 서로 기다리지 않으므로 오케스트레이터가 한 메시지에서 동시에 부른다.

## 3. 폴더 구조
```
smart-factory-multiagent-demo/
├── CLAUDE.md                    # 오케스트레이터 지침 (순서·분기·규칙)
├── .claude/agents/              # 서브에이전트 정의 5개
├── data/
│   ├── sensor_cnc_line.csv      # 1,344행 (4대 × 336시간)
│   ├── maintenance_history.csv  # 정비이력 6건
│   └── spare_parts.csv          # 예비품 재고
├── docs/manuals/cnc_spindle_troubleshooting.md
├── scripts/
│   ├── make_synthetic_data.py   # 데이터 재생성 (seed 42)
│   └── detect_anomaly.py        # z-score + 지속성 + 다변량 동조 규칙
└── output/                      # 시범 실행 결과 01~05, run_log.md, 차트
```

## 4. 실행 방법 — 수강생은 프롬프트만 붙여 넣는다
압축을 푼 폴더를 Claude Code로 연 뒤, 아래 프롬프트를 차례로 붙여 넣는다. 설치·실행·파일 열기·오류 해결은 모두 Claude Code가 한다.

**① 준비**
```
이 폴더의 README와 CLAUDE.md를 읽고 실습 준비를 해줘.
필요한 파이썬 패키지(pandas, numpy, matplotlib)를 확인해 없으면 설치하고,
output/에 있는 시범 결과는 output_sample/로 옮겨 둬.
등록된 서브에이전트 5개의 이름과 역할을 표로 보여줘.
```

**② 파이프라인 실행**
```
CLAUDE.md의 예지보전 파이프라인을 처음부터 실행해줘.
2a·2b는 병렬로 부르고, 단계마다 output/에 결과를 남긴 뒤
마지막에 run_log.md와 다섯 줄 요약을 줘.
```

**③ 결과 비교**
```
output/과 output_sample/의 결과를 비교해 줘.
판정·원인 1순위·경보 도달 시점·검토 판정이 같은지 표로 정리하고,
다르면 어느 단계에서 왜 갈렸는지 설명해 줘. 차트도 열어서 보여줘.
```

오류가 나면 메시지를 그대로 두고 "방금 오류를 고치고 다시 실행해줘"라고 입력한다.

## 5. 강의에서 보여줄 지점

| 지점 | 보여주는 것 |
|---|---|
| CNC-01 단발 튐 | 단일 지표 경보의 한계, 다변량 동조로 오경보 거르기 |
| 2a·2b 병렬 호출 | 의존 관계 없는 일은 동시에 — 오케스트레이터의 분배 판단 |
| 원인 vs 가정 작업 분기 | 병렬로 진행하면 생기는 불일치를 오케스트레이터가 다시 맞추는 법 |
| reviewer의 지적 | 직선 외삽 16일 16시 → 2차 추세 16일 08시. 만든 에이전트와 검토 에이전트를 분리하는 이유 |
| "승인 대기" | 실행 권한은 사람에게 — 작업지시 발행·MES 등록은 승인 후 |

## 6. 바꿔 볼 실습
- (프롬프트로 지시) `make_synthetic_data.py`에서 CNC-03 마모를 끄고 CNC-02에 공구 불균형(진동만 rpm 비례 상승)을 심어, 원인 가설이 H2로 바뀌는지 본다
- 생산계획 CSV를 추가하고 `production-scheduler` 에이전트를 2c로 붙인다
- reviewer를 일부러 엄격하게 바꿔 반려 → 재작성 루프를 확인한다
