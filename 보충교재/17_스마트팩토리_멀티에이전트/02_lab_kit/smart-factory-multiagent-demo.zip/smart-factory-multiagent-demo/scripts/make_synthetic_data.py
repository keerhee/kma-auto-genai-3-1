"""합성 데이터 생성기 — 가공 라인 CNC 4대, 14일, 1시간 간격 센서 데이터.

심어 둔 사건
- CNC-03: 9일차부터 스핀들 베어링 마모 (진동·온도·전류가 서서히 상승)
- CNC-01: 11일차 14시 단발 스파이크 1건 (센서 케이블 접촉 불량 — 오경보 판별용)
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

ts = pd.date_range("2026-10-01 00:00", periods=14 * 24, freq="h")
machines = {
    "CNC-01": dict(vib=1.6, temp=48.0, cur=21.0),
    "CNC-02": dict(vib=1.8, temp=50.0, cur=22.5),
    "CNC-03": dict(vib=1.7, temp=49.0, cur=21.8),
    "CNC-04": dict(vib=1.5, temp=47.0, cur=20.5),
}

rows = []
for m, b in machines.items():
    hour = ts.hour.values
    load = np.where((hour >= 8) & (hour < 20), 1.0, 0.85)  # 주간 2교대 부하
    vib = b["vib"] * load + rng.normal(0, 0.08, len(ts))
    temp = b["temp"] + 4 * (load - 0.85) / 0.15 + rng.normal(0, 0.6, len(ts))
    cur = b["cur"] * load + rng.normal(0, 0.35, len(ts))
    rpm = np.where(load == 1.0, 8000, 6800) + rng.normal(0, 40, len(ts))

    if m == "CNC-03":
        start = 8 * 24  # 9일차 00시
        t = np.clip(np.arange(len(ts)) - start, 0, None) / 24.0  # 경과 일수
        vib += 0.12 * t ** 1.6          # 비선형 가속 마모
        temp += 1.1 * t ** 1.3
        cur += 0.18 * t ** 1.2
    if m == "CNC-01":
        i = 10 * 24 + 14  # 11일차 14시
        vib[i] += 4.2      # 단발 스파이크, 온도·전류 변화 없음

    for k in range(len(ts)):
        rows.append([ts[k], m, round(vib[k], 3), round(temp[k], 2),
                     round(cur[k], 2), int(rpm[k])])

df = pd.DataFrame(rows, columns=["timestamp", "machine_id", "vibration_rms_mm_s",
                                 "spindle_temp_c", "motor_current_a", "spindle_rpm"])
df.to_csv(DATA / "sensor_cnc_line.csv", index=False)

maint = pd.DataFrame([
    ["WO-2025-0412", "CNC-02", "2025-08-19", "스핀들 베어링 교체", "진동 5.1 mm/s·온도 68℃까지 상승 후 교체. 원인: 그리스 열화", 9.5, "SKF 7014 ACD/P4A ×2"],
    ["WO-2025-0533", "CNC-03", "2025-08-27", "스핀들 베어링 교체(예방)", "CNC-02 사례 후 동일 모델 예방 교체", 8.0, "SKF 7014 ACD/P4A ×2"],
    ["WO-2026-0105", "CNC-01", "2026-02-11", "진동 센서 케이블 교체", "단발성 진동 튐 반복. 커넥터 산화 확인", 0.5, "M12 센서 케이블"],
    ["WO-2026-0221", "CNC-03", "2026-05-14", "스핀들 그리스 보충", "정기 PM. 보충량 기준 미달 기록", 1.0, "Kluber Isoflex NBU 15"],
    ["WO-2026-0388", "CNC-04", "2026-07-02", "쿨런트 펌프 교체", "유량 저하", 2.0, "쿨런트 펌프 CP-200"],
    ["WO-2026-0417", "CNC-03", "2026-08-20", "정기 PM 연기", "생산 일정으로 그리스 보충 PM 연기(9월→10월 말)", 0.0, "-"],
], columns=["wo_id", "machine_id", "date", "work", "note", "downtime_h", "parts"])
maint.to_csv(DATA / "maintenance_history.csv", index=False)

parts = pd.DataFrame([
    ["SKF 7014 ACD/P4A", "스핀들 앵귤러 베어링", 2, 2, 5],
    ["Kluber Isoflex NBU 15", "스핀들 그리스(카트리지)", 6, 2, 3],
    ["M12 센서 케이블", "진동 센서 케이블", 4, 2, 2],
    ["스핀들 오일 시일 OS-70", "스핀들 시일", 1, 2, 7],
], columns=["part", "description", "on_hand", "reorder_point", "lead_time_days"])
parts.to_csv(DATA / "spare_parts.csv", index=False)

print(df.shape, "rows written")
