"""이상탐지 — 기준구간 z-score + 지속성 규칙 + 다변량 동조 확인.

판정 규칙
1) 기준구간: 첫 7일. 설비별·주야(부하)별 평균·표준편차
2) z > 3 구간(2시간 이하 공백은 이어 붙임)이 3시간 이상 → '지속 이상'
   3시간 미만이지만 z > 5 → '단발'. 그 밖의 z 3~5 단발점은 정상 잡음으로 버림
3) 진동 이상과 같은 시간대에 온도·전류 z > 2 가 동반되면 '다변량 동조'
4) 진동 절대치: 주의 2.8 mm/s, 경보 4.5 mm/s (ISO 10816-3 그룹 2, 강성 기초 구간 준용)
5) 지속 이상 설비는 최근 72시간 진동 추세로 경보선(4.5) 도달 시점을 외삽
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)
plt.rcParams["font.family"] = "Noto Sans CJK KR"
plt.rcParams["axes.unicode_minus"] = False

df = pd.read_csv(ROOT / "data" / "sensor_cnc_line.csv", parse_dates=["timestamp"])
df["shift"] = np.where(df.timestamp.dt.hour.between(8, 19), "day", "night")
base_end = df.timestamp.min() + pd.Timedelta(days=7)
SIG = {"vibration_rms_mm_s": "진동", "spindle_temp_c": "온도", "motor_current_a": "전류"}
WARN, ALARM = 2.8, 4.5

base = df[df.timestamp < base_end].groupby(["machine_id", "shift"])[list(SIG)].agg(["mean", "std"])
for s in SIG:
    mu = df.set_index(["machine_id", "shift"]).index.map(lambda k: base.loc[k, (s, "mean")])
    sd = df.set_index(["machine_id", "shift"]).index.map(lambda k: base.loc[k, (s, "std")])
    df[f"z_{s}"] = (df[s].values - np.array(mu)) / np.array(sd)

results = []
for m, g in df.groupby("machine_id"):
    g = g.sort_values("timestamp").reset_index(drop=True)
    flag = g["z_vibration_rms_mm_s"] > 3
    runs, i = [], 0
    while i < len(g):
        if flag[i]:
            j = i
            while j + 1 < len(g) and flag[j + 1]:
                j += 1
            if runs and i - runs[-1][1] <= 3:   # 공백 2시간 이하 → 병합
                runs[-1] = (runs[-1][0], j)
            else:
                runs.append((i, j))
            i = j + 1
        else:
            i += 1
    for a, b in runs:
        seg = g.loc[a:b]
        dur = b - a + 1
        if dur < 3 and seg.z_vibration_rms_mm_s.max() < 5:
            continue
        co = bool(((seg["z_spindle_temp_c"] > 2) & (seg["z_motor_current_a"] > 2)).mean() > 0.5)
        ev = {
            "machine_id": m,
            "start": str(seg.timestamp.iloc[0]),
            "end": str(seg.timestamp.iloc[-1]),
            "duration_h": int(dur),
            "type": "지속 이상" if dur >= 3 else "단발",
            "multivariate_co_movement": co,
            "max_vibration": round(float(seg.vibration_rms_mm_s.max()), 2),
            "max_temp": round(float(seg.spindle_temp_c.max()), 1),
            "max_z_vib": round(float(seg.z_vibration_rms_mm_s.max()), 1),
        }
        if dur >= 3:
            last = g.tail(72)
            x = (last.timestamp - last.timestamp.iloc[0]).dt.total_seconds() / 3600
            k, c = np.polyfit(x, last.vibration_rms_mm_s, 1)
            now_v = float(np.polyval([k, c], x.iloc[-1]))
            ev["latest_vibration_fit"] = round(now_v, 2)
            ev["trend_mm_s_per_day"] = round(k * 24, 3)
            ev["hours_to_alarm_4_5"] = round((ALARM - now_v) / k, 0) if k > 0 and now_v < ALARM else 0
        results.append(ev)

# 기간 중 끊어진 지속 이상 구간을 설비별로 합쳐 요약
summary = []
for m in df.machine_id.unique():
    ev = [e for e in results if e["machine_id"] == m]
    sustained = [e for e in ev if e["type"] == "지속 이상"]
    spikes = [e for e in ev if e["type"] == "단발"]
    if sustained:
        first = min(e["start"] for e in sustained)
        last_e = max(sustained, key=lambda e: e["end"])
        level = "경보" if last_e["max_vibration"] >= ALARM else ("주의" if last_e["max_vibration"] >= WARN else "관찰")
        summary.append({"machine_id": m, "verdict": "지속 이상", "level": level,
                        "first_detected": first, "co_movement": any(e["multivariate_co_movement"] for e in sustained),
                        "latest": last_e})
    elif spikes:
        summary.append({"machine_id": m, "verdict": "단발 이상(오경보 의심)", "level": "관찰",
                        "events": spikes})
    else:
        summary.append({"machine_id": m, "verdict": "정상", "level": "정상"})

json.dump({"rule": __doc__, "events": results, "summary": summary},
          open(OUT / "anomaly_events.json", "w"), ensure_ascii=False, indent=2)

# 차트 — 설비별 진동, 이상 구간 음영
fig, axes = plt.subplots(2, 1, figsize=(11, 6.2), sharex=True,
                         gridspec_kw={"height_ratios": [3, 2]})
colors = {"CNC-01": "#8a94a6", "CNC-02": "#b9c0cc", "CNC-03": "#c2410c", "CNC-04": "#5b6b85"}
for m, g in df.groupby("machine_id"):
    lw = 2.0 if m == "CNC-03" else 1.0
    axes[0].plot(g.timestamp, g.vibration_rms_mm_s, color=colors[m], lw=lw, label=m)
    axes[1].plot(g.timestamp, g.spindle_temp_c, color=colors[m], lw=lw)
axes[0].axhline(WARN, ls="--", color="#d97706", lw=1)
axes[0].axhline(ALARM, ls="--", color="#b91c1c", lw=1)
axes[0].text(df.timestamp.min(), WARN + 0.08, "주의 2.8", color="#d97706", fontsize=9)
axes[0].text(df.timestamp.min(), ALARM + 0.08, "경보 4.5", color="#b91c1c", fontsize=9)
axes[0].axvspan(df.timestamp.min(), base_end, color="#e5e7eb", alpha=0.5, lw=0)
axes[0].text(df.timestamp.min() + pd.Timedelta(hours=6), 5.7, "기준구간(7일)", fontsize=9, color="#4b5563")
spike = [e for e in results if e["type"] == "단발"]
for e in spike:
    t = pd.Timestamp(e["start"])
    axes[0].annotate(f"{e['machine_id']} 단발 튐\n(온도·전류 동반 없음)", xy=(t, e["max_vibration"]),
                     xytext=(t - pd.Timedelta(days=3.4), 4.85), fontsize=9,
                     arrowprops=dict(arrowstyle="->", color="#4b5563"))
axes[0].set_ylabel("진동 RMS (mm/s)")
axes[0].set_ylim(0.8, 6.3)
axes[0].legend(ncol=4, loc="upper left", bbox_to_anchor=(0.18, 1.0), frameon=False, fontsize=9)
axes[0].set_title("가공 라인 CNC 4대 — 스핀들 진동·온도 (2026-10-01 ~ 10-14)", loc="left", fontsize=12)
axes[1].set_ylabel("스핀들 온도 (℃)")
for ax in axes:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#eef0f3")
fig.tight_layout()
fig.savefig(OUT / "vibration_chart.png", dpi=160)

for s in summary:
    print(s["machine_id"], s["verdict"], s["level"])
