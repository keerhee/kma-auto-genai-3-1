# 예지보전 멀티에이전트 파이프라인 — 오케스트레이터 지침

이 폴더에서 Claude Code 메인 세션은 **오케스트레이터**다. 직접 분석하지 않고, 서브에이전트(`.claude/agents/`)에 일을 나눠 맡기고 결과를 합친다.

## 상황
가공 라인 CNC 4대(CNC-01~04)의 14일치 센서 데이터(2026-10-01 ~ 10-14)를 받았다. 기준 시각은 2026-10-15 00:00이다.

## 실행 순서
```
[1] anomaly-detector
        │
        ├──▶ [2a] root-cause-analyst ─┐   ← 한 메시지에서 두 에이전트를 동시에 호출
        └──▶ [2b] parts-planner ──────┤
                                       ▼
                         [3] work-order-writer
                                       ▼
                         [4] reviewer
                                       ▼
                 [5] 오케스트레이터 요약 → 사람 승인
```

1. **anomaly-detector** → `output/01_anomaly_report.md`
   - 판정이 모두 "정상"이면 여기서 멈추고 요약만 보고한다.
2. **root-cause-analyst**와 **parts-planner**를 병렬로 호출한다 → `02_root_cause.md`, `03_parts_plan.md`
   - 원인 분석의 1순위 원인이 parts-planner가 가정한 작업(베어링 교체)과 다르면, parts-planner를 새 원인으로 한 번 더 부른다.
3. **work-order-writer** → `04_work_order.md`
4. **reviewer** → `05_review.md`
   - 판정이 "반려"면 지적된 담당 에이전트를 다시 불러 고치고 reviewer를 한 번 더 돌린다. 재시도는 최대 2회.
5. 오케스트레이터가 `output/run_log.md`에 단계별 호출·소요·판정을 남기고, 사용자에게 다섯 줄 이내로 요약한다.

## 공통 규칙
- 서브에이전트에게 넘기는 프롬프트에는 입력 파일 경로와 출력 파일 경로를 반드시 적는다. 서브에이전트는 이 대화를 보지 못한다.
- 산출물은 모두 `output/`에 한국어 마크다운으로 쓴다. 수치는 원자료에서 가져온다.
- 작업지시서는 "승인 대기" 상태로만 만든다. 발행·메일 발송·MES 등록은 사람이 승인한 뒤에만 한다.
- 데이터 원본(`data/`)은 수정하지 않는다.
