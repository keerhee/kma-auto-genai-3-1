from webtoon_lib import *

CUTS = [(0, 4), (4, 10.5), (10.5, 17.5), (17.5, 31), (31, 38), (38, 41.5)]
DUR = 41.5
EQ = [f"eq/epNN_{i}.png" for i in (1, 2, 3)]   # latex_png()로 미리 생성

def cut1(t): return title_cut(t, "EP.NN · 제목")

def cut2(t):   # 문제: 네이비 패널 + 문서 카드 + 펭 오해
    s = [bg("#E4ECF6")]
    s.append(punch("상황 제목", 540, 170, 108, fill=BLUE, scale=back(prog(t, 0, .5))))
    inner = ['<rect x="80" y="320" width="920" height="1180" fill="#2B3A5C"/><rect x="80" y="320" width="920" height="1180" fill="url(#dotsW)"/>']
    # ... 문서/카드: translate(540,640) scale(back(prog(t,.4,.5))) 안에 rect + label
    inner.append(penguin(540, 1290, .7, "shock" if t > 2.3 else "worry", sweat=prog(t, 2.3, .4)))
    s.append(panel_frame(80, 320, 920, 1180, "".join(inner), scale=back(prog(t, .05, .45))))
    s.append(bubble(["펭의 오해 1줄", "2줄"], 540, 1700, 900, 230, tail=(-0.3, -1), scale=back(prog(t, 3.1, .45)), size=54))
    return s

def cut3(t):   # 반전
    s = [bg(NAVY, "dotsW")]
    s.append(owl(540, 1120 + (1 - ease_out(prog(t, 0, .5))) * 300, 1.25, blink=(1.6 < t < 1.75), point=t > 3.4))
    s.append(bubble(["부장님 해설 1줄", "2줄"], 540, 330, 1000, 250, tail=(0, 1), scale=back(prog(t, .7, .45)), size=48))
    if t > 3.4: s.append(punch("효과 문구!", 540, 1650, 170, fill=YELLOW, scale=back(prog(t, 3.4, .45)), rot=-5))
    return s

def cut4(t):   # 해설: 차트 → 칩 → 수식 3줄 → 빨간 요약 → 말풍선
    s = [bg(CREAM)]
    s.append(punch("해설 제목", 540, 150, 100, fill=ORANGE, scale=back(prog(t, 0, .45))))
    s.append(f'<g opacity="{ease_out(prog(t,.3,.5))}">' + label("전제 · 가정 숫자 · 손계산 예시", 540, 275, 38, NAVY, 700) + "</g>")
    s.append(f'<rect x="50" y="330" width="980" height="1150" rx="24" fill="#fff" stroke="{NAVY}" stroke-width="8"/>')
    # ... 차트: 막대 높이 = 값*k*ease_out(prog(t, a, .6)), 순차 등장 a=0.5, 1.4, 2.2 ...
    for i, y in enumerate((1040, 1130, 1225)):
        s.append(eq_img(EQ[i], 540, y, ease_out(prog(t, 6.0 + .7 * i, .5))))
    s.append(owl(180, 1730, .45, point=True))
    s.append(bubble(["핵심 한 줄", "2줄"], 650, 1690, 740, 220, tail=(-1.6, 1), scale=back(prog(t, 9.0, .45)), size=48))
    return s

def cut5(t):   # 후속 질문 + 실무 답 + 체크 칩
    s = [bg("#CFE6F2")]
    inner = penguin(310, 1120, .85, "happy" if t > 3.6 else "worry", flap=prog(t, 3.6, 1.0))
    inner += owl(780, 1150, .74, blink=(1.2 < t < 1.35))
    inner += chip("체크: A · B · C", 540, 1480, NAVY, back(prog(t, 4.4, .45)), w=880, size=36)
    s.append(panel_frame(60, 560, 960, 1000, inner, fill="#F7F3EA", scale=back(prog(t, 0, .4))))
    s.append(bubble(["펭 질문", "2줄"], 400, 320, 620, 220, tail=(-0.3, 1), scale=back(prog(t, .4, .4)), size=52))
    if t > 1.6: s.append(bubble(["부장님 실무 답", "2줄"], 540, 1720, 1000, 230, tail=(0.5, -1), scale=back(prog(t, 1.6, .4)), size=46))
    if t > 3.6: s.append(punch("짧은 리액션!", 330, 740, 100, fill="#fff", scale=back(prog(t, 3.6, .4)), rot=-10))
    return s

def cut6(t): return next_cut(t, TEAL, "다음 주제", "한 줄 질문?")

if __name__ == "__main__":
    run([cut1, cut2, cut3, cut4, cut5, cut6], CUTS, DUR, "output/ic_webtoon_epNN.mp4",
        [2.8, 9.9, 17.0, 30.5, 37.5, 41.0])
