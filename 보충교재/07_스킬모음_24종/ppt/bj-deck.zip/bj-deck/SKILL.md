---
name: bj-deck
description: 'bj덱으로 PPT를 만들 때 사용. 크림 배경·골드 좌측 바·네이비 표지/카드의 발제·리뷰형 16:9 덱(python-pptx)에 matplotlib 차트, SVG 인포그래픽, LaTeX 수식 렌더링을 함께 쓴다. "bj덱", "bj덱으로", "bj 스타일"이라는 표현이 나오면 사용한다.'
---

# bj덱 룰북 (v2 · 시각화 레이어 포함)

사용자가 "bj덱", "bj덱으로", "bj 스타일"이라고 하면 이 스킬로 만든다. 기준은 플랫폼국가 세미나 발제 덱(크림+골드+네이비)이다. 산출물은 .pptx, 파일명은 영어로 한다.


> **이 맥에서 돌릴 때 (로컬 패치 2026-09-28):**
> - 파이썬: 시스템 python3에는 python-pptx가 없다. `python-pptx·matplotlib·cairosvg`가 모두 있는
>   `"/Users/keerhee/Project/[2026]연기금 운용전략과 성과평가_강의노트/New_Lecture_with_New_Cases/.venv/bin/python"`으로 실행한다(경로는 따옴표 필수).
> - LaTeX(pdflatex·xelatex)가 설치돼 있지 않다. `render_eq()`는 엔진이 없으면 **matplotlib mathtext로 자동 대체**한다
>   (`_render_eq_mathtext`, `\Big` 류 크기 지정은 제거·`\text{}`는 한글 폰트). 업스트림 zip으로 덮어쓰면 이 대체가 사라진다.
> - PDF 검수는 `soffice`(LibreOffice)와 `pdftoppm`으로 한다.

## 1. 디자인 규격
- 16:9 (13.333 × 7.5in). 폰트는 맑은 고딕(latin·ea 모두 지정)
- 팔레트: NAVY 1B2A41 · GOLD D99A1E · CREAM F6F1E7(본문 배경) · LINE E4E9F0(카드 테두리·표 밴딩) · MUTED 5B6B82 · INK 222222 · PALE DDE3EC · GREY B8C2D1 · 경고 RED B23A2E
- 모든 슬라이드 왼쪽에 골드 세로 바(폭 0.18in). 그림자 없음(effectLst 비움)
- 표지·파트 디바이더: 네이비 배경. 골드 eyebrow → 흰색 대제목(표지 50pt, 디바이더 40pt) → PALE/GREY 부제
- 본문 배치: eyebrow(13pt 굵게 MUTED, 출처 쪽수 등) (0.6, 0.33) → 제목(28pt 굵게 NAVY) (0.6, 0.66) → 내용 영역 y 1.75~6.7 → 출처 줄(10pt MUTED) (0.6, 6.95) → 우하단 쪽번호(11pt)
- 카드: 흰 바탕 + LINE 테두리. 번호 카드는 골드 원(0.55in) + 16pt 굵은 제목 + 본문. 강조 카드는 네이비 바탕(제목 골드, 본문 PALE)
- 표: 헤더는 네이비 바탕에 흰 글씨, 행은 흰색·LINE 교대, 첫 열은 굵은 네이비. 경계 신호 열은 RED 굵게
- 하단 한 줄 결론(punch): 골드 짧은 세로 선 + 16pt 굵은 네이비
- 로고·워드마크·기관명은 넣지 않는다

## 2. 시각화 레이어: 무엇을 무엇으로 그리나
| 콘텐츠 | 도구 | 덱 삽입 |
|---|---|---|
| 데이터 차트(막대·선·산점도·분포) | matplotlib: `mpl_style()` → `save_fig()` | `figure_slide` / `figure_panel` / `image` |
| 구조형 도해(흐름·레이어·비교·타임라인·매트릭스) | SVG: `svg_doc()` → `render_svg()` (cairosvg) | `figure_slide`(WIDE) / `figure_panel`(PANEL) |
| 수식 | LaTeX: `render_eq()` (pdflatex, 한글이 있으면 xelatex) | `eq_card` / `image` |
| 단순 막대·도넛(편집 가능성이 중요할 때) | 네이티브 `bar_chart` / `donut` | 직접 |

원칙
- 수식은 항상 LaTeX로 렌더링한다. 텍스트로 풀어 쓰지 않는다. 식 안의 한글은 `\text{}`에 넣으면 xelatex+Noto Sans CJK KR로 자동 처리된다
- 그림 배경은 올라갈 면의 색으로 굽는다. 슬라이드 위면 CREAM, 흰 카드 위면 WHITE, 네이비 카드 위면 NAVY(글자는 FFFFFF). 투명 PNG를 쓰지 않는다
- matplotlib: 차트 제목은 왼쪽 정렬 굵은 NAVY. 강조 계열 1개만 GOLD, 비교는 GREY, 나머지는 NAVY. 값 레이블을 직접 달고 불필요한 축·격자는 지운다. 전체폭 그림은 figsize (12.1, 4.4), 패널용은 (7.3, 4.9)
- SVG 프리셋: WIDE 1500×600(→ `figure_slide`, `render_svg(width=3000)`), PANEL 1260×700(→ `figure_panel`, width=2520). 본문 글자 WIDE 28px 이상, PANEL 32px 이상, 박스 제목 36~42px 굵게. SVG 안에는 슬라이드 제목을 넣지 않는다. 마지막 카드 오른쪽 끝이 WIDE 1476px, PANEL 1240px 안에 들어오는지 assert로 확인한다
- SVG 한글은 font-family "Noto Sans CJK KR, Malgun Gothic, sans-serif". `&` 같은 기호는 render_svg가 자동으로 이스케이프한다
- svg-infographic 스킬이 있으면 TypePack 선택(process-flow, layer-stack, before-after, decision-matrix, roadmap-timeline 등)과 layout pass 계산 규칙을 따르고, 색만 bj 팔레트로 바꾼다
- 그림 배치는 `image()`가 상자 안에 비율을 유지해(contain) 가운데 놓는다. 그림 때문에 글자가 13pt 아래로 작아지면 캔버스 비율을 고친다

## 3. 글쓰기 규칙
- 표지·디바이더 제목은 격식 있는 명사구로, 본문 제목은 문어체 주장문(30자 이내)으로 쓴다. eyebrow·부제에는 전제·출처·원어를 적는다
- 본문은 최소 13pt(표는 12pt까지), 여유가 있으면 14~16pt로 키운다
- 기본 개념(정의와 "왜") 슬라이드를 앞에 둔다. 케이스·에피소드를 넣는다. 작성자 해석은 출처 줄에 "작성자"로 표시한다
- 현재 사실(정책·수치·일정)은 검색해 확인하고 출처 줄에 기관과 날짜를 적는다
- 투자 리뷰 덱의 표준 흐름: 표지 → 요지(네이비 배너 + 주장/근거/질문 3카드) → 구성 → PART별 디바이더 → 본문 → 실사 질문 → 봐야 할 분야(렌즈) → 모니터링(틀·대시보드 표·이벤트 캘린더) → 종합(매력/우려/권고) → 출처

## 4. 작업 순서
1. 원문을 읽고 슬라이드 목록을 정한다. 슬라이드마다 차트·도해·수식 중 무엇이 필요한지 표시한다
2. `scripts/bj_deck.py`를 작업 폴더로 복사한다. 필요하면 `pip install cairosvg --break-system-packages`
3. 그림을 먼저 굽는다(fig_*.png, eq_*.png). 그다음 build 스크립트에서 슬라이드를 만든다
4. 검수: soffice로 PDF 변환 → pdftoppm 50dpi → 6장씩 몽타주로 본다. 넘침·겹침·줄바꿈(큰 숫자 타일 등)·그림 속 작은 글씨를 고친다. 도넛 데이터 레이블은 LibreOffice에서 안 보일 수 있으니 범례에 %를 넣는다

## 5. 사용 예
```python
from bj_deck import *
D = Deck()
D.cover("eyebrow", "대제목", "부제", "보조 설명", "2026년 9월")
plt = mpl_style()
fig, ax = plt.subplots(figsize=(12.1, 4.4))
b = ax.bar(["A", "B"], [3, 5], color=["#" + GREY, "#" + GOLD]); ax.bar_label(b, fontweight="bold")
save_fig(fig, "fig_bar.png")
D.figure_slide("eyebrow", "주장문 제목", "fig_bar.png", source="출처: ...", punch="한 줄 결론")
inner = '<rect x="24" y="100" width="300" height="380" rx="12" fill="#FFFFFF" stroke="#E4E9F0" stroke-width="3"/>'
render_svg(svg_doc(1500, 600, inner), "fig_flow.png", width=3000)
render_eq(r"D^{LP}_{\text{우선}} = \min\{D,\; C(1+h)^{T}\}", "eq1.png", fontsize=26)            # 흰 카드용
render_eq(r"\sum_t \frac{CF_t}{(1+r)^t}=0", "eq2.png", bg=NAVY, color="FFFFFF")                 # 네이비 카드용
s = D.base("eyebrow", "제목", "출처")
D.eq_card(s, 0.6, 1.75, 6.0, 2.3, "eq1.png", label="① 우선수익", note="기호 설명")
D.save("Output_Name.pptx")
```

## 6. 파일 구성
- `scripts/bj_deck.py` — 라이브러리 전체(Deck 클래스, mpl_style·save_fig·render_eq·render_svg·svg_doc). 작업 폴더로 복사하거나 sys.path에 추가해 import한다
- `examples/build_demo.py` — matplotlib 전체폭, SVG PANEL·WIDE, LaTeX 수식 카드를 한 번씩 쓰는 5장 예제. 새 덱을 만들 때 출발점으로 쓴다
- `examples/sample_preview.png` — 예제 결과 미리보기

주요 API
- `Deck()` → `cover()`, `divider()`, `base(eyebrow, title, source)`, `num_card()`, `title_card()`, `banner()`, `stat()`, `punch()`, `table()`, `bar_chart()`, `donut()`, `image()`, `figure_slide()`, `figure_panel()`, `eq_card()`, `save()`
- `mpl_style()` → plt, `save_fig(fig, path, bg=CREAM)`
- `render_eq(latex, path, fontsize=28, color=NAVY, bg=WHITE)`
- `svg_doc(w, h, inner, bg=CREAM)`, `render_svg(svg, path, width=3000)`
