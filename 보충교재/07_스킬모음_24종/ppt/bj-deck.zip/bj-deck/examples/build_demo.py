import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from bj_deck import *

OUT = "."
D = Deck()
D.cover("bj덱 시각화 레이어 · 샘플", "시각화 샘플 덱", "matplotlib · SVG 인포그래픽 · LaTeX 수식", "Cerberus Supply Chain Fund II 리뷰 데이터로 헬퍼를 시험한 샘플", "2026년 9월")

# 1) matplotlib 전체폭 -------------------------------------------------
plt = mpl_style()
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12.1, 4.4), gridspec_kw={"width_ratios": [1, 1.2]})
yrs, v = ["2020", "2021", "2025", "2026\n(1~5월)"], [1.6, 3.9, 9.6, 14.6]
b = a1.bar(yrs, v, color=["#" + GREY, "#" + GREY, "#" + NAVY, "#" + GOLD], width=0.6)
a1.bar_label(b, fmt="%.1f", fontsize=14, fontweight="bold", color="#" + NAVY, padding=3)
a1.set_title("방산 스타트업 벤처 투자 (십억 달러)", loc="left", color="#" + NAVY)
a1.set_yticks([]); a1.spines["left"].set_visible(False); a1.grid(False)
dom = ["항공우주·방산", "산업재", "핵심광물·전력", "지정학 자산", "데이터테크", "차세대 통신", "바이오", "조선·해양"]
pv = [30, 21, 17, 17, 7, 4, 3, 1]
b2 = a2.barh(dom[::-1], pv[::-1], color=["#" + (GOLD if x == 30 else NAVY) for x in pv[::-1]], height=0.62)
a2.bar_label(b2, labels=[f"{x}%" for x in pv[::-1]], fontsize=13, fontweight="bold", color="#" + NAVY, padding=4)
a2.set_title("Fund I 도메인 비중 (투자원금 %)", loc="left", color="#" + NAVY)
a2.set_xticks([]); a2.spines["bottom"].set_visible(False); a2.grid(False)
fig.tight_layout(w_pad=3)
save_fig(fig, f"{OUT}/fig_mpl.png")
D.figure_slide("matplotlib · figure_slide", "자금은 방산 기술로 몰리고, Fund I은 항공우주·방산에 무게를 뒀다",
               "fig_mpl.png", source="출처: Crunchbase News(2026.6.2); Cerberus 제안서 p.19. 데이터테크 7%는 역산값",
               punch="차트는 크림 배경으로 구워 슬라이드와 이어지게 한다")

# 2) SVG PANEL + figure_panel -------------------------------------------
W, H = 1260, 700
layers = [("정부 · 수요자·보증자", "가격하한 · 오프테이크 · 다년 조달계약", NAVY, "FFFFFF"),
          ("공적 대출 · 대주", "OSC · EXIM · DFC 저리 대출과 보증", "3B5A85", "FFFFFF"),
          ("민간 PE 지분 · 실행자", "Supply Chain Fund II: 경영권·운영 개선", GOLD, "FFFFFF"),
          ("출구 · 전략적 매수자", "프라임 방산 · 빅테크 · IPO · CV", "FFFFFF", NAVY)]
inner = ""
x0, bw, bh, gap, y0 = 40, 1180, 140, 26, 40
for i, (t, sub, fc, tc) in enumerate(layers):
    y = y0 + i * (bh + gap)
    stroke = f' stroke="#{LINE}" stroke-width="3"' if fc == "FFFFFF" else ""
    inner += f'<rect x="{x0}" y="{y}" width="{bw}" height="{bh}" rx="10" fill="#{fc}"{stroke}/>'
    inner += f'<circle cx="{x0+70}" cy="{y+bh/2}" r="34" fill="#{GOLD if fc != GOLD else NAVY}"/>'
    inner += f'<text x="{x0+70}" y="{y+bh/2+13}" text-anchor="middle" font-size="36" font-weight="700" fill="#FFFFFF">{i+1}</text>'
    inner += f'<text x="{x0+135}" y="{y+58}" font-size="40" font-weight="700" fill="#{tc}">{t}</text>'
    inner += f'<text x="{x0+135}" y="{y+108}" font-size="32" fill="#{tc}" opacity="0.92">{sub}</text>'
render_svg(svg_doc(W, H, inner), f"{OUT}/fig_stack.png", width=2520)
D.figure_panel("SVG 인포그래픽 · figure_panel (PANEL 1260×700)", "안보 딜은 네 층의 자본이 함께 움직인다", "fig_stack.png",
               "읽는 법", ["정부는 수요와 하방을 받쳐 준다", "공적 대출이 자본비용을 낮춘다", "PE는 실행과 운영을 맡는다",
                         "출구는 매수자 풀이 좁아 미리 설계한다"], source="작성자 정리")

# 3) SVG WIDE 프로세스 -----------------------------------------------------
W, H = 1500, 600
steps = [("실사·계획", "360도 평가\n가치창출 계획"), ("첫 100일", "시니어 인재 투입\n인센티브 정렬"),
         ("가치창출", "레버 3~5개\n증설·가격·M&A"), ("회수", "전략적 매각\nIPO · 부분 회수")]
inner = ""
cw, gap, x0, y0, ch = 300, 80, 24, 110, 380
for i, (t, sub) in enumerate(steps):
    x = x0 + i * (cw + gap)
    dark = i == 2
    inner += f'<rect x="{x}" y="{y0}" width="{cw}" height="{ch}" rx="12" fill="#{NAVY if dark else "FFFFFF"}" stroke="#{LINE}" stroke-width="3"/>'
    inner += f'<rect x="{x}" y="{y0}" width="{cw}" height="12" fill="#{GOLD}"/>'
    inner += f'<text x="{x+cw/2}" y="{y0-30}" text-anchor="middle" font-size="30" font-weight="700" fill="#{GOLD}">STEP {i+1}</text>'
    inner += f'<text x="{x+cw/2}" y="{y0+110}" text-anchor="middle" font-size="42" font-weight="700" fill="#{"FFFFFF" if dark else NAVY}">{t}</text>'
    for k, ln in enumerate(sub.split("\n")):
        inner += f'<text x="{x+cw/2}" y="{y0+200+k*50}" text-anchor="middle" font-size="32" fill="#{PALE if dark else INK}">{ln}</text>'
    if i < 3:
        ax = x + cw + 8
        inner += f'<line x1="{ax}" y1="{y0+ch/2}" x2="{ax+gap-16}" y2="{y0+ch/2}" stroke="#{GOLD}" stroke-width="6" marker-end="url(#ah)"/>'
assert x0 + 3 * (cw + gap) + cw <= 1476
render_svg(svg_doc(W, H, inner), f"{OUT}/fig_flow.png", width=3000)
D.figure_slide("SVG 인포그래픽 · figure_slide (WIDE 1500×600)", "가치 창출은 네 단계 플레이북으로 표준화했다", "fig_flow.png",
               source="출처: Cerberus 제안서 p.16", punch="SVG 본문 글자는 28px 이상, 박스 제목 36px 이상")

# 4) LaTeX 수식 카드 -------------------------------------------------------
render_eq(r"D^{LP}_{\text{우선}} = \min\!\Big\{D,\; C\,(1+h)^{T}\Big\},\quad h=10\%", f"{OUT}/eq1.png", fontsize=26)
render_eq(r"D^{GP}_{\text{캐치업}} = \frac{c}{1-c}\,\big(D^{LP}_{\text{우선}}-C\big),\quad c=20\%", f"{OUT}/eq2.png", fontsize=26)
render_eq(r"\sum_{t=0}^{T}\frac{CF_t}{(1+r)^{t}} = 0 \;\Rightarrow\; r=\text{IRR}", f"{OUT}/eq3.png", fontsize=26, bg=NAVY, color="FFFFFF")
s = D.base("LaTeX 수식 · eq_card", "분배 워터폴은 세 개의 식으로 요약된다",
           "예시용 단순화(전액 캐치업 가정). 실제 조건은 Fund II LPA의 워터폴 조항으로 확인")
D.eq_card(s, 0.6, 1.75, 6.0, 2.3, f"{OUT}/eq1.png", label="① 우선수익(10%)", note="C: 납입원금, D: 분배 가능액, T: 보유 연수")
D.eq_card(s, 6.8, 1.75, 5.9, 2.3, f"{OUT}/eq2.png", label="② GP 캐치업", note="GP가 전체 이익의 20%에 도달할 때까지")
D.eq_card(s, 0.6, 4.3, 12.1, 2.35, f"{OUT}/eq3.png", label="③ 순 IRR 정의", fill=NAVY, note="수정 미국식 워터폴은 딜 단위로 ①~②를 먼저 적용 → 클로백 조항이 핵심")

D.save(f"{OUT}/bj_visual_sample.pptx")
print("saved", D.n)
