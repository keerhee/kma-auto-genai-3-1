"""bj덱 — 크림 배경 + 골드 좌측 바 + 네이비 카드의 발제형 PPT 룰북 (python-pptx).

팔레트·폰트·좌표는 기준 PPT(플랫폼국가 세미나 발제 덱)에서 추출했다.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.oxml.ns import qn
from lxml import etree

NAVY = "1B2A41"
NAVY2 = "263A57"
GOLD = "D99A1E"
CREAM = "F6F1E7"
LINE = "E4E9F0"
MUTED = "5B6B82"
INK = "222222"
WHITE = "FFFFFF"
PALE = "DDE3EC"
GREY = "B8C2D1"
RED = "B23A2E"
GREEN = "2E7D5B"
FONT = "맑은 고딕"


def rgb(h):
    return RGBColor.from_string(h)


class Deck:
    def __init__(self):
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        self.n = 0

    # ---------- primitives ----------
    def _slide(self, bg=CREAM):
        s = self.prs.slides.add_slide(self.prs.slide_layouts[6])
        fill = s.background.fill
        fill.solid()
        fill.fore_color.rgb = rgb(bg)
        self.n += 1
        return s

    def rect(self, s, x, y, w, h, fill=WHITE, line=None, shape=MSO_SHAPE.RECTANGLE, lw=1.0):
        sh = s.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
        if fill is None:
            sh.fill.background()
        else:
            sh.fill.solid()
            sh.fill.fore_color.rgb = rgb(fill)
        if line:
            sh.line.color.rgb = rgb(line)
            sh.line.width = Pt(lw)
        else:
            sh.line.fill.background()
        # remove theme shadow
        spPr = sh._element.spPr
        spPr.append(etree.SubElement(spPr, qn("a:effectLst")))
        if shape == MSO_SHAPE.ROUNDED_RECTANGLE:
            sh.adjustments[0] = 0.08
        return sh

    def text(self, s, x, y, w, h, paras, size=15, color=INK, bold=False, align="l",
             anchor="t", spacing=1.15, after=6):
        """paras: str | list of str | list of (str, dict) with dict keys size,color,bold,bullet."""
        tb = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Emu(45720)
        tf.margin_top = tf.margin_bottom = Emu(22860)
        tf.vertical_anchor = {"t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}[anchor]
        if isinstance(paras, str):
            paras = [paras]
        first = True
        for p in paras:
            if isinstance(p, tuple):
                t, o = p
            else:
                t, o = p, {}
            para = tf.paragraphs[0] if first else tf.add_paragraph()
            first = False
            para.alignment = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}[o.get("align", align)]
            para.line_spacing = o.get("spacing", spacing)
            para.space_after = Pt(o.get("after", after))
            bullet = o.get("bullet")
            runs = t if isinstance(t, list) else [(t, {})]
            if bullet:
                runs = [(bullet + " ", {"color": o.get("bcolor", GOLD), "bold": True})] + runs
            for rt, ro in runs:
                r = para.add_run()
                r.text = rt
                f = r.font
                f.name = FONT
                f.size = Pt(ro.get("size", o.get("size", size)))
                f.bold = ro.get("bold", o.get("bold", bold))
                f.color.rgb = rgb(ro.get("color", o.get("color", color)))
                rPr = r._r.get_or_add_rPr()
                ea = rPr.find(qn("a:ea"))
                if ea is None:
                    ea = etree.SubElement(rPr, qn("a:ea"))
                ea.set("typeface", FONT)
        return tb

    # ---------- chrome ----------
    def base(self, eyebrow, title, source=None, bg=CREAM):
        s = self._slide(bg)
        self.rect(s, 0, 0, 0.18, 7.5, GOLD)
        if eyebrow:
            self.text(s, 0.6, 0.33, 11.0, 0.4, eyebrow, size=13, color=MUTED, bold=True)
        self.text(s, 0.6, 0.66, 12.2, 0.9, title, size=28, color=NAVY, bold=True)
        self.text(s, 12.2, 7.0, 0.9, 0.35, str(self.n), size=11, color=MUTED, align="r")
        if source:
            self.text(s, 0.6, 6.95, 11.4, 0.45, source, size=10, color=MUTED)
        return s

    def cover(self, eyebrow, title, sub, sub2, date):
        s = self._slide(NAVY)
        self.rect(s, 0, 0, 0.18, 7.5, GOLD)
        self.text(s, 0.9, 1.45, 11.0, 0.5, eyebrow, size=16, color=GOLD, bold=True)
        self.text(s, 0.9, 2.0, 11.8, 1.5, title, size=50, color=WHITE, bold=True)
        self.text(s, 0.9, 3.45, 11.8, 0.8, sub, size=26, color=PALE)
        self.text(s, 0.9, 4.3, 11.8, 1.0, sub2, size=17, color=GREY)
        self.text(s, 0.9, 6.3, 6.0, 0.5, date, size=14, color=GREY)
        return s

    def divider(self, num, title, sub):
        s = self._slide(NAVY)
        self.rect(s, 0, 0, 0.18, 7.5, GOLD)
        self.text(s, 0.9, 2.2, 6, 0.6, f"PART {num}", size=18, color=GOLD, bold=True)
        self.text(s, 0.9, 2.8, 11.5, 1.2, title, size=40, color=WHITE, bold=True)
        self.text(s, 0.9, 4.0, 11.5, 1.0, sub, size=18, color=GREY)
        self.text(s, 12.2, 7.0, 0.9, 0.35, str(self.n), size=11, color=GREY, align="r")
        return s

    # ---------- components ----------
    def oval_num(self, s, x, y, num, d=0.55, fill=GOLD, size=15):
        o = self.rect(s, x, y, d, d, fill, shape=MSO_SHAPE.OVAL)
        tf = o.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.text = str(num)
        r.font.size = Pt(size); r.font.bold = True; r.font.name = FONT; r.font.color.rgb = rgb(WHITE)
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        return o

    def num_card(self, s, x, y, w, h, num, title, body, body_size=15, title_size=16, fill=WHITE):
        self.rect(s, x, y, w, h, fill, LINE)
        tcol = WHITE if fill == NAVY else NAVY
        bcol = PALE if fill == NAVY else INK
        if num is not None:
            self.oval_num(s, x + 0.25, y + 0.25, num)
            self.text(s, x + 0.95, y + 0.22, w - 1.15, 0.65, title, size=title_size, color=tcol, bold=True, anchor="m")
        else:
            self.text(s, x + 0.25, y + 0.22, w - 0.5, 0.65, title, size=title_size, color=GOLD if fill == NAVY else tcol, bold=True, anchor="m")
        self.text(s, x + 0.25, y + 1.0, w - 0.5, h - 1.1, body, size=body_size, color=bcol)

    def title_card(self, s, x, y, w, h, title, body, body_size=14, title_color=NAVY, accent=False, fill=WHITE):
        self.rect(s, x, y, w, h, fill, LINE)
        if accent:
            self.rect(s, x, y, 0.08, h, GOLD)
        tc = GOLD if fill == NAVY else title_color
        bc = PALE if fill == NAVY else INK
        self.text(s, x + 0.25, y + 0.15, w - 0.45, 0.55, title, size=16, color=tc, bold=True)
        self.text(s, x + 0.25, y + 0.7, w - 0.45, h - 0.8, body, size=body_size, color=bc)

    def banner(self, s, x, y, w, h, head, sub=None, head_size=24):
        self.rect(s, x, y, w, h, NAVY)
        paras = [(head, {"size": head_size, "bold": True, "color": WHITE})]
        if sub:
            paras.append((sub, {"size": 14, "color": PALE}))
        self.text(s, x + 0.3, y + 0.1, w - 0.6, h - 0.2, paras, anchor="m")

    def stat(self, s, x, y, w, h, big, label, fill=WHITE, big_color=None, big_size=30, label_size=13):
        self.rect(s, x, y, w, h, fill, LINE)
        bc = big_color or (GOLD if fill == NAVY else NAVY)
        lc = PALE if fill == NAVY else MUTED
        self.text(s, x + 0.2, y + 0.12, w - 0.4, h * 0.55, big, size=big_size, color=bc, bold=True, anchor="b")
        self.text(s, x + 0.2, y + 0.12 + h * 0.55, w - 0.4, h * 0.42, label, size=label_size, color=lc)

    def note(self, s, x, y, w, h, txt, size=14, color=MUTED):
        self.text(s, x, y, w, h, txt, size=size, color=color)

    def punch(self, s, txt, y=6.2):
        """하단 한 줄 결론 — 골드 좌측 선 + 굵은 네이비."""
        self.rect(s, 0.6, y, 0.07, 0.55, GOLD)
        self.text(s, 0.8, y, 11.9, 0.55, txt, size=16, color=NAVY, bold=True, anchor="m")

    def arrow(self, s, x, y, w=0.3, h=0.3, color=GOLD):
        return self.rect(s, x, y, w, h, color, shape=MSO_SHAPE.RIGHT_ARROW)

    def down_arrow(self, s, x, y, w=0.4, h=0.25, color=GOLD):
        return self.rect(s, x, y, w, h, color, shape=MSO_SHAPE.DOWN_ARROW)

    def table(self, s, x, y, w, col_w, rows, size=13, head_size=14, row_h=0.45, first_bold=True,
              band=True, col_align=None, color_cells=None):
        nrows, ncols = len(rows), len(rows[0])
        gt = s.shapes.add_table(nrows, ncols, Inches(x), Inches(y), Inches(w), Inches(row_h * nrows))
        tbl = gt.table
        tot = sum(col_w)
        for j, cw in enumerate(col_w):
            tbl.columns[j].width = Inches(w * cw / tot)
        for i, row in enumerate(rows):
            tbl.rows[i].height = Inches(row_h)
            for j, val in enumerate(row):
                c = tbl.cell(i, j)
                c.margin_left = c.margin_right = Inches(0.1)
                c.margin_top = c.margin_bottom = Inches(0.04)
                c.vertical_anchor = MSO_ANCHOR.MIDDLE
                if i == 0:
                    fill, col, b, sz = NAVY, WHITE, True, head_size
                else:
                    fill = LINE if (band and i % 2 == 0) else WHITE
                    col = NAVY if (j == 0 and first_bold) else INK
                    b = (j == 0 and first_bold)
                    sz = size
                if color_cells and (i, j) in color_cells:
                    col = color_cells[(i, j)]
                    b = True
                c.fill.solid(); c.fill.fore_color.rgb = rgb(fill)
                tf = c.text_frame
                tf.word_wrap = True
                lines = val.split("\n") if isinstance(val, str) else val
                for k, ln in enumerate(lines):
                    p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
                    p.line_spacing = 1.05
                    if col_align and col_align[j] == "c":
                        p.alignment = PP_ALIGN.CENTER
                    r = p.add_run(); r.text = ln
                    r.font.size = Pt(sz); r.font.bold = b; r.font.name = FONT
                    r.font.color.rgb = rgb(col)
                    rPr = r._r.get_or_add_rPr()
                    ea = etree.SubElement(rPr, qn("a:ea")); ea.set("typeface", FONT)
        # plain style id (no theme banding)
        tblPr = tbl._tbl.tblPr
        tblPr.set("firstRow", "1"); tblPr.set("bandRow", "0")
        return gt

    def bar_chart(self, s, x, y, w, h, cats, vals, title=None, colors=None, fmt="0.0", horizontal=False,
                  label_size=13, axis_size=12, maxv=None):
        cd = CategoryChartData()
        cd.categories = cats
        cd.add_series("S", vals)
        ct = XL_CHART_TYPE.BAR_CLUSTERED if horizontal else XL_CHART_TYPE.COLUMN_CLUSTERED
        gf = s.shapes.add_chart(ct, Inches(x), Inches(y), Inches(w), Inches(h), cd)
        ch = gf.chart
        ch.has_legend = False
        ch.font.name = FONT
        ch.font.size = Pt(axis_size)
        ch.font.color.rgb = rgb(INK)
        if title:
            ch.has_title = True
            ch.chart_title.text_frame.text = title
            r = ch.chart_title.text_frame.paragraphs[0].runs[0]
            r.font.size = Pt(13); r.font.bold = True; r.font.color.rgb = rgb(NAVY); r.font.name = FONT
        else:
            ch.has_title = False
        pl = ch.plots[0]
        pl.gap_width = 60
        pl.has_data_labels = True
        dl = pl.data_labels
        dl.number_format = fmt; dl.number_format_is_linked = False
        dl.font.size = Pt(label_size); dl.font.bold = True; dl.font.color.rgb = rgb(NAVY)
        dl.position = XL_LABEL_POSITION.OUTSIDE_END
        ser = pl.series[0]
        ser.format.fill.solid(); ser.format.fill.fore_color.rgb = rgb(NAVY)
        if colors:
            for i, c in enumerate(colors):
                pt = ser.points[i]
                pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(c)
        va = ch.value_axis
        va.has_major_gridlines = False
        va.visible = False
        if maxv:
            va.maximum_scale = maxv
        va.minimum_scale = 0
        ca = ch.category_axis
        ca.format.line.color.rgb = rgb(GREY)
        ca.tick_labels.font.size = Pt(axis_size)
        if horizontal:
            ca.reverse_order = True
        return gf

    def donut(self, s, x, y, w, h, cats, vals, colors, title=None, legend=True, label_size=12):
        cd = CategoryChartData()
        cd.categories = cats
        cd.add_series("S", vals)
        gf = s.shapes.add_chart(XL_CHART_TYPE.DOUGHNUT, Inches(x), Inches(y), Inches(w), Inches(h), cd)
        ch = gf.chart
        ch.font.name = FONT; ch.font.size = Pt(12)
        if title:
            ch.has_title = True
            ch.chart_title.text_frame.text = title
            r = ch.chart_title.text_frame.paragraphs[0].runs[0]
            r.font.size = Pt(13); r.font.bold = True; r.font.color.rgb = rgb(NAVY); r.font.name = FONT
        else:
            ch.has_title = False
        ch.has_legend = legend
        if legend:
            ch.legend.position = XL_LEGEND_POSITION.RIGHT
            ch.legend.include_in_layout = False
            ch.legend.font.size = Pt(12)
        pl = ch.plots[0]
        pl.has_data_labels = True
        dl = pl.data_labels
        dl.number_format = '0"%"'; dl.number_format_is_linked = False
        dl.font.size = Pt(label_size); dl.font.bold = True; dl.font.color.rgb = rgb(WHITE)
        ser = pl.series[0]
        for i, c in enumerate(colors):
            pt = ser.points[i]
            pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(c)
            pt.format.line.color.rgb = rgb(CREAM)
        # hole size
        dn = ch._chartSpace.find(".//" + qn("c:doughnutChart"))
        hs = dn.find(qn("c:holeSize"))
        if hs is None:
            hs = etree.SubElement(dn, qn("c:holeSize"))
        hs.set("val", "55")
        return gf

    # ---------- images & figure slides ----------
    def image(self, s, path, x, y, w, h, align="c"):
        """이미지를 (x,y,w,h) 상자 안에 비율 유지(contain)로 넣는다."""
        from PIL import Image as _I
        iw, ih = _I.open(path).size
        r = iw / ih
        if w / h > r:
            nh, nw = h, h * r
        else:
            nw, nh = w, w / r
        nx = x + (w - nw) / 2 if align == "c" else x
        ny = y + (h - nh) / 2
        return s.shapes.add_picture(path, Inches(nx), Inches(ny), Inches(nw), Inches(nh))

    def figure_slide(self, eyebrow, title, png, source=None, punch=None):
        """전체폭 그림 슬라이드 (matplotlib 12.1x4.4in 또는 SVG WIDE 1500x600)."""
        s = self.base(eyebrow, title, source)
        bottom = 6.1 if punch else 6.75
        self.image(s, png, 0.6, 1.7, 12.1, bottom - 1.7)
        if punch:
            self.punch(s, punch, y=6.25)
        return s

    def figure_panel(self, eyebrow, title, png, head, bullets, source=None, left=True):
        """그림(7.3in) + 설명 패널(4.6in). left=True면 그림이 왼쪽."""
        s = self.base(eyebrow, title, source)
        fx, px = (0.6, 8.1) if left else (5.4, 0.6)
        self.image(s, png, fx, 1.75, 7.3, 4.9)
        self.rect(s, px, 1.75, 4.6, 4.9, NAVY)
        self.text(s, px + 0.25, 1.9, 4.1, 0.5, head, size=16, color=GOLD, bold=True)
        self.text(s, px + 0.25, 2.45, 4.1, 4.1,
                  [(b, {"bullet": "·", "color": WHITE, "after": 10}) for b in bullets], size=15)
        return s

    def eq_card(self, s, x, y, w, h, png, label=None, fill=WHITE, note=None):
        """수식 카드: LaTeX PNG(카드 배경색으로 렌더한 것)를 카드 중앙에."""
        self.rect(s, x, y, w, h, fill, LINE)
        top = y + 0.15
        if label:
            self.text(s, x + 0.25, y + 0.12, w - 0.5, 0.45, label, size=14,
                      color=GOLD if fill == NAVY else MUTED, bold=True)
            top = y + 0.6
        bot = y + h - (0.55 if note else 0.15)
        self.image(s, png, x + 0.3, top, w - 0.6, bot - top)
        if note:
            self.text(s, x + 0.25, y + h - 0.55, w - 0.5, 0.45, note, size=13,
                      color=PALE if fill == NAVY else MUTED)

    def save(self, path):
        self.prs.save(path)


# ====================== 시각화 레이어 ======================
import os, subprocess, tempfile, shutil

KFONT = "Noto Sans CJK KR"          # 렌더 환경 한글 폰트 (없으면 JP/HK로 대체)
SERIES = [NAVY, GOLD, "7C8FA8", "3B5A85", "E7C27A", MUTED, GREY]


def mpl_style():
    """matplotlib를 bj덱 톤으로. 차트 배경은 크림(슬라이드와 동일)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager as fm
    names = {f.name for f in fm.fontManager.ttflist}
    fam = next((n for n in [KFONT, "Malgun Gothic", "Noto Sans CJK JP", "Noto Sans CJK HK", "NanumGothic"] if n in names), "DejaVu Sans")
    plt.rcParams.update({
        "font.family": fam, "axes.unicode_minus": False,
        "font.size": 15, "axes.titlesize": 17, "axes.titleweight": "bold", "axes.labelsize": 15,
        "xtick.labelsize": 14, "ytick.labelsize": 14, "legend.fontsize": 14, "legend.frameon": False,
        "axes.edgecolor": "#" + GREY, "axes.labelcolor": "#" + INK, "text.color": "#" + INK,
        "xtick.color": "#" + INK, "ytick.color": "#" + MUTED,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.color": "#" + LINE, "grid.linewidth": 1.0, "axes.axisbelow": True,
        "axes.prop_cycle": matplotlib.cycler(color=["#" + c for c in SERIES]),
        "figure.facecolor": "#" + CREAM, "axes.facecolor": "#" + CREAM, "savefig.facecolor": "#" + CREAM,
        "figure.dpi": 100, "savefig.dpi": 250, "lines.linewidth": 2.6,
    })
    return plt


def save_fig(fig, path, bg=CREAM):
    """bg: 그림이 올라갈 면의 색 (슬라이드=CREAM, 흰 카드=WHITE, 네이비 카드=NAVY)."""
    fig.patch.set_facecolor("#" + bg)
    for ax in fig.axes:
        ax.set_facecolor("#" + bg)
    fig.savefig(path, bbox_inches="tight", pad_inches=0.12)
    import matplotlib.pyplot as plt
    plt.close(fig)
    return path


def render_eq(latex, path, fontsize=28, color=NAVY, bg=WHITE, dpi=300, display=True):
    """진짜 LaTeX 렌더링 → PNG. bg는 카드 배경색과 맞춘다(투명 대신 동색).
    한글이 있으면 xelatex + fontspec으로 한글 구간만 Noto Sans CJK KR로 감싼다(\\text{} 안에 쓴다)."""
    import re
    korean = bool(re.search(r"[\uac00-\ud7a3]", latex))
    if not shutil.which("xelatex" if korean else "pdflatex"):   # [로컬 패치] TeX 없는 맥 → mathtext
        return _render_eq_mathtext(latex, path, fontsize, color, bg, dpi)
    tmp = tempfile.mkdtemp()
    if korean:
        latex = re.sub(r"([\uac00-\ud7a3][\uac00-\ud7a3\s·]*)", lambda m: "{\\hk " + m.group(1) + "}", latex)
    body = f"$\\displaystyle {latex}$" if display else f"${latex}$"
    pre = "\\usepackage{fontspec}\n\\newfontfamily\\hk{" + KFONT + "}\n" if korean else ""
    tex = ("\\documentclass[border=4pt]{standalone}\n\\usepackage{amsmath,amssymb,bm}\n"
           "\\usepackage[HTML]{xcolor}\n\\usepackage{anyfontsize}\n" + pre +
           "\\begin{document}\n\\pagecolor[HTML]{" + bg + "}\\color[HTML]{" + color + "}\n"
           "{\\fontsize{" + str(fontsize) + "}{" + str(int(fontsize * 1.25)) + "}\\selectfont " + body + "}\n"
           "\\end{document}\n")
    open(os.path.join(tmp, "eq.tex"), "w").write(tex)
    eng = "xelatex" if korean else "pdflatex"
    r = subprocess.run([eng, "-interaction=nonstopmode", "eq.tex"], cwd=tmp, capture_output=True, text=True)
    if not os.path.exists(os.path.join(tmp, "eq.pdf")) or "! " in r.stdout:
        raise RuntimeError("LaTeX 오류: " + r.stdout[-800:])
    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), "-singlefile", "eq.pdf", "eq"], cwd=tmp, check=True)
    from PIL import Image as _I
    im = _I.open(os.path.join(tmp, "eq.png")).convert("RGB")
    im.crop((3, 3, im.width - 3, im.height - 3)).save(path)   # pagecolor 가장자리 헤어라인 제거
    shutil.rmtree(tmp, ignore_errors=True)
    return path


def _render_eq_mathtext(latex, path, fontsize=28, color=NAVY, bg=WHITE, dpi=300):
    """[로컬 패치] LaTeX 엔진이 없을 때 matplotlib mathtext(Computer Modern)로 굽는다.
    \\text{한글}은 \\mathrm{}으로 바꿔 한글 폰트로 그린다. \\displaystyle·\\dfrac 등 일부 명령은 근사한다."""
    import re
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager as fm
    names = {f.name for f in fm.fontManager.ttflist}
    kf = next((n for n in [KFONT, "Noto Sans KR", "Apple SD Gothic Neo", "AppleGothic"] if n in names), "DejaVu Sans")
    s = latex.replace("\\dfrac", "\\frac").replace("\\tfrac", "\\frac").replace("\\displaystyle", "")
    s = re.sub(r"\\(?:text|textrm|mbox)\{", r"\\mathrm{", s)
    s = re.sub(r"\\[Bb]igg?[lr]?(?![a-zA-Z])", "", s)          # \\Big 등 크기 지정은 mathtext에 없다
    s = s.replace("\\bm{", "\\mathbf{").replace("\\boldsymbol{", "\\mathbf{")
    with plt.rc_context({"mathtext.fontset": "custom", "mathtext.rm": kf, "mathtext.it": "cmmi10",
                         "mathtext.bf": kf + ":bold", "mathtext.cal": "cmsy10", "mathtext.sf": kf}):
        fig = plt.figure(figsize=(0.01, 0.01))
        fig.text(0, 0, "$" + s + "$", fontsize=fontsize, color="#" + color)
        fig.savefig(path, dpi=dpi, bbox_inches="tight", pad_inches=0.06, facecolor="#" + bg)
        plt.close(fig)
    return path


def render_svg(svg, path, width=3000):
    """SVG 문자열 또는 파일 경로 → PNG (cairosvg, 2배 해상도).
    pip install cairosvg --break-system-packages 필요.
    SVG 안 한글은 font-family="Noto Sans CJK KR, Malgun Gothic, sans-serif" 로 쓴다."""
    import cairosvg, re
    if not svg.lstrip().startswith("<"):
        svg = open(svg, encoding="utf-8").read()
    svg = re.sub(r"&(?!(amp|lt|gt|quot|apos|#\d+);)", "&amp;", svg)   # M&A 같은 맨 & 자동 이스케이프
    cairosvg.svg2png(bytestring=svg.encode("utf-8"), write_to=path, output_width=width)
    return path


def svg_doc(w, h, inner, bg=CREAM):
    """bj 팔레트 SVG 골격. WIDE=1500x600(figure_slide), PANEL=1260x700(figure_panel·카드)."""
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"
 font-family="Noto Sans CJK KR, Malgun Gothic, sans-serif">
<rect width="{w}" height="{h}" fill="#{bg}"/>
<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
<path d="M0,0 L10,5 L0,10 z" fill="#{GOLD}"/></marker></defs>
{inner}
</svg>"""
