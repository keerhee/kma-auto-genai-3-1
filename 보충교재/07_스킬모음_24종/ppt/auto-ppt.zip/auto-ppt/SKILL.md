---
name: auto-ppt
description: >
  다크 테마 PPT 자동 생성. "다크 PPT", "auto-ppt", "다크 테마 발표자료",
  "dark theme presentation", "다크 슬라이드 만들어줘" 등을 요청할 때 사용.
  템플릿 모듈(generate_ppt_template.py)의 헬퍼 함수를 활용하여 다크 네이비+오렌지 테마의
  .pptx 파일을 생성한다. 라이트 테마 PPT는 /ppt 스킬을 사용할 것.
---

# auto-ppt — PowerPoint 발표자료 자동 생성 스킬

발표 주제, 대상 청중, 발표 시간을 입력받아 **다크 테마 디자인**의 .pptx 파일을 자동 생성한다.

## 워크플로우

### Phase 1: 정보 수집

사용자 입력에서 다음 3가지를 파악한다. 누락된 항목은 합리적 기본값을 사용한다.

| 파라미터 | 필수 | 기본값 |
|----------|------|--------|
| **발표 주제** | O | — |
| **대상 청중** | 선택 | "일반 비즈니스 청중" |
| **발표 시간** | 선택 | 15분 |

### Phase 2: 슬라이드 구조 설계

발표 시간 기준 슬라이드 수:
- **5분**: 5–7장
- **10분**: 8–12장
- **15분**: 12–16장
- **20분**: 16–20장
- **30분+**: 20–30장

#### 표준 슬라이드 구성

1. **타이틀 슬라이드** — 발표 제목, 발표자, 날짜
2. **목차/아젠다** — 전체 흐름 개요 (컬러 번호 블록 + 카드)
3. **섹션 구분** — "SECTION 01" 라벨 + 큰 제목 + 틸 밑줄
4. **본론** (전체의 60%) — 다양한 레이아웃 혼합
5. **결론** (1–2장) — 핵심 요약 카드
6. **Q&A / 감사 슬라이드** — 마무리

### Phase 3: 슬라이드 콘텐츠 생성

각 슬라이드에 포함할 항목:

```
슬라이드 N: [레이아웃 타입]
├── 제목: 슬라이드 제목
├── 핵심 메시지: 이 슬라이드에서 전달할 한 문장
├── 본문: 불릿/카드/차트 등
├── 시각 자료: 차트, 터미널 모의, 비교 테이블 등
└── 발표자 노트: 발표 시 참고할 상세 설명
```

### Phase 4: .pptx 파일 생성

Python `python-pptx` + 템플릿 모듈(`assets/generate_ppt_template.py`)을 사용한다.

#### 생성 규칙

1. **템플릿 모듈을 import**하여 헬퍼 함수 사용
2. **Python 스크립트를 작성하고 실행**하여 .pptx 생성
3. **출력 경로**: 사용자 지정 경로 또는 현재 디렉토리에 `presentation.pptx`

#### 스크립트 작성 패턴

```python
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(".claude", "skills", "auto-ppt", "assets")))
from generate_ppt_template import *

prs = create_presentation()
TOTAL = 25  # 슬라이드 수

# 슬라이드 생성 (헬퍼 함수 사용)
create_title_slide(prs, "제목", "부제")
create_section_slide(prs, "섹션 제목", "부제", section_num=1)
create_content_slide(prs, "제목", ["불릿1", "불릿2"], section_label="SECTION 01")
# ... 등

prs.save("output.pptx")
```

## 디자인 시스템 — 다크 테마

### 색상 팔레트

| 용도 | 색상 | 코드 |
|------|------|------|
| **메인 배경** | 다크 네이비 | `#1B2033` |
| **카드 배경** | 약간 밝은 네이비 | `#242B3F` |
| **코드/입력 배경** | 더 어두운 네이비 | `#171C2C` |
| **주 액센트** | 오렌지 | `#E8760A` |
| **보조 액센트** | 틸/민트 | `#2DD4A8` |
| **블루 액센트** | 블루 | `#3B82F6` |
| **퍼플 액센트** | 퍼플 | `#8B5CF6` |
| **경고/부정** | 레드 | `#EF4444` |
| **긍정** | 그린 | `#22C55E` |
| **기본 텍스트** | 화이트 | `#FFFFFF` |
| **본문 텍스트** | 라이트 그레이 | `#C8D0E0` |
| **보조 텍스트** | 뮤트 그레이 | `#8B95AB` |

### 디자인 원칙

- **다크 배경** — 모든 슬라이드 `#1B2033` 배경, 화이트/라이트 그레이 텍스트
- **오렌지 주 액센트** — 섹션 라벨, 강조 숫자, 주요 데이터
- **틸 보조 액센트** — 섹션 밑줄, 타이틀 구분선
- **"SECTION XX" 라벨** — 좌상단 오렌지 소문자 라벨로 섹션 표시
- **초대형 숫자** — 통계/데이터는 96pt 오렌지 숫자로 강조
- **카드 배경** — `#242B3F`로 구분, 상단 컬러 바로 구별
- **터미널 모의** — 코드 슬라이드는 3색 점 + 다크 배경 + Consolas
- **폰트**: 맑은 고딕 (한글), Consolas (코드)
- **제목 32pt+, 본문 14~19pt**

### 레이아웃 타입 & 헬퍼 함수

| 함수명 | 용도 | 시각적 특징 |
|--------|------|-------------|
| `create_title_slide` | 타이틀 | 큰 흰색 제목 + 틸 밑줄 + 부제 |
| `create_agenda_slide` | 목차 | 컬러 번호 블록 + 카드 배경 + 설명 |
| `create_section_slide` | 섹션 구분 | "SECTION XX" 오렌지 라벨 + 큰 제목 + 틸 밑줄 |
| `create_content_slide` | 제목 + 불릿 | 오렌지 도트 불릿 + 섹션 라벨 |
| `create_big_number_slide` | 초대형 숫자 | 96pt 오렌지 숫자 + 사이드 컬러 바 통계 |
| `create_stat_cards_slide` | 통계 카드 그리드 | 상단 컬러 바 + 큰 숫자 + 라벨 카드 |
| `create_icon_cards_slide` | 아이콘 카드 그리드 | 컬러 원 아이콘 + 제목 + 설명 (2x2 또는 2x3) |
| `create_comparison_table_slide` | 비교 테이블 | 열 헤더 색상 + 그리드 행 데이터 |
| `create_comparison_visual_slide` | VS 비교 | 좌/우 카드 + VS 원 + 체크/엑스 마크 |
| `create_steps_slide` | 프로세스 스텝 | 카드 + 화살표 (STEP 1/2/3) |
| `create_timeline_slide` | 타임라인 | 세로 라인 + 연도 점 + 이벤트 |
| `create_terminal_slide` | 터미널/코드 | 3색 점 + 다크 배경 + Consolas 코드 |
| `create_pie_chart_slide` | 원형 차트 | python-pptx 실제 파이 차트 + 사이드 메시지 |
| `create_bar_chart_slide` | 막대 차트 | python-pptx 실제 바 차트 + 사이드 텍스트 |
| `create_quote_slide` | 인용문 | 큰 따옴표 + 중앙 텍스트 |
| `create_three_column_slide` | 3단 컬럼 | 상단 컬러 바 카드 3개 (초급/중급/고급 등) |
| `create_closing_slide` | 마무리 | 핵심 메시지 카드 + Q&A |

### 슬라이드 타입 선택 가이드

콘텐츠에 따라 적절한 레이아웃을 선택한다:

- **핵심 통계 1개 강조** → `create_big_number_slide` (92%, 32% 등)
- **통계 여러 개 비교** → `create_stat_cards_slide` (4개 카드)
- **기능/항목 나열** → `create_icon_cards_slide` (4~6개 카드)
- **도구/옵션 비교** → `create_comparison_table_slide` (테이블)
- **장단점 대비** → `create_comparison_visual_slide` (VS 카드)
- **프로세스/단계** → `create_steps_slide` (3~5 스텝)
- **역사/진화** → `create_timeline_slide` (세로 타임라인)
- **코드/CLI 시연** → `create_terminal_slide` (터미널 모의)
- **데이터 분포** → `create_pie_chart_slide` (실제 파이 차트)
- **성과/비율** → `create_bar_chart_slide` (실제 막대 차트)
- **카테고리별 분류** → `create_three_column_slide` (3단 컬럼)
- **일반 설명** → `create_content_slide` (불릿 포인트)
- **명언/인용** → `create_quote_slide`

### 핵심 헬퍼

| 함수 | 용도 |
|------|------|
| `create_presentation()` | 16:9 빈 프레젠테이션 생성 |
| `add_section_label(slide, "SECTION 01")` | 좌상단 오렌지 섹션 라벨 |
| `add_notes(slide, "...")` | 발표자 노트 추가 |
| `add_page_number(slide, n, total)` | 우하단 페이지 번호 |
| `add_textbox(slide, ...)` | 범용 텍스트 박스 |
| `add_shape(slide, ...)` | 범용 도형 |
| `THEME["accent_orange"]` 등 | 테마 색상 상수 접근 |

### Phase 5: 자체 검증

생성 완료 후 다음 체크리스트를 검증하고 결과를 사용자에게 보고한다:

- [ ] **파일 생성**: .pptx 파일이 정상적으로 생성되었는가
- [ ] **슬라이드 수**: 발표 시간에 적합한 슬라이드 수인가
- [ ] **구조 완성도**: 타이틀 → 목차 → 섹션 → 본론 → 결론 → 마무리 구조 완비
- [ ] **핵심 메시지**: 각 슬라이드에 명확한 핵심 메시지가 있는가
- [ ] **시각 다양성**: 불릿만 나열하지 않고 차트, 카드, 비교, 터미널 등 혼합
- [ ] **발표자 노트**: 콘텐츠 슬라이드에 발표자 노트 포함
- [ ] **텍스트 분량**: 슬라이드당 텍스트가 과도하지 않은가
- [ ] **일관성**: 다크 테마, 폰트, 색상이 전체적으로 일관적인가
- [ ] **청중 적합성**: 내용의 깊이와 톤이 대상 청중에 맞는가

## 출력

1. **.pptx 파일** — 지정 경로 또는 `./presentation.pptx`
2. **생성 보고서** — 슬라이드 구성 요약 + 검증 체크리스트 결과
3. **Python 스크립트** — `generate_ppt.py` (수정/재실행 가능)

## 주의사항

- 이미지 삽입이 필요한 경우 플레이스홀더 박스와 설명을 넣고, 사용자가 직접 교체하도록 안내
- 차트 데이터가 있으면 `create_pie_chart_slide` / `create_bar_chart_slide`로 실제 차트 생성
- 한글 폰트: 맑은 고딕 (시스템 설치 의존)
- 슬라이드당 텍스트는 최소화하고, 시각적 요소 중심으로 구성
- **불릿 텍스트만 나열하는 슬라이드는 최소화** — 카드, 차트, 비교, 터미널 등 다양한 레이아웃 활용

## Additional Resources

### Reference Files
- **`assets/generate_ppt_template.py`** — 다크 테마 디자인 시스템 구현체. 모든 헬퍼 함수, 색상 상수, 레이아웃 타입 포함
- **`references/,PPT출력 샘플.pdf`** — 디자인 참조 원본 (다크 네이비 + 오렌지 스타일)
