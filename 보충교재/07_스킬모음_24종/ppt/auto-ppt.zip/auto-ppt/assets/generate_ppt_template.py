"""
PPT 자동 생성 템플릿 — 다크 테마 디자인 시스템
참조: PPT출력 샘플.pdf (다크 네이비 + 오렌지 액센트)
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.chart.data import CategoryChartData, ChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
import os
import sys

# ──────────────────────────────────────────────
# 다크 테마 색상 시스템
# ──────────────────────────────────────────────
THEME = {
    # 배경
    "bg_dark":       RGBColor(0x1B, 0x20, 0x33),   # 메인 배경
    "bg_card":       RGBColor(0x24, 0x2B, 0x3F),   # 카드/박스 배경
    "bg_card_alt":   RGBColor(0x2C, 0x35, 0x4A),   # 카드 밝은 버전
    "bg_input":      RGBColor(0x17, 0x1C, 0x2C),   # 코드/입력 배경 (더 어두운)
    # 액센트
    "accent_orange": RGBColor(0xE8, 0x76, 0x0A),   # 주 액센트 (오렌지)
    "accent_teal":   RGBColor(0x2D, 0xD4, 0xA8),   # 보조 액센트 (틸/민트)
    "accent_blue":   RGBColor(0x3B, 0x82, 0xF6),   # 블루 액센트
    "accent_purple": RGBColor(0x8B, 0x5C, 0xF6),   # 퍼플 액센트
    "accent_red":    RGBColor(0xEF, 0x44, 0x44),   # 레드 (경고/비교)
    "accent_green":  RGBColor(0x22, 0xC5, 0x5E),   # 그린 (긍정/비교)
    # 텍스트
    "text_white":    RGBColor(0xFF, 0xFF, 0xFF),
    "text_light":    RGBColor(0xC8, 0xD0, 0xE0),   # 밝은 회색 (본문)
    "text_muted":    RGBColor(0x8B, 0x95, 0xAB),   # 흐린 회색 (부제/보조)
    "text_dark":     RGBColor(0x2C, 0x2C, 0x2C),
    # 구분선
    "border":        RGBColor(0x3A, 0x42, 0x56),
}

# 슬라이드 크기 (16:9 와이드스크린)
SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)

# 공통 여백
MARGIN_LEFT = Inches(0.8)
MARGIN_TOP = Inches(0.6)
CONTENT_WIDTH = Inches(11.733)

# 폰트
FONT_KR = "맑은 고딕"


def create_presentation():
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH
    prs.slide_height = SLIDE_HEIGHT
    return prs


def set_slide_bg(slide, color=None):
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color or THEME["bg_dark"]


def _new_slide(prs):
    """다크 배경의 빈 슬라이드 생성"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide)
    return slide


def add_shape(slide, shape_type, left, top, width, height, fill_color=None, line_color=None):
    shape = slide.shapes.add_shape(shape_type, left, top, width, height)
    if fill_color:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill_color
    else:
        shape.fill.background()
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = Pt(1)
    else:
        shape.line.fill.background()
    return shape


def add_textbox(slide, left, top, width, height, text="", font_size=18,
                font_color=None, bold=False, alignment=PP_ALIGN.LEFT,
                font_name=FONT_KR, anchor=MSO_ANCHOR.TOP):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = font_color or THEME["text_white"]
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = alignment
    return txBox


def add_multiline_textbox(slide, left, top, width, height, lines,
                          font_size=18, font_color=None, bold=False,
                          alignment=PP_ALIGN.LEFT, line_spacing=Pt(8)):
    """여러 줄 텍스트 (각 줄이 개별 paragraph)"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    for i, line in enumerate(lines):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = line
        p.font.size = Pt(font_size)
        p.font.color.rgb = font_color or THEME["text_light"]
        p.font.bold = bold
        p.font.name = FONT_KR
        p.alignment = alignment
        p.space_after = line_spacing
    return txBox


def add_notes(slide, notes_text):
    notes_slide = slide.notes_slide
    notes_slide.notes_text_frame.text = notes_text


def add_page_number(slide, num, total):
    add_textbox(slide, Inches(12.2), Inches(7.05), Inches(1), Inches(0.4),
                text=f"{num} / {total}", font_size=10,
                font_color=THEME["text_muted"],
                alignment=PP_ALIGN.RIGHT)


# ──────────────────────────────────────────────
# 섹션 라벨 ("SECTION 01" 스타일)
# ──────────────────────────────────────────────
def add_section_label(slide, section_text, left=None, top=None):
    """좌상단 섹션 라벨 (오렌지, 작은 대문자)"""
    l = left or MARGIN_LEFT
    t = top or Inches(0.5)
    add_textbox(slide, l, t, Inches(3), Inches(0.35),
                text=section_text, font_size=12,
                font_color=THEME["accent_orange"], bold=True)


# ──────────────────────────────────────────────
# 슬라이드 타입별 생성 함수
# ──────────────────────────────────────────────

def create_title_slide(prs, title, subtitle, presenter="", date=""):
    """타이틀 슬라이드 — 다크 배경, 큰 흰색 제목"""
    slide = _new_slide(prs)

    # 제목 (중앙, 매우 크게)
    title_lines = title.split("\n")
    y = Inches(1.8)
    for line in title_lines:
        add_textbox(slide, Inches(0.8), y, Inches(11.7), Inches(0.9),
                    text=line, font_size=48, font_color=THEME["text_white"],
                    bold=True, alignment=PP_ALIGN.LEFT)
        y += Inches(0.9)

    # 구분선 (틸)
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              MARGIN_LEFT, y + Inches(0.2), Inches(2.5), Pt(4),
              fill_color=THEME["accent_teal"])

    # 부제
    add_textbox(slide, MARGIN_LEFT, y + Inches(0.6), Inches(10), Inches(0.6),
                text=subtitle, font_size=20, font_color=THEME["text_muted"])

    # 발표자 / 날짜
    info_parts = []
    if presenter:
        info_parts.append(presenter)
    if date:
        info_parts.append(date)
    if info_parts:
        add_textbox(slide, MARGIN_LEFT, Inches(6.3), Inches(10), Inches(0.5),
                    text="  |  ".join(info_parts), font_size=14,
                    font_color=THEME["text_muted"])

    return slide


def create_agenda_slide(prs, items, slide_num, total_slides):
    """목차 — 번호 색상 블록 + 제목 + 설명"""
    slide = _new_slide(prs)

    add_textbox(slide, MARGIN_LEFT, Inches(0.5), Inches(10), Inches(0.9),
                text="오늘 다룰 내용", font_size=36,
                font_color=THEME["text_white"], bold=True)

    colors = [
        THEME["accent_orange"],
        THEME["accent_blue"],
        THEME["accent_teal"],
        THEME["accent_purple"],
        THEME["accent_green"],
    ]

    y_start = Inches(1.8)
    item_height = Inches(0.95)

    for i, item in enumerate(items):
        y = y_start + Inches(i * 1.05)
        color = colors[i % len(colors)]

        # 번호 배경 블록
        num_shape = add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                              MARGIN_LEFT, y, Inches(0.85), item_height,
                              fill_color=color)
        tf = num_shape.text_frame
        tf.paragraphs[0].text = f"0{i + 1}" if i < 9 else str(i + 1)
        tf.paragraphs[0].font.size = Pt(20)
        tf.paragraphs[0].font.color.rgb = THEME["text_white"]
        tf.paragraphs[0].font.bold = True
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        tf.word_wrap = False

        # 제목 + 설명 배경
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  Inches(1.85), y, Inches(10.6), item_height,
                  fill_color=THEME["bg_card"])

        # 항목 텍스트
        if isinstance(item, tuple):
            title, desc = item
        else:
            title = item
            desc = ""

        add_textbox(slide, Inches(2.2), y + Inches(0.15), Inches(9.5), Inches(0.4),
                    text=title, font_size=20, font_color=THEME["text_white"],
                    bold=True)
        if desc:
            add_textbox(slide, Inches(2.2), y + Inches(0.5), Inches(9.5), Inches(0.3),
                        text=desc, font_size=13, font_color=THEME["text_muted"])

    add_page_number(slide, slide_num, total_slides)
    return slide


def create_section_slide(prs, section_title, section_subtitle="", section_num=None):
    """섹션 구분 — SECTION XX 라벨 + 큰 제목 + 틸 밑줄"""
    slide = _new_slide(prs)

    # 섹션 라벨
    label = f"SECTION  {section_num:02d}" if section_num else ""
    if label:
        add_textbox(slide, MARGIN_LEFT, Inches(2.0), Inches(4), Inches(0.4),
                    text=label, font_size=14,
                    font_color=THEME["accent_orange"], bold=True)

    # 큰 제목
    add_textbox(slide, MARGIN_LEFT, Inches(2.6), Inches(11), Inches(1.5),
                text=section_title, font_size=44,
                font_color=THEME["text_white"], bold=True)

    # 틸 밑줄
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              MARGIN_LEFT, Inches(4.3), Inches(2.5), Pt(5),
              fill_color=THEME["accent_teal"])

    # 부제
    if section_subtitle:
        add_textbox(slide, MARGIN_LEFT, Inches(4.7), Inches(10), Inches(0.6),
                    text=section_subtitle, font_size=18,
                    font_color=THEME["text_muted"])

    return slide


def create_content_slide(prs, title, bullets, notes="", slide_num=0, total_slides=0,
                         section_label="", subtitle=None):
    """제목 + 불릿 — 다크 배경, 흰색 텍스트"""
    slide = _new_slide(prs)

    # 섹션 라벨
    if section_label:
        add_section_label(slide, section_label)

    title_y = Inches(0.9) if section_label else Inches(0.5)

    # 제목
    add_textbox(slide, MARGIN_LEFT, title_y, CONTENT_WIDTH, Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    if subtitle:
        add_textbox(slide, MARGIN_LEFT, title_y + Inches(0.75), CONTENT_WIDTH, Inches(0.4),
                    text=subtitle, font_size=15, font_color=THEME["text_muted"])

    # 불릿 (도트 포함)
    bullet_y = title_y + Inches(1.3) if subtitle else title_y + Inches(1.0)
    for i, bullet in enumerate(bullets):
        y = bullet_y + Inches(i * 0.85)
        # 도트
        add_shape(slide, MSO_SHAPE.OVAL,
                  MARGIN_LEFT + Inches(0.1), y + Inches(0.12),
                  Inches(0.12), Inches(0.12),
                  fill_color=THEME["accent_orange"])
        # 텍스트
        add_textbox(slide, MARGIN_LEFT + Inches(0.45), y, Inches(11), Inches(0.7),
                    text=bullet, font_size=19, font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_big_number_slide(prs, title, big_number, big_label,
                            side_stats=None, notes="", slide_num=0, total_slides=0,
                            section_label=""):
    """초대형 숫자 강조 — 오렌지 큰 숫자 + 사이드 바"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    # 제목 (큰 볼드)
    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(1.2),
                text=title, font_size=34, font_color=THEME["text_white"], bold=True)

    # 초대형 숫자 (오렌지)
    add_textbox(slide, MARGIN_LEFT, Inches(2.5), Inches(6), Inches(2.5),
                text=big_number, font_size=96,
                font_color=THEME["accent_orange"], bold=True)

    # 숫자 라벨
    add_textbox(slide, MARGIN_LEFT, Inches(5.0), Inches(6), Inches(0.5),
                text=big_label, font_size=16,
                font_color=THEME["text_muted"])

    # 사이드 통계 바
    if side_stats:
        bar_x = Inches(8.5)
        for i, (value, label, color) in enumerate(side_stats):
            y = Inches(2.8) + Inches(i * 1.3)

            # 컬러 좌측 바
            add_shape(slide, MSO_SHAPE.RECTANGLE,
                      bar_x, y, Pt(5), Inches(0.9),
                      fill_color=color)

            # 값 (큰 숫자)
            add_textbox(slide, bar_x + Inches(0.25), y, Inches(1.8), Inches(0.5),
                        text=value, font_size=28,
                        font_color=color, bold=True)

            # 라벨
            add_textbox(slide, bar_x + Inches(2.1), y + Inches(0.05), Inches(2.5), Inches(0.5),
                        text=label, font_size=15,
                        font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_stat_cards_slide(prs, title, stats, notes="", slide_num=0, total_slides=0,
                            section_label="", desc_text=""):
    """통계 카드 그리드 — 큰 숫자 + 라벨 카드"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    n = len(stats)
    card_w = Inches(2.5)
    gap = Inches(0.35)
    total_w = n * card_w + (n - 1) * gap
    start_x = (SLIDE_WIDTH - total_w) / 2

    colors = [THEME["accent_orange"], THEME["accent_teal"],
              THEME["accent_blue"], THEME["accent_purple"]]

    for i, (number, label) in enumerate(stats):
        x = start_x + i * (card_w + gap)
        color = colors[i % len(colors)]

        # 카드 배경
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  x, Inches(2.2), card_w, Inches(2.5),
                  fill_color=THEME["bg_card"])

        # 상단 컬러 바
        add_shape(slide, MSO_SHAPE.RECTANGLE,
                  x, Inches(2.2), card_w, Pt(4),
                  fill_color=color)

        # 숫자
        add_textbox(slide, x, Inches(2.6), card_w, Inches(1.0),
                    text=number, font_size=40,
                    font_color=color, bold=True,
                    alignment=PP_ALIGN.CENTER)

        # 라벨
        add_textbox(slide, x + Inches(0.2), Inches(3.6), card_w - Inches(0.4), Inches(0.8),
                    text=label, font_size=13,
                    font_color=THEME["text_muted"],
                    alignment=PP_ALIGN.CENTER)

    # 하단 설명
    if desc_text:
        add_textbox(slide, Inches(1.5), Inches(5.2), Inches(10.3), Inches(1.8),
                    text=desc_text, font_size=15,
                    font_color=THEME["text_muted"],
                    alignment=PP_ALIGN.CENTER)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_icon_cards_slide(prs, title, cards, notes="", slide_num=0, total_slides=0,
                            section_label=""):
    """아이콘 카드 그리드 (2x3 또는 2x2) — 아이콘 + 제목 + 설명"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    cols = 2 if len(cards) <= 4 else 3
    card_w = Inches(5.5) if cols == 2 else Inches(3.6)
    card_h = Inches(1.2)
    gap_x = Inches(0.5) if cols == 2 else Inches(0.3)
    gap_y = Inches(0.35)
    start_x = Inches(0.8)
    start_y = Inches(2.0)

    for i, (icon, card_title, card_desc, color) in enumerate(cards):
        col = i % cols
        row = i // cols
        x = start_x + col * (card_w + gap_x)
        y = start_y + row * (card_h + gap_y)

        # 카드 배경
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, card_w, card_h,
                  fill_color=THEME["bg_card"], line_color=THEME["border"])

        # 아이콘 원
        icon_shape = add_shape(slide, MSO_SHAPE.OVAL,
                               x + Inches(0.25), y + Inches(0.25),
                               Inches(0.55), Inches(0.55),
                               fill_color=color)
        tf = icon_shape.text_frame
        tf.paragraphs[0].text = icon
        tf.paragraphs[0].font.size = Pt(16)
        tf.paragraphs[0].font.color.rgb = THEME["text_white"]
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        tf.word_wrap = False

        # 제목
        add_textbox(slide, x + Inches(1.0), y + Inches(0.12),
                    card_w - Inches(1.2), Inches(0.35),
                    text=card_title, font_size=15,
                    font_color=THEME["text_white"], bold=True)

        # 설명
        add_textbox(slide, x + Inches(1.0), y + Inches(0.5),
                    card_w - Inches(1.2), Inches(0.6),
                    text=card_desc, font_size=12,
                    font_color=THEME["text_muted"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_comparison_table_slide(prs, title, col_headers, rows,
                                  highlight_col=None,
                                  notes="", slide_num=0, total_slides=0,
                                  section_label=""):
    """비교 테이블 — 열 헤더 색상 + 행 데이터"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    n_cols = len(col_headers)
    first_col_w = Inches(2.2)
    data_col_w = (Inches(10.5) - first_col_w) / (n_cols - 1) if n_cols > 1 else Inches(3)
    row_h = Inches(0.7)
    start_y = Inches(2.0)
    start_x = MARGIN_LEFT + Inches(0.3)

    # 헤더 색상
    header_colors = [THEME["bg_card"]] + [THEME["bg_card"]] * (n_cols - 1)
    if highlight_col is not None and highlight_col < n_cols:
        header_colors[highlight_col] = THEME["accent_orange"]

    # 열 헤더
    for j, header in enumerate(col_headers):
        if j == 0:
            x = start_x
            w = first_col_w
        else:
            x = start_x + first_col_w + (j - 1) * data_col_w
            w = data_col_w

        bg_color = header_colors[j]
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  x, start_y, w - Inches(0.1), row_h,
                  fill_color=bg_color)

        fc = THEME["text_white"]
        add_textbox(slide, x + Inches(0.15), start_y + Inches(0.12),
                    w - Inches(0.4), Inches(0.4),
                    text=header, font_size=16,
                    font_color=fc, bold=True,
                    alignment=PP_ALIGN.CENTER)

    # 데이터 행
    for i, row_data in enumerate(rows):
        y = start_y + (i + 1) * (row_h + Inches(0.1))

        for j, cell in enumerate(row_data):
            if j == 0:
                x = start_x
                w = first_col_w
            else:
                x = start_x + first_col_w + (j - 1) * data_col_w
                w = data_col_w

            # 행 배경 (짝수/홀수)
            bg = THEME["bg_card"] if i % 2 == 0 else THEME["bg_card_alt"]
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                      x, y, w - Inches(0.1), row_h,
                      fill_color=bg)

            # 셀 텍스트 — 특수 마커 처리
            fc = THEME["text_light"]
            cell_text = cell
            if cell.startswith("O "):
                fc = THEME["accent_green"]
            elif cell.startswith("X "):
                fc = THEME["accent_red"]

            align = PP_ALIGN.LEFT if j == 0 else PP_ALIGN.CENTER
            add_textbox(slide, x + Inches(0.15), y + Inches(0.12),
                        w - Inches(0.4), Inches(0.4),
                        text=cell_text, font_size=14,
                        font_color=fc, alignment=align)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_steps_slide(prs, title, steps, notes="", slide_num=0, total_slides=0,
                       section_label=""):
    """3~5 스텝 프로세스 — 카드 + 화살표"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    n = len(steps)
    card_w = Inches(2.8) if n <= 3 else Inches(2.0)
    card_h = Inches(3.2) if n <= 3 else Inches(3.0)
    arrow_w = Inches(0.5)
    total_w = n * card_w + (n - 1) * arrow_w
    start_x = (SLIDE_WIDTH - total_w) / 2
    card_y = Inches(2.3)

    colors = [THEME["accent_blue"], THEME["accent_teal"], THEME["accent_orange"],
              THEME["accent_purple"], THEME["accent_green"]]

    for i, (step_label, step_title, step_desc) in enumerate(steps):
        x = start_x + i * (card_w + arrow_w)
        color = colors[i % len(colors)]

        # 카드 배경
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  x, card_y, card_w, card_h,
                  fill_color=THEME["bg_card"], line_color=THEME["border"])

        # 상단 라벨 (STEP 1 등)
        add_textbox(slide, x, card_y + Inches(0.3), card_w, Inches(0.3),
                    text=step_label, font_size=11,
                    font_color=color, bold=True,
                    alignment=PP_ALIGN.CENTER)

        # 제목
        add_textbox(slide, x, card_y + Inches(0.8), card_w, Inches(0.7),
                    text=step_title, font_size=22 if n <= 3 else 18,
                    font_color=THEME["text_white"], bold=True,
                    alignment=PP_ALIGN.CENTER)

        # 설명
        add_textbox(slide, x + Inches(0.2), card_y + Inches(1.6),
                    card_w - Inches(0.4), Inches(1.2),
                    text=step_desc, font_size=12,
                    font_color=THEME["text_muted"],
                    alignment=PP_ALIGN.CENTER)

        # 화살표 (마지막 제외)
        if i < n - 1:
            arrow_x = x + card_w + Inches(0.05)
            add_textbox(slide, arrow_x, card_y + card_h / 2 - Inches(0.2),
                        arrow_w - Inches(0.1), Inches(0.4),
                        text="\u2192", font_size=24,
                        font_color=THEME["text_muted"],
                        alignment=PP_ALIGN.CENTER)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_timeline_slide(prs, title, items, notes="", slide_num=0, total_slides=0,
                          section_label=""):
    """세로 타임라인 — 연도 + 이벤트"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    n = len(items)
    start_y = Inches(2.2)
    line_x = Inches(3.0)
    item_gap = Inches(1.1)

    # 세로 라인
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              line_x + Inches(0.08), start_y,
              Pt(3), Inches(item_gap * (n - 1) + 0.2),
              fill_color=THEME["border"])

    colors = [THEME["text_muted"], THEME["text_muted"],
              THEME["accent_blue"], THEME["accent_orange"]]

    for i, (year, event) in enumerate(items):
        y = start_y + i * item_gap
        color = colors[min(i, len(colors) - 1)]

        # 점
        add_shape(slide, MSO_SHAPE.OVAL,
                  line_x - Inches(0.04), y,
                  Inches(0.25), Inches(0.25),
                  fill_color=color)

        # 연도 (왼쪽)
        add_textbox(slide, Inches(0.8), y - Inches(0.02), Inches(2.0), Inches(0.4),
                    text=year, font_size=20,
                    font_color=color, bold=True,
                    alignment=PP_ALIGN.RIGHT)

        # 이벤트 (오른쪽)
        add_textbox(slide, Inches(3.6), y - Inches(0.02), Inches(8.5), Inches(0.4),
                    text=event, font_size=18,
                    font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_terminal_slide(prs, title, terminal_lines, notes="", slide_num=0,
                          total_slides=0, section_label=""):
    """터미널/코드 모의 슬라이드"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    # 터미널 창 배경
    term_x = Inches(1.5)
    term_y = Inches(2.0)
    term_w = Inches(10.3)
    term_h = Inches(4.5)

    add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
              term_x, term_y, term_w, term_h,
              fill_color=THEME["bg_input"], line_color=THEME["border"])

    # 터미널 상단 바 (3개 점)
    dot_y = term_y + Inches(0.15)
    dot_colors = [THEME["accent_red"], THEME["accent_orange"], THEME["accent_green"]]
    for j, dc in enumerate(dot_colors):
        add_shape(slide, MSO_SHAPE.OVAL,
                  term_x + Inches(0.3) + Inches(j * 0.3), dot_y,
                  Inches(0.15), Inches(0.15), fill_color=dc)

    # 구분선
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              term_x, term_y + Inches(0.5), term_w, Pt(1),
              fill_color=THEME["border"])

    # 터미널 텍스트
    line_y = term_y + Inches(0.7)
    for line_text, line_color in terminal_lines:
        c = line_color or THEME["text_light"]
        if isinstance(c, str):
            c = THEME.get(c, THEME["text_light"])
        add_textbox(slide, term_x + Inches(0.4), line_y, term_w - Inches(0.8), Inches(0.35),
                    text=line_text, font_size=15,
                    font_color=c, font_name="Consolas")
        line_y += Inches(0.4)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_pie_chart_slide(prs, title, categories, values, colors_hex,
                           key_message="", notes="", slide_num=0, total_slides=0,
                           section_label=""):
    """실제 원형 차트"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    chart_data = ChartData()
    chart_data.categories = categories
    chart_data.add_series("", values)

    chart_frame = slide.shapes.add_chart(
        XL_CHART_TYPE.PIE, Inches(0.8), Inches(2.0), Inches(7.0), Inches(5.0),
        chart_data
    )
    chart = chart_frame.chart
    chart.has_legend = True
    chart.legend.position = XL_LEGEND_POSITION.BOTTOM
    chart.legend.include_in_layout = False
    chart.legend.font.size = Pt(12)
    chart.legend.font.name = FONT_KR
    chart.legend.font.color.rgb = THEME["text_light"]

    plot = chart.plots[0]
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.font.size = Pt(13)
    dl.font.name = FONT_KR
    dl.font.bold = True
    dl.font.color.rgb = THEME["text_white"]
    dl.number_format = '0"%"'
    dl.show_value = True
    dl.show_category_name = False
    dl.show_percentage = False

    for i, hex_c in enumerate(colors_hex):
        pt = plot.series[0].points[i]
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = RGBColor.from_string(hex_c)

    # 차트 배경 투명
    chart.chart_style = 2

    if key_message:
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  Inches(8.5), Inches(2.2), Inches(4.5), Inches(4.5),
                  fill_color=THEME["bg_card"])
        add_textbox(slide, Inches(8.9), Inches(2.6), Inches(3.7), Inches(3.8),
                    text=key_message, font_size=15,
                    font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_bar_chart_slide(prs, title, categories, values, bar_color=None,
                           side_text="", notes="", slide_num=0, total_slides=0,
                           section_label=""):
    """실제 가로 막대 차트"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    chart_data = CategoryChartData()
    chart_data.categories = categories
    chart_data.add_series("", values)

    chart_frame = slide.shapes.add_chart(
        XL_CHART_TYPE.BAR_CLUSTERED,
        Inches(0.8), Inches(2.0), Inches(7.5), Inches(4.8),
        chart_data
    )
    chart = chart_frame.chart
    chart.has_legend = False

    cat_axis = chart.category_axis
    cat_axis.tick_labels.font.size = Pt(13)
    cat_axis.tick_labels.font.name = FONT_KR
    cat_axis.tick_labels.font.color.rgb = THEME["text_light"]
    cat_axis.has_major_gridlines = False
    cat_axis.format.line.color.rgb = THEME["border"]

    val_axis = chart.value_axis
    val_axis.tick_labels.font.size = Pt(11)
    val_axis.tick_labels.font.color.rgb = THEME["text_muted"]
    val_axis.has_major_gridlines = True
    val_axis.major_gridlines.format.line.color.rgb = THEME["border"]
    val_axis.format.line.color.rgb = THEME["border"]

    bc = bar_color or THEME["accent_orange"]
    series = chart.series[0]
    series.format.fill.solid()
    series.format.fill.fore_color.rgb = bc

    plot = chart.plots[0]
    plot.has_data_labels = True
    plot.data_labels.font.size = Pt(13)
    plot.data_labels.font.bold = True
    plot.data_labels.font.color.rgb = THEME["text_white"]
    plot.data_labels.number_format = '0"%"'
    plot.data_labels.show_value = True
    plot.gap_width = 100

    if side_text:
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  Inches(8.8), Inches(2.2), Inches(4.2), Inches(4.5),
                  fill_color=THEME["bg_card"])
        add_textbox(slide, Inches(9.1), Inches(2.6), Inches(3.6), Inches(3.8),
                    text=side_text, font_size=15,
                    font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_comparison_visual_slide(prs, title, left_title, left_items, left_color,
                                    right_title, right_items, right_color,
                                    notes="", slide_num=0, total_slides=0,
                                    section_label=""):
    """VS 비교 (좌/우 카드)"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    col_w = Inches(5.2)
    card_h = Inches(4.8)
    left_x = Inches(0.6)
    right_x = Inches(7.4)

    # 왼쪽 카드
    add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
              left_x, Inches(2.0), col_w, card_h,
              fill_color=THEME["bg_card"], line_color=THEME["border"])

    # 왼쪽 상단 컬러 바
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              left_x, Inches(2.0), col_w, Pt(5),
              fill_color=left_color)

    add_textbox(slide, left_x + Inches(0.3), Inches(2.25), col_w - Inches(0.6), Inches(0.4),
                text=left_title, font_size=18, font_color=left_color, bold=True)

    for i, item in enumerate(left_items):
        y = Inches(2.85) + Inches(i * 0.65)
        add_textbox(slide, left_x + Inches(0.4), y, Inches(0.3), Inches(0.3),
                    text="\u2716", font_size=12, font_color=left_color)
        add_textbox(slide, left_x + Inches(0.8), y, Inches(4.0), Inches(0.5),
                    text=item, font_size=14, font_color=THEME["text_light"])

    # VS
    vs_shape = add_shape(slide, MSO_SHAPE.OVAL,
                         Inches(6.15), Inches(3.8), Inches(1.0), Inches(1.0),
                         fill_color=THEME["accent_orange"])
    tf = vs_shape.text_frame
    tf.paragraphs[0].text = "VS"
    tf.paragraphs[0].font.size = Pt(18)
    tf.paragraphs[0].font.color.rgb = THEME["text_white"]
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER

    # 오른쪽 카드
    add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
              right_x, Inches(2.0), col_w, card_h,
              fill_color=THEME["bg_card"], line_color=THEME["border"])

    add_shape(slide, MSO_SHAPE.RECTANGLE,
              right_x, Inches(2.0), col_w, Pt(5),
              fill_color=right_color)

    add_textbox(slide, right_x + Inches(0.3), Inches(2.25), col_w - Inches(0.6), Inches(0.4),
                text=right_title, font_size=18, font_color=right_color, bold=True)

    for i, item in enumerate(right_items):
        y = Inches(2.85) + Inches(i * 0.65)
        add_textbox(slide, right_x + Inches(0.4), y, Inches(0.3), Inches(0.3),
                    text="\u2714", font_size=12, font_color=right_color)
        add_textbox(slide, right_x + Inches(0.8), y, Inches(4.0), Inches(0.5),
                    text=item, font_size=14, font_color=THEME["text_light"])

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_quote_slide(prs, quote, author="", notes="", slide_num=0, total_slides=0):
    """인용문 슬라이드"""
    slide = _new_slide(prs)

    # 큰 따옴표
    add_textbox(slide, Inches(1.5), Inches(1.5), Inches(1), Inches(1.5),
                text="\u201C", font_size=80,
                font_color=THEME["accent_orange"], bold=True)

    add_textbox(slide, Inches(2.5), Inches(2.5), Inches(8.3), Inches(2.5),
                text=quote, font_size=26,
                font_color=THEME["text_white"],
                alignment=PP_ALIGN.CENTER)

    if author:
        add_textbox(slide, Inches(2.5), Inches(5.2), Inches(8.3), Inches(0.5),
                    text=f"\u2014 {author}", font_size=16,
                    font_color=THEME["text_muted"],
                    alignment=PP_ALIGN.CENTER)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide


def create_closing_slide(prs, title="감사합니다", messages=None, qna=True):
    """마무리 슬라이드"""
    slide = _new_slide(prs)

    add_textbox(slide, MARGIN_LEFT, Inches(0.8), Inches(11), Inches(1.0),
                text=title, font_size=36, font_color=THEME["text_white"], bold=True)

    # 틸 구분선
    add_shape(slide, MSO_SHAPE.RECTANGLE,
              MARGIN_LEFT, Inches(1.8), Inches(2.5), Pt(4),
              fill_color=THEME["accent_teal"])

    if messages:
        colors = [THEME["accent_orange"], THEME["accent_teal"], THEME["accent_purple"]]
        for i, (msg_title, msg_desc) in enumerate(messages):
            y = Inches(2.3) + Inches(i * 1.5)
            color = colors[i % len(colors)]

            # 카드 배경
            add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                      Inches(0.5), y, Inches(12.3), Inches(1.2),
                      fill_color=THEME["bg_card"])

            # 넘버 원
            num_shape = add_shape(slide, MSO_SHAPE.OVAL,
                                  Inches(0.8), y + Inches(0.25),
                                  Inches(0.6), Inches(0.6),
                                  fill_color=color)
            tf = num_shape.text_frame
            tf.paragraphs[0].text = str(i + 1)
            tf.paragraphs[0].font.size = Pt(20)
            tf.paragraphs[0].font.color.rgb = THEME["text_white"]
            tf.paragraphs[0].font.bold = True
            tf.paragraphs[0].alignment = PP_ALIGN.CENTER

            add_textbox(slide, Inches(1.7), y + Inches(0.15),
                        Inches(10.5), Inches(0.45),
                        text=msg_title, font_size=20,
                        font_color=THEME["text_white"], bold=True)

            add_textbox(slide, Inches(1.7), y + Inches(0.6),
                        Inches(10.5), Inches(0.4),
                        text=msg_desc, font_size=14,
                        font_color=THEME["text_muted"])

    if qna:
        add_textbox(slide, Inches(1.5), Inches(6.5), Inches(10.3), Inches(0.5),
                    text="Q & A", font_size=22,
                    font_color=THEME["accent_orange"], bold=True,
                    alignment=PP_ALIGN.CENTER)

    return slide


def create_three_column_slide(prs, title, columns, notes="", slide_num=0,
                              total_slides=0, section_label=""):
    """3단 컬럼 카드 (초급/중급/고급 등)"""
    slide = _new_slide(prs)

    if section_label:
        add_section_label(slide, section_label)

    add_textbox(slide, MARGIN_LEFT, Inches(0.9), Inches(11), Inches(0.8),
                text=title, font_size=32, font_color=THEME["text_white"], bold=True)

    col_w = Inches(3.6)
    col_h = Inches(4.5)
    gap = Inches(0.35)
    start_x = Inches(0.8)

    colors = [THEME["accent_teal"], THEME["accent_blue"], THEME["accent_orange"]]

    for i, (col_title, col_items) in enumerate(columns):
        x = start_x + i * (col_w + gap)
        color = colors[i % len(colors)]

        # 카드 배경
        add_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE,
                  x, Inches(2.0), col_w, col_h,
                  fill_color=THEME["bg_card"], line_color=THEME["border"])

        # 상단 컬러 바
        add_shape(slide, MSO_SHAPE.RECTANGLE,
                  x, Inches(2.0), col_w, Pt(4),
                  fill_color=color)

        # 컬럼 제목
        add_textbox(slide, x, Inches(2.3), col_w, Inches(0.5),
                    text=col_title, font_size=20,
                    font_color=color, bold=True,
                    alignment=PP_ALIGN.CENTER)

        # 아이템들
        for j, item in enumerate(col_items):
            y = Inches(3.0) + Inches(j * 0.75)
            add_textbox(slide, x + Inches(0.3), y, col_w - Inches(0.6), Inches(0.6),
                        text=f'"{item}"', font_size=13,
                        font_color=THEME["text_light"],
                        alignment=PP_ALIGN.CENTER)

    if notes:
        add_notes(slide, notes)
    add_page_number(slide, slide_num, total_slides)
    return slide
