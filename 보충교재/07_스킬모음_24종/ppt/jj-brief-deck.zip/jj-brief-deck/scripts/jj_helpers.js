// jj-brief-deck v1.6 보조 헬퍼 — template.js에 없는 수식·표 헬퍼
// 사용: const { newDeck, C } = require("./template.js");
//       const D = newDeck({...});
//       const H = require("./jj_helpers.js")(D, C, n => `eq/${n}.png`);
//       H.mtable(...); H.ecs(...); H.numEq(...);
module.exports = function (D, C, E) {
  E = E || (n => `eq/${n}.png`);
  // 표 셀에 LaTeX 수식: 셀 값을 {eq:"name"}으로 주면 PNG를 셀 안에 얹는다
  function mtable(s, y, headers, rows, widths, o) {
    o = o || {}; const rh = o.rowH || 0.42, hh = 0.40, tot = widths.reduce((a, b) => a + b, 0);
    const ws = widths.map(w => 9.2 * w / tot), xs = []; let acc = 0.4; ws.forEach(w => { xs.push(acc); acc += w; });
    D.wtable(s, y, headers, rows.map(r => r.map(c => (typeof c === "object" ? "" : c))), widths, o);
    rows.forEach((r, i) => r.forEach((c, j) => { if (typeof c === "object") D.eq(s, E(c.eq),
      { x: xs[j] + 0.08, y: y + hh + i * rh + 0.07, w: ws[j] - 0.16, h: Math.min(rh - 0.14, o.eqH || 0.28), align: "l" }); }));
    return y + hh + rows.length * rh;
  }
  // 수식 카드 적층(전체폭, side 라벨). list = [[eqName, label, h?], ...]. 다음 y를 반환
  function ecs(s, y, list, o) {
    o = o || {}; let yy = y;
    list.forEach(it => { const h = it[2] || o.h || 0.72;
      D.eqCard(s, E(it[0]), { x: 0.4, y: yy, w: 9.2, h, side: true, lw: o.lw || 2.2, label: it[1] }); yy += h + 0.08; });
    return yy;
  }
  // 수치 예제용 작은 수식 카드: 수식 높이를 eqH로 제한(본 수식보다 작게)
  function numEq(s, name, o) {
    D.R(s, o.x, o.y, o.w, o.h, C.white, C.hair);
    if (o.label) { D.R(s, o.x, o.y, o.lw || 2.2, o.h, C.zebra, C.hair); D.R(s, o.x, o.y, 0.06, o.h, C.blue);
      D.T(s, o.label, { x: o.x + 0.14, y: o.y, w: (o.lw || 2.2) - 0.2, h: o.h, fontSize: 12, bold: true, color: C.blue, valign: "middle" }); }
    const lx = o.label ? o.x + (o.lw || 2.2) + 0.15 : o.x + 0.15, lw = o.w - (o.label ? (o.lw || 2.2) + 0.3 : 0.3);
    const eh = Math.min(o.eqH || 0.5, o.h - 0.16);
    D.eq(s, E(name), { x: lx, y: o.y + (o.h - eh) / 2, w: lw, h: eh });
  }
  return { mtable, ecs, numEq };
};
