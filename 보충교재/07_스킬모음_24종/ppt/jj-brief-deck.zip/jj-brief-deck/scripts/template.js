/* jj-brief-deck 룰북 v1.5 템플릿 — 짙은 블루 상단바 + 시각화 헬퍼(img·eq·eqCard·code·source) */
const pptxgen = require("pptxgenjs");

const C = {
  blue: "2563EB", navy: "1E4E8C", ink: "1E293B", body: "333333", muted: "64748B",
  hair: "E5E7EB", zebra: "F8FAFC", tabBg: "F1F5F9", white: "FFFFFF",
  topbar: "1E4E8C",        // 기본 테마 navy: 상단바 짙은 블루 (v1.4)
  coverBg: "16325C",       // 표지·마무리·간지 배경
  dividerNo: "7FB0FF",
  ok: "2E7D4F", okBg: "F0F9F3", okLn: "B8DCC6",
  bad: "C0392B", badBg: "FDF2F2", badLn: "F0C0C0",
  warn: "B7791F", warnBg: "FFF8E8", warnLn: "E8D5A8",
  tint: "EBF5FF", coverSub: "C7D2E5", coverCap: "8A93A8",
};
const F = "맑은 고딕";
const M = 0.40, CW = 9.20, W = 10.0, H = 5.625;
const THEMES = {
  navy: { topbar: "1E4E8C", coverBg: "16325C", dividerNo: "7FB0FF", chip: "2A4A7A" },   // 기본 (v1.4)
  ink:  { topbar: "1A1A2E", coverBg: "1E1E2E", dividerNo: "4E7FE0", chip: "333344" },   // v1.3까지의 검정 테마
};

function newDeck(o) {
  const th = THEMES[o.theme || "navy"]; Object.assign(C, { topbar: th.topbar, coverBg: th.coverBg, dividerNo: th.dividerNo }); C.chip = th.chip;
  const p = new pptxgen();
  const D = { p, title: o.title, sections: o.sections, slides: [] };
  const T = (s, t, op) => s.addText(t, Object.assign({ fontFace: F, color: C.ink, margin: 0 }, op));
  const R = (s, x, y, w, h, fill, line) => s.addShape(p.ShapeType.rect, { x, y, w, h, fill: { color: fill }, line: line ? { color: line, width: 0.5 } : { color: fill, width: 0 } });
  D.T = T; D.R = R;

  D.cover = (c) => {
    const s = p.addSlide(); s.background = { color: C.coverBg }; D.slides.push({ s, num: false });
    R(s, 0, 0, 0.08, H, C.blue);
    T(s, c.kicker, { x: 0.60, y: 0.70, w: 7.0, h: 0.35, fontSize: 13, color: C.coverSub });
    T(s, c.l1, { x: 0.60, y: 1.15, w: 8.4, h: 0.95, fontSize: 40, bold: true, color: C.white });
    T(s, c.l2, { x: 0.60, y: 2.10, w: 8.4, h: 0.60, fontSize: 24, bold: true, color: C.white });
    if (c.sub) T(s, c.sub, { x: 0.60, y: 2.85, w: 8.6, h: 0.40, fontSize: 14, color: C.coverSub });
    (c.chips || []).forEach((t, i) => {
      const x = 0.60 + i * 1.72;
      R(s, x, 3.75, 1.60, 0.40, C.chip);
      T(s, t, { x, y: 3.75, w: 1.60, h: 0.40, fontSize: 12, bold: true, color: C.white, align: "center", valign: "middle" });
    });
    if (c.note) T(s, c.note, { x: 0.60, y: 4.85, w: 6.0, h: 0.30, fontSize: 12, color: C.coverCap });
    return s;
  };

  D.closing = (c) => {
    const s = p.addSlide(); s.background = { color: C.coverBg }; D.slides.push({ s, num: true, dark: true });
    R(s, 0, 0, 0.08, H, C.blue);
    T(s, c.kicker, { x: 0.60, y: 1.20, w: 8.0, h: 0.35, fontSize: 13, color: C.coverSub });
    T(s, c.l1, { x: 0.60, y: 1.65, w: 8.8, h: 1.55, fontSize: 32, bold: true, color: C.white, valign: "top", lineSpacingMultiple: 1.15 });
    if (c.sub) T(s, c.sub, { x: 0.60, y: 3.45, w: 8.6, h: 0.70, fontSize: 14, color: C.coverSub, lineSpacingMultiple: 1.2 });
    if (c.note) T(s, c.note, { x: 0.60, y: 4.85, w: 7.0, h: 0.30, fontSize: 12, color: C.coverCap });
    return s;
  };

  D.slide = (secIdx) => {
    const s = p.addSlide(); s.background = { color: C.white }; D.slides.push({ s, num: true, secIdx });
    R(s, 0, 0, W, 0.50, C.topbar);
    T(s, D.title, { x: 0.40, y: 0, w: 7.5, h: 0.50, fontSize: 12, bold: true, color: C.white, valign: "middle" });
    const n = D.sections.length, tw = W / n;
    D.sections.forEach((t, i) => {
      const on = i === secIdx;
      R(s, i * tw, 0.50, tw, 0.30, on ? C.blue : C.tabBg);
      T(s, t, { x: i * tw, y: 0.50, w: tw, h: 0.30, fontSize: 12, bold: on, color: on ? C.white : C.muted, align: "center", valign: "middle" });
    });
    return s;
  };

  const units = (t) => { let u = 0; for (const ch of t) { const c = ch.charCodeAt(0); u += (c >= 0xAC00 && c <= 0xD7A3) || (c >= 0x3000 && c <= 0x9FFF) ? 1.0 : ch === " " ? 0.32 : 0.56; } return u * 1.06; };
  D.fit = (t, w, max, min) => { const fs = Math.floor((w * 72 / units(t)) * 2) / 2; return Math.max(min, Math.min(max, fs)); };
  D.head = (s, eyebrow, title, sub) => {
    T(s, eyebrow, { x: 0.40, y: 0.95, w: 9.2, h: 0.26, fontSize: 12.5, color: C.blue, bold: true });
    R(s, 0.40, 1.27, 0.06, 0.36, C.blue);
    const fs = D.fit(title, 8.9, 22, 17); if (fs === 17 && units(title) * 17 / 72 > 8.9) console.warn("[title] 17pt에도 넘침:", title);
    T(s, title, { x: 0.56, y: 1.24, w: 9.0, h: 0.42, fontSize: fs, bold: true, color: C.ink, valign: "middle" });
    if (sub) { T(s, sub, { x: 0.40, y: 1.72, w: 9.2, h: 0.30, fontSize: 12.5, color: C.muted, valign: "middle" }); return 2.12; }
    return 1.85;
  };

  D.banner = (s, y, text, note) => {
    const h = note ? 0.62 : 0.45;
    R(s, 0.40, y, 9.20, h, C.tint);
    T(s, text, { x: 0.50, y, w: 9.0, h: note ? 0.40 : h, fontSize: 13, bold: true, color: C.blue, valign: "middle" });
    if (note) T(s, note, { x: 0.50, y: y + 0.36, w: 9.0, h: 0.24, fontSize: 12, color: C.muted, valign: "middle" });
  };

  D.rowCards = (s, y, rows, o) => {
    o = o || {}; const h = o.h || 0.62, gap = o.gap || 0.10, lw = o.labelW || 1.10, mw = o.midW || 0;
    rows.forEach((r, i) => {
      const ry = y + i * (h + gap); const col = r.color || C.blue;
      R(s, 0.40, ry, 9.20, h, i % 2 ? C.white : C.zebra, C.hair);
      R(s, 0.40, ry, 0.06, h, col);
      T(s, r.label, { x: 0.58, y: ry, w: lw, h, fontSize: 13.5, bold: true, color: col, valign: "middle" });
      let tx = 0.58 + lw + 0.10, tw = 9.20 - lw - 0.40;
      if (r.mid) { T(s, r.mid, { x: tx, y: ry, w: mw, h, fontSize: 12.5, bold: true, color: C.ink, valign: "middle" }); tx += mw + 0.10; tw -= mw + 0.10; }
      T(s, r.text, { x: tx, y: ry, w: tw, h, fontSize: 12.5, color: C.body, valign: "middle" });
    });
    return y + rows.length * (h + gap) - gap;
  };

  D.numCards = (s, y, items, o) => {
    o = o || {}; const cols = o.cols || 3, h = o.h || 1.30, gap = 0.15, w = (9.20 - gap * (cols - 1)) / cols;
    items.forEach((it, i) => {
      const x = 0.40 + (i % cols) * (w + gap), yy = y + Math.floor(i / cols) * (h + gap);
      R(s, x, yy, w, h, C.white, C.hair);
      T(s, it.no, { x: x + 0.20, y: yy + 0.12, w: 1.0, h: 0.42, fontSize: 24, bold: true, color: C.blue });
      T(s, it.title, { x: x + 0.20, y: yy + 0.58, w: w - 0.40, h: 0.30, fontSize: 13.5, bold: true, color: C.ink, valign: "middle" });
      s.addShape(p.ShapeType.line, { x: x + 0.20, y: yy + 0.92, w: w - 0.40, h: 0, line: { color: C.hair, width: 0.5 } });
      T(s, it.desc, { x: x + 0.20, y: yy + 0.96, w: w - 0.40, h: h - 1.02, fontSize: 12, color: C.muted, valign: "top" });
    });
    return y + Math.ceil(items.length / cols) * (h + gap) - gap;
  };

  D.headCards = (s, y, items, o) => {
    o = o || {}; const n = items.length, gap = 0.15, w = (9.20 - gap * (n - 1)) / n, h = o.h || 2.42;
    items.forEach((it, i) => {
      const x = 0.40 + i * (w + gap); const hc = it.dim ? C.navy : C.blue;
      R(s, x, y, w, h, C.white, C.hair);
      R(s, x, y, w, 0.36, hc);
      T(s, it.head, { x, y, w, h: 0.36, fontSize: 12.5, bold: true, color: C.white, align: "center", valign: "middle" });
      T(s, it.big, { x: x + 0.15, y: y + 0.44, w: w - 0.30, h: 0.62, fontSize: 15, bold: true, color: C.ink, valign: "middle", lineSpacingMultiple: 1.1 });
      T(s, it.desc, { x: x + 0.15, y: y + 1.10, w: w - 0.30, h: it.badge ? h - 1.62 : h - 1.20, fontSize: 12, color: C.body, valign: "top", lineSpacingMultiple: 1.15 });
      if (it.badge) {
        R(s, x + 0.15, y + h - 0.46, w - 0.30, 0.32, C.tint);
        T(s, it.badge, { x: x + 0.15, y: y + h - 0.46, w: w - 0.30, h: 0.32, fontSize: 12, bold: true, color: C.blue, align: "center", valign: "middle" });
      }
    });
    return y + h;
  };

  D.compareCols = (s, y, L, Rr, o) => {
    o = o || {}; const rh = o.rowH || 0.66, n = Math.max(L.items.length, Rr.items.length);
    T(s, L.head, { x: 1.45, y, w: 3.55, h: 0.36, fontSize: 12.5, bold: true, color: C.white, align: "center", valign: "middle", fill: { color: C.muted } });
    T(s, Rr.head, { x: 5.55, y, w: 4.05, h: 0.36, fontSize: 12.5, bold: true, color: C.white, align: "center", valign: "middle", fill: { color: C.blue } });
    for (let i = 0; i < n; i++) {
      const ry = y + 0.45 + i * (rh + 0.08);
      R(s, 0.40, ry, 9.20, rh, i % 2 ? C.white : C.zebra, C.hair);
      const lab = (o.labels || [])[i] || "";
      T(s, lab, { x: 0.45, y: ry, w: 0.95, h: rh, fontSize: 12.5, bold: true, color: C.ink, align: "center", valign: "middle" });
      T(s, "✕", { x: 1.50, y: ry, w: 0.30, h: rh, fontSize: 12.5, bold: true, color: C.bad, align: "center", valign: "middle" });
      T(s, L.items[i] || "", { x: 1.82, y: ry, w: 3.20, h: rh, fontSize: 12.5, color: C.body, valign: "middle" });
      T(s, "▶", { x: 5.12, y: ry, w: 0.30, h: rh, fontSize: 12, color: C.muted, align: "center", valign: "middle" });
      T(s, "✓", { x: 5.50, y: ry, w: 0.30, h: rh, fontSize: 12.5, bold: true, color: C.ok, align: "center", valign: "middle" });
      T(s, Rr.items[i] || "", { x: 5.82, y: ry, w: 3.75, h: rh, fontSize: 12.5, color: C.body, valign: "middle" });
    }
    return y + 0.45 + n * (rh + 0.08) - 0.08;
  };

  const tone = (t) => ({ blue: [C.blue, C.tint, "BFDBFE"], ok: [C.ok, C.okBg, C.okLn], bad: [C.bad, C.badBg, C.badLn], warn: [C.warn, C.warnBg, C.warnLn], gray: [C.muted, C.zebra, C.hair] }[t || "blue"]);
  D.panel = (s, x, y, w, h, o) => {
    const [fg, bg, ln] = tone(o.tone);
    R(s, x, y, w, h, bg, ln);
    T(s, o.title, { x: x + 0.18, y: y + 0.12, w: w - 0.36, h: 0.32, fontSize: 13, bold: true, color: fg, valign: "middle" });
    if (o.text) T(s, o.text, { x: x + 0.18, y: y + 0.50, w: w - 0.36, h: h - 0.62, fontSize: o.fs || 13, color: C.body, valign: "top", lineSpacingMultiple: 1.2 });
    if (o.bullets) o.bullets.forEach((b, i) => {
      const by = y + 0.50 + i * (o.rowH || 0.34);
      T(s, "•", { x: x + 0.18, y: by, w: 0.20, h: 0.30, fontSize: 13, color: fg, valign: "middle" });
      T(s, b, { x: x + 0.40, y: by, w: w - 0.58, h: 0.30, fontSize: o.fs || 13, color: C.body, valign: "middle" });
    });
  };
  D.dualPanel = (s, y, h, L, Rr) => { D.panel(s, 0.40, y, 4.50, h, L); D.panel(s, 5.10, y, 4.50, h, Rr); return y + h; };

  D.headPanels = (s, y, h, L, Rr) => {
    [[0.40, L, C.blue], [5.10, Rr, C.navy]].forEach(([x, it, hc]) => {
      R(s, x, y, 4.50, h, C.white, C.hair);
      R(s, x, y, 4.50, 0.36, hc);
      T(s, it.head, { x, y, w: 4.50, h: 0.36, fontSize: 12.5, bold: true, color: C.white, align: "center", valign: "middle" });
      T(s, it.quote, { x: x + 0.18, y: y + 0.46, w: 4.14, h: 0.62, fontSize: 14, bold: true, color: C.ink, valign: "middle", lineSpacingMultiple: 1.1 });
      s.addShape(p.ShapeType.line, { x: x + 0.18, y: y + 1.12, w: 4.14, h: 0, line: { color: C.hair, width: 0.5 } });
      it.items.forEach((b, i) => {
        const by = y + 1.20 + i * 0.34;
        T(s, "•", { x: x + 0.18, y: by, w: 0.20, h: 0.30, fontSize: 13, color: hc, valign: "middle" });
        T(s, b, { x: x + 0.40, y: by, w: 3.92, h: 0.30, fontSize: 12.5, color: C.body, valign: "middle" });
      });
      if (it.foot) T(s, it.foot, { x: x + 0.18, y: y + h - 0.42, w: 4.14, h: 0.32, fontSize: 12.5, bold: true, color: hc, valign: "middle" });
    });
    return y + h;
  };

  D.wtable = (s, y, headers, rows, widths, o) => {
    o = o || {}; const rh = o.rowH || 0.46, hh = 0.40, tot = widths.reduce((a, b) => a + b, 0);
    const ws = widths.map(w => 9.20 * w / tot); const xs = []; let acc = 0.40; ws.forEach(w => { xs.push(acc); acc += w; });
    R(s, 0.40, y, 9.20, hh, C.blue);
    headers.forEach((h, j) => T(s, h, { x: xs[j] + 0.08, y, w: ws[j] - 0.16, h: hh, fontSize: 12, bold: true, color: C.white, valign: "middle", align: j ? "left" : "left" }));
    rows.forEach((r, i) => {
      const ry = y + hh + i * rh;
      R(s, 0.40, ry, 9.20, rh, i % 2 ? C.white : C.zebra, C.hair);
      r.forEach((c, j) => {
        const emph = o.emph && o.emph[i] && o.emph[i][j];
        T(s, c, { x: xs[j] + 0.08, y: ry, w: ws[j] - 0.16, h: rh, fontSize: o.fs || 12.5, bold: j === 0 || !!emph, color: emph ? C.blue : (j === 0 ? C.ink : C.body), valign: "middle" });
      });
    });
    return y + hh + rows.length * rh;
  };

  D.statCards = (s, y, items, o) => {
    o = o || {}; const n = items.length, gap = 0.13, w = (9.20 - gap * (n - 1)) / n, h = o.h || 1.15;
    items.forEach((it, i) => {
      const x = 0.40 + i * (w + gap); const inv = it.invert;
      R(s, x, y, w, h, inv ? C.blue : C.white, inv ? C.blue : C.hair);
      T(s, it.big, { x, y: y + 0.08, w, h: 0.55, fontSize: 21, bold: true, color: inv ? C.white : C.blue, align: "center", valign: "middle" });
      T(s, it.label, { x, y: y + 0.63, w, h: 0.25, fontSize: 12.5, bold: true, color: inv ? C.white : C.ink, align: "center", valign: "middle" });
      T(s, it.cap, { x, y: y + 0.87, w, h: 0.22, fontSize: 12, color: inv ? "DBEAFE" : C.muted, align: "center", valign: "middle" });
    });
    return y + h;
  };

  D.stepFlow = (s, y, steps, o) => {
    o = o || {}; const n = steps.length, gap = 0.30, w = (9.20 - gap * (n - 1)) / n, h = o.h || 2.60;
    steps.forEach((st, i) => {
      const x = 0.40 + i * (w + gap); const last = i === n - 1;
      R(s, x, y, w, h, last ? C.tint : C.white, last ? "BFDBFE" : C.hair);
      T(s, st.step, { x: x + 0.15, y: y + 0.12, w: w - 0.30, h: 0.26, fontSize: 12, bold: true, color: C.blue });
      T(s, st.title, { x: x + 0.15, y: y + 0.40, w: w - 0.30, h: 0.34, fontSize: 13.5, bold: true, color: C.ink, valign: "middle" });
      st.items.forEach((b, k) => {
        const by = y + 0.82 + k * 0.36;
        T(s, "•", { x: x + 0.15, y: by, w: 0.18, h: 0.32, fontSize: 12.5, color: C.blue, valign: "middle" });
        T(s, b, { x: x + 0.35, y: by, w: w - 0.50, h: 0.32, fontSize: 12.5, color: C.body, valign: "middle" });
      });
      if (!last) T(s, "▶", { x: x + w, y: y + h / 2 - 0.2, w: gap, h: 0.4, fontSize: 14, color: C.blue, align: "center", valign: "middle" });
    });
    return y + h;
  };

  D.numRows = (s, y, rows, o) => {
    o = o || {}; const h = o.h || 0.52, lw = o.labelW || 1.60;
    rows.forEach((r, i) => {
      const ry = y + i * (h + 0.06);
      R(s, 0.40, ry, 9.20, h, i % 2 ? C.white : C.zebra, C.hair);
      s.addShape(p.ShapeType.ellipse, { x: 0.52, y: ry + (h - 0.34) / 2, w: 0.34, h: 0.34, fill: { color: C.blue }, line: { color: C.blue, width: 0 } });
      T(s, String(i + 1), { x: 0.52, y: ry + (h - 0.34) / 2, w: 0.34, h: 0.34, fontSize: 12, bold: true, color: C.white, align: "center", valign: "middle" });
      T(s, r.label, { x: 0.98, y: ry, w: lw, h, fontSize: 13, bold: true, color: C.ink, valign: "middle" });
      T(s, r.text, { x: 0.98 + lw + 0.10, y: ry, w: 9.20 - lw - 0.80, h, fontSize: 12.5, color: C.body, valign: "middle" });
    });
    return y + rows.length * (h + 0.06) - 0.06;
  };

  D.plainCards = (s, y, items, o) => {
    o = o || {}; const n = items.length, gap = 0.15, w = (9.20 - gap * (n - 1)) / n, h = o.h || 1.72;
    items.forEach((it, i) => {
      const x = 0.40 + i * (w + gap);
      R(s, x, y, w, h, C.white, C.hair);
      R(s, x, y, w, 0.36, it.dim ? C.navy : C.blue);
      T(s, it.head, { x, y, w, h: 0.36, fontSize: 12.5, bold: true, color: C.white, align: "center", valign: "middle" });
      T(s, it.text, { x: x + 0.12, y: y + 0.42, w: w - 0.24, h: h - 0.50, fontSize: 13, bold: !!it.bold, color: C.ink, align: "center", valign: "middle", lineSpacingMultiple: 1.2 });
    });
    return y + h;
  };

  D.noteBox = (s, y, label, text, o) => {
    o = o || {}; const h = o.h || 0.84, lw = o.labelW || 1.50;
    R(s, 0.40, y, 9.20, h, C.zebra, C.hair);
    R(s, 0.40, y, lw, h, C.blue);
    T(s, label, { x: 0.40, y, w: lw, h, fontSize: 13, bold: true, color: C.white, align: "center", valign: "middle" });
    T(s, text, { x: 0.40 + lw + 0.18, y, w: 9.20 - lw - 0.36, h, fontSize: 12.5, color: C.body, valign: "middle", lineSpacingMultiple: 1.2 });
    return y + h;
  };

  D.image = (s, path, ratio, o) => {
    o = o || {}; const top = o.y, bot = o.bottom || 4.85; const availW = o.w || 9.20, availH = bot - top;
    let w = availW, h = w / ratio; if (h > availH) { h = availH; w = h * ratio; }
    const x = (o.x != null ? o.x : 0.40) + (availW - w) / 2;
    if (o.frame) R(s, x, top + (availH - h) / 2, w, h, C.white, C.hair);
    s.addImage({ path, x, y: top + (availH - h) / 2, w, h });
    return top + (availH - h) / 2 + h;
  };

  D.divider = (c) => {
    const s = p.addSlide(); s.background = { color: C.coverBg }; D.slides.push({ s, num: true, dark: true });
    R(s, 0, 0, 0.08, H, C.blue);
    T(s, c.no, { x: 0.60, y: 1.10, w: 3.0, h: 1.30, fontSize: 80, bold: true, color: C.dividerNo });
    T(s, c.sec, { x: 0.60, y: 2.50, w: 8.0, h: 0.35, fontSize: 13, color: C.coverSub });
    T(s, c.title, { x: 0.60, y: 2.90, w: 8.8, h: 0.80, fontSize: 30, bold: true, color: C.white, valign: "middle" });
    if (c.sub) T(s, c.sub, { x: 0.60, y: 3.80, w: 8.6, h: 0.50, fontSize: 14, color: C.coverSub });
    return s;
  };

  D.bullets = (s, x, y, w, items, o) => {
    o = o || {}; const rh = o.rowH || 0.34;
    items.forEach((b, i) => {
      T(s, "•", { x, y: y + i * rh, w: 0.20, h: rh, fontSize: o.fs || 12.5, color: C.blue, valign: "middle" });
      T(s, b, { x: x + 0.22, y: y + i * rh, w: w - 0.22, h: rh, fontSize: o.fs || 12.5, color: o.color || C.body, valign: "middle" });
    });
    return y + items.length * rh;
  };

  D.labeledBullets = (s, x, y, items, o) => {
    o = o || {}; const rh = o.rowH || 0.40, lw = o.labelW || 1.40, w = o.w || 4.50;
    items.forEach((it, i) => {
      const ry = y + i * rh;
      T(s, "•", { x, y: ry, w: 0.20, h: rh, fontSize: 12.5, color: C.blue, valign: "middle" });
      T(s, it.label, { x: x + 0.22, y: ry, w: lw, h: rh, fontSize: 12.5, bold: true, color: C.ink, valign: "middle" });
      T(s, it.text, { x: x + 0.22 + lw, y: ry, w: w - lw - 0.22, h: rh, fontSize: 12.5, color: C.body, valign: "middle" });
    });
    return y + items.length * rh;
  };

  D.matrix2x2 = (s, y, q, o) => {
    o = o || {}; const gap = 0.12, w = (9.20 - gap) / 2, h = 1.16;
    const cells = [[0.40, y], [0.40 + w + gap, y], [0.40, y + h + gap], [0.40 + w + gap, y + h + gap]];
    q.forEach((c, i) => {
      const [x, yy] = cells[i]; const hot = c.hot;
      R(s, x, yy, w, h, hot ? C.tint : C.white, hot ? "BFDBFE" : C.hair);
      T(s, c.title, { x: x + 0.15, y: yy + 0.10, w: w - 0.30, h: 0.32, fontSize: 13, bold: true, color: hot ? C.blue : C.ink, valign: "middle" });
      T(s, c.text, { x: x + 0.15, y: yy + 0.44, w: w - 0.30, h: h - 0.52, fontSize: 12, color: C.body, valign: "top", lineSpacingMultiple: 1.15 });
    });
    const ay = y + 2 * h + gap + 0.04;
    if (o.top) T(s, o.top, { x: 0.40, y: y - 0.30, w: 9.20, h: 0.26, fontSize: 12, color: C.muted, align: "center" });
    if (o.bl) T(s, o.bl, { x: 0.40, y: ay, w: w, h: 0.26, fontSize: 12, color: C.muted, align: "center" });
    if (o.br) T(s, o.br, { x: 0.40 + w + gap, y: ay, w: w, h: 0.26, fontSize: 12, color: C.muted, align: "center" });
    return ay + 0.30;
  };

  // ---------- v1.5 시각화 헬퍼 ----------
  const fs_ = require("fs");
  const pngSize = (path) => { const b = fs_.readFileSync(path); return [b.readUInt32BE(16), b.readUInt32BE(20)]; };
  D.pngRatio = (path) => { const [w, h] = pngSize(path); return w / h; };
  // 그림(matplotlib·SVG PNG·원본 그림)을 PNG 실제 비율로 얹는다. o: {y,bottom,w,x,frame}
  D.img = (s, path, o) => D.image(s, path, D.pngRatio(path), o);
  // 수식 PNG를 상자(x,y,w,h) 안에 비율 유지로 넣는다. align:"l"이면 왼쪽 정렬
  D.eq = (s, path, o) => {
    const r = D.pngRatio(path); let hh = o.h, ww = hh * r; if (ww > o.w) { ww = o.w; hh = ww / r; }
    const x = o.align === "l" ? o.x : o.x + (o.w - ww) / 2;
    s.addImage({ path, x, y: o.y + (o.h - hh) / 2, w: ww, h: hh }); return o.y + o.h;
  };
  // 수식 카드. 기본은 위 라벨형, side:true면 왼쪽 라벨 칸(lw) + 오른쪽 수식(권장 — 수식이 가장 크게 보인다)
  D.eqCard = (s, path, o) => {
    R(s, o.x, o.y, o.w, o.h, C.white, C.hair);
    if (o.side) {
      const lw = o.lw || 2.2;
      R(s, o.x, o.y, lw, o.h, C.zebra, C.hair); R(s, o.x, o.y, 0.06, o.h, C.blue);
      T(s, o.label || "", { x: o.x + 0.14, y: o.y, w: lw - 0.2, h: o.h, fontSize: 12, bold: true, color: C.blue, valign: "middle" });
      return D.eq(s, path, { x: o.x + lw + 0.15, y: o.y + 0.08, w: o.w - lw - 0.3, h: o.h - 0.16 });
    }
    let top = o.y + 0.08;
    if (o.label) { T(s, o.label, { x: o.x + 0.15, y: o.y + 0.06, w: o.w - 0.3, h: 0.28, fontSize: 12, bold: true, color: C.blue, valign: "middle" }); top = o.y + 0.36; }
    const bot = o.y + o.h - (o.note ? 0.34 : 0.08);
    D.eq(s, path, { x: o.x + 0.2, y: top, w: o.w - 0.4, h: bot - top });
    if (o.note) T(s, o.note, { x: o.x + 0.15, y: o.y + o.h - 0.34, w: o.w - 0.3, h: 0.30, fontSize: 12, color: C.muted, valign: "middle" });
    return o.y + o.h;
  };
  // 코드 블록(어두운 상자 + Consolas 12pt). 한 줄 60자 이내로 쓴다
  D.code = (s, x, y, w, h, lines) => {
    R(s, x, y, w, h, C.ink);
    T(s, lines.map((l, i) => ({ text: l, options: { breakLine: i < lines.length - 1 } })), { x: x + 0.12, y: y + 0.08, w: w - 0.24, h: h - 0.16, fontFace: "Consolas", fontSize: 12, color: "E2E8F0", valign: "top" });
  };
  // 출처 줄(하단 5.30). 배너는 5.25 위에서 끝나게 둔다
  D.source = (s, text) => T(s, text, { x: 0.40, y: 5.30, w: 8.0, h: 0.24, fontSize: 12, color: C.muted, valign: "middle" });

  D.save = async (path) => {
    const total = D.slides.length;
    D.slides.forEach((it, i) => {
      if (!it.num) return;
      if (it.dark) T(it.s, `${i + 1} / ${total}`, { x: 8.40, y: 5.15, w: 1.20, h: 0.30, fontSize: 12, color: C.coverCap, align: "right" });
      else T(it.s, `${i + 1} / ${total}`, { x: 8.40, y: 0, w: 1.20, h: 0.50, fontSize: 12, color: C.white, align: "right", valign: "middle" });
    });
    await p.writeFile({ fileName: path }); console.log("saved", path, total, "slides");
  };
  return D;
}
module.exports = { newDeck, C };
