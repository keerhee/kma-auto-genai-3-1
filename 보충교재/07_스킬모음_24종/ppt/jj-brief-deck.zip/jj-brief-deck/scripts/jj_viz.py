"""jj_viz — JJ 덱용 시각화 레이어 (v1.5).

수식: render_eq()  — 진짜 LaTeX(pdflatex, 한글이 있으면 xelatex+Noto Sans CJK KR) → PNG
차트: mpl_style() + save_fig() — JJ 팔레트 matplotlib, 흰 배경
도해: svg_doc() + render_svg() — JJ 팔레트 SVG → PNG(cairosvg)

필요: texlive(pdflatex·xelatex·standalone), poppler(pdftoppm), matplotlib,
      pip install cairosvg --break-system-packages
"""
import os, re, shutil, subprocess, tempfile

INK, BLUE, NAVY = "1E293B", "2563EB", "1E4E8C"
MUTED, HAIR, GREY = "64748B", "E5E7EB", "94A3B8"
OK, BAD, AMBER, WHITE, ZEBRA = "2E7D4F", "C0392B", "B7791F", "FFFFFF", "F8FAFC"
SERIES = [NAVY, BLUE, "93C5FD", AMBER, OK, GREY]
KFONT = "Noto Sans CJK KR"


def render_eq(latex, path, fontsize=24, color=INK, bg=WHITE, dpi=300, display=True):
    """LaTeX 수식 → PNG. bg는 올라갈 카드 색(JJ 카드는 흰색). 한글은 \\text{} 안에 쓴다.
    큰 합·적분 기호가 카드 높이를 잡아먹으면 \\sum\\nolimits_i 처럼 nolimits로 납작하게 만든다."""
    tmp = tempfile.mkdtemp()
    korean = bool(re.search(r"[\uac00-\ud7a3]", latex))
    if korean:
        latex = re.sub(r"([\uac00-\ud7a3][\uac00-\ud7a3\s·]*)", lambda m: "{\\hk " + m.group(1) + "}", latex)
    body = f"$\\displaystyle {latex}$" if display else f"${latex}$"
    pre = "\\usepackage{fontspec}\n\\newfontfamily\\hk{" + KFONT + "}\n" if korean else ""
    tex = ("\\documentclass[border=4pt]{standalone}\n\\usepackage{amsmath,amssymb,bm}\n"
           "\\usepackage[HTML]{xcolor}\n\\usepackage{anyfontsize}\n" + pre +
           "\\begin{document}\n\\pagecolor[HTML]{" + bg + "}\\color[HTML]{" + color + "}\n"
           "{\\fontsize{" + str(fontsize) + "}{" + str(int(fontsize * 1.25)) + "}\\selectfont " + body + "}\n"
           "\\end{document}\n")
    open(os.path.join(tmp, "eq.tex"), "w").write(tex)
    eng = "xelatex" if korean else "pdflatex"
    r = subprocess.run([eng, "-interaction=nonstopmode", "eq.tex"], cwd=tmp, capture_output=True, text=True)
    if not os.path.exists(os.path.join(tmp, "eq.pdf")) or "! " in r.stdout:
        raise RuntimeError("LaTeX 오류: " + r.stdout[-800:])
    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), "-singlefile", "eq.pdf", "eq"], cwd=tmp, check=True)
    from PIL import Image
    im = Image.open(os.path.join(tmp, "eq.png")).convert("RGB")
    im.crop((3, 3, im.width - 3, im.height - 3)).save(path)
    shutil.rmtree(tmp, ignore_errors=True)
    return path


def mpl_style():
    """JJ 팔레트 matplotlib. 슬라이드에 거의 실제 크기로 얹으므로 글자 12pt 이상.
    전체폭 그림 figsize=(9.2, 2.8~3.0), 반폭 패널 (4.6, 3.0)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager as fm
    names = {f.name for f in fm.fontManager.ttflist}
    fam = next((n for n in [KFONT, "Malgun Gothic", "Noto Sans CJK JP", "NanumGothic"] if n in names), "DejaVu Sans")
    plt.rcParams.update({
        "font.family": fam, "axes.unicode_minus": False, "font.size": 12,
        "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlecolor": "#" + INK,
        "axes.edgecolor": "#" + GREY, "axes.labelcolor": "#" + INK, "xtick.color": "#" + INK, "ytick.color": "#" + MUTED,
        "xtick.labelsize": 12, "ytick.labelsize": 12, "legend.fontsize": 12, "legend.frameon": False,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#" + HAIR,
        "axes.axisbelow": True, "axes.prop_cycle": matplotlib.cycler(color=["#" + c for c in SERIES]),
        "figure.facecolor": "white", "axes.facecolor": "white", "savefig.dpi": 260, "lines.linewidth": 2.2,
    })
    return plt


def save_fig(fig, path):
    import matplotlib.pyplot as plt
    fig.savefig(path, bbox_inches="tight", pad_inches=0.06, facecolor="white")
    plt.close(fig)
    return path


def svg_doc(w, h, inner, bg=WHITE):
    """JJ 팔레트 SVG 골격. 전체폭 WIDE 1500×600, 반폭 PANEL 1000×700 권장. 본문 28px 이상."""
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"
 font-family="Noto Sans CJK KR, Malgun Gothic, sans-serif">
<rect width="{w}" height="{h}" fill="#{bg}"/>
<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
<path d="M0,0 L10,5 L0,10 z" fill="#{BLUE}"/></marker></defs>
{inner}
</svg>"""


def render_svg(svg, path, width=3000):
    """SVG 문자열 → PNG. 맨 & 는 자동 이스케이프. 아래첨자 유니코드(ᵢ 등)는 폰트에 없으니 쓰지 않는다."""
    import cairosvg
    svg = re.sub(r"&(?!(amp|lt|gt|quot|apos|#\d+);)", "&amp;", svg)
    cairosvg.svg2png(bytestring=svg.encode("utf-8"), write_to=path, output_width=width)
    return path
