---
name: jj-brief-deck
description: 짙은 블루 상단바 + 섹션 탭 칩 + 블루 accent bar + 연블루 하단 배너의 "설명자료형(브리핑형)" PPT 덱 룰북. "JJ 덱", "JJ 브리프", "jj-brief", "설명자료 PPT", "정책 설명자료", "도입 설명자료", "보고용 브리핑 덱", "섹션 탭 칩 슬라이드", "한 장 요약 슬라이드", "2×2 위치 판정 슬라이드" 등의 표현이나, 이런 골격의 기준 PPT를 첨부하며 "이 스타일로"라고 하면 반드시 사용한다. 수식은 항상 LaTeX 렌더링 PNG로 넣고, 이해를 돕는 곳에는 matplotlib 차트·SVG 도해를 넣는다(scripts/jj_viz.py). 수식·이론 강의는 본편·특별 세션·워크북 3덱 체계로 만든다. pptxgenjs 기반 단일 파일 출력.
---

# JJ Brief Deck — 룰북 v1.6 (3덱 강의 체계 · 방법별 1장 · 수식 텍스트 금지 · 짙은 블루 테마)

> **v1.6 (위험 기반 자산배분 본편 I→VI, 60장으로 검증하며 갱신):** ① **수식·이론 강의는 3덱 체계로 만든다** — 본편(수식·스토리·결과), 특별 세션(도출·증명·알고리즘·실습), 워크북(손계산·수치 과정). 본편에서 손계산은 "오히려 진행을 방해"하므로 결과만 쓰고 번호로 참조한다(§9). ② **방법론·모형이 바뀌면 슬라이드도 바뀐다** — 한 장에 방법 하나, eyebrow와 제목에 방법 이름(§9.3). ③ **제목·부제·표·패널에도 수식 텍스트를 쓰지 않는다** — 표 안 수식은 `mtable`로 셀에 LaTeX PNG를 얹고, 부제·불릿은 말로 풀어 쓴다(§9.4). ④ **수치 예제 수식은 작게**(`numEq`, 수식 높이 상한), 수식 적층은 `ecs`(§10). ⑤ 원본 자료를 "모두 넣으라"는 요청은 **원본 항목 체크리스트**로 대조한다(§9.5). ⑥ 질의응답에서 나온 설명은 **장난감 예제 한 장**으로 덱에 흡수한다(§9.6). ⑦ 끝에 **사용법 장**(코드 상자 + Claude 프롬프트)을 둔다(§9.7). ⑧ 개정은 덮어쓰지 않고 II·III·IV…로 판을 올린다.

> **v1.5 (리스크 패리티·최대분산 통합 덱 76장으로 검증하며 갱신):** ① **수식은 항상 LaTeX 렌더링 PNG로 넣는다.** 텍스트로 풀어 쓴 수식은 금지한다(§8). ② **시각화 레이어를 추가했다** — 데이터는 matplotlib, 구조·흐름은 SVG, 수식은 LaTeX로 굽는 표와 규칙(§8), 파이썬 도구 `scripts/jj_viz.py`. ③ **수식 중심 자료를 더 이상 적용 제외로 보내지 않는다.** 설명형 구성(주장 제목·섹션 탭·배너)에 수식·손계산을 얹는 강의 설명자료도 이 스킬로 만든다. ④ 템플릿 헬퍼 5개 추가: `D.img`(PNG 비율 자동), `D.eq`, `D.eqCard`(옆 라벨형 `side:true` 권장), `D.code`, `D.source`. ⑤ 페이지 번호를 12pt로 올려 폰트 하한 검사에 걸리지 않게 했다.

> **v1.4 (TPA 실무 덱으로 검증하며 갱신):** ① **상단바·표지 색을 검정 계열에서 짙은 블루로 바꿨다.** 사용자가 "페이지 탑은 검정이 아니라 짙은 블루"를 요청했고, 기준 덱(KCI 중간보고)의 골격은 그대로 두되 색만 바꾸는 것이 맞았다. `newDeck({theme:"navy"})`가 **기본값**이고, 이전 검정 톤은 `theme:"ink"`로 남겨 두었다. ② **제목 자동 축소.** 22pt 제목이 한 줄에 안 들어가면 17pt까지 줄이고, 그래도 넘치면 빌드 로그에 경고를 찍는다(제목을 32자 이내로 고쳐 쓴다). ③ **`D.image` 헬퍼**를 추가했다 — matplotlib 차트·SVG 도해·LaTeX 수식 PNG를 비율 유지·중앙정렬로 얹는다. ④ `scripts/template.js`를 이 환경에서 실제로 돌아가는 구현으로 교체하고, `scripts/build_demo.js`는 모든 헬퍼를 한 번씩 쓰는 28장 덱(TPA 프레임 실무자료)으로 바꿨다. ⑤ 용어 원칙을 §3-9에 한 줄 보탰다 — 실무자 대상이라도 **논문 조어(배경자산·스패닝·커밋먼트 슬리브)는 실무에서 쓰는 말로 바꾼다.**

### 제목·부제 두 층 규칙 (덱 스킬 공통)

제목 줄은 **두 층**으로 쓴다. 제목이 격식을 맡고, 부제가 친절한 설명을 맡는다.

- **제목** — 표지·섹션 디바이더는 자료의 정체를 밝히는 **명사구**(`평균-분산 포트폴리오 최적화 / 이론과 활용`).
  본문은 완결된 **주장문**이되 문어체 단정형으로 쓴다. 구어체 종결·감탄·의문 부호·과장 수식어는 쓰지 않는다.
- **부제** — 제목을 읽기 위해 필요한 사전 정보를 한 줄로 담는다. 전제·가정, 실험이나 자료 설정,
  처음 나오는 용어의 원어, 표·그림 읽는 법 중 하나. `~한다` 체로 20~35자.
- 표지·디바이더는 부제가 사실상 필수다. 본문에서도 제목의 수치·조건·용어가 본문 어디에도 없으면 반드시 단다.
- 부제를 달면 본문 시작 y가 내려간다. **카드·수식 높이를 그만큼 줄여야** 콘텐츠 하한을 넘지 않는다.

## 0. 목적과 성격

정책·시스템·제안을 **처음 보는 사람에게 끝까지 설명하는 문서형 덱**을 만든다.
강의 덱(report-navy-deck)이 "말로 보충하는 슬라이드"라면, 이 스킬은 **슬라이드만 넘겨도 논리가 이어지는 설명자료**다.

원칙 세 줄:

1. **위치를 항상 보여준다** — 상단 다크바 + 섹션 탭 칩이 모든 본문 슬라이드에 붙는다. 지금 몇 번째 섹션인지 매 장 드러난다.
2. **한 슬라이드 = 한 주장** — 제목이 곧 주장이고, 아래 카드는 그 주장의 근거다. 제목을 명사구("운영 비용")로 두지 말고 판단문("운영 비용 — 월 처리량별 추정")으로 쓴다.
3. **결론은 하단 배너로 못 박는다** — 슬라이드당 최대 1개, 연블루 띠에 파란 굵은 한 문장.

적용 대상: 정책 설명자료 · 시스템 도입 제안 · 기관 보고 · 사업계획 브리핑.
적용 대상에 **수식·손계산이 들어가는 강의 설명자료**도 포함한다(수식 카드는 §8). 적용 제외: 리서치 차트 장표(→ `jaykong-research-deck`), 말로 보충하는 순수 강의 슬라이드(→ `report-navy-deck`).

---

## 1. Design Tokens — 절대 바꾸지 않는 시각 골격

### 1.1 캔버스

- **10.00 × 5.625 in** (pptxgenjs 기본 `LAYOUT_16x9`). **`pres.layout`을 절대 설정하지 않는다.** `LAYOUT_WIDE`(13.3")로 바꾸면 모든 좌표가 어긋난다.
- 좌우 여백 `M = 0.40`, 콘텐츠 폭 `CW = 9.20`.
- 2열 분할: 좌 `x=0.40 w=4.50` / 우 `x=5.10 w=4.50` (간격 0.20).

### 1.2 컬러 (지배색 = 블루 하나)

| 역할 | HEX | 쓰는 곳 |
|---|---|---|
| 포인트 블루 | `2563EB` | accent bar · 라벨 · 표 헤더 · 활성 탭 · 배너 텍스트 |
| 진블루 | `1E4E8C` | 4번째 카드/우측 패널 헤더의 변주 **1개만** |
| 잉크 | `1E293B` | 슬라이드 제목 · 카드 본문 |
| 본문 | `333333` | 불릿 문장 |
| 보조 | `64748B` | 부제 · 캡션 · 비활성 탭 |
| hairline | `E5E7EB` | 모든 테두리 · 구분선 (0.5pt) |
| zebra | `F8FAFC` | 짝수 행 · 회색 패널 |
| 탭 배경 | `F1F5F9` | 비활성 섹션 칩 |
| 상단바 | `1E4E8C` (navy, 기본) / `1A1A2E` (ink) | 본문 슬라이드 상단바 — **기본은 짙은 블루**, 검정은 `theme:"ink"` |
| 표지 배경 | `16325C` (navy, 기본) / `1E1E2E` (ink) | 표지 · 마무리 · 간지 |
| 표지 부제 | `C7D2E5` / 캡션 `8A93A8` | 표지 |
| 간지 번호 | `7FB0FF` (navy) / `4E7FE0` (ink) | 간지 대형 숫자 80pt — 다크 배경에서 읽히도록 |
| 긍정 | `2E7D4F` / bg `F0F9F3` / ln `B8DCC6` | "하는 것" · 추진 |
| 부정 | `C0392B` / bg `FDF2F2` / ln `F0C0C0` | "하지 않는 것" · ✕ |
| 주의 | `B7791F` / bg `FFF8E8` / ln `E8D5A8` | 한계 · 보완 |
| tint 배너 | `EBF5FF` | 하단 결론 띠 |

**금지:** 그라데이션, 4색 이상 동시 사용, 카드 한쪽 모서리만 색띠(엣지 스트라이프), 제목 밑줄.
색은 **의미가 있을 때만** 쓴다 — 초록=하는 것/통과, 빨강=안 하는 것/결함, 앰버=한계·보완, 블루=기본.

### 1.3 타이포

폰트는 **맑은 고딕 하나로 통일**한다(한국어 자료 기준). **발표용이므로 본문 하한은 12pt** — 어떤 요소도 12pt 아래로 내리지 않는다.

| 요소 | 크기 |
|---|---|
| 상단바 제목 / 페이지 | 12pt bold / 12pt |
| 섹션 탭 칩 | 12pt |
| eyebrow (섹션 라벨) | 12.5pt, 블루 |
| 슬라이드 제목 | **22pt bold**, 잉크 |
| 부제 | 12.5pt, 보조색 |
| 카드 라벨 / 카드 본문 | 13.5pt bold / 12.5pt |
| 표 헤더 / 표 본문 | 12pt bold / 12.5pt |
| 패널 제목 / 패널 본문 | 13pt bold / 13pt |
| 불릿 | 12.5pt |
| 하단 배너 | 13pt bold, 블루 |
| 카드 설명 · 배지 · 축 라벨 · 각주 | **12pt** (하한) |

표지 제목 40pt / 마무리 36pt는 고정. 숫자 강조(01, 02…)는 24pt bold 블루.

### 1.4 골격 좌표 (모든 본문 슬라이드 동일)

```
상단바       x0    y0     10.00 × 0.50   fill 1E4E8C (navy) / 1A1A2E (ink)
  제목       x0.40 y0      7.60 × 0.55   12pt bold white
  n / N      x8.40 y0      1.20 × 0.55   11pt white, 우측정렬
섹션 탭 칩   y0.55  h0.35   폭 = 10 / 섹션수   (활성 2563EB, 비활성 F1F5F9)
eyebrow     x0.40 y1.08   9.20 × 0.26
accent bar  x0.40 y1.36   0.06 × 0.34   fill 2563EB
제목        x0.56 y1.32   9.00 × 0.42
부제(선택)  x0.40 y1.88   9.20 × 0.30
콘텐츠 시작 y = 1.95 (부제 없음) / 2.30 (부제 있음)
하단 배너   y ≤ 4.95 (note 있으면 y ≤ 4.80), h0.50 / 0.72
바닥 한계   y + h ≤ 5.45  ← 이 선을 넘으면 잘린다
```

**섹션 탭은 4~6개**가 적정. 12pt 기준 칩 하나에 들어가는 라벨은 **5~6자**다. 7개를 넘거나 라벨이 길면 줄여서 쓴다("신뢰성·운영" → "운영").

---

## 2. 표준 슬라이드 트랙

설명자료는 이 순서를 기본으로 하고, 없는 항목만 뺀다.

| # | 슬라이드 | 헬퍼 |
|---|---|---|
| 1 | **표지** — 다크 배경 + 좌측 블루 리본 + 2행 제목 + 숫자 pill 5개 | `cover()` |
| 2 | **한 장 요약** — 무엇을/왜/어떻게/결과 4행 | `rowCards()` + `banner()` |
| 3 | **설명 순서(목차)** — 01~06 번호 카드 3×2 | `numCards()` |
| 4 | **문제 정의 ①** — 접수/검증/회신/축적 상태 카드 + 병목 노트 | `statCards()` + `noteBox()` |
| 5 | **문제 정의 ②** — 현재 ✕ / 제안 ✓ 대비 2열 | `compareCols()` |
| 6 | **대원칙** — 하지 않는 것(빨강) / 하는 것(초록) + 왜 이 순서인가 | `dualPanel()` + `panel()` |
| 7 | **전체 흐름** — STEP 1·2·3 단계 카드 | `stepFlow()` |
| 8 | **구조** — 축 A / 축 B 헤더 패널 2열 | `headPanels()` |
| 9 | **절차·장치** — 헤더칩 카드 3~4열 | `headCards()` |
| 10 | **판정 산출물 ①** — 5문장 결과 번호 행 | `numRows()` |
| 11 | **판정 산출물 ②** — 2×2 위치 판정 | `matrix2x2()` |
| 12 | **수치** — 블루 헤더 표 | `wtable()` |
| 13 | **구축 방식** — 구성 카드 4열 + 지킨 원칙 | `plainCards()` + `labeledBullets()` |
| 14 | **한계와 다음 단계** — 앰버 / 블루 패널 2열 | `dualPanel()` |
| 15 | **마무리** — 다크 배경 + 한 문장 결론 | `closing()` |

같은 레이아웃을 3장 연속으로 쓰지 않는다. 행 카드가 두 장 이어지면 세 번째는 카드 그리드나 표로 바꾼다.

---

### 2.1 파트가 여러 개일 때

파트가 3개 이상이면 각 파트 앞에 **간지 한 장**을 넣고, 그 뒤는 상단바 + 섹션 탭 양식을 그대로 반복한다.

```
표지 → 한 장 요약 → 목차
  ├ [간지 01] → 본문(탭 1 활성) …
  ├ [간지 02] → 본문(탭 2 활성) …
  └ [간지 03] → 본문(탭 3 활성) …
→ 마무리
```

지킬 것:

- **간지의 `sec`와 섹션 탭 라벨은 같은 말로.** 간지에서 "필요성"이라 했으면 뒤따르는 본문의 활성 탭도 "필요성"이어야 한다. 다르면 위치 감각이 깨진다.
- **간지 번호(`no`)와 본문 eyebrow 번호를 맞춘다.** 간지가 `01`이면 뒤 본문은 `01. 왜 필요한가`.
- **간지 번호는 연블루 80pt.** 다크 배경에 어두운 회색 숫자를 쓰면 빔 프로젝터에서 사실상 안 보인다.
- **간지는 파트당 1장.** 파트가 2개거나 전체 12장 미만이면 간지 없이 탭만으로 충분하다.
- 목차(`numCards`)의 01~06과 간지 번호를 일치시키면 목차가 곧 간지 지도가 된다.

---

## 3. 작성 규칙 (내용)

1. **제목은 주장으로.** "비용" ✕ → "운영 비용 — 월 처리량별 추정" ○. 대시(—)로 주제와 관점을 잇는 게 이 덱의 제목 문법이다.
2. **eyebrow는 섹션 번호 + 이름**(`01. 왜 필요한가`) 또는 영문 라벨(`EXECUTIVE SUMMARY`, `CONTENTS`).
3. **부제는 한 문장, 마침표로 끝낸다.** 제목이 주장이면 부제는 그 주장의 조건·범위를 적는다.
4. **카드 본문은 명사구 또는 한 문장.** 두 문장을 한 칸에 넣지 않는다. 넘치면 슬라이드를 나눈다.
5. **불릿은 슬라이드당 최대 6개, 한 줄 40자 이내.**
6. **12pt 기준 수용량을 먼저 계산한다.** 행 카드 4행 · 표 4행 · 대비 3행 · 카드 4열이 한 장의 한계다. 넘치면 줄여 쓰지 말고 슬라이드를 나눈다.
7. **배너는 슬라이드당 1개.** 그 장에서 독자가 가져갈 문장 하나만 쓴다. 배너를 두 개 쓰면 둘 다 안 읽힌다.
8. **숫자에는 근거와 시점을 붙인다** — "7,362건" 옆에 출처, 추정치에는 `※` 각주(`banner`의 두 번째 인자)로 가정을 밝힌다.
9. 재직자·실무자 대상이면 **업계 용어를 그대로 쓴다.** 쉬운 말로 의역하지 않고, 필요하면 영문을 병기한다. 단, **논문에서 만든 조어는 업계 용어가 아니다** — 배경자산 → 운용자산 밖의 자산·부채, 스패닝 R² → 시장에서 따라 살 수 있는 정도(R²), 커밋먼트 슬리브 → 대체투자 부문·신규 약정, 확실성등가 → 위험조정 가치, 지평 → 보유기간, 코너해 → 0%처럼 실무에서 통하는 말로 바꾼다.
10. **제목은 32자 이내.** `head()`가 17pt까지 자동 축소하지만, 17pt로도 넘치면 로그에 경고가 난다. 그때는 폰트를 더 줄이지 말고 제목을 고쳐 쓴다.

---

## 4. 헬퍼 API (`scripts/template.js`)

```js
const { newDeck } = require("./template.js");
const D = newDeck({ title:"덱 상단바 제목", sections:["개요","필요성","구조","운영","비용","다음 단계"],
                    theme:"navy" });   // 기본 navy(짙은 블루). 검정 톤이 필요하면 "ink"
```

| 헬퍼 | 시그니처 | 비고 |
|---|---|---|
| `D.cover` | `({kicker,l1,l2,sub,chips[],note,year})` | chips는 **4개**까지 (12pt 기준 pill당 8~10자) |
| `D.closing` | `({kicker,l1,l2,sub})` | 페이지 번호 자동(우하단) |
| `D.divider` | `({no,sec,title,sub})` | **파트 간지.** 다크 배경, 상단바·탭 없음. `sec`는 해당 파트의 **섹션 탭 라벨과 같은 말**을 쓴다 |
| `D.slide` | `(secIdx) → slide` | 상단바·탭 자동. `secIdx`는 0-based |
| `D.head` | `(s, eyebrow, title, sub?) → y` | **반환값이 콘텐츠 시작 y** |
| `D.rowCards` | `(s,y,[{label,mid?,text,color?}],{h,gap,labelW,midW})` | 좌측 accent bar + zebra. `mid` 지정 시 3단(라벨·중간·설명) |
| `D.numCards` | `(s,y,[{no,title,desc}],{cols,h})` | 목차. cols 기본 3 |
| `D.headCards` | `(s,y,[{head,big,desc,badge?,dim?}],{h})` | 2~4열. **badge가 있으면 desc는 최대 2줄** |
| `D.compareCols` | `(s,y,{head,items},{head,items},{h})` | ✕ / ▶ / ✓ 자동. 좌측 헤더는 회색, 우측은 블루 |
| `D.panel` | `(s,x,y,w,h,{tone,title,text\|bullets,fs,rowH})` | tone: `blue\|ok\|bad\|warn\|gray` |
| `D.dualPanel` | `(s,y,h,L,R)` | panel 2개를 좌우로 |
| `D.headPanels` | `(s,y,h,{head,quote,items},{...})` | 헤더칩 + 인용구 + 불릿. 우측은 진블루 |
| `D.bullets` | `(s,x,y,w,items,{fs,rowH,color})` | • 는 블루 |
| `D.wtable` | `(s,y,headers[],rows[][],widths[],{rowH,fs})` | 도형 기반 표. widths는 비율 |
| `D.matrix2x2` | `(s,y,[q1..q4],{top,bl,br})` | 순서: 좌상·우상·좌하·우하 |
| `D.statCards` | `(s,y,[{label,big,cap,invert?}],{h})` | 라벨 + 큰 단어(21pt) + 캡션. `invert:true`는 블루 채움 — **한 장에 1개만** |
| `D.stepFlow` | `(s,y,[{step,title,items[]}],{h})` | STEP 헤더 + 소제목 + 불릿, 카드 사이 ▶ 자동. 3단계 권장(4단계는 불릿 3개까지) |
| `D.numRows` | `(s,y,[{label,text}],{h,labelW})` | 원형 번호 배지 + 라벨 + 설명. 5~6행까지 |
| `D.plainCards` | `(s,y,[{head,text,dim?}],{h})` | 헤더칩 + 중앙정렬 3줄 본문. 구성요소 나열용 |
| `D.noteBox` | `(s,y,label,text,{h,labelW})` | 좌측 블루 라벨 + 우측 본문. 슬라이드 하단 해설 |
| `D.labeledBullets` | `(s,x,y,[{label,text}],{rowH,labelW,w})` | 굵은 라벨 + 우측 설명 2단 불릿 |
| `D.banner` | `(s,y,text,note?)` | note 있으면 h 0.62 |
| `D.image` | `(s,path,ratio,{y,bottom,w,x,frame})` | 그림·차트·수식 PNG를 **비율 유지·중앙정렬**로 얹는다. `ratio`는 실제 PNG의 가로/세로(`1600/500`처럼 나눗셈으로). 전체폭 그림은 `bottom:4.85`까지, 수식은 `w:3.6~5.2`로 좁혀 위에 |
| `D.img` | `(s,path,{y,bottom,w,x,frame})` | `D.image`와 같되 **PNG 실제 비율을 자동으로 읽는다.** matplotlib·SVG·원본 그림은 이것을 쓴다 |
| `D.eq` | `(s,path,{x,y,w,h,align})` | 수식 PNG를 상자 안에 비율 유지로. 카드 없이 수식만 둘 때 |
| `D.eqCard` | `(s,path,{x,y,w,h,label,note,side,lw})` | 수식 카드. **`side:true`(왼쪽 라벨 칸 lw 2.2~2.6 + 오른쪽 수식)가 수식을 가장 크게 보여 준다 — 전체폭 카드의 기본값으로 쓴다.** 위 라벨형은 반폭 카드용 |
| `D.code` | `(s,x,y,w,h,lines[])` | 어두운 코드 상자, Consolas 12pt. 한 줄 60자 이내 |
| `D.source` | `(s,text)` | 하단 출처 줄(y 5.30). 배너는 5.25 위에서 끝낸다 |
| `D.fit` | `(text,widthIn,maxPt,minPt) → pt` | 한 줄 폭에 맞춘 폰트 크기. `head()`가 제목에 자동 적용(22→17) |
| `D.save` | `(path)` | **페이지 번호를 여기서 일괄 부여** — 반드시 마지막에 호출 |

세로 예산 계산:

```
가용 높이 = 4.95 - 콘텐츠시작y   (배너를 쓸 경우)
가용 높이 = 5.45 - 콘텐츠시작y - 배너높이

rowCards  : 행수 × 0.72   (4행이 한계)
numRows   : 행수 × 0.58   (5행 + 부제 + 배너는 안 들어간다 — 부제를 뺀다)
headCards : 2.42 고정 (배지 포함)
statCards : 1.58 고정
plainCards: 1.72 고정
stepFlow  : 2.60 고정 (3단계 · 불릿 4개까지)
noteBox   : 0.84 (본문 2줄)
compareCols: 0.55 + 행수 × 0.76 (3행이 한계)
dualPanel : 0.55 + 불릿수 × 0.32  ← 내용에 맞춰 준다(빈 아래 여백 금지)
wtable    : 0.46 + 행수 × 0.46 (4행이 한계)
matrix2x2 : 2.44 + 축라벨 0.30
```

### 4.1 폰트 크기 하한 (자동 검증 대상)

**발표용 하한은 12pt다.** 모든 텍스트 런이 12pt 이상이어야 하며, 헬퍼가 쓰는 최소값(`headCards` desc·badge, `statCards` 캡션, `matrix2x2` 축 라벨, 배너 각주)이 모두 12pt다. 빌드 후 다음으로 전수 점검한다.

```bash
python3 -c "
import re,glob,zipfile
from defusedxml import minidom
zipfile.ZipFile('out.pptx').extractall('_chk')
low=[]
for f in glob.glob('_chk/ppt/slides/slide*.xml'):
    d=minidom.parse(f); n=int(re.findall(r'[0-9]+',f)[-1])
    for r in d.getElementsByTagName('a:r'):
        rp=r.getElementsByTagName('a:rPr')
        if not rp or not rp[0].getAttribute('sz'): continue
        v=int(rp[0].getAttribute('sz'))/100
        if v<12:
            t=''.join(x.firstChild.nodeValue for x in r.getElementsByTagName('a:t') if x.firstChild)
            low.append((n,v,t[:30]))
print(low or '하한 충족')
"
```

---

## 5. 빌드 절차

이 저장소(로컬 macOS) 기준 절차다. `pptxgenjs`는 `/Users/keerhee/Project/node_modules`에
이미 설치돼 있으므로, 빌드 디렉터리는 그 아래(또는 `NODE_PATH` 지정)에서 돌린다.

```bash
SKILL=/Users/keerhee/Project/.claude/skills/jj-brief-deck
mkdir -p build && cp "$SKILL/scripts/template.js" build/
# build/build_deck.js 작성 후 (Project 루트에서 실행 — node_modules/pptxgenjs 해석)
cd /Users/keerhee/Project && node build/build_deck.js out.pptx

# 1) 무결성 검증 (python-pptx로 열리는지 + 슬라이드 수)
python3 -c "from pptx import Presentation; print('slides:', len(Presentation('out.pptx').slides))"

# 2) PDF 렌더 → JPG로 전 슬라이드 자가 검수
soffice --headless --convert-to pdf out.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 100 out.pdf slide

# 3) MS 호환 정규화 (PowerPoint "복구 필요" 예방 — 자매 스킬 report-navy-deck과 동일)
soffice --headless --convert-to pptx:"Impress MS PowerPoint 2007 XML" --outdir _norm out.pptx

# 4) Keynote 호환 후처리 (3번 정규화 직후 필수)
python3 /Users/keerhee/Project/.claude/skills/report-navy-deck/scripts/fix_keynote_notes.py _norm/out.pptx
```

정규화본(`_norm/out.pptx`)을 PDF로 재렌더해 **디자인이 원본과 같은지 눈으로 확인한 뒤** 최종 출고본으로 삼는다
(round-trip이 드물게 도형·폰트를 틀 수 있다).

**4번을 건너뛰지 말 것.** LibreOffice round-trip은 슬라이드마다 빈 notesSlide를 만들면서 `<p:clrMapOvr>`를
빼먹는데, PowerPoint는 그냥 열지만 **Keynote는 그 파일을 열지 못하고 모달 오류창에서 멈춘다**.
1번 무결성 검증은 통과하므로 이 단계 없이는 잡히지 않는다. 스크립트는 notesSlide에 한 줄을 넣을 뿐이라
디자인·노트 텍스트는 그대로이고, 이미 정상인 파일은 건드리지 않아 몇 번 돌려도 안전하다(확인은 `--check`).

**폰트 주의:** 이 맥에는 맑은 고딕이 없어 LibreOffice 렌더 시 대체 폰트로 그려진다.
폭이 조금 달라질 수 있으니 텍스트 박스는 10% 여유를 두고, 최종 확인은 실제 PowerPoint(또는 Keynote)에서 한다.

수식·차트·도해가 있으면 **먼저** `python examples/viz_demo.py`처럼 `scripts/jj_viz.py`로 PNG를 굽고, 그다음 덱을 빌드한다. `examples/viz_demo_deck.js`가 v1.5 헬퍼(`eqCard side:true`·`img`·`code`·`source`) 사용 예다.

`scripts/build_demo.js`가 **모든 헬퍼를 한 번씩 쓰는 참조 구현**(TPA 프레임 실무자료 28장)이다. 새 덱은 이 파일을 복사해 슬라이드 블록만 교체하는 방식이 가장 빠르다. 데모는 `eq/ratios.json`과 `fig/*.png`를 참조하므로, 그림 없이 돌리려면 `D.image` 줄을 지우거나 `latex-equation-png`·matplotlib으로 먼저 굽는다.

그림을 넣을 때의 팔레트: 배경 `FFFFFF`, 잉크 `1E293B`, 포인트 `2563EB`, 진블루 `1E4E8C`, 긍정 `2E7D4F`, 부정 `C0392B`, 앰버 `B7791F`, hairline `E5E7EB`. 수식 PNG는 흰 배경(`bg="FFFFFF"`)으로 굽는다 — 이 덱의 카드는 모두 흰색이다.

---

## 6. QA 체크리스트 (렌더 이미지를 반드시 눈으로 본다)

- [ ] **12pt 미만 텍스트가 없는가** (§4.1 스크립트로 전수 확인)
- [ ] 카드 본문이 배지·구분선·카드 하단을 넘지 않는가 (배지 카드 desc 3줄이 대표 사고)
- [ ] 표 셀 텍스트가 셀 폭 안에 드는가 (긴 헤더는 `widths` 비율을 키운다)
- [ ] 패널 아래에 빈 공간이 1.0" 이상 남지 않는가 (남으면 패널 h를 줄인다)
- [ ] 섹션 탭 라벨이 칩 안에서 줄바꿈되지 않는가
- [ ] 배너가 슬라이드당 1개인가, 콘텐츠와 0.15" 이상 떨어졌는가
- [ ] 같은 레이아웃이 3장 연속 반복되지 않는가
- [ ] 색이 의미 없이 쓰인 곳은 없는가 (초록/빨강/앰버는 판정에만)
- [ ] **수식이 텍스트로 풀어 쓰인 곳이 없는가**(모든 수식은 LaTeX PNG)
- [ ] 수식 PNG가 너무 작지 않은가 — 렌더 이미지에서 본문 12pt보다 작아 보이면 `side:true`로 바꾸거나 카드 높이를 키운다
- [ ] 차트·도해 안 글자가 12pt 상당 이상인가(figsize를 슬라이드 실제 크기로 잡았는가)
- [ ] 논문식 비표준 표기((Σw)ᵢ 등)를 쓴 경우, 처음 나오는 곳에 **정의 슬라이드나 표기 약속**이 있는가
- [ ] **제목·부제·표·패널·불릿에 첨자·그리스 문자 텍스트(w_i, σ_p, (Σw)ᵢ, μ − r_f)가 남지 않았는가** — 표는 `mtable`, 나머지는 말로
- [ ] 한 슬라이드에 방법·모형이 하나인가, eyebrow·제목에 그 이름이 있는가
- [ ] 부제가 한 줄인가 — 두 줄로 넘어가면 본문이 밀려 배너와 겹친다(가장 흔한 사고)
- [ ] 패널 불릿: `0.45 + 불릿수 × rowH ≤ h`인가(마지막 불릿이 배너 뒤로 숨는 사고)
- [ ] 3덱 체계면 **상호 참조 번호(W-n, A-n)가 실제 덱에 있고 숫자가 일치하는가**, 특별 세션 번호에 빈 번호가 없는가(§9.2)
- [ ] `validate.py`가 PASS인가

**렌더 주의:** 이 환경의 LibreOffice에는 맑은 고딕이 없어 대체 폰트로 그려진다. 폭이 조금 달라질 수 있으므로 텍스트 박스는 **10% 여유**를 두고 잡는다. 실제 PowerPoint에서는 지정한 폰트로 렌더된다.

---

## 7. 자매 스킬과의 결합

- 수식·차트·도해는 §8의 시각화 레이어(`scripts/jj_viz.py`)로 굽는다. 더 복잡한 구조 다이어그램은 `svg-infographic`(TypePack·layout pass 규칙)을 따르고 색만 JJ 팔레트로 바꾼다.
- 수식이 많은 Word·마크다운 원고는 `latex-equation-docx`·`obsidian-math-md`.
- 한국어 문장 다듬기는 `professional-korean-finance-editor`, 마크다운 원고 규칙은 `korean-md-standard`.

---

## 8. 시각화 레이어 (v1.5) — 무엇을 무엇으로 그리나

**원칙 두 줄.** ① 수식은 **항상** 진짜 LaTeX로 렌더링한 PNG로 넣는다. `w_i ∝ 1/σ_i` 같은 텍스트 풀어쓰기는 표·불릿 안의 짧은 기호 언급에만 허용한다. ② 그림은 장식이 아니라 **이해를 돕는 곳에** 넣는다 — 비교·추세·분포·구조·흐름·기하적 직관이 글보다 그림으로 빨리 읽히면 그린다. 같은 레이아웃 3연속 금지 규칙은 그림 슬라이드에도 적용된다.

| 콘텐츠 | 도구 (`scripts/jj_viz.py`) | 덱 삽입 |
|---|---|---|
| 수식·정의·유도 단계 | `render_eq(latex, path)` — pdflatex, 한글 있으면 xelatex | `D.eqCard(..., side:true)` / `D.eq` |
| 데이터 차트(막대·선·산점도·누적) | `mpl_style()` → `save_fig()` | `D.img` (전체폭 `bottom:4.7`) |
| 구조·흐름·단계·레이어 도해 | `svg_doc()` → `render_svg()` | `D.img` |
| 원본 자료의 그림(사용자 덱·PDF) | 추출한 PNG 그대로 | `D.img` + `D.source("원본: …")` |
| 코드 | — | `D.code` |

**수식 규칙**
- 흰 배경(`bg="FFFFFF"`), 잉크 `1E293B`, fontsize 24 전후. 카드 배경색과 PNG 배경을 맞춘다(투명 PNG 금지).
- 전체폭 수식 카드는 `side:true`가 기본이다. 위 라벨형은 라벨 높이 0.36"를 잡아먹어 수식이 작아진다. 수식 3장 적층이면 카드 h 0.85~1.0, 배너는 생략하고 결론을 부제로 올린다.
- 큰 합 기호의 위·아래 첨자가 카드 높이를 잡아먹으면 `\sum\nolimits_i`로 납작하게 만든다.
- 식 안의 한글은 `\text{…}`에 넣는다(xelatex + Noto Sans CJK KR로 자동 처리).
- **손계산 수치예제**는 Step 1·2·3 수식 카드로 쌓는다(라벨 = 이 단계에서 하는 일). 마지막에 검산 카드를 둔다.
- 비표준 표기는 쓰되 정의를 붙인다: 처음 나오는 곳에 "표기 정의" 슬라이드(행렬 곱 풀어쓰기 + 원소 정의 + 오독 주의 noteBox), 특별 세션·부록 덱이면 "표기 약속" 표.

**matplotlib 규칙**
- 슬라이드에 거의 실제 크기로 얹는다: 전체폭 figsize `(9.2, 2.8~3.0)`, 반폭 패널 `(4.6, 3.0)`. 글자 12pt 이상.
- 팔레트: 강조 계열 1개만 블루 `2563EB`, 기준 네이비 `1E4E8C`, 비교 회색 `94A3B8`, 판정색(초록·빨강·앰버)은 의미 있을 때만. 값 레이블을 직접 달고 불필요한 축·격자는 지운다. 차트 제목은 왼쪽 정렬, 슬라이드 제목과 중복되면 생략.
- 아래첨자 유니코드(₁₂ᵢ)는 CJK 폰트에 없어 깨진다 — 축·주석은 `$y_1$` mathtext로 쓴다.

**SVG 규칙**
- 전체폭 1500×600(`render_svg(width=3000)`), 반폭 1000×700. 본문 28px 이상, 박스 제목 36~44px 굵게. 마지막 박스 오른쪽 끝을 assert로 확인한다.
- 흰 카드 + hairline 테두리 + 블루 강조 박스 1개 + 블루 화살표. SVG 안에 슬라이드 제목을 넣지 않는다.
- 아래첨자 유니코드·특수 기호는 쓰지 않는다(폰트 누락 → □). 필요한 수식은 LaTeX PNG로 따로 얹는다.

**배치 예산(10×5.625 캔버스)**
- 부제 있는 슬라이드의 콘텐츠 시작 y = 2.12. 그림 전체폭 `bottom 4.7` + 배너 4.85, 또는 배너 없이 `bottom 5.35` + `D.source`.
- 좌 그림 + 우 패널: 그림 `w 4.6~5.0, x 0.3~0.4`, 패널 `x 5.2~5.4, w 4.2~4.4`.

---

## 9. 수식·이론 강의 설명자료 (v1.6)

### 9.1 3덱 체계

| 덱 | 담는 것 | 담지 않는 것 |
|---|---|---|
| **본편** | 기본 지식 → 정의 수식 → 직관·한계 → 공통 예제 결과 → 비교 → 실증·사례 → 사용법 | 손계산 단계, 긴 도출, 증명 |
| **특별 세션** | 도출·KKT·증명·알고리즘·실습(코드) — 번호 A-1, B-1, C-1, D-1 | 손계산 수치(워크북으로) |
| **워크북** | 본편 결과 숫자마다 Step 1·2·3 손계산 + 검산 — 번호 W-1, W-2 … | 새로운 개념 |

- 본편 부제에 참조를 단다: "계산 과정은 워크북 W-8", "도출은 특별 세션 A".
- 본편 끝에 **"함께 보는 덱"** 한 장(`headPanels`)으로 두 덱의 구간 지도를 준다.
- 모든 결과는 **공통 예제 하나**(예: 3자산 공분산)에서 나오게 하고, 숫자는 코드로 다시 계산해 확인한다.

### 9.2 번호 점검 (개정할 때마다)

1. 본편 텍스트에서 `W-\d+`, `특별 세션 [A-D]` 참조를 정규식으로 뽑는다.
2. 워크북·특별 세션 제목 줄의 번호와 대조한다 — 없는 번호, 빈 번호(A-3 누락 등), 결과 숫자 불일치를 표로 보고한다.
3. 본편에 새로 넣은 결과 숫자 중 워크북 계산이 없는 것을 목록으로 만든다 → 워크북 판을 올려 W-번호를 추가하고 본편 참조를 갱신한다.

```python
from pptx import Presentation; import re
T=lambda f:[(i," ".join(sh.text_frame.text for sh in s.shapes if sh.has_text_frame)) for i,s in enumerate(Presentation(f).slides,1)]
M,W,S=T("main.pptx"),T("workbook.pptx"),T("special.pptx")
wid={int(m.group(1)) for _,t in W for m in [re.search(r"\bW-(\d+) ·",t)] if m}
sid={m.group(1) for _,t in S for m in [re.search(r"\b([A-D]-\d+) ·",t)] if m}
bad=[(i,f"W-{n}") for i,t in M for a,b in re.findall(r"W-(\d+)(?:~(\d+))?",t) for n in range(int(a),int(b or a)+1) if n not in wid]
bad+=[(i,x) for i,t in M for x in re.findall(r"특별 세션 ([A-D]-\d+)",t) if x not in sid]
print("깨진 참조:",bad or "없음"); print("W 빈 번호:",sorted(set(range(1,max(wid)+1))-wid))
raw=re.compile(r"[σμρβΣλ∂ᵢⱼ₁₂]")   # 제목·본문 텍스트에 남은 수식 기호
print([(n,i) for n,D in [("main",M),("wb",W),("ss",S)] for i,t in D if raw.search(t)])
```

### 9.3 방법별 1장 패턴

비교 대상이 여러 방법(모형)이면:

- 섹션 첫 장 = **한눈에 표**(`mtable`): 방법 | 무엇을 맞추나 | 규칙(LaTeX 셀) | 입력.
- 이어서 **방법마다 한 장**: eyebrow `03. 방법 · ERC`, 제목 "ERC(리스크 패리티)는 모든 자산의 위험기여를 같게 맞춘다". 구성은 `eqCard(side)` 정의 → `dualPanel` 직관(blue)/한계(warn) → `statCards` 공통 예제 결과 3개(가운데 1개만 invert).
- 방법 사용법이 필요하면 바로 뒤에 "○○ 계산" 장: 풀 문제 수식 + `labeledBullets` 4단계 + `D.code` 10줄 + 검증식.
- 비교 섹션은 **가정으로 비교**한다: 하나의 공식(특수형 표) → 역최적화(암묵 가정) → 최적 조건 표 → 수렴 조건 → 성질 표 → 선택 지도 `matrix2x2`.

### 9.4 수식 텍스트 금지의 실전 규칙

- 제목에는 기호를 넣지 않는다. "σ_GMV ≤ σ_ERC" ✕ → "ERC는 변동성이 GMV와 1/n 사이에 놓인다" ○.
- 부제의 기호는 말로 푼다: "Σ는 합기호가 아니라…" ✕ → "대문자 시그마는 합 기호가 아니라 공분산 행렬이다" ○.
- 표 셀 수식은 `mtable`(§10)로 LaTeX PNG를 셀에 얹는다. 패널 불릿은 "기준 0.655(분산 비율의 역수)"처럼 말 + 숫자로.
- 원본 식 번호((1), (2a), (7))는 LaTeX 안에 `\text{(7)}`로 남겨 원문과 대조되게 한다.

### 9.5 원본 자료 "모두 넣기"

사용자가 원본(PDF·덱)을 주며 "모두 넣으라"고 하면:
1. 원본을 페이지 이미지로 떠서 **항목 체크리스트**를 만든다(정의·식 번호·주장·각주·출처별로).
2. 각 항목을 본편 섹션에 배정한다 — 도구(정의·분해), 방법(정식 정의·해법·확장 제약), 비교(최적 조건·성질·장점).
3. 수식은 원문 표기를 살려 LaTeX로 다시 굽고, 원문의 주의 문구(예: "S&P의 MC는 실제로는 총 위험기여")는 eqCard 라벨이나 배너로 살린다.
4. 원본 그림은 JJ 팔레트로 다시 그리고 `D.source("원본: …")`.

### 9.6 질의응답을 덱에 흡수하기

설명 요청에 답한 내용을 사용자가 "포함해 달라"고 하면 **장난감 예제 한 장**으로 만든다: 공통 예제에 자산 하나를 더하거나 조건 하나를 바꿔, 두 방법의 결과 차이를 막대그래프(좌) + 읽는 법 패널(우) + 규칙 수식 eqCard(상단) + 결론 배너로 보인다. 예: "ERC는 겹치는 위험원을 줄이고, MDP는 아예 뺀다"(상관 0.8 자산 D 추가 → MDP 0%, ERC 14%).

### 9.7 마지막 사용법 장

- 계산 장에 `D.code`(10줄 이내 함수 + 검증 반환값).
- 실증 뒤 **"Claude 프롬프트"** 장: 어두운 상자(잉크 채움, 12pt, `E2E8F0` 글자)에 6~8줄 프롬프트 — 데이터·기간, 추정 방식, 계산할 방법 목록, **assert 검증 조건**, 출력 표·차트, 미래 정보 금지. 오른쪽 `panel`에 프롬프트 요령 5개.

---

## 10. 보조 헬퍼 (덱 스크립트 상단에 붙여 쓴다)

`template.js`에 없는 헬퍼다. **`scripts/jj_helpers.js`**로 불러 쓴다:

```js
const { newDeck, C } = require("./template.js");
const D = newDeck({ ... });
const { mtable, ecs, numEq } = require("./jj_helpers.js")(D, C, n => `eq/${n}.png`);
```

아래는 같은 코드다(스크립트 상단에 직접 붙여 써도 된다. 이때는 `` const E = n => `eq/${n}.png` ``를 먼저 둔다).

```js
// 표 셀에 LaTeX 수식: 셀 값을 {eq:"name"}으로 주면 PNG를 셀 안에 얹는다
function mtable(s, y, headers, rows, widths, o) {
  o = o || {}; const rh = o.rowH || 0.42, hh = 0.40, tot = widths.reduce((a, b) => a + b, 0);
  const ws = widths.map(w => 9.2 * w / tot), xs = []; let acc = 0.4; ws.forEach(w => { xs.push(acc); acc += w; });
  D.wtable(s, y, headers, rows.map(r => r.map(c => (typeof c === "object" ? "" : c))), widths, o);
  rows.forEach((r, i) => r.forEach((c, j) => { if (typeof c === "object") D.eq(s, E(c.eq),
    { x: xs[j] + 0.08, y: y + hh + i * rh + 0.07, w: ws[j] - 0.16, h: Math.min(rh - 0.14, o.eqH || 0.28), align: "l" }); }));
  return y + hh + rows.length * rh;
}
// 수식 카드 적층(전체폭, side 라벨). list = [[eqName, label, h?], ...]. 높이 누적 반환
function ecs(s, y, list, o) { o = o || {}; let yy = y; list.forEach(it => { const h = it[2] || o.h || 0.72;
  D.eqCard(s, E(it[0]), { x: 0.4, y: yy, w: 9.2, h, side: true, lw: o.lw || 2.2, label: it[1] }); yy += h + 0.08; }); return yy; }
// 수치 예제용 작은 수식 카드: 수식 높이를 eqH로 제한(본 수식보다 작게)
function numEq(s, name, o) {
  D.R(s, o.x, o.y, o.w, o.h, C.white, C.hair);
  if (o.label) { D.R(s, o.x, o.y, o.lw || 2.2, o.h, C.zebra, C.hair); D.R(s, o.x, o.y, 0.06, o.h, C.blue);
    D.T(s, o.label, { x: o.x + 0.14, y: o.y, w: (o.lw || 2.2) - 0.2, h: o.h, fontSize: 12, bold: true, color: C.blue, valign: "middle" }); }
  const lx = o.label ? o.x + (o.lw || 2.2) + 0.15 : o.x + 0.15, lw = o.w - (o.label ? (o.lw || 2.2) + 0.3 : 0.3);
  const eh = Math.min(o.eqH || 0.5, o.h - 0.16);
  D.eq(s, E(name), { x: lx, y: o.y + (o.h - eh) / 2, w: lw, h: eh });
}
```

세로 예산(부제 한 줄, 배너 4.85 기준): `ecs` 3장 h 0.8, 4장 h 0.62. 4장을 넘기면 슬라이드를 나눈다. 수식 카드 2장 + `wtable` 2행이 한 장의 한계다.
