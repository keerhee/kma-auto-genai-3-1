"""v1.5 시각화 레이어 예제 — 수식 2개, 차트 1개, SVG 도해 1개를 굽는다 (out/ 폴더)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from jj_viz import *
os.makedirs("out", exist_ok=True)
render_eq(r"TRC_i=w_i\frac{\partial\sigma_p}{\partial w_i}=\frac{w_i(\Sigma w)_i}{\sigma_p},\qquad \sigma_p=\sum\nolimits_i TRC_i", "out/eq_trc.png")
render_eq(r"(\Sigma w)_i\equiv[\Sigma w]_i=\sum_{j}\sigma_{ij}w_j=\mathrm{cov}(r_i,\,r_p)\quad(\text{i번째 원소})", "out/eq_def.png")
plt = mpl_style()
fig, ax = plt.subplots(figsize=(9.2, 2.6))
for i, (lab, v) in enumerate([("위험기여", [90, 10]), ("자본 비중", [60, 40])]):
    ax.barh(i, v[0], color="#" + NAVY, height=0.55); ax.barh(i, v[1], left=v[0], color="#" + BLUE, height=0.55)
    ax.text(v[0] / 2, i, f"주식 {v[0]}%", ha="center", va="center", color="white", fontweight="bold")
ax.set_yticks([0, 1]); ax.set_yticklabels(["위험기여", "자본 비중"]); ax.set_xticks([]); ax.grid(False)
save_fig(fig, "out/fig_bar.png")
steps = [("① 떼어 낸다", "합계 = 1 제약 제거"), ("② 풀어 낸다", "로그 장벽 볼록문제"), ("③ 나눈다", "x = y ÷ (y의 합)")]
inner = ""
for i, (t, sub) in enumerate(steps):
    x = 24 + i * 490; dark = i == 1
    inner += f'<rect x="{x}" y="120" width="420" height="360" rx="12" fill="#{BLUE if dark else "FFFFFF"}" stroke="#{HAIR}" stroke-width="3"/>'
    inner += f'<text x="{x+210}" y="260" text-anchor="middle" font-size="44" font-weight="700" fill="#{"FFFFFF" if dark else INK}">{t}</text>'
    inner += f'<text x="{x+210}" y="340" text-anchor="middle" font-size="30" fill="#{"FFFFFF" if dark else INK}">{sub}</text>'
    if i < 2: inner += f'<line x1="{x+428}" y1="300" x2="{x+478}" y2="300" stroke="#{BLUE}" stroke-width="6" marker-end="url(#ah)"/>'
render_svg(svg_doc(1500, 600, inner), "out/fig_flow.png")
print("ok")
