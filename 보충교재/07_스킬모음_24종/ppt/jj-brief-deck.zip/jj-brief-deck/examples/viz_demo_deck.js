// v1.5 시각화 헬퍼 데모: node viz_demo_deck.js (먼저 python viz_demo.py)
const { newDeck } = require("../scripts/template.js");
const D = newDeck({ title: "JJ 덱 v1.5 — 시각화 레이어 데모", sections: ["수식", "차트", "도해"] });
D.cover({ kicker: "DEMO", l1: "시각화 레이어", l2: "LaTeX · matplotlib · SVG", sub: "수식은 LaTeX로 굽고, 이해를 돕는 그림은 필요한 곳에 넣는다", chips: ["eqCard", "img", "code"] });
let s = D.slide(0); let y = D.head(s, "01. 수식 · 옆 라벨형 카드", "위험기여는 비중과 한계 위험기여의 곱이다", "side:true 카드가 수식을 가장 크게 보여 준다.");
D.eqCard(s, "out/eq_trc.png", { x: 0.4, y, w: 9.2, h: 0.95, side: true, label: "① 총 위험기여 TRC" });
D.eqCard(s, "out/eq_def.png", { x: 0.4, y: y + 1.05, w: 9.2, h: 0.85, side: true, label: "② 표기 정의 (Σw)ᵢ" });
D.code(s, 0.4, y + 2.02, 9.2, 0.8, ["rc = w * (S @ w) / np.sqrt(w @ S @ w)   # 위험기여 벡터", "assert np.isclose(rc.sum(), np.sqrt(w @ S @ w))"]);
s = D.slide(1); y = D.head(s, "02. 차트 · matplotlib", "자본은 6:4여도 위험은 9:1로 쏠린다", "D.img는 PNG 실제 비율을 읽어 얹는다.");
D.img(s, "out/fig_bar.png", { y, bottom: 4.7 }); D.banner(s, 4.85, "데이터가 있으면 표보다 그림이 먼저 읽힌다");
s = D.slide(2); y = D.head(s, "03. 도해 · SVG", "해법은 세 단계로 나뉜다", "구조·흐름은 SVG로 그린다.");
D.img(s, "out/fig_flow.png", { y, bottom: 5.0 }); D.source(s, "작성자 도식");
D.save("viz_demo.pptx");
