# 슬라이드 레이아웃 및 DOM 구조

## 1. HTML 시맨틱 구조

### 권장 DOM 구조

```html
<div class="presentation" role="region" aria-label="Presentation" aria-roledescription="slide deck">
  <main class="slides">
    <section class="slide" aria-roledescription="slide" aria-label="Slide 1: Title">
      <!-- 슬라이드 콘텐츠 -->
    </section>
    <section class="slide" aria-roledescription="slide" aria-label="Slide 2: Overview">
      <!-- 슬라이드 콘텐츠 -->
    </section>
  </main>
  <nav class="slide-controls" aria-label="Slide navigation">
    <button aria-label="Previous slide">Prev</button>
    <span aria-live="polite" aria-atomic="true">Slide 2 of 10</span>
    <button aria-label="Next slide">Next</button>
  </nav>
</div>
```

### Reveal.js 참고 패턴

Reveal.js는 `.reveal > .slides > section` 3단계 계층을 사용한다:
- `<section>` 요소를 슬라이드 단위로 사용 (시맨틱적으로 적합)
- 중첩 `section`은 수직 슬라이드 (1단계만 허용)
- `data-state`, `data-background` 등 data 속성으로 슬라이드별 설정
- 스피커 노트는 `<aside class="notes">`로 표현

### Impress.js 참고 패턴

CSS3 3D transform 기반 "캔버스 위 배치" 방식:
- `#impress` 래퍼 + `.step` 클래스 + `.slide` 클래스
- `data-x`, `data-y`, `data-z`, `data-rotate`, `data-scale`로 3D 좌표 지정
- 각 step은 `future`, `present`, `past` 클래스로 상태 관리

---

## 2. 풀스크린 슬라이드 레이아웃

### 기본: CSS Grid 중앙 정렬

```css
html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  overflow: hidden;
}

.slides {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  position: relative;
}

.slide {
  width: 100vw;
  height: 100vh;
  display: grid;
  place-content: center;
  padding: clamp(1rem, 5vw, 4rem);
  box-sizing: border-box;
}
```

### Reveal.js 스타일: 고정 해상도 + transform 스케일링

슬라이드를 고정 크기(예: 960x700)로 만든 뒤 `transform: scale()`로 뷰포트에 맞춘다. 모든 화면에서 동일한 레이아웃을 보장한다:

```css
.slides {
  position: absolute;
  width: 960px;
  height: 700px;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%) scale(var(--scale-factor));
}
```

---

## 3. CSS scroll-snap vs JS 기반 전환

### CSS scroll-snap 방식

```css
.slides {
  width: 100vw;
  height: 100vh;
  overflow-y: scroll;
  scroll-snap-type: y mandatory;
}

.slide {
  width: 100vw;
  height: 100vh;
  scroll-snap-align: start;
  scroll-snap-stop: always;
}
```

### 비교

| 항목 | CSS scroll-snap | JS 기반 전환 |
|------|----------------|-------------|
| 애니메이션 제어 | 제한적 (easing/duration 커스텀 불가) | 완전한 제어 (fade, zoom, 3D 등) |
| 키보드 | 화살표 키, 스크롤바 자동 지원 | 직접 구현 필요 |
| 모바일 | 네이티브 스크롤 느낌, 터치 친화적 | 터치 이벤트 직접 핸들링 |
| Fragment 빌드 | 어려움 | 용이 |

**권장**: 빌드 효과와 커스텀 트랜지션이 필요하므로 **JS 기반 전환**이 프레젠테이션에 적합하다.

---

## 4. 슬라이드 레이아웃 유형

### 타이틀 슬라이드

```css
.slide--title {
  display: grid;
  place-content: center;
  text-align: center;
  background-image: linear-gradient(135deg, var(--color-primary), var(--color-secondary));
}
.slide--title h1 {
  font-size: clamp(2rem, 6vw, 5rem);
  margin-bottom: 0.5em;
}
.slide--title p {
  font-size: clamp(1rem, 2.5vw, 1.8rem);
  opacity: 0.8;
}
```

### 타이틀 + 콘텐츠

```css
.slide--content {
  display: grid;
  grid-template-rows: auto 1fr;
  padding: clamp(1.5rem, 4vw, 4rem);
  gap: 1.5rem;
}
.slide--content header {
  border-bottom: 3px solid var(--color-accent);
  padding-bottom: 0.75rem;
}
.slide--content .body {
  display: flex;
  flex-direction: column;
  justify-content: center;
  font-size: clamp(1rem, 2vw, 1.5rem);
}
```

### 2단 레이아웃

```css
.slide--two-col {
  display: grid;
  grid-template-rows: auto 1fr;
  grid-template-columns: 1fr 1fr;
  padding: clamp(1.5rem, 4vw, 4rem);
  gap: 2rem;
}
.slide--two-col header {
  grid-column: 1 / -1;
}
```

### 이미지 풀 (전체 배경)

```css
.slide--image-full {
  display: grid;
  place-content: end start;
  padding: 2rem;
  background-size: cover;
  background-position: center;
  color: white;
}
.slide--image-full .overlay {
  background: linear-gradient(transparent, rgba(0,0,0,0.7));
  position: absolute;
  inset: 0;
}
```

### 인용문 슬라이드

```css
.slide--quote {
  display: grid;
  place-content: center;
  text-align: center;
  padding: clamp(2rem, 8vw, 8rem);
}
.slide--quote blockquote {
  font-size: clamp(1.5rem, 3.5vw, 3rem);
  font-style: italic;
  line-height: 1.5;
  max-width: 60ch;
}
.slide--quote blockquote::before {
  content: "\201C";
  font-size: 4em;
  position: absolute;
  top: -0.4em;
  left: -0.3em;
  color: var(--color-accent);
  opacity: 0.3;
}
```

### 코드 블록 슬라이드

```css
.slide--code pre {
  background: var(--color-code-bg, #1e1e1e);
  color: var(--color-code-text, #d4d4d4);
  border-radius: 0.5rem;
  padding: 1.5rem;
  font-size: clamp(0.75rem, 1.5vw, 1.2rem);
  font-family: 'Fira Code', 'Consolas', monospace;
  overflow-x: auto;
  line-height: 1.6;
  tab-size: 2;
}
```

---

## 5. 반응형 처리

### clamp() 유동 타이포그래피

```css
:root {
  --fs-title: clamp(1.8rem, 5vw, 4.5rem);
  --fs-heading: clamp(1.2rem, 3vw, 2.5rem);
  --fs-body: clamp(0.9rem, 1.8vw, 1.4rem);
  --slide-padding: clamp(1rem, 5vw, 4rem);
}
```

### Container Queries

```css
.slide {
  container-type: inline-size;
  container-name: slide;
}

@container slide (max-width: 600px) {
  .slide--two-col {
    grid-template-columns: 1fr;
  }
}
```

---

## 6. CSS 커스텀 프로퍼티 테마

```css
:root {
  /* Color Primitives */
  --color-blue-500: #3b82f6;
  --color-gray-50: #f9fafb;
  --color-gray-900: #111827;

  /* Semantic Tokens */
  --color-primary: var(--color-blue-500);
  --color-bg: var(--color-gray-50);
  --color-text: var(--color-gray-900);

  /* Typography */
  --font-sans: system-ui, -apple-system, sans-serif;
  --font-mono: 'Fira Code', Consolas, monospace;
  --line-height-body: 1.6;
  --line-height-heading: 1.2;

  /* Spacing */
  --spacing-md: 1rem;
  --spacing-lg: 2rem;
  --spacing-xl: 4rem;

  /* Effects */
  --border-radius: 0.5rem;
  --transition-speed: 0.3s;
}

/* 다크 테마 */
[data-theme="dark"] {
  --color-bg: var(--color-gray-900);
  --color-text: var(--color-gray-50);
}

/* 슬라이드별 오버라이드 */
/* <section class="slide" style="--color-bg: #1a1a2e;"> */
```

---

## 7. 접근성

### ARIA 속성

- 프레젠테이션 컨테이너: `role="region"`, `aria-roledescription="slide deck"`
- 각 슬라이드: `role="group"`, `aria-roledescription="slide"`, `aria-label="Slide N of M"`
- 비활성 슬라이드: `aria-hidden="true"` (CSS만으로는 스크린 리더가 읽음)
- 슬라이드 상태 공지: `aria-live="polite"`, `aria-atomic="true"`

### 비활성 슬라이드 숨기기

`visibility: hidden`이나 `opacity: 0`만으로는 스크린 리더가 모든 슬라이드를 읽는다. 반드시 `display: none` 또는 `aria-hidden="true"`를 사용해야 한다.

### 모션 감소 대응

```css
@media (prefers-reduced-motion: reduce) {
  .slide {
    transition: none !important;
    animation: none !important;
  }
}
```

### 스크린 리더용 숨김

```css
.sr-only {
  position: absolute;
  width: 1px; height: 1px;
  padding: 0; margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap; border: 0;
}
```
