# 슬라이드 내 콘텐츠 애니메이션 (빌드 효과)

## 1. Fragment/Build 시스템 코어

핵심 패턴: **`.fragment` 클래스 요소를 순회하며, 입력 시 `.visible` 클래스를 순차 추가**.

### HTML 마크업

```html
<section class="slide">
  <h2>제목</h2>
  <p class="fragment">첫 번째 포인트</p>
  <p class="fragment">두 번째 포인트</p>
  <p class="fragment">세 번째 포인트</p>
</section>
```

### JavaScript 코어 로직

```javascript
let currentSlide = 0;
let currentFragment = -1;

function getFragments(slideIndex) {
  const slide = document.querySelectorAll('.slide')[slideIndex];
  return [...slide.querySelectorAll('.fragment')];
}

document.addEventListener('keydown', (e) => {
  const fragments = getFragments(currentSlide);

  if (e.key === 'ArrowRight' || e.key === ' ') {
    if (currentFragment < fragments.length - 1) {
      currentFragment++;
      fragments[currentFragment].classList.add('visible');
    } else {
      // 모든 fragment 완료 → 다음 슬라이드
      currentSlide++;
      currentFragment = -1;
      showSlide(currentSlide);
    }
  }

  if (e.key === 'ArrowLeft') {
    if (currentFragment >= 0) {
      fragments[currentFragment].classList.remove('visible');
      currentFragment--;
    } else {
      // 이전 슬라이드 (모든 fragment 복원)
      currentSlide--;
      const prevFragments = getFragments(currentSlide);
      prevFragments.forEach(f => f.classList.add('visible'));
      currentFragment = prevFragments.length - 1;
      showSlide(currentSlide);
    }
  }
});
```

---

## 2. CSS 클래스 체계

### 기본 3-class 시스템

| 클래스 | 역할 |
|--------|------|
| `.fragment` | 기본 숨김 상태 |
| `.fragment.visible` | 표시됨 (누적) |
| `.fragment.current-fragment` | 현재 활성 fragment만 (비누적) |

```css
.fragment:not(.custom) {
  opacity: 0;
  visibility: hidden;
  will-change: opacity;
  transition: all 0.2s ease;
}

.fragment.visible {
  opacity: 1;
  visibility: inherit;
}
```

### `current-fragment` 활용 (현재만 강조)

```css
.fragment.highlight-current {
  opacity: 1; visibility: inherit;
}
.fragment.highlight-current.current-fragment {
  color: #ff2c2d;
  background: rgba(255,44,45,0.1);
}
```

### `custom` 클래스 (기본 fade-in 방지)

```html
<p class="fragment custom blur">커스텀 블러 효과</p>
```

```css
.fragment.custom { opacity: 1; visibility: inherit; }
.fragment.blur { filter: blur(5px); }
.fragment.blur.visible { filter: none; transition: filter 0.5s ease; }
```

---

## 3. 빌드 애니메이션 종류

### Fade-In (기본)
```css
.fragment { opacity: 0; transition: opacity 0.4s ease; }
.fragment.visible { opacity: 1; }
```

### Fade-Up
```css
.fragment.fade-up {
  opacity: 0; transform: translateY(40px);
  transition: opacity 0.4s ease, transform 0.4s ease;
}
.fragment.fade-up.visible { opacity: 1; transform: translateY(0); }
```

### Scale-In
```css
.fragment.scale-in {
  opacity: 0; transform: scale(0.5);
  transition: opacity 0.4s ease, transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.fragment.scale-in.visible { opacity: 1; transform: scale(1); }
```

### Blur-In
```css
.fragment.blur-in {
  opacity: 0; filter: blur(10px);
  transition: opacity 0.5s ease, filter 0.5s ease;
}
.fragment.blur-in.visible { opacity: 1; filter: blur(0); }
```

### Grow / Shrink
```css
.fragment.grow { opacity: 1; visibility: inherit; transition: transform 0.4s ease; }
.fragment.grow.visible { transform: scale(1.3); }
.fragment.shrink.visible { transform: scale(0.7); }
```

### Highlight Colors
```css
.fragment.highlight-red { opacity: 1; visibility: inherit; }
.fragment.highlight-red.visible { color: #ff2c2d; }
.fragment.highlight-green.visible { color: #17ff2e; }
.fragment.highlight-blue.visible { color: #1b91ff; }
```

### Fade-Out
```css
.fragment.fade-out { opacity: 1; visibility: inherit; transition: opacity 0.4s ease; }
.fragment.fade-out.visible { opacity: 0; visibility: hidden; }
```

### Fade-In-Then-Out (2단계)
```css
.fragment.fade-in-then-out { opacity: 0; transition: opacity 0.4s ease; }
.fragment.fade-in-then-out.visible:not(.current-fragment) { opacity: 0; }
.fragment.fade-in-then-out.current-fragment { opacity: 1; }
```

### Typewriter (CSS-only)
```css
.typewriter .text {
  overflow: hidden; border-right: 0.15em solid orange;
  white-space: nowrap; width: 0;
}
.typewriter .text.visible {
  animation: typing 3.5s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
}
@keyframes typing { from { width: 0; } to { width: 100%; } }
@keyframes blink-caret { from, to { border-color: transparent; } 50% { border-color: orange; } }
```

---

## 4. 빌드 순서 제어

### `data-fragment-index` 속성

DOM 순서와 무관하게 등장 순서를 지정:

```html
<p class="fragment" data-fragment-index="3">세 번째로 나타남</p>
<p class="fragment" data-fragment-index="1">첫 번째로 나타남</p>
<p class="fragment" data-fragment-index="2">두 번째로 나타남</p>
```

### 동시 표시 (같은 index)

```html
<p class="fragment" data-fragment-index="1">함께 나타남 A</p>
<p class="fragment" data-fragment-index="1">함께 나타남 B</p>
<p class="fragment" data-fragment-index="2">다음 단계</p>
```

### JS 구현: 정렬 및 그룹핑

```javascript
function getFragmentsSorted(slide) {
  const fragments = [...slide.querySelectorAll('.fragment')];
  return fragments.sort((a, b) => {
    const indexA = parseInt(a.dataset.fragmentIndex ?? 999);
    const indexB = parseInt(b.dataset.fragmentIndex ?? 999);
    if (indexA !== indexB) return indexA - indexB;
    return fragments.indexOf(a) - fragments.indexOf(b);
  });
}

function getFragmentGroups(slide) {
  const sorted = getFragmentsSorted(slide);
  const groups = [];
  let currentGroup = [];
  let lastIndex = null;

  sorted.forEach(f => {
    const idx = f.dataset.fragmentIndex ?? 'auto';
    if (idx !== lastIndex && currentGroup.length) {
      groups.push(currentGroup);
      currentGroup = [];
    }
    currentGroup.push(f);
    lastIndex = idx;
  });
  if (currentGroup.length) groups.push(currentGroup);
  return groups;
}
```

---

## 5. 역방향 빌드

### CSS transition 방식 (권장)

클래스 제거 시 자동으로 원래 상태로 되돌아간다:

```css
.fragment.fade-up {
  opacity: 0; transform: translateY(40px);
  transition: opacity 0.4s ease, transform 0.4s ease;
}
.fragment.fade-up.visible { opacity: 1; transform: translateY(0); }
/* .visible 제거 시 자연스럽게 역재생됨 */
```

### 이전 슬라이드 복귀 시 모든 fragment 복원

```javascript
function goToPrevSlide() {
  currentSlide--;
  showSlide(currentSlide);
  const frags = getFragments(currentSlide);
  frags.forEach(f => f.classList.add('visible'));
  currentFragment = frags.length - 1;
}
```

---

## 6. 중첩 빌드

### 순차 적용 (중첩 fragment)

```html
<span class="fragment fade-in">
  <span class="fragment highlight-red">
    <span class="fragment fade-out">
      1단계: 나타남 → 2단계: 빨간색 → 3단계: 사라짐
    </span>
  </span>
</span>
```

### 그룹 빌드

```html
<div class="fragment" data-fragment-index="1">
  <h3>주제 A</h3>
  <ul>
    <li class="fragment" data-fragment-index="2">세부 항목 1</li>
    <li class="fragment" data-fragment-index="3">세부 항목 2</li>
  </ul>
</div>
```

부모 `.fragment`가 먼저 visible이 되어야 자식이 보인다 → 자연스러운 계층적 빌드.

---

## 7. 코드 하이라이팅 빌드

### 라인별 빌드

```html
<pre class="code-build"><code>
  <span class="code-line fragment" data-fragment-index="1">const app = express();</span>
  <span class="code-line fragment" data-fragment-index="2">app.get('/', handler);</span>
  <span class="code-line fragment" data-fragment-index="3">app.listen(3000);</span>
</code></pre>
```

```css
.code-line {
  display: block;
  opacity: 0.2;
  transition: opacity 0.3s ease, background 0.3s ease;
}
.code-line.visible { opacity: 1; background: rgba(255, 255, 0, 0.1); }
.code-line.current-fragment { background: rgba(255, 255, 0, 0.25); }
```

---

## 8. 성능 최적화

### transform + opacity만 애니메이션

```css
/* 좋음 */ .fragment.good { transform: translateY(-100px); opacity: 0; }
/* 나쁨 */ .fragment.bad { top: -100px; }  /* layout 트리거 */
```

### will-change (현재 슬라이드만)

```javascript
function activateSlide(index) {
  document.querySelectorAll('.slide.active .fragment').forEach(f => {
    f.style.willChange = 'auto';
  });
  slides[index].querySelectorAll('.fragment').forEach(f => {
    f.style.willChange = 'opacity, transform';
  });
}
```

### CSS Containment

```css
.slide { contain: content; }
.slide:not(.active) { content-visibility: hidden; }
```

`content-visibility: hidden`은 비활성 슬라이드 렌더링을 완전히 건너뛴다 (732ms → 54ms 사례 보고).

### DOM 조작 배칭

```javascript
requestAnimationFrame(() => {
  fragments.forEach(f => f.classList.add('visible'));
});
```

### visibility: hidden vs display: none

- `display: none`: 레이아웃 제거, 표시 시 reflow 발생
- `visibility: hidden` + `opacity: 0`: 레이아웃 유지, 전환 자연스러움 → **빌드에 권장**

### 이벤트 위임

```javascript
document.querySelector('.slideshow').addEventListener('click', (e) => {
  if (e.target.closest('.fragment')) { handler(e); }
});
```
