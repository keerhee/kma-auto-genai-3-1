# 키보드 및 마우스 네비게이션

## 1. 키보드 네비게이션

### 핵심 원칙
- **`keydown` 이벤트** 사용 (`keyup` 아닌): 키를 누르는 즉시 반응
- **`event.code`** 사용 권장: 물리적 키 위치 기반, 키보드 레이아웃 무관
- **`preventDefault()`** 필수: Arrow keys 페이지 스크롤 차단
- 입력 필드(`<input>`, `<textarea>`)에 포커스 시 네비게이션 비활성화

### 구현 패턴

```javascript
document.addEventListener('keydown', (event) => {
  if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

  switch (event.code) {
    case 'ArrowRight':
    case 'ArrowDown':
    case 'Space':
    case 'Enter':
      event.preventDefault();
      nextSlide();
      break;
    case 'ArrowLeft':
    case 'ArrowUp':
      event.preventDefault();
      prevSlide();
      break;
    case 'Home':
      event.preventDefault();
      goToSlide(0);
      break;
    case 'End':
      event.preventDefault();
      goToSlide(totalSlides - 1);
      break;
    case 'Escape':
      event.preventDefault();
      exitFullscreenOrOverview();
      break;
    case 'KeyF':
      event.preventDefault();
      toggleFullscreen();
      break;
    case 'KeyS':
      event.preventDefault();
      openSpeakerNotes();
      break;
  }
});
```

---

## 2. 터치/스와이프 제스처

### 핵심 원칙
- `touchstart`에서 시작 좌표, `touchend`에서 종료 좌표 비교
- **최소 임계값 50px**으로 의도하지 않은 터치 필터링
- 수평/수직 비율 비교로 주된 방향만 인식

### 구현 패턴

```javascript
let touchStartX = 0;
let touchStartY = 0;
const SWIPE_THRESHOLD = 50;

document.addEventListener('touchstart', (e) => {
  touchStartX = e.changedTouches[0].screenX;
  touchStartY = e.changedTouches[0].screenY;
}, { passive: true });

document.addEventListener('touchend', (e) => {
  const diffX = e.changedTouches[0].screenX - touchStartX;
  const diffY = e.changedTouches[0].screenY - touchStartY;
  const ratioX = Math.abs(diffX / diffY);
  const ratioY = Math.abs(diffY / diffX);

  const absDiff = Math.abs(ratioX > ratioY ? diffX : diffY);
  if (absDiff < SWIPE_THRESHOLD) return;

  if (ratioX > ratioY) {
    if (diffX > 0) prevSlide();   // 오른쪽 스와이프 = 이전
    else nextSlide();              // 왼쪽 스와이프 = 다음
  }
}, { passive: true });
```

---

## 3. 마우스 휠 네비게이션

### 핵심 원칙
- `wheel` 이벤트는 초당 30~100회 발생 → **throttle** 필수
- `deltaY` 값으로 방향 판단
- 슬라이드 전환 애니메이션 중 추가 입력 차단

### 상태 잠금 패턴 (추천)

```javascript
let isTransitioning = false;

document.addEventListener('wheel', (e) => {
  e.preventDefault();
  if (isTransitioning) return;

  isTransitioning = true;
  if (e.deltaY > 0) nextSlide();
  else if (e.deltaY < 0) prevSlide();

  // CSS 트랜지션 시간과 동기화
  setTimeout(() => { isTransitioning = false; }, 600);
}, { passive: false });
```

### Throttle 패턴

```javascript
function throttle(func, limit) {
  let inThrottle = false;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

document.addEventListener('wheel', throttle((e) => {
  e.preventDefault();
  if (e.deltaY > 0) nextSlide();
  else if (e.deltaY < 0) prevSlide();
}, 800), { passive: false });
```

---

## 4. URL 해시 라우팅

프레젠테이션에서는 **Hash 방식**이 적합: 서버 설정 없이 정적 파일로 동작, 딥링크 공유 간단.

### 구현 패턴

```javascript
function goToSlide(index) {
  currentSlide = index;
  showSlide(index);
  window.location.hash = `slide-${index + 1}`;
  updateProgressBar();
}

function initFromHash() {
  const hash = window.location.hash;
  if (hash) {
    const match = hash.match(/^#slide-(\d+)$/);
    if (match) {
      const index = parseInt(match[1], 10) - 1;
      if (index >= 0 && index < totalSlides) {
        goToSlide(index);
        return;
      }
    }
  }
  goToSlide(0);
}

// 브라우저 뒤로/앞으로 버튼 대응
window.addEventListener('hashchange', () => {
  const match = window.location.hash.match(/^#slide-(\d+)$/);
  if (match) {
    const index = parseInt(match[1], 10) - 1;
    if (index >= 0 && index < totalSlides) {
      showSlide(index);
      currentSlide = index;
      updateProgressBar();
    }
  }
});

document.addEventListener('DOMContentLoaded', initFromHash);
```

---

## 5. Fullscreen API

### 핵심 규칙
- `requestFullscreen()`은 반드시 **사용자 제스처 핸들러** 내에서 호출
- Promise를 반환하므로 `.catch()`로 에러 처리 가능

```javascript
function toggleFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else {
    document.documentElement.requestFullscreen().catch(err => {
      console.warn(`Fullscreen 진입 실패: ${err.message}`);
    });
  }
}

document.addEventListener('fullscreenchange', () => {
  const btn = document.getElementById('fullscreen-btn');
  if (document.fullscreenElement) {
    btn.textContent = 'Exit Fullscreen';
    document.body.classList.add('is-fullscreen');
  } else {
    btn.textContent = 'Fullscreen';
    document.body.classList.remove('is-fullscreen');
  }
});
```

---

## 6. 상태 관리

### 중앙 객체 + 이벤트 시스템

```javascript
const presentation = {
  currentIndex: 0,
  totalSlides: 0,
  slides: [],
  history: [],

  init() {
    this.slides = Array.from(document.querySelectorAll('.slide'));
    this.totalSlides = this.slides.length;
    this.goTo(0);
  },

  goTo(index) {
    if (index < 0 || index >= this.totalSlides) return;
    this.history.push(this.currentIndex);
    this.currentIndex = index;
    this.render();
    this.emit('slidechanged', { index, slide: this.slides[index] });
  },

  next() { if (this.currentIndex < this.totalSlides - 1) this.goTo(this.currentIndex + 1); },
  prev() { if (this.currentIndex > 0) this.goTo(this.currentIndex - 1); },

  _listeners: {},
  on(event, fn) { (this._listeners[event] ||= []).push(fn); },
  emit(event, data) { (this._listeners[event] || []).forEach(fn => fn(data)); },

  render() {
    this.slides.forEach((slide, i) => {
      slide.classList.toggle('active', i === this.currentIndex);
      slide.setAttribute('aria-hidden', i !== this.currentIndex);
    });
    window.location.hash = `slide-${this.currentIndex + 1}`;
    this.updateProgress();
  },

  getProgress() { return this.currentIndex / (this.totalSlides - 1); },
  isFirst() { return this.currentIndex === 0; },
  isLast() { return this.currentIndex === this.totalSlides - 1; },
};
```

---

## 7. 프로그레스 바

```html
<div class="progress-bar">
  <div class="progress-bar-fill"></div>
</div>
```

```css
.progress-bar {
  position: fixed;
  bottom: 0; left: 0;
  width: 100%; height: 4px;
  background: rgba(0, 0, 0, 0.1);
  z-index: 1000;
}
.progress-bar-fill {
  height: 100%; width: 0%;
  background: #2196F3;
  transition: width 400ms ease;
}
```

```javascript
function updateProgressBar() {
  const fill = document.querySelector('.progress-bar-fill');
  const progress = presentation.totalSlides > 1
    ? (presentation.currentIndex / (presentation.totalSlides - 1)) * 100
    : 100;
  fill.style.width = `${progress}%`;
}
```

---

## 8. 스피커 노트

### HTML에 노트 포함

```html
<section class="slide" data-notes="이 슬라이드에서는 프로젝트 개요를 설명합니다.">
  <h2>프로젝트 개요</h2>
</section>
```

### 별도 창 + PostMessage 동기화

```javascript
let speakerWindow = null;

function openSpeakerNotes() {
  speakerWindow = window.open('', 'speaker-notes', 'width=800,height=600');
  speakerWindow.document.write(`
    <html><head><title>Speaker Notes</title>
    <style>
      body { font-family: sans-serif; padding: 20px; }
      #notes { font-size: 1.4em; line-height: 1.6; }
      #timer { font-size: 2em; font-weight: bold; }
    </style></head>
    <body>
      <div id="timer">00:00</div>
      <div id="slide-info"></div>
      <div id="notes"></div>
    </body></html>
  `);
  updateSpeakerNotes();
}

function updateSpeakerNotes() {
  if (!speakerWindow || speakerWindow.closed) return;
  const slide = presentation.slides[presentation.currentIndex];
  const notes = slide.getAttribute('data-notes') || '(노트 없음)';
  speakerWindow.document.getElementById('notes').textContent = notes;
  speakerWindow.document.getElementById('slide-info').textContent =
    `슬라이드 ${presentation.currentIndex + 1} / ${presentation.totalSlides}`;
}

presentation.on('slidechanged', updateSpeakerNotes);
```

### 콘솔 기반 (가장 간단)

```javascript
presentation.on('slidechanged', ({ index, slide }) => {
  const notes = slide.getAttribute('data-notes');
  if (notes) {
    console.clear();
    console.log(`%c[Slide ${index + 1}] Speaker Notes:`, 'font-weight:bold; font-size:14px;');
    console.log(`%c${notes}`, 'font-size:12px; color:#333;');
  }
});
```
