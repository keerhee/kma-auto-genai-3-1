# 슬라이드 전환 애니메이션

## 1. 기본 전환 효과

모든 효과에서 **`transform`과 `opacity`만 애니메이션**하여 GPU 가속을 보장한다.

### Fade

```css
.slide {
  position: absolute;
  inset: 0;
  opacity: 0;
  transition: opacity 0.6s ease-in-out;
}
.slide.active { opacity: 1; }
```

### Slide Left/Right

```css
.slide {
  position: absolute;
  inset: 0;
  transform: translateX(100%);
  transition: transform 0.7s ease, opacity 0.7s ease;
  opacity: 0;
}
.slide.active { transform: translateX(0); opacity: 1; }
.slide.prev { transform: translateX(-100%); opacity: 0; }
```

### Slide Up/Down

```css
.slide.next { transform: translateY(100%); }
.slide.active { transform: translateY(0); }
.slide.prev { transform: translateY(-100%); }
```

### Zoom In/Out

```css
.slide {
  transform: scale(0.8);
  opacity: 0;
  transition: transform 0.6s ease, opacity 0.6s ease;
}
.slide.active { transform: scale(1); opacity: 1; }
.slide.prev { transform: scale(1.2); opacity: 0; }
```

### Flip (3D)

```css
.slides-container { perspective: 1200px; }
.slide {
  backface-visibility: hidden;
  transform: rotateY(90deg);
  transition: transform 0.8s ease;
}
.slide.active { transform: rotateY(0deg); }
.slide.prev { transform: rotateY(-90deg); }
```

---

## 2. CSS transition vs @keyframes

| 기준 | transition | @keyframes |
|------|-----------|------------|
| 단순 A→B 전환 | **적합** | 과잉 |
| 중간 단계 애니메이션 | 불가 | **적합** |
| 역방향 자동 처리 | **적합** (클래스 제거로 자동) | `animation-direction: reverse` 필요 |
| 반복/자동 재생 | 불가 | **적합** |

**권장**: 기본 슬라이드 전환은 `transition`, 복합 진입 효과는 `@keyframes`.

---

## 3. View Transitions API

Chrome 111+, Edge 111+, Safari 18+, Firefox 133+ 지원.

### 기본 사용법

```javascript
function goToSlide(nextIndex) {
  if (!document.startViewTransition) {
    updateSlideDOM(nextIndex);
    return;
  }
  document.startViewTransition(() => updateSlideDOM(nextIndex));
}
```

### 방향별 전환

```javascript
function goToSlide(nextIndex, currentIndex) {
  const direction = nextIndex > currentIndex ? 'forwards' : 'backwards';
  document.startViewTransition({
    update: () => updateSlideDOM(nextIndex),
    types: [direction]
  });
}
```

```css
.slide.active { view-transition-name: slide-content; }

::view-transition-group(slide-content) { animation-duration: 0.5s; }

html:active-view-transition-type(forwards) {
  &::view-transition-old(slide-content) { animation: 500ms ease-out both slide-out-left; }
  &::view-transition-new(slide-content) { animation: 500ms ease-out both slide-in-right; }
}

html:active-view-transition-type(backwards) {
  &::view-transition-old(slide-content) { animation: 500ms ease-out both slide-out-right; }
  &::view-transition-new(slide-content) { animation: 500ms ease-out both slide-in-left; }
}

@keyframes slide-out-left { to { transform: translateX(-100%); } }
@keyframes slide-in-right { from { transform: translateX(100%); } }
@keyframes slide-out-right { to { transform: translateX(100%); } }
@keyframes slide-in-left { from { transform: translateX(-100%); } }
```

---

## 4. 전환 상태 관리 (5-class 시스템)

| 클래스 | 위치 | 설명 |
|--------|------|------|
| `.before` | `translateX(-220%)` | 이전 슬라이드들 (숨김) |
| `.prev` | `translateX(-110%)` | 바로 이전 슬라이드 |
| `.active` | `translateX(0)` | 현재 슬라이드 |
| `.next` | `translateX(110%)` | 바로 다음 슬라이드 |
| `.after` | `translateX(220%)` | 이후 슬라이드들 (숨김) |

```css
.slide { position: absolute; inset: 0; transition: transform 0.7s ease, opacity 0.7s ease; opacity: 0; }
.slide.active { transform: none; opacity: 1; z-index: 2; }
.slide.prev { transform: translate3d(-110%, 0, 0); opacity: 0.25; z-index: 1; }
.slide.next { transform: translate3d(110%, 0, 0); opacity: 0.25; z-index: 1; }
.slide.before { transform: translate3d(-220%, 0, 0); opacity: 0; }
.slide.after { transform: translate3d(220%, 0, 0); opacity: 0; }
```

```javascript
function updateClasses(newIndex) {
  slides.forEach((slide, i) => {
    slide.classList.remove('before', 'prev', 'active', 'next', 'after');
    if (i < newIndex - 1) slide.classList.add('before');
    else if (i === newIndex - 1) slide.classList.add('prev');
    else if (i === newIndex) slide.classList.add('active');
    else if (i === newIndex + 1) slide.classList.add('next');
    else slide.classList.add('after');
  });
  currentIndex = newIndex;
}
```

**장점**: JS는 클래스만 토글, 모든 시각적 전환은 CSS가 담당. 깔끔한 관심사 분리.

---

## 5. GPU 가속

### 핵심 규칙

`transform`과 `opacity`만 애니메이션하면 GPU 컴포지터에서 처리 (60fps).

```css
/* 좋음: GPU 가속 */
.slide { transition: transform 0.7s ease, opacity 0.7s ease; }

/* 나쁨: CPU 레이아웃 재계산 */
.slide-bad { transition: left 0.7s ease, width 0.7s ease; }
```

### will-change

```css
/* 전환 직전/직후 슬라이드에만 적용 */
.slide.next, .slide.prev { will-change: transform, opacity; }
.slide.active { will-change: auto; }
```

주의: 남용 시 각 요소가 별도 GPU 레이어로 승격 → VRAM 소비 (800x600px당 ~1.9MB).

### 암묵적 컴포지팅 방지

```css
.slide.active { z-index: 10; }  /* 다른 요소보다 높게 */
```

---

## 6. 전환 방향 처리

```css
.slides-container.going-forward .slide.active {
  animation: slideInFromRight 0.6s ease forwards;
}
.slides-container.going-forward .slide.prev {
  animation: slideOutToLeft 0.6s ease forwards;
}
.slides-container.going-backward .slide.active {
  animation: slideInFromLeft 0.6s ease forwards;
}
.slides-container.going-backward .slide.prev {
  animation: slideOutToRight 0.6s ease forwards;
}
```

```javascript
function navigate(direction) {
  const container = document.querySelector('.slides-container');
  container.classList.remove('going-forward', 'going-backward');
  container.classList.add(direction === 1 ? 'going-forward' : 'going-backward');
  updateClasses(currentIndex + direction);
}
```

---

## 7. 전환 타이밍

### 프레젠테이션 추천 이징 함수

| 이름 | cubic-bezier | 용도 |
|------|-------------|------|
| easeInOutCubic | `(0.65, 0, 0.35, 1)` | **프레젠테이션 추천** — 부드럽고 프로페셔널 |
| easeOutQuint | `(0.22, 1, 0.36, 1)` | 빠른 진입 후 느린 정착 |
| easeOutExpo | `(0.16, 1, 0.3, 1)` | 매우 빠른 진입 — 스냅 느낌 |

```css
:root {
  --transition-duration: 0.6s;
  --ease-slide: cubic-bezier(0.65, 0, 0.35, 1);
  --ease-fade: cubic-bezier(0.42, 0, 0.58, 1);
  --ease-enter: cubic-bezier(0.22, 1, 0.36, 1);
  --ease-exit: cubic-bezier(0.55, 0, 1, 0.45);
}

.slide {
  transition: transform var(--transition-duration) var(--ease-slide),
              opacity var(--transition-duration) var(--ease-fade);
}
```

**전환 시간**: 300ms~700ms가 적절.

---

## 8. 인쇄 스타일

```css
@page { size: landscape; margin: 1cm; }

@media print {
  .controls, .progress-bar, .slide-number { display: none !important; }

  .slide {
    position: relative !important;
    transform: none !important;
    opacity: 1 !important;
    visibility: visible !important;
    display: block !important;
    width: 100% !important;
    height: auto !important;
    overflow: visible !important;
    break-after: page;
    page-break-after: always;
    break-inside: avoid;
    page-break-inside: avoid;
  }
  .slide:last-child {
    break-after: auto;
    page-break-after: auto;
  }

  * {
    animation: none !important;
    transition: none !important;
  }

  body {
    background: white !important;
    color: black !important;
  }
}
```
