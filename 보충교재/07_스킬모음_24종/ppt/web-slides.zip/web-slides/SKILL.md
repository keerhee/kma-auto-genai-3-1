---
name: web-slides
description: >
  This skill should be used when the user asks to "순수 HTML로 슬라이드 만들어",
  "바닐라 JS 프레젠테이션", "웹 슬라이드 구현", "HTML 프레젠테이션 생성",
  "create vanilla slide presentation", "build HTML slides",
  "라이브러리 없이 슬라이드", "순수 웹 PPT", "web-slides",
  "웹 슬라이드 만들어줘", "프레젠테이션 HTML로 만들어".
  Generate web-based slide presentations using only vanilla HTML, CSS, and JavaScript — no external libraries.
---

# Web Slides

순수 HTML, CSS, JavaScript만으로 웹 기반 슬라이드 프레젠테이션을 생성한다. 외부 라이브러리 없이 Reveal.js 수준의 기능(전환 애니메이션, 빌드 효과, 키보드/터치 네비게이션, 스피커 노트)을 구현한다.

## 사용법

사용자가 출력 경로를 지정하면 해당 위치에 단일 HTML 파일을 생성한다.

```
사용자: "AI 트렌드에 대한 프레젠테이션을 ./output/ai-trends.html로 만들어줘"
사용자: "이 내용으로 웹 슬라이드 만들어. 경로: presentations/quarterly-review.html"
사용자: "web-slides로 5장짜리 슬라이드 생성해줘"  (경로 미지정 시 ./slides.html)
```

### 출력 규칙

1. **경로가 지정된 경우** — 해당 경로에 HTML 파일 생성 (디렉토리가 없으면 생성)
2. **경로 미지정** — 현재 작업 디렉토리에 `slides.html` 생성
3. **항상 단일 HTML 파일** — CSS와 JS를 인라인으로 포함하여 의존성 없이 동작
4. **샘플 참조** — `assets/sample.html`을 구조적 템플릿으로 참고하여 생성

## 아키텍처 원칙

1. **단일 HTML 파일** — CSS와 JS를 인라인으로 포함하여 의존성 없이 동작
2. **JS는 클래스만 토글, CSS가 모든 시각 효과 담당** — 관심사 분리
3. **GPU 가속** — `transform`과 `opacity`만 애니메이션 (절대 `left`, `top`, `width` 등 레이아웃 속성 금지)
4. **접근성** — ARIA roles, 키보드 네비게이션, `prefers-reduced-motion` 대응

## HTML 구조

```html
<div class="presentation" role="region" aria-roledescription="slide deck">
  <main class="slides">
    <section class="slide [layout-class]" aria-roledescription="slide" data-notes="스피커 노트">
      <element class="fragment [effect-class]" data-fragment-index="N">콘텐츠</element>
    </section>
  </main>
  <div class="progress-bar"><div class="progress-bar-fill"></div></div>
</div>
```

## 슬라이드 레이아웃 클래스

| 클래스 | 용도 | CSS 핵심 |
|--------|------|----------|
| `.slide--title` | 타이틀 슬라이드 | `place-content: center; text-align: center` |
| `.slide--content` | 타이틀+본문 | `grid-template-rows: auto 1fr` |
| `.slide--two-col` | 2단 레이아웃 | `grid-template-columns: 1fr 1fr` |
| `.slide--image-full` | 전체 배경 이미지 | `background-size: cover` |
| `.slide--quote` | 인용문 | `blockquote` 중앙 배치 |
| `.slide--code` | 코드 블록 | `pre/code` 스타일링 |

상세 CSS 패턴 → `references/layout-and-dom.md`

## 슬라이드 전환

### 5-class 상태 시스템

JS가 각 슬라이드에 위치 클래스를 부여하고, CSS `transition`이 애니메이션을 처리:

- `.before` / `.prev` / `.active` / `.next` / `.after`

### 전환 효과 타입

CSS 변수 `--transition-type`으로 전환 효과를 선택:
- **slide** (기본): `translateX` 기반 좌우 이동
- **fade**: `opacity` 전환
- **zoom**: `scale` + `opacity`
- **flip**: `rotateY` (3D, `perspective` 필요)

### 핵심 CSS 변수

```css
:root {
  --transition-duration: 0.6s;
  --ease-slide: cubic-bezier(0.65, 0, 0.35, 1);  /* easeInOutCubic 추천 */
}
```

상세 전환 패턴 → `references/slide-transitions.md`

## 빌드 효과 (Fragment)

### 클래스 체계

- `.fragment` — 기본 숨김 (opacity: 0, visibility: hidden)
- `.fragment.visible` — 표시됨 (누적)
- `.fragment.current-fragment` — 현재 활성 fragment만

### 효과 클래스

`fade-up`, `scale-in`, `blur-in`, `grow`, `shrink`, `highlight-red/green/blue`, `fade-out`, `fade-in-then-out`

### 순서 제어

`data-fragment-index="N"` — 같은 값은 동시 표시, DOM 순서 무관

### 역방향

CSS `transition` 사용 시 `.visible` 제거로 자동 역재생. 이전 슬라이드 복귀 시 모든 fragment를 `.visible`로 복원.

상세 빌드 패턴 → `references/build-effects.md`

## 네비게이션

### 입력 방식

| 입력 | 동작 |
|------|------|
| `ArrowRight` / `Space` / `Enter` | 다음 (fragment 우선, 없으면 다음 슬라이드) |
| `ArrowLeft` | 이전 (fragment 역방향 우선) |
| `Home` / `End` | 첫/마지막 슬라이드 |
| `Escape` | 전체화면 해제 |
| `F` | 전체화면 토글 |
| `S` | 스피커 노트 창 열기 |
| 터치 스와이프 | 좌우 스와이프로 이동 (threshold 50px) |
| 마우스 휠 | 상하 스크롤로 이동 (throttle 600ms) |

### URL 해시

`#slide-N` 형식으로 딥링크. `hashchange` 이벤트로 뒤로/앞으로 버튼 대응.

상세 네비게이션 패턴 → `references/navigation.md`

## 테마 시스템

CSS 커스텀 프로퍼티 기반. `[data-theme="dark"]` 셀렉터로 다크 모드 전환. 슬라이드별 `style="--color-bg: ..."` 오버라이드 가능.

## 인쇄 지원

`@media print`에서 모든 슬라이드를 `break-after: page`로 한 페이지씩 출력. 애니메이션/전환 비활성화, 컨트롤 숨김.

## 성능 체크리스트

- [ ] `transform` + `opacity`만 애니메이션
- [ ] 비활성 슬라이드에 `content-visibility: hidden`
- [ ] `will-change`는 전환 직전/직후 슬라이드에만
- [ ] 휠 이벤트에 throttle 또는 상태 잠금
- [ ] `prefers-reduced-motion`에서 애니메이션 비활성화

## Additional Resources

### Reference Files
- **`references/layout-and-dom.md`** — HTML 시맨틱 구조, 풀스크린 레이아웃, 슬라이드 레이아웃 유형 6종, 반응형 처리, CSS 테마 변수, 접근성 ARIA 패턴
- **`references/navigation.md`** — 키보드/터치/휠 네비게이션, URL 해시 라우팅, Fullscreen API, 상태 관리 객체, 프로그레스 바, 스피커 노트
- **`references/slide-transitions.md`** — fade/slide/zoom/flip 전환 CSS, View Transitions API, 5-class 상태 시스템, GPU 가속, 이징 함수, 인쇄 스타일
- **`references/build-effects.md`** — fragment 시스템, 10종 빌드 애니메이션 CSS, 순서 제어, 역방향 빌드, 중첩 빌드, 코드 하이라이팅, 성능 최적화

### Assets
- **`assets/sample.html`** — 완전한 동작 샘플. 모든 레이아웃, 전환, 빌드 효과, 네비게이션이 포함된 참조 구현체
