# Day3 응용 실습 II 자료 설명

기준일은 2026년 10월 23일이다. 질문과 실제 결과는 공개 보도에서 가져왔다. 가상 인물의 확률(`is_assumed=1`)과 이득·손실 금액은 교육용으로 만든 예시이므로, 실습에서 조가 직접 받은 값으로 바꾼다.

## 파일

| 파일 | 담은 내용 |
|---|---|
| `fml_d3p_questions.csv` | 질문 일곱 개의 문장, 기준일, 마감일, 실제 결과(1은 예, 0은 아니오), 판정 출처 |
| `fml_d3p_swarm_interviews.csv` | 질문·실행·집단마다 가상 인물이 말한 '예'일 확률의 평균 (교육용 예시) |
| `fml_d3p_human_forecasts.csv` | 전략기획팀의 확률(교육용 예시)과 강의실에서 받을 사람 예측 빈칸 |
| `fml_d3p_actions.csv` | 질문마다 '예'일 때 할 일과 이득 G, 손실 L (교육용 예시, 억 달러) |
| `d3p_compute.py` | 확률을 모으고, Brier 점수로 채점하고, 기준선 L/(G+L)로 결정표를 내는 계산기 |
| `my_interviews_template.csv` | 조별 인터뷰 결과를 적을 빈 양식 |
| `seeds/seed_announce_20250324.md` | 시드 A: 3월 25일 아침까지의 공개 사실과 질문 1~5 |
| `seeds/seed_shock_20250905.md` | 시드 B: 9월 5일까지 새로 알려진 사실과 질문 6·7 |

## 열 설명 (`fml_d3p_swarm_interviews.csv`)

| 열 | 뜻 |
|---|---|
| `qid` | 질문 번호 Q1~Q7 |
| `run` | 같은 설정으로 돌린 실행 번호 |
| `group` | 인물 집단 여섯 가지 가운데 하나 |
| `is_expert` | 투자자·애널리스트, 통상·정책 전문가이면 1 |
| `prob_yes` | 그 집단 인물들이 말한 '예'일 확률의 평균 (0~1) |
| `n_agents` | 그 집단의 인물 수 |
| `is_assumed` | 교육용 예시이면 1 |

## 계산기 사용법

```bash
python3 d3p_compute.py                       # 준비된 예시 확률로 계산
python3 d3p_compute.py class_interviews.csv  # 우리 반이 받은 확률로 계산
```
