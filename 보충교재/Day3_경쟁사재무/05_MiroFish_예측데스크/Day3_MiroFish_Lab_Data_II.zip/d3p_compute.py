"""Day3 II 계산기: 스웜 확률을 모으고, 실제 결과로 채점하고, 행동 규칙으로 바꾼다.
사용법: python3 d3p_compute.py [인터뷰 csv]  (기본: fml_d3p_swarm_interviews.csv)
"""
import csv, sys, statistics as st
from collections import defaultdict
F = sys.argv[1] if len(sys.argv) > 1 else "fml_d3p_swarm_interviews.csv"
Q = {r["qid"]: r for r in csv.DictReader(open("fml_d3p_questions.csv", encoding="utf-8"))}
H = {r["qid"]: r for r in csv.DictReader(open("fml_d3p_human_forecasts.csv", encoding="utf-8"))}
A = {r["qid"]: r for r in csv.DictReader(open("fml_d3p_actions.csv", encoding="utf-8"))}
I = list(csv.DictReader(open(F, encoding="utf-8")))

allp, exp, grp = defaultdict(list), defaultdict(list), defaultdict(lambda: defaultdict(list))
for r in I:
    p = float(r["prob_yes"]); allp[r["qid"]].append(p); grp[r["qid"]][r["group"]].append(p)
    if r["is_expert"] == "1": exp[r["qid"]].append(p)

def brier(ps): return sum((ps[q] - int(Q[q]["outcome"])) ** 2 for q in ps) / len(ps)
sw = {q: st.mean(allp[q]) for q in Q}
se = {q: st.mean(exp[q]) for q in Q}
hu = {q: float(H[q]["strategy_team_prob"]) for q in Q}
cm = {q: float(H[q]["class_market_prob"]) for q in Q if H[q]["class_market_prob"]}

print("1. 질문마다 '예'일 확률을 모았다 (괄호는 실제 결과)")
for q in Q:
    print(f"  {q} 스웜 전체 {sw[q]:.2f} · 전문가 집단 {se[q]:.2f} · 전략기획팀 {hu[q]:.2f} (실제 {'예' if Q[q]['outcome']=='1' else '아니오'})")
print("\n2. Brier 점수로 채점했다 (0에 가까울수록 잘 맞혔다, 아무것도 모르고 50%를 부르면 0.25)")
board = [("스웜 전문가 집단", brier(se)), ("스웜 전체", brier(sw)), ("전략기획팀", brier(hu)), ("모두 50%", 0.25)]
if len(cm) == len(Q): board.append(("강의실 예측시장", brier(cm)))
for k, v in sorted(board, key=lambda x: x[1]): print(f"  {k}: {v:.3f}")
print("\n3. 확률이 기준선을 넘으면 행동한다 (기준선 = 틀렸을 때 손실 ÷ (맞혔을 때 이득 + 손실))")
tot = defaultdict(float)
for q in Q:
    G, L = float(A[q]["gain_if_right"]), float(A[q]["loss_if_wrong"]); th = L / (G + L); y = int(Q[q]["outcome"])
    for name, ps in [("스웜 전문가 집단", se), ("전략기획팀", hu)]:
        act = ps[q] > th; tot[name] += (G if y else -L) if act else 0
    act = se[q] > th
    print(f"  {q} 기준선 {th:.2f} · 스웜 {se[q]:.2f} → {'한다' if act else '하지 않는다'}: {A[q]['action_if_yes_ko']}")
print("\n4. 그대로 따랐다면 얻었을 가치 (교육용 가정 금액, 억 달러)")
for k, v in tot.items(): print(f"  {k}의 확률을 따랐다면 {v:+.0f}")
print("\n5. 집단마다 확률이 얼마나 달랐나 (Q4·Q7은 '아니오'가 정답이었다)")
for q in ["Q4", "Q7"]:
    print("  " + q + " " + " · ".join(f"{g} {st.mean(v):.2f}" for g, v in grp[q].items()))
