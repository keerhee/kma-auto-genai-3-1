# K-Auto Neo4j Obsidian Vault

## 구성
- `00_시작_여기.md`: 수강생 시작 페이지
- `KAuto_Stage1_종합실습교재.md`: 전체 P0~P14 강의노트 + SVG + 기업 30/관계 42 전체표 + Cypher 9개
- `student_report_TEMPLATE.md`: 제출 양식
- `assets/svg/`: 11개의 개별 SVG 원본 (폰트 파일 미포함)
- `assets/png/`: v1.3에서 더한 데이터 그림 8장 (CSV에서 직접 계산 — 관계 분포·전체 지도·출처 확인·근거 카드·발표 연도·성공 계단·두 층·2단계)
- `KAuto_Project_Source/kauto_kg_mvp/`: CSV / Python / Neo4j Docker / MCP / Cypher 실습 원본
- `Reference_Original/`: 기존 강의 자료, PPTX 및 보충 가이드

## 시작
ZIP 압축을 푼 폴더 자체를 Obsidian Vault로 열고 `00_시작_여기.md`를 클릭합니다.
명령은 반드시 `KAuto_Project_Source/kauto_kg_mvp/`에서 실행합니다.
원본 프로젝트는 .env가 없으므로 `.env.example`에서 각자 만들어야 합니다.

## 안전
기존 DB 초기화 금지. 학생의 DB 접속/MCP 성공 상태는 개별 PC에서 검증해야 합니다.
