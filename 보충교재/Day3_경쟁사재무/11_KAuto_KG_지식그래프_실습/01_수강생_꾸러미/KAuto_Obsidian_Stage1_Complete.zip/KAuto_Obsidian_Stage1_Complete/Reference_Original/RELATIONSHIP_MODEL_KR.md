# 기업↔기업 관계 온톨로지 (1단계 보강판)

## 왜 필요한가

기존 1단계 데이터에서는 회사가 어떤 기술을 보유하는지만 표현되었으며, 회사 간 공식 관계가 누락되었다. 이 데이터는 이를 1단계에서 보완한다.

## 관계유형 (42개 관계 · 12개 1차 출처)

| Cypher type | 의미 | 수량 |
|---|---|---:|
| `AFFILIATED_WITH` | 동일 기업집단 | 12 |
| `CO_MEMBER_OF_CONSORTIUM` | 컨소시엄 공동참여 | 12 |
| `JOINT_RESEARCH_WITH` | 공동 연구·개발 | 6 |
| `TECH_PARTNERS_WITH` | 기술 협력 | 4 |
| `SUPPLY_AGREEMENT_WITH` | 공급계약 | 3 |
| `JOINT_VENTURE_PLAN_WITH` | JV 계획 승인 | 3 |
| `SUPPLIES_TO` | 실제 공급 보도 | 1 |
| `BATTERY_COOPERATION_WITH` | 배터리 협력 | 1 |

## 유의사항

- `AFFILIATED_WITH`는 단순한 동일 그룹 소속이며 지분율이나 지배관계를 나타내지 않는다. 별도 원문 공시 없이 소유비중을 생성하지 않는다.
- `SUPPLY_AGREEMENT_WITH`는 계약 체결 사실이고 현재 납품 물량·매출 발생을 의미하지 않는다.
- `SUPPLIES_TO`는 공식 자료에서 기존 공급관계를 명시한 경우만 사용한다. 품목별·연도별 금액은 별도로 조사해야 한다.
- `JOINT_VENTURE_PLAN_WITH`는 당시 발표 및 이사회 승인을 의미한다. 2026년 현재 소유·가동 상태와 동일하지 않다.
- `CO_MEMBER_OF_CONSORTIUM`은 동일 컨소시엄에 참여한다는 의미이고 두 기업의 양자 계약을 증명하지 않는다.
- 2026-10-19 현재 조사. 발표일이 없는 기업집단 목록은 날짜를 공란으로 두었으며 `reviewed_on`은 자료를 확인한 날짜다.

## 재현 가능한 기업↔기업 관계 샘플

| 원천기업 | 연결기업 | 유형 | 공표/근거일 | 출처 |
|---|---|---|---|---|
| 현대자동차 | 기아 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대모비스 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대위아 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대트랜시스 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대케피코 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대제철 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 현대오토에버 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| 현대자동차 | 포티투닷 | 동일 기업집단 | 미상 | [공식자료](https://www.hyundai.com/worldwide/en/footer/corporate/affiliates) |
| LG에너지솔루션 | LG화학 | 동일 기업집단 | 미상 | [공식자료](https://lgcorp.com/media/release/27644) |
| LG에너지솔루션 | LG전자 | 동일 기업집단 | 미상 | [공식자료](https://lgcorp.com/media/release/27644) |
| 포스코 | 포스코퓨처엠 | 동일 기업집단 | 미상 | [공식자료](https://www.posco-inc.com/hs91a1-front/app/en/index.html) |
| 삼성전자 | 삼성SDI | 동일 기업집단 | 2025-04-30 | [공식자료](https://www.samsung.com/global/ir/reports-disclosures/public-disclosure-view.84357/) |
| 포스코퓨처엠 | LG에너지솔루션 | 공급계약 | 2023-09-04 | [공식자료](https://newsroom.posco.com/en/posco-future-m-introducing-posco-future-m-employees-of-the-year-dae-gyeong-jo-and-gi-hyeon-lee/) |
| 포스코퓨처엠 | 삼성SDI | 공급계약 | 2026-10-06 | [공식자료](https://newsroom.posco.com/en/posco-future-m-signs-krw-6-trillion-lfp-supply-contract-with-samsung-sdi-builds-strategic-partnership-as-key-supplier-of-non-pfe-materials/) |
| 포스코퓨처엠 | SK온 | 공급계약 | 2026-10-06 | [공식자료](https://newsroom.posco.com/en/posco-future-m-signs-krw-1-1-trillion-lfp-cathode-material-supply-contract-with-sk-on-order-wins-gather-pace/) |
| 포스코퓨처엠 | SK온 | 실제 공급 보도 | 2026-10-06 | [공식자료](https://newsroom.posco.com/en/posco-future-m-signs-krw-1-1-trillion-lfp-cathode-material-supply-contract-with-sk-on-order-wins-gather-pace/) |
| 현대자동차 | 에코프로비엠 | 공동 연구·개발 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motor-and-kia-team-up-with-hyundai-steel-and-ecopro-bm-to-enhance-ev-battery-technology-0000000835) |
| 기아 | 에코프로비엠 | 공동 연구·개발 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motor-and-kia-team-up-with-hyundai-steel-and-ecopro-bm-to-enhance-ev-battery-technology-0000000835) |
| 현대자동차 | 현대제철 | 공동 연구·개발 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motor-and-kia-team-up-with-hyundai-steel-and-ecopro-bm-to-enhance-ev-battery-technology-0000000835) |
| 기아 | 현대제철 | 공동 연구·개발 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motor-and-kia-team-up-with-hyundai-steel-and-ecopro-bm-to-enhance-ev-battery-technology-0000000835) |
| 현대제철 | 에코프로비엠 | 공동 연구·개발 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motor-and-kia-team-up-with-hyundai-steel-and-ecopro-bm-to-enhance-ev-battery-technology-0000000835) |
| 현대자동차 | 삼성전자 | 기술 협력 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000834) |
| 현대자동차 | 포티투닷 | 기술 협력 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000834) |
| 기아 | 삼성전자 | 기술 협력 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000834) |
| 기아 | 포티투닷 | 기술 협력 | 2024-09-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000834) |
| 현대자동차 | SK온 | JV 계획 승인 | 2023-04-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motorgroup-and-sk-on-to-establish-ev-battery-cell-production-joint-venturein-us-0000000237) |
| 기아 | SK온 | JV 계획 승인 | 2023-04-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motorgroup-and-sk-on-to-establish-ev-battery-cell-production-joint-venturein-us-0000000237) |
| 현대모비스 | SK온 | JV 계획 승인 | 2023-04-25 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/hyundai-motorgroup-and-sk-on-to-establish-ev-battery-cell-production-joint-venturein-us-0000000237) |
| 현대자동차 | LG에너지솔루션 | 배터리 협력 | 2023-05-26 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000254) |
| 현대자동차 | 기아 | 공동 연구·개발 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | 현대모비스 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | 현대위아 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | 현대케피코 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | 현대트랜시스 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | 현대오토에버 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 현대자동차 | HL만도 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | 현대모비스 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | 현대위아 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | 현대케피코 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | 현대트랜시스 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | 현대오토에버 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |
| 기아 | HL만도 | 컨소시엄 공동참여 | 2023-04-07 | [공식자료](https://www.hyundai.com/worldwide/en/newsroom/detail/0000000228) |

## 관계 조회 예제

```cypher
MATCH (a:KAutoCompany)-[r]-(b:KAutoCompany)
WHERE a.id = 'company.poscofuturem' AND r.project='kauto-stage1'
RETURN a.name_ko AS 기준회사, b.name_ko AS 상대회사, type(r) AS 관계유형,
       r.topic AS 내용, r.announcement_date AS 발표일, r.assertion_status AS 진행상태,
       r.evidence_url AS 공식출처;
```

## 향후 단계 연결점

NeoQuant에서는 이 관계 그래프를 증권·팩터·신용등급·위험 노출 노드와 연결한다. 다만 그래프 연결만으로 주가 동행, 산업위험 전파, 실제 매출 의존도를 추정해서는 안 된다.
