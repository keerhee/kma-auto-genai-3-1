"""Self-contained OFFLINE CSV preview; not a live rendering of the Neo4j database."""
from __future__ import annotations
import json
from pathlib import Path
from common import ROOT,read_csv

def main():
    dataset={
       'stages':read_csv('stages.csv'),
       'companies':read_csv('companies.csv'),
       'capabilities':read_csv('capabilities.csv'),
       'relationships':read_csv('company_relationships.csv'),
    }
    blob=json.dumps(dataset,ensure_ascii=False).replace('</','<\\/')
    template=r'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>K-Auto KG — 산업 온톨로지 미리보기</title>
<style>
:root{--bg:#f2f5fa;--ink:#122039;--muted:#64748b;--line:#dbe2eb;--navy:#111f38;--teal:#00af96;--amber:#be7a00}*{box-sizing:border-box}body{margin:0;font-family:'Apple SD Gothic Neo','Malgun Gothic',Inter,system-ui,sans-serif;background:var(--bg);color:var(--ink)}a{color:#2067ae;text-decoration:none}a:hover{text-decoration:underline}header{background:var(--navy);color:#fff;padding:25px max(24px,calc((100vw - 1450px)/2)) 22px}header h1{font-size:29px;margin:7px 0 8px;letter-spacing:-.8px}header p{color:#cbd5e1;margin:0;line-height:1.55}.eyebrow{font-size:11px;color:#69dfcd;letter-spacing:1.8px;font-weight:800}.wrap{max-width:1450px;margin:0 auto;padding:22px}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:19px}.stat{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px}.stat strong{font-size:27px;display:block}.stat span{color:var(--muted);font-size:12px}.stage-container{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px}.stage{border:1px solid var(--line);background:white;color:#334155;padding:9px 13px;border-radius:18px;cursor:pointer;font-weight:600}.stage.active{background:var(--navy);color:white;border-color:var(--navy)}.layout{display:grid;grid-template-columns:340px minmax(0,1fr);gap:17px}.panel{background:white;border:1px solid var(--line);border-radius:16px;box-shadow:0 5px 16px #0f233707;overflow:hidden}.list-top{padding:17px;border-bottom:1px solid var(--line)}h2{font-size:16px;margin:0 0 13px}.list-top input{width:100%;padding:11px 13px;border:1px solid #ccd8e6;border-radius:10px;font-size:14px}.list{max-height:680px;overflow:auto}.company{display:flex;align-items:center;justify-content:space-between;gap:8px;border:0;border-bottom:1px solid #edf1f5;padding:13px 16px;background:white;width:100%;text-align:left;cursor:pointer}.company:hover{background:#f6fafc}.company.active{background:#e9f8f5;border-left:4px solid var(--teal);padding-left:12px}.company .name{font-size:14px;font-weight:700}.company small{display:block;font-size:11px;color:var(--muted);margin-top:3px}.status{display:inline-flex;font-size:10px;font-weight:700;padding:4px 7px;border-radius:20px;white-space:nowrap;background:#fff2d9;color:#895500}.status.verified{background:#dbf8ee;color:#087360}.visual-top{padding:18px 20px 6px}.over{color:var(--muted);font-size:12px;letter-spacing:.8px;text-transform:uppercase;font-weight:700}.visual-top h2{font-size:24px;letter-spacing:-.7px;margin:5px 0}.sub{font-size:13px;color:var(--muted)}.graphframe{margin:8px 17px;border:1px solid var(--line);border-radius:13px;background:linear-gradient(180deg,#fafcff,#f6fafd);overflow:auto}.graphframe svg{width:100%;min-width:670px;display:block}.details{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:4px 18px 20px}.detail{border:1px solid var(--line);background:#fcfdff;border-radius:11px;padding:14px;min-height:112px}.detail b{display:block;font-size:12px;color:#526177;margin-bottom:7px}.detail p{font-size:13px;line-height:1.6;margin:0}.detail a{overflow-wrap:anywhere}.note{margin:18px 0 0;font-size:12px;color:var(--muted);line-height:1.6}.graph-label{font-family:inherit;font-size:14px;font-weight:700;fill:#1b3552}.graph-hint{font-family:inherit;font-size:11px;fill:#687a90}.connector{stroke:#b4c1d2;stroke-width:1.7;fill:none}.relation-section{margin:12px 18px 20px;border:1px solid var(--line);border-radius:12px;padding:16px;background:#fff}.relation-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}.relation-head h2{margin:0 0 6px}.relation-head select{border:1px solid var(--line);border-radius:9px;padding:9px;background:white;min-width:145px}.relation-frame{background:#f8fafe;border:1px solid var(--line);border-radius:10px;overflow:auto;max-height:620px}.relation-frame svg{display:block;width:100%;min-width:630px}.relation-evidence{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:12px}.rel-record{background:#fbfcfe;border:1px solid #e2e8f0;border-radius:9px;padding:9px 11px;font-size:12px}.rel-record b{display:block;margin-bottom:5px}.rel-record small{color:#66758a;display:block;line-height:1.5}.rel-record a{overflow-wrap:anywhere;display:block;margin-top:5px}.chip{display:inline-block;border-radius:20px;background:#eff4fc;color:#416187;font-size:11px;padding:4px 8px;margin:3px 3px 0 0}@media(max-width:1000px){.relation-evidence{grid-template-columns:1fr}.layout{grid-template-columns:1fr}.list{max-height:260px}.details{grid-template-columns:1fr}}@media(max-width:600px){.stats{grid-template-columns:repeat(2,1fr)}header h1{font-size:23px}.wrap{padding:12px}.graphframe{margin:10px}}
</style></head><body>
<header><div class="eyebrow">K-AUTO INDUSTRY · STAGE 1</div><h1>한국 자동차 산업 Knowledge Graph</h1><p>기업 ↔ 기업 관계와 기업 → 핵심역량 → 차량 시스템. 관계의 공식 출처·시점·상태를 확인할 수 있는 오프라인 지도입니다.</p></header>
<div class="wrap">
<section class="stats"><div class="stat"><strong id="nCompanies">30</strong><span>산업 참여 기업</span></div><div class="stat"><strong id="nStages">7</strong><span>밸류체인 영역</span></div><div class="stat"><strong id="nCaps">24</strong><span>핵심역량 유형</span></div><div class="stat"><strong id="nVerified">11</strong><span>공식 페이지 확인 기업</span></div><div class="stat"><strong id="nRelations">42</strong><span>기업 간 근거 기반 관계</span></div></section>
<div id="stageMenu" class="stage-container"></div>
<div class="layout"><aside class="panel"><div class="list-top"><h2>기업 선택 <span id="filteredCount" class="sub"></span></h2><input type="search" id="search" placeholder="기업명 · 영문명 검색" aria-label="기업 검색"/></div><div class="list" id="companies"></div></aside>
<main class="panel"><div class="visual-top"><div class="over">COMPANY KNOWLEDGE GRAPH</div><h2 id="selectedName">현대모비스</h2><div class="sub" id="selectedSubtitle"></div></div>
<div class="graphframe" id="graphframe"><svg id="graph" role="img" aria-label="기업 핵심역량과 차량 시스템 연결 그래프"></svg></div>
<section class="relation-section"><div class="relation-head"><div><h2>기업 ↔ 기업 관계 그래프 <span id="relCount" class="sub"></span></h2><div class="sub">공식 자료 확인된 관계만 표시 · 공급계약 ≠ 납품실행 · 컨소시엄 참여 ≠ 개별 계약</div></div><select id="relFilter" aria-label="기업간 관계 필터"><option value="all">관계 전체</option><option value="supply">납품·공급계약</option><option value="research">공동연구·기술협력</option><option value="affiliation">계열 관계</option><option value="other">그 밖의 관계</option></select></div><div class="relation-frame"><svg id="relGraph" role="img" aria-label="선택된 기업과 연결된 기업 간 관계 그래프"></svg></div><div id="relEvidence" class="relation-evidence"></div></section>
<div class="details"><div class="detail"><b>검증 상태 및 근거</b><p id="evidence"></p></div><div class="detail"><b>핵심역량 및 시스템 분류</b><p id="capNotes"></p></div></div></main></div>
<div class="note"><b>주의:</b> 이 화면은 CSV 시드 데이터의 독립 실행형 <b>미리보기</b>이며 Neo4j 서버에 실시간 연결되어 있지 않습니다. 「검토 필요」는 해당 기업·역량의 공식 자료와 최신성 추가 확인이 필요하다는 뜻입니다. 위의 <b>역량·차량시스템 그래프</b>는 개념적 분류입니다. 별도의 <b>기업 간 관계 그래프</b>에서만 공식 출처가 연결된 관계를 표시합니다. 발표된 계획은 현재 납품 실적을 의미하지 않습니다.</div>
</div>
<script>const DATA=__DATA__;
const companyById=Object.fromEntries(DATA.companies.map(c=>[c.id,c]));
const capById=Object.fromEntries(DATA.capabilities.map(c=>[c.id,c]));
const stageById=Object.fromEntries(DATA.stages.map(c=>[c.id,c]));
let stage='all',selected='mobis',search='';
const esc=x=>String(x||'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const verified=c=>c.evidence_status==='official_page_checked';
const statusText=c=>verified(c)?'공식 페이지 확인':'추가 검토 필요';
const $=id=>document.getElementById(id);
function renderMenu(){const counts={};DATA.companies.forEach(c=>counts[c.stage_id]=(counts[c.stage_id]||0)+1); $('stageMenu').innerHTML=[{id:'all',name_ko:'전체',count:DATA.companies.length},...DATA.stages.map(s=>({...s,count:counts[s.id]||0}))].map(s=>`<button class="stage ${stage===s.id?'active':''}" data-stage="${esc(s.id)}">${esc(s.name_ko)} · ${s.count}</button>`).join('');$('stageMenu').querySelectorAll('button').forEach(b=>b.onclick=()=>{stage=b.dataset.stage; renderMenu();renderList();});}
function renderList(){let c=DATA.companies.filter(c=>(stage==='all'||c.stage_id===stage)&&`${c.name_ko} ${c.name_en}`.toLowerCase().includes(search.toLowerCase()));$('filteredCount').textContent=`(${c.length}개)`;$('companies').innerHTML=c.map(x=>`<button class="company ${selected===x.id?'active':''}" data-id="${esc(x.id)}"><span><span class="name">${esc(x.name_ko)}</span><small>${esc(x.name_en)}</small></span><span class="status ${verified(x)?'verified':''}">${verified(x)?'확인':'검토 필요'}</span></button>`).join('')||'<p style="padding:14px;color:#64748b">검색 결과가 없습니다.</p>';$('companies').querySelectorAll('button').forEach(b=>b.onclick=()=>{selected=b.dataset.id;renderList();renderGraph();});}
function node(x,y,w,h,label,fill,stroke='#cfdeed',font=14){return `<rect x="${x}" y="${y}" rx="12" width="${w}" height="${h}" stroke="${stroke}" stroke-width="1.4" fill="${fill}"/><text x="${x+w/2}" y="${y+h/2+5}" text-anchor="middle" class="graph-label" style="font-size:${font}px">${esc(label)}</text>`;}
function renderGraph(){const c=companyById[selected];const caps=c.capability_ids.split('|').map(id=>capById[id]);const systems=[...new Map(caps.map(v=>[v.system_id,{id:v.system_id,name:v.system_name_ko}])).values()];const H=Math.max(365,caps.length*78+90,systems.length*90+90); const W=1040;const centers=(n,step)=>Array.from({length:n},(_,i)=>H/2 + (i-(n-1)/2)*step);
const left={x:24,w:218,y:H/2-29,h:58}, middleY=centers(caps.length,78),rightY=centers(systems.length,90);
const sysIndex=Object.fromEntries(systems.map((s,i)=>[s.id,i]));let paths='',shapes='';
shapes+=`<text class="graph-hint" x="28" y="27">기업</text><text class="graph-hint" x="416" y="27">핵심역량</text><text class="graph-hint" x="795" y="27">차량 시스템</text>`;
shapes+=node(left.x,left.y,left.w,left.h,c.name_ko,'#e0faf3','#44c1ad',17);
for(let i=0;i<caps.length;i++){const yy=middleY[i],sy=rightY[sysIndex[caps[i].system_id]],ly=H/2;
paths+=`<path class="connector" d="M242 ${ly} C310 ${ly},335 ${yy},402 ${yy}"/><path class="connector" d="M648 ${yy} C704 ${yy},720 ${sy},776 ${sy}"/>`;
shapes+=node(402,yy-27,246,54,caps[i].name_ko,'#edf4ff','#c4d6f4',14);}
for(let i=0;i<systems.length;i++)shapes+=node(776,rightY[i]-27,238,54,systems[i].name,'#fff2dc','#ead4a9',14);
$('graph').setAttribute('viewBox',`0 0 ${W} ${H}`);$('graph').style.height=`${Math.min(720,Math.max(340,H))}px`;$('graph').innerHTML=paths+shapes;
$('selectedName').textContent=c.name_ko;$('selectedSubtitle').textContent=`${c.name_en} · ${stageById[c.stage_id].name_ko}`;
$('evidence').innerHTML=`<span class="status ${verified(c)?'verified':''}">${statusText(c)}</span><div style="margin-top:8px"><a target="_blank" rel="noopener noreferrer" href="${esc(c.source_url)}">참고 페이지 열기 ↗</a></div><small style="display:block;margin-top:8px;color:#64748b">출처의 제품·사업 범위와 최근 변경사항을 수작업으로 재검토하세요.</small>`;
$('capNotes').innerHTML=caps.map(x=>`<span class="chip">${esc(x.name_ko)}</span>`).join('')+`<p style="margin-top:10px;font-size:12px;color:#64748b">역량→차량시스템 관계는 산업 온톨로지의 개념적 분류입니다.</p>`;
renderRelations();
}

const RELTYPES={
 AFFILIATED_WITH:'동일 기업집단',SUPPLY_AGREEMENT_WITH:'공급계약',SUPPLIES_TO:'실제 납품 발표',
 JOINT_RESEARCH_WITH:'공동 연구',TECH_PARTNERS_WITH:'기술 협력',
 JOINT_VENTURE_PLAN_WITH:'합작계획·승인',BATTERY_COOPERATION_WITH:'배터리 협력',
 CO_MEMBER_OF_CONSORTIUM:'컨소시엄 동반 참여'};
const RELGROUP={AFFILIATED_WITH:'affiliation',SUPPLY_AGREEMENT_WITH:'supply',SUPPLIES_TO:'supply',
 JOINT_RESEARCH_WITH:'research',TECH_PARTNERS_WITH:'research',JOINT_VENTURE_PLAN_WITH:'other',
 BATTERY_COOPERATION_WITH:'other',CO_MEMBER_OF_CONSORTIUM:'other'};
let relFilter='all';
function renderRelations(){
 const rels=DATA.relationships.filter(r=>(r.from_company_id===selected||r.to_company_id===selected)&&
    (relFilter==='all'||RELGROUP[r.relation_type]===relFilter));
 const c=companyById[selected]; $('relCount').textContent=`(${rels.length}건)`;
 if(!rels.length){$('relGraph').setAttribute('viewBox','0 0 950 170');$('relGraph').style.height='170px';
 $('relGraph').innerHTML=`<text x="28" y="84" fill="#64748b" font-size="17">${esc(c.name_ko)}에 대해 이 필터에서 확인된 기업 간 관계가 없습니다.</text>`;
 $('relEvidence').innerHTML='<div class="sub">관계가 없다는 뜻이 아니라 현재 시드에 공식 근거를 아직 등록하지 않았다는 의미입니다.</div>';return;}
 const n=rels.length,W=1020,H=Math.max(220,n*70+28),mid=H/2;
 let lines='',boxes='';
 boxes+=`<rect x="25" y="${mid-32}" width="220" height="64" rx="14" fill="#d9f6ee" stroke="#17a78e" stroke-width="2"/><text x="135" y="${mid+7}" font-weight="800" font-size="18" fill="#133c48" text-anchor="middle">${esc(c.name_ko)}</text>`;
 rels.forEach((r,i)=>{
   const y=35+i*70,toId=r.from_company_id===selected?r.to_company_id:r.from_company_id,other=companyById[toId];
   const dir=r.relation_type==='AFFILIATED_WITH'?'↔':r.from_company_id===selected?'→':'←';
   const label=RELTYPES[r.relation_type]||r.relation_type;
   const stroke=RELGROUP[r.relation_type]==='supply'?'#15803d':RELGROUP[r.relation_type]==='research'?'#2563eb':RELGROUP[r.relation_type]==='affiliation'?'#7c3aed':'#d97706';
   lines+=`<path d="M245 ${mid} C360 ${mid},420 ${y},680 ${y}" stroke="${stroke}" stroke-opacity=".40" fill="none" stroke-width="2"/>`;
   boxes+=`<rect x="686" y="${y-21}" width="280" height="43" rx="10" fill="#fff" stroke="${stroke}" stroke-opacity=".48" stroke-width="1.4"/><text x="826" y="${y+5}" font-size="13" font-weight="700" fill="#21344b" text-anchor="middle">${esc(other.name_ko)}</text>`;
   boxes+=`<rect x="346" y="${y-17}" width="308" height="34" rx="17" fill="#fff" stroke="${stroke}" stroke-width="1.2"/><text x="500" y="${y+4}" font-size="12" fill="#334155" text-anchor="middle">${dir} ${esc(label)}</text>`;
 });
 $('relGraph').setAttribute('viewBox',`0 0 ${W} ${H}`);$('relGraph').style.height=`${H}px`; $('relGraph').innerHTML=lines+boxes;
 $('relEvidence').innerHTML=rels.map(r=>{
   const other=companyById[r.from_company_id===selected?r.to_company_id:r.from_company_id];
   const dir=r.from_company_id===selected?'→':'←';
   return `<div class="rel-record"><b>${esc(dir+' '+other.name_ko+' · '+r.relation_label_ko)}</b><small>주제: ${esc(r.topic)}<br>발표일/근거일: ${esc(r.announcement_date||'미상')} · 상태: ${esc(r.assertion_status)}</small><small>${esc(r.evidence_summary_ko)}</small><a href="${esc(r.evidence_url)}" target="_blank" rel="noopener noreferrer">1차 출처 확인 ↗</a></div>`;
 }).join('');
}
$('relFilter').addEventListener('change',e=>{relFilter=e.target.value;renderRelations();});

$('nRelations').textContent=DATA.relationships.length; $('nCompanies').textContent=DATA.companies.length;$('nStages').textContent=DATA.stages.length;$('nCaps').textContent=DATA.capabilities.length;$('nVerified').textContent=DATA.companies.filter(verified).length;
$('search').addEventListener('input',e=>{search=e.target.value;renderList();}); renderMenu();renderList();renderGraph();
</script></body></html>'''
    html=template.replace('__DATA__',blob)
    out=ROOT/'output'/'kauto_graph.html';out.parent.mkdir(exist_ok=True)
    out.write_text(html,encoding='utf-8')
    print('Wrote:',out,'bytes:',out.stat().st_size)

if __name__=='__main__':main()
