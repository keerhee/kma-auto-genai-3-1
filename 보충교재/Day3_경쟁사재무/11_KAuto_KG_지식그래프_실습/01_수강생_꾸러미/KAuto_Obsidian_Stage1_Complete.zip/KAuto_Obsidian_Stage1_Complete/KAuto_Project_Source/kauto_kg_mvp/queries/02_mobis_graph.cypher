// Neo4j Browser graph view: run as a single Cypher statement
MATCH (c:KAutoCompany {id:'company.mobis'})-[r:HAS_CAPABILITY]->(p:KAutoCapability)-[e:ENABLES_SYSTEM]->(s:KAutoSystem)
RETURN c,r,p,e,s;
