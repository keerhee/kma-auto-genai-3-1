import csv
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def rows(name):
    with (ROOT/'data'/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

class TestDataset(unittest.TestCase):
    def test_company_count_unique_ids(self):
        x=rows('companies.csv')
        self.assertEqual(len(x),30)
        self.assertEqual(len({c['id'] for c in x}),len(x))
    def test_relationship_references_and_evidence(self):
        co=rows('companies.csv')
        stages={x['id'] for x in rows('stages.csv')}
        caps={x['id'] for x in rows('capabilities.csv')}
        for c in co:
            self.assertIn(c['stage_id'],stages)
            self.assertTrue(set(c['capability_ids'].split('|')).issubset(caps))
            self.assertIn(c['evidence_status'],{'official_page_checked','review_required'})
            self.assertTrue(c['source_url'].startswith('https://'))
        self.assertGreaterEqual(sum(c['evidence_status']=='official_page_checked' for c in co),10)
    def test_capability_to_system_consistency(self):
        caps=rows('capabilities.csv')
        self.assertEqual(len({c['id'] for c in caps}),len(caps))
        sys={}
        for c in caps:
            if c['system_id'] in sys:
                self.assertEqual(sys[c['system_id']],c['system_name_ko'])
            else: sys[c['system_id']]=c['system_name_ko']
    def test_stage_links(self):
        stages={x['id'] for x in rows('stages.csv')}
        for l in rows('stage_links.csv'):
            self.assertIn(l['from_stage_id'],stages)
            self.assertIn(l['to_stage_id'],stages)
            self.assertNotEqual(l['from_stage_id'],l['to_stage_id'])

    def test_company_relationships_schema_and_provenance(self):
        records=rows('company_relationships.csv')
        companies={c['id'] for c in rows('companies.csv')}
        self.assertGreaterEqual(len(records),30)
        self.assertEqual(len({r['id'] for r in records}),len(records))
        allowed={'AFFILIATED_WITH','SUPPLY_AGREEMENT_WITH','SUPPLIES_TO',
                 'JOINT_RESEARCH_WITH','TECH_PARTNERS_WITH',
                 'JOINT_VENTURE_PLAN_WITH','BATTERY_COOPERATION_WITH',
                 'CO_MEMBER_OF_CONSORTIUM'}
        for r in records:
            self.assertIn(r['from_company_id'],companies)
            self.assertIn(r['to_company_id'],companies)
            self.assertNotEqual(r['from_company_id'],r['to_company_id'])
            self.assertIn(r['relation_type'], allowed)
            self.assertTrue(r['evidence_url'].startswith('https://'))
            self.assertEqual(r['evidence_level'],'official_primary_source')
            self.assertTrue(r['assertion_status'])
            self.assertTrue(r['evidence_summary_ko'])
            self.assertLessEqual(r['announcement_date'] or '2026-10-19','2026-10-19')

    def test_no_announced_contract_is_presented_as_executed_supply(self):
        records=rows('company_relationships.csv')
        supply=[r for r in records if r['relation_type']=='SUPPLIES_TO']
        self.assertTrue(supply)
        self.assertTrue(all(r['assertion_status']=='reported_existing_supply' for r in supply))
        agreements=[r for r in records if r['relation_type']=='SUPPLY_AGREEMENT_WITH']
        self.assertTrue(agreements)
        self.assertFalse(any(r['assertion_status']=='reported_existing_supply' for r in agreements))

if __name__=='__main__':unittest.main()
