// 기업 간 관계: 선택기업 중심, 방향을 무시하고 연결된 사실과 출처를 함께 조회
MATCH p=(c:KAutoCompany {id:'company.hyundai'})-[r]-(other:KAutoCompany)
WHERE r.project='kauto-stage1'
RETURN p LIMIT 50;
