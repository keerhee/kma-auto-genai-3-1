# Claude Code 실행 프롬프트 — K-Auto KG Stage 1

역할: Claude Code 환경구축 엔지니어 + Neo4j 지식그래프 모델러 + 한국 자동차 산업 분석가.

목표: 이 프로젝트의 파일을 이용해 **한국 자동차 산업 지식그래프 1단계**를 이 컴퓨터에서 실제로 실행·검증한다. NeoQuant/GraphRAG 확장은 아직 수행하지 않는다.

## 작업 규칙

1. README.md, CLAUDE.md, data/*.csv, scripts/*.py를 읽어 프로젝트 구조를 확인한다. *이미 설치된* Docker, Python, Neo4j, MCP는 재설치하지 않는다.
2. OS/macOS/Windows, 셸, Python 버전, Docker daemon, 7474/7687 포트 사용 여부, 기존 Neo4j 및 기존 `claude mcp list` 상태를 먼저 보고한다.
3. `python -m unittest discover -s tests -v`를 실행해 데이터 무결성 테스트 6건을 확인한다. 기업↔기업 관계 42건의 타입·출처·진척상태도 포함한다.
4. `scripts/render_html.py`를 실행해 `output/kauto_graph.html`을 만들고 파일 존재·실행 여부를 확인한다. 이 파일은 CSV 미리보기임을 분명하게 표시한다. 관계유형 필터를 통해 기업↔기업 그래프와 근거 링크를 열어 검토한다.
5. DB가 없다면 Docker Compose 방식의 로컬 Neo4j를 설치/실행한다. 이미 DB가 있다면 기존 DB/포트/볼륨을 파괴하지 말고 사용 가능한 연결을 우선 검토한다. Docker Desktop 설치·실행에 관리자 승인이 필요하면 어디를 클릭해야 하는지 안내한다.
6. `.env`가 없으면 `.env.example`에서 로컬로 만들고, **사용자가 로컬 편집기에 직접 비밀번호를 입력하도록 요청한다**. 비밀번호를 Claude 대화창으로 전달하거나 채팅/명령 기록/공유 설정에 출력하지 않는다. 기존 DB 비밀번호와 달라 연결 실패할 수 있으니 무리하게 초기화하지 않는다.
7. 가상환경에 `requirements-mcp.txt` 패키지를 설치한다. Neo4j 접속을 점검하고 APOC Core가 설치되었는지 확인한다. 설치 명령, 버전 및 실제 검증 결과를 구분해 보고한다.
8. 운영/업무용 기존 데이터베이스라면 새 DB 또는 별도 네임스페이스의 쓰기 위험을 검토하고, **적재 실행 직전에 반드시 사용자 승인**을 받는다. 테스트 인스턴스에 승인받은 뒤 `python scripts/import_neo4j.py`를 실행한다. 모든 노드에 KAuto 접두 레이블/고유 ID를 적용하며 삭제는 금지한다.
9. `python scripts/verify_neo4j.py`로 노드 수, 관계 수, 근거 표기 및 기업 간 관계 42건, 주장 노드 42개, 공식 관계 출처 12종, 범용 `SUPPLIES` 0건을 검증한다. `SUPPLIES_TO` 1건과 `SUPPLY_AGREEMENT_WITH` 3건은 구분한다. 설치 및 검증 결과가 실패하면 이유를 수정한 뒤 재시도한다.
10. `scripts/mcp_launcher.py`를 절대경로의 가상환경 Python으로 실행하도록 **현재 프로젝트 local scope**의 Neo4j MCP 서버로 등록한다 (`claude mcp add neo4j-kauto -- <python-abs-path> <launcher-abs-path>` 형식). 이미 동일 MCP가 정상 작동하면 중복 등록하지 않는다. MCP는 read-only 유지. `claude mcp list` 또는 Claude Code의 `/mcp`로 연결과 스키마/읽기 질의가 실제 가능한지 검증한다.
11. `queries/02_mobis_graph.cypher`, `queries/03_ev_ecosystem.cypher`, `queries/04_sources_to_review.cypher`, `queries/06_valuechain_flow.cypher`, `queries/07_company_network.cypher`, `queries/08_supplier_network.cypher`를 Neo4j Browser에서 실행할 수 있게 설명하고, 가능하면 실측 결과를 기록한다.
12. 최종 보고서: 설치/재사용한 프로그램, DB 주소, 기업/단계/역량/시스템/기업간 관계 수와 대표적 증거 3건, 검증 PASS/FAIL, 미검증 기업 수, HTML 미리보기 위치, Neo4j Browser 실행 방법, 다음 개선점을 한글로 제공한다. 2단계는 하지 않는다.

## 데이터 정확성

- `official_page_checked`와 `review_required`는 다르다. 기업 홈페이지가 있다고 특정 납품관계를 증명하는 것은 아니다.
- `HAS_CAPABILITY`는 기업의 공개 사업/제품 역량 분류이다. `ENABLES_SYSTEM` 및 `TYPICALLY_FEEDS`는 온톨로지 개념연결이다.
- 출처 없는 기업 간 납품, 지분, 고객사, 하청관계를 창작하지 않는다. 계약 발표를 실제 납품으로, 프로젝트 공동 참여를 직접 공급 관계로 변환하지 않는다.
- 회사명이 변경되었거나 확인이 곤란한 경우 확인 필요로 표시하고, 근거 없이 단정하지 않는다.

## 사용자 경험

- 매 단계 “어디 → 입력 → 결과 → 확인”으로 보여준다.
- 필요한 사용자 수동 작업은 한 번에 하나씩, 스크린에서 찾을 수 있는 수준으로 설명한다.
- 기존 상태를 안전하게 보존하는 것을 가장 우선한다.
- 설정이 가능한 것은 실제 실행하고 결과를 보여주되, 실행하지 못한 항목은 완료로 표시하지 않는다.
