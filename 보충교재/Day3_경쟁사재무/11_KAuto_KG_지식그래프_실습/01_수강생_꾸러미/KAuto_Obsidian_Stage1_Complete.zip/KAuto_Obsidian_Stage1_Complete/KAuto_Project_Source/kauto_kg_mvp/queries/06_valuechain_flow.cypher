// Industry-stage flow graph: NOT verified contracts
MATCH (a:KAutoStage)-[r:TYPICALLY_FEEDS]->(b:KAutoStage)
RETURN a,r,b;
