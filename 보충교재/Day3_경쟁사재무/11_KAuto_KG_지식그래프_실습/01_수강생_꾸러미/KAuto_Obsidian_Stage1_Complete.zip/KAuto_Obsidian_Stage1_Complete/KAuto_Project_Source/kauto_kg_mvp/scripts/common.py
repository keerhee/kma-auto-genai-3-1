from __future__ import annotations
import csv
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'


def read_csv(filename: str) -> list[dict[str, str]]:
    with (DATA / filename).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def config() -> dict[str, str]:
    load_dotenv(ROOT / '.env')
    password = os.getenv('NEO4J_PASSWORD', '')
    if not password or password.startswith('CHANGE_TO_'):
        raise RuntimeError('Set NEO4J_PASSWORD in project .env first.')
    return {
        'uri': os.getenv('NEO4J_URI', 'bolt://127.0.0.1:7687'),
        'user': os.getenv('NEO4J_USERNAME', 'neo4j'),
        'password': password,
        'database': os.getenv('NEO4J_DATABASE', 'neo4j'),
    }
