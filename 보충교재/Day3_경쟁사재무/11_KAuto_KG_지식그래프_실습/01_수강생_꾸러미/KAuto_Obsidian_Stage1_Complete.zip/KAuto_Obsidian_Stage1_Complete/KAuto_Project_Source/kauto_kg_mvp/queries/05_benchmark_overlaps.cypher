// Competitors/overlapping competencies, NOT suppliers or contracts
MATCH (a:KAutoCompany)-[:HAS_CAPABILITY]->(p:KAutoCapability)<-[:HAS_CAPABILITY]-(b:KAutoCompany)
WHERE a.id < b.id
RETURN a.name_ko AS 기업A, b.name_ko AS 기업B, collect(p.name_ko) AS 공통역량
ORDER BY size(공통역량) DESC, 기업A LIMIT 30;
