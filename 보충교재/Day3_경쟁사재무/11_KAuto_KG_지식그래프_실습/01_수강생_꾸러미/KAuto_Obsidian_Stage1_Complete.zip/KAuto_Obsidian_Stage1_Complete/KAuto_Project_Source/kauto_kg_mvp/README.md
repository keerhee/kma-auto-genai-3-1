# K-Auto KG — 한국 자동차 산업 지식그래프 1단계 MVP

**목표:** Claude Code + Neo4j + MCP로 한국 자동차 산업의 **기업 ↔ 기업 관계**, **기업 → 역량 → 차량 시스템**, **밸류체인 단계**를 탐색합니다.

> 본 패키지는 실제 실행 가능한 *프로젝트 소스 및 초기 데이터*입니다. 여기에서 사용자의 컴퓨터·Docker·Neo4j에 직접 설치한 것은 아닙니다. `output/kauto_graph.html`은 **CSV 기반 정적 미리보기**이고 Neo4j 서버와 실시간 연동하지 않습니다.

## 실습 산출물

- **30개 한국 자동차 산업 참여 기업**: 완성차 4, 주요 부품 8, 배터리 3, 소재 6, 차량SW/전자 5, 타이어 3, 충전 1
- **7개 밸류체인 단계**, **24개 핵심역량**, **9개 차량 시스템**
- **공식 사업/제품 페이지로 확인한 11개 기업**과 **자료 추가 검토가 필요한 19개 기업**을 구분
- **기업 간 출처 확인 관계 42건(8개 타입)**: 공식 그룹 관계·공급계약·실제 납품 발표·공동연구·기술협력·합작사업 관련 발표·동일 컨소시엄 참여 등을 구분합니다.
- 실제 납품 `SUPPLIES_TO`는 공식 기사에서 기존 공급을 명시한 경우 1건만 등록했습니다. 공급계약 `SUPPLY_AGREEMENT_WITH`는 실행 중 납품과 구별합니다.
- **12개 고유 공식 1차 출처 URL**, 자료일·상태·원문 근거 텍스트
- Cypher 실습 9개, 데이터 무결성 검사 6개, 기업간 네트워크를 포함한 오프라인 HTML 미리보기

## 구성

```text
kauto_kg_mvp/
  .env.example                 # 환경변수 예시. 실제 비밀번호 저장 X
  docker-compose.yml           # 로컬 Neo4j + APOC
  requirements.txt             # Python driver 등
  requirements-mcp.txt         # 공식 Neo4j MCP 서버 추가
  CLAUDE_SETUP_PROMPT.md       # Claude Code에 줄 실행 지시서
  CLAUDE.md                    # 프로젝트 내 AI 작업 규칙
  data/
    companies.csv             # 기업/역량/출처/증거상태
    company_relationships.csv # 출처 확인 기업간 관계 42건
    capabilities.csv          # 핵심역량 -> 차량시스템 온톨로지
    stages.csv                # 밸류체인
    stage_links.csv           # 밸류체인 개념 흐름
  scripts/
    common.py
    import_neo4j.py           # Neo4j에 idempotent MERGE 적재
    verify_neo4j.py           # 적재 결과 검증(읽기 전용)
    mcp_launcher.py            # 비밀번호를 CLI/설정 파일에 노출하지 않는 MCP 실행 래퍼
    render_html.py            # CSV에서 오프라인 HTML 생성
  queries/                     # Neo4j Browser Cypher 예제 9개
  tests/test_dataset.py        # 데이터 무결성 단위 테스트 6개
  output/kauto_graph.html      # DB 설치 전에도 열 수 있는 독립형 미리보기
```

## 가장 쉬운 방법: Claude Code에게 전부 맡기기

1. 압축파일을 해제합니다.
2. 해당 폴더를 VS Code 또는 터미널에서 엽니다.
3. `claude`를 시작하고 다음 문장을 입력합니다.

```text
프로젝트의 CLAUDE_SETUP_PROMPT.md 파일을 읽고, 단계별로 작업을 실제 수행해줘.
기존 DB는 건드리지 말고, 비밀번호는 대화창에 출력하지 마.
```

Claude Code가 설치 확인 → 이미 설치된 Neo4j 재사용 여부 확인 → Docker/APOC 준비 → Python 환경 → 데이터 검증 → DB 적재(쓰기 전 승인) → 읽기 전용 MCP 연결 → 쿼리 검증을 순서대로 진행하게 구성되어 있습니다.

## 직접 실행할 경우

### 1. 설정

`.env.example`을 `.env`로 복사하고 **고유한 긴 비밀번호(8자 이상)**를 로컬 파일에 입력합니다. Neo4j는 기본적으로 8자 미만 비밀번호를 거부하므로 컨테이너가 바로 멈출 수 있습니다. `.env`를 Git에 올리거나 채팅에 붙여 넣지 않습니다.

```bash
# macOS/Linux
cp .env.example .env
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-mcp.txt
```

```powershell
# Windows PowerShell (Python 설치 상태에 따라 py 또는 python 사용)
Copy-Item .env.example .env
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-mcp.txt
```

> Windows는 활성화 정책 문제를 피하기 위해 가상환경의 `python.exe`를 직접 호출하면 됩니다. macOS/Linux는 가상환경 활성화 후 `python`을 사용합니다.

### 2. Neo4j 실행 (기존 인스턴스가 없을 때만)

Docker Desktop이 실행 중이고 7474, 7687 포트가 비어 있는지 확인합니다.

```bash
docker compose up -d
docker compose ps
```

Neo4j Browser: **http://localhost:7474** (사용자: `neo4j`, 비밀번호: `.env`에 입력한 값)

이 예시 Compose는 `neo4j:2026.09.0`과 APOC Core를 개발용으로 실행합니다. 포트는 localhost에만 노출하며 데이터는 별도 Docker 볼륨에 보관합니다. 기존 Neo4j가 있는 경우 **새 컨테이너를 추가로 실행하지 않고** 연결 설정만 맞추세요.

**주의:** 이미 생성된 Neo4j 데이터 볼륨에서는 `.env`의 비밀번호만 바꿔도 기존 DB 비밀번호가 자동으로 바뀌지 않습니다. 재사용 시 기존 로그인 값을 설정하거나 정식 비밀번호 변경 절차를 거치세요. 기존 볼륨을 삭제하지 마세요.

### 3. 사전 데이터 테스트와 정적 그래프

```bash
python -m unittest discover -s tests -v
python scripts/render_html.py
```

`output/kauto_graph.html`을 웹브라우저로 열면 실제 DB 없이 **기업·기업(관계유형 필터, 출처 링크 포함)** 및 **기업·역량·차량 시스템** 그래프를 함께 확인할 수 있습니다.

### 4. Neo4j에 데이터 적재 (쓰기 작업)

아래 작업은 로컬 데이터베이스에 노드를 추가/갱신합니다. 안전을 위해 사용자가 실행을 승인한 경우에만 진행하세요.

```bash
python scripts/import_neo4j.py
python scripts/verify_neo4j.py
```

반복 실행해도 `MERGE`를 사용해 같은 ID의 노드/관계를 새로 중복 생성하지 않습니다. 다만 수동으로 추가한 데이터까지 되돌리지는 않습니다.

### 5. Claude Code에서 MCP 활성화

**공식 Neo4j MCP**가 필요합니다. 이 프로젝트는 `requirements-mcp.txt`로 설치합니다.

```bash
# 현재 프로젝트 폴더에서 실행. <...> 는 실제 절대 경로입니다.
claude mcp add neo4j-kauto -- <ABSOLUTE_PATH_TO_VENV_PYTHON> <ABSOLUTE_PATH_TO_PROJECT>/scripts/mcp_launcher.py
claude mcp list
```

`mcp_launcher.py`가 비밀번호를 로컬 `.env`에서 읽어 **읽기 전용**으로 Neo4j MCP 서버를 실행합니다. v1.2부터 neo4j-mcp-server 1.6 이상의 새 환경변수 이름(`NEO4J_MCP_URI`, `NEO4J_MCP_READ_ONLY=true` 등)으로 넘기고 `--read-only true`를 함께 지정합니다(이전 이름은 v2에서 지원 종료 예정). `.env` 파일의 항목 이름은 그대로 둡니다. CLI 옵션이나 Claude의 `.mcp.json`에 비밀번호를 넣을 필요가 없습니다. 정확한 절대 경로, 실행기의 Python 호환성, MCP 도구 노출 여부는 Claude Code에 자동 검증을 지시하세요.

Neo4j MCP는 APOC Core 설치를 요구합니다. 기존 Neo4j를 쓰는 경우 APOC 사용 가능 여부를 확인하세요.

> 2026-10-23 확인: Neo4j 공식 설정 문서의 예시는 아직 옛 환경변수 이름(`NEO4J_URI`, `NEO4J_READ_ONLY` 등)을 씁니다. neo4j-mcp-server 1.6 이상에서는 그 이름이 ‘v2에서 지원 종료’ 경고를 냅니다. 이 프로젝트는 `mcp_launcher.py`가 새 이름(`NEO4J_MCP_*`)으로 넘기므로 문서 예시를 그대로 따라 하지 않아도 됩니다.

### 6. Neo4j Browser에서 시각화

`queries/02_mobis_graph.cypher`를 복사해서 Browser에 붙여 넣고 실행하면 현대모비스 → 핵심역량 → 차량 시스템이 노드·선으로 표시됩니다. `queries/06_valuechain_flow.cypher`는 밸류체인 개념 흐름을 표시합니다. `queries/07_company_network.cypher`는 현대차 중심 기업↔기업 직접관계를, `queries/08_supplier_network.cypher`는 실거래 발표와 공급계약의 차이를 표시합니다.

## 온톨로지 스키마

```text
(:KAutoCompany:Company {id,name_ko,name_en,evidence_status,source_url})
  -[:PARTICIPATES_IN_STAGE]-> (:KAutoStage:ValueChainStage)
  -[:HAS_CAPABILITY {evidence_status,source_url}]-> (:KAutoCapability:Capability)
  -[:HAS_REFERENCE]-> (:KAutoSource:Source)
(:KAutoCapability)-[:ENABLES_SYSTEM]->(:KAutoSystem:VehicleSystem)
(:KAutoStage)-[:TYPICALLY_FEEDS]->(:KAutoStage)
(:KAutoCompany)-[:AFFILIATED_WITH|SUPPLY_AGREEMENT_WITH|SUPPLIES_TO|JOINT_RESEARCH_WITH|TECH_PARTNERS_WITH|JOINT_VENTURE_PLAN_WITH|BATTERY_COOPERATION_WITH|CO_MEMBER_OF_CONSORTIUM {id,topic,announcement_date,assertion_status,evidence_url}]->(:KAutoCompany)
(:KAutoRelationAssertion {id,type,summary_ko})-[:SUPPORTED_BY]->(:KAutoSource)
```

기업간 관계 데이터 상세 설명과 공식 출처 목록은 `RELATIONSHIP_MODEL_KR.md`를 참조하세요.

`HAS_CAPABILITY`는 제품·사업 역량의 분류이고 `ENABLES_SYSTEM`, `TYPICALLY_FEEDS`는 **산업 구조 온톨로지**입니다. 기업 간 관계는 종류별로 별도 타입으로 구분하며, 과거 발표와 현재 상태를 혼동하지 않습니다. 포괄적인 타입 `SUPPLIES`는 여전히 금지합니다.

증거 정책:

- `official_page_checked`: 작성 시 공식 기업/제품·사업 페이지를 확인한 역량. 이후 변경 여부는 추가 점검 필요.
- `review_required`: 이름과 초기 분류는 실습 후보이며 직접적인 1차 제품/사업 출처 검토가 아직 필요.
- 기업별 `source_url`을 유지합니다. 기업간 관계에는 `reviewed_on`, `evidence_url`, `assertion_status`와 별도 `KAutoRelationAssertion` 노드를 적용합니다. 이후 2단계의 금융 엔티티·리스크 전파 평가에 재사용합니다.

## 실습 질의 예시

**예시 A. 열관리 기술 관련 기업**

```cypher
MATCH (c:KAutoCompany)-[r:HAS_CAPABILITY]->(p:KAutoCapability {id:'cap.thermal_management'})
RETURN c.name_ko AS 회사, r.evidence_status AS 근거상태, r.source_url AS 출처;
```

**예시 B. 같은 역량을 가진 기업 비교**

```cypher
MATCH (a:KAutoCompany)-[:HAS_CAPABILITY]->(p:KAutoCapability)<-[:HAS_CAPABILITY]-(b:KAutoCompany)
WHERE a.id < b.id
RETURN a.name_ko AS 기업1, b.name_ko AS 기업2, collect(p.name_ko) AS 공통역량;
```

**예시 C. 검토가 필요한 데이터 목록**

```cypher
MATCH (c:KAutoCompany {evidence_status:'review_required'})
RETURN c.name_ko AS 회사, c.source_url AS 후보페이지;
```

## 완료 판정

- `python -m unittest ...`에서 6건 PASS
- 적재 스크립트 종료코드 0
- `verify_neo4j.py`에서 기업 30, 단계 7, 역량 24, 기업간 관계 42, 관계 주장 노드 42, 출처 42
- Neo4j Browser에서 현대모비스 그래프 표시
- Claude Code 내 MCP 도구를 통해 읽기 전용으로 스키마와 질의 결과 확인
- 포괄적인 `SUPPLIES` 관계 0건. 구체적 `SUPPLIES_TO` 실거래 근거 1건과 `SUPPLY_AGREEMENT_WITH` 공급계약 3건을 구분해 검증

## 참고 공식 문서

- Neo4j MCP 설치: https://neo4j.com/docs/mcp/current/installation/
- Neo4j MCP 클라이언트 설정: https://neo4j.com/docs/mcp/current/client-configuration/
- Neo4j Docker/APOC: https://neo4j.com/docs/operations-manual/current/docker/plugins/
- Neo4j Python Driver: https://neo4j.com/docs/python-manual/current/

