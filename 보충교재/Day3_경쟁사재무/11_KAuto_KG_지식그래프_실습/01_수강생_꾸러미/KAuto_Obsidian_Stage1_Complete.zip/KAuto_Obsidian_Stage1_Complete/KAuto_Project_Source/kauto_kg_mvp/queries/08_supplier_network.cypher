// 실제 납품 확인 vs 공급계약 체결은 별도 타입
MATCH (supplier:KAutoCompany)-[r:SUPPLIES_TO|SUPPLY_AGREEMENT_WITH]->(buyer:KAutoCompany)
RETURN supplier.name_ko AS 공급자, type(r) AS 관계구분,
       buyer.name_ko AS 수요자, r.topic AS 품목,
       r.announcement_date AS 자료일, r.assertion_status AS 진척상태,
       r.evidence_url AS 공식출처 ORDER BY 공급자,수요자;
