"""Starts official Neo4j MCP in read-only mode; credentials stay in untracked .env.

Install with: pip install -r requirements-mcp.txt
Register launcher via: claude mcp add neo4j-kauto -- <absolute-python> <absolute-this-file>

v1.2: neo4j-mcp-server 1.6+ uses NEO4J_MCP_* variable names. The old names
(NEO4J_URI, NEO4J_READ_ONLY, ...) print deprecation warnings and will be removed
in v2, so this launcher passes only the new names and also forces --read-only true.
"""
import os
import subprocess
import sys
from common import config

OLD_NAMES = ('NEO4J_URI', 'NEO4J_USERNAME', 'NEO4J_PASSWORD', 'NEO4J_DATABASE',
             'NEO4J_READ_ONLY', 'NEO4J_TELEMETRY', 'NEO4J_LOG_FORMAT', 'NEO4J_LOG_LEVEL')


def main():
    cfg=config()
    env=os.environ.copy()
    for k in OLD_NAMES:          # .env loaded by python-dotenv uses the old names
        env.pop(k, None)
    env.update({
        'NEO4J_MCP_URI':cfg['uri'], 'NEO4J_MCP_USERNAME':cfg['user'],
        'NEO4J_MCP_PASSWORD':cfg['password'], 'NEO4J_MCP_DATABASE':cfg['database'],
        'NEO4J_MCP_READ_ONLY':'true', 'NEO4J_MCP_TELEMETRY':'false',
        'NEO4J_MCP_LOG_FORMAT':'text',
    })
    # Inherit stdio so MCP JSON-RPC messages work directly with Claude Code.
    raise SystemExit(subprocess.call([sys.executable, '-m', 'neo4j_mcp_server', '--read-only', 'true'], env=env))

if __name__=='__main__':main()
