// All data entries needing a direct product/service page check
MATCH (c:KAutoCompany {evidence_status:'review_required'})-[:HAS_REFERENCE]->(s:KAutoSource)
RETURN c.name_ko AS 기업, s.url AS 후보참고링크 ORDER BY 기업;
