// Electric-battery-related capabilities, not company-to-company supply claims
MATCH (c:KAutoCompany)-[r:HAS_CAPABILITY]->(p:KAutoCapability)-[:ENABLES_SYSTEM]->(s:KAutoSystem {id:'system.energy'})
RETURN c.name_ko AS 기업, p.name_ko AS 역량, r.evidence_status AS 검증상태, r.source_url AS 근거
ORDER BY 검증상태, 기업;
