// Sector-by-sector company coverage; conceptual industry participation
MATCH (c:KAutoCompany)-[:PARTICIPATES_IN_STAGE]->(s:KAutoStage)
RETURN s.name_ko AS 밸류체인, count(c) AS 기업수, collect(c.name_ko) AS 기업
ORDER BY 기업수 DESC;
