// 2홉 기업 네트워크: 모든 연결을 리스크전파로 단정하지 말 것
MATCH p=(origin:KAutoCompany {id:'company.poscofuturem'})-[r1]-(mid:KAutoCompany)-[r2]-(dest:KAutoCompany)
WHERE origin<>dest AND all(r IN relationships(p) WHERE r.project='kauto-stage1')
RETURN p LIMIT 30;
