"""Read-only post-load health and provenance checks."""
from neo4j import GraphDatabase
from common import config, read_csv

QUERIES = {
    'companies': 'MATCH (n:KAutoCompany) RETURN count(n) AS n',
    'stages': 'MATCH (n:KAutoStage) RETURN count(n) AS n',
    'capabilities': 'MATCH (n:KAutoCapability) RETURN count(n) AS n',
    'systems': 'MATCH (n:KAutoSystem) RETURN count(n) AS n',
    'company_capability_edges': 'MATCH (:KAutoCompany)-[r:HAS_CAPABILITY]->(:KAutoCapability) RETURN count(r) AS n',
    'source_nodes': 'MATCH (n:KAutoSource) RETURN count(n) AS n',
    'company_company_edges': "MATCH (:KAutoCompany)-[r]->(:KAutoCompany) WHERE r.project='kauto-stage1' RETURN count(r) AS n",
    'relations_with_provenance': "MATCH (:KAutoCompany)-[r]->(:KAutoCompany) WHERE r.project='kauto-stage1' AND r.evidence_url STARTS WITH 'https://' AND r.assertion_status IS NOT NULL RETURN count(r) AS n",
    'relation_assertions': 'MATCH (n:KAutoRelationAssertion) RETURN count(n) AS n',
    'unsupported_supply_edges': 'MATCH (:KAutoCompany)-[r:SUPPLIES]->(:KAutoCompany) RETURN count(r) AS n',
}


def main():
    cfg=config()
    with GraphDatabase.driver(cfg['uri'],auth=(cfg['user'],cfg['password'])) as d:
        d.verify_connectivity()
        results={}
        for key,q in QUERIES.items():
            records,_,_=d.execute_query(q,database_=cfg['database'])
            results[key]=records[0]['n']
            print(f'{key}: {results[key]}')
    rels=read_csv('company_relationships.csv')
    source_urls={r['evidence_url'] for r in rels}
    expected={'company_company_edges':len(rels),'relations_with_provenance':len(rels), 'relation_assertions':len(rels), 'companies':len(read_csv('companies.csv')),'stages':len(read_csv('stages.csv')),
              'capabilities':len(read_csv('capabilities.csv')),'source_nodes':len(read_csv('companies.csv'))+len(source_urls)}
    for key,value in expected.items():
        if results[key]!=value:
            raise AssertionError(f'{key}: expected {value}, got {results[key]}')
    if results['unsupported_supply_edges']:
        raise AssertionError('Unexpected company-to-company SUPPLIES edges present; audit required.')
    print('PASS: company-to-company sourced edges verified; unapproved generic SUPPLIES edges = 0.')

if __name__=='__main__': main()
