# 1단계 보강판 업그레이드 — 기업↔기업 관계 42건

## 기존 패키지와 달라진 점

- 30개 기업 / 7개 밸류체인 / 24개 역량은 그대로 유지합니다.
- `data/company_relationships.csv`로 출처를 확인한 기업간 관계 42건을 추가했습니다.
- 관계 타입 8종을 분리합니다. 단순 납품계약은 실제 납품으로 바꿔 적재하지 않습니다.
- `KAutoRelationAssertion` 증거노드와 `KAutoSource` 12개 공식 자료를 추가합니다.
- `queries/07_company_network.cypher` ~ `queries/09_company_risk_paths.cypher`를 추가했습니다.
- `output/kauto_graph.html`에서 **기업↔기업 관계 그래프**를 직접 확인할 수 있습니다.

## 기존 Neo4j 데이터가 이미 있는 경우

1. 새 ZIP 파일을 별도 폴더에 압축 해제합니다. 기존 `.env`를 백업하고 비밀번호를 화면에 표시하지 않습니다.
2. 새 폴더에 사용 중인 DB 연결 설정을 로컬 `.env`로 구성합니다. 포트·DB 연결을 우선 검사합니다.
3. `python -m unittest discover -s tests -v`로 6개 테스트를 실행합니다.
4. `python scripts/render_html.py`를 실행하고 HTML 프리뷰를 엽니다.
5. 설치된 DB가 테스트 DB인지 확인한 뒤 사용자 승인을 받고 `python scripts/import_neo4j.py`를 실행합니다.
6. `python scripts/verify_neo4j.py`로 관계와 출처 노드 수를 검증합니다.
7. 기존 MCP를 그대로 재사용할 수 있습니다. MCP가 읽기 전용인지 재확인합니다.

위 적재 스크립트는 네임스페이스를 한정해 MERGE/upsert하며 삭제 쿼리를 실행하지 않습니다. 다만 기존 수작업 데이터에 중복 ID가 있는 경우 충돌할 수 있으므로 백업 후 테스트 DB에서 수행하세요.

## Claude Code에 내릴 프롬프트

```text
기존 K-Auto KG 1단계에서 기업간 관계가 빠졌으므로,
UPGRADE_FROM_STAGE1_KR.md와 RELATIONSHIP_MODEL_KR.md를 읽고
회사↔회사 관계 42건을 안전하게 추가해줘.
기존 데이터는 삭제하지 말고, 먼저 백업/DB 연결 상태와 CSV 단위테스트를 확인해줘.
실제 적재 전에 승인을 요청하고, 완료 후 Cypher 07~09와
HTML 미리보기에서 출처·관계유형·계약/실납품 구분을 검증해줘.
실행하지 못한 검증은 완료 처리하지 마.
```

## 검증 시 유의할 사항

- 회사가 동일 그룹에 속한다고 해서 서로 직접 소유·공급 관계에 있다는 것은 아닙니다.
- 대규모 공동개발 프로젝트가 있다고 해서 상호 독점계약이 체결된 것은 아닙니다.
- 사용자 컴퓨터의 Neo4j/MCP 설치 및 실제 데이터 적재는 **이 패키지 작성 환경에서 검증되지 않았습니다**.
