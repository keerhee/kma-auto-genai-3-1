# 제작/검증 현황 (패키지 생성 환경)

- [x] 시드 CSV 기업 30개 작성 (공식 사업/제품 페이지 확인 11, 추가 검토 19)
- [x] 밸류체인 7개, 역량 24개, 시스템 9개, 단계 링크 8개 구성
- [x] Python 단위 테스트 6개 통과
- [x] 원문 출처와 자료 시점을 갖춘 기업간 관계 42건 구축 (공식 고유 출처 12건)
- [x] 유형별 공급계약·실공급·공동개발을 분리하고 3개 Cypher 질의 추가
- [x] HTML 독립 실행형 미리보기 생성 (기업↔기업 지도 추가)
- [x] HTML에 포함된 JavaScript 문법 점검 (`node --check`) 통과
- [x] 헤드리스 브라우저 DOM 검증: 기업 변경, 관계필터, 1차 근거 링크 정상 렌더링
- [x] Python 소스 컴파일 검사 통과
- [ ] 사용자 컴퓨터에 Neo4j/Docker 설치·실행 — 이 패키지 작성 환경에 사용자 컴퓨터 원격 접속 권한 없음
- [ ] Neo4j Bolt DB에 실적재 및 쿼리 검증 — 사용자 환경에서 실행 필요
- [ ] Claude Code MCP 실제 연결 — 사용자 환경에서 실행 필요

**표기 규칙:** `offline preview`는 데이터 CSV를 기반으로 한 미리보기입니다. Neo4j Browser는 Neo4j 서버의 실제 데이터를 조회합니다. 두 화면을 동일한 실시간 화면으로 설명하지 않습니다.

## v1.2 점검 (2026-10-22)

- [x] 단위 테스트 6건 재실행 PASS · Python 소스 컴파일 PASS
- [x] render_html.py 재생성 결과가 배포 HTML과 바이트 단위로 동일 · JavaScript 문법 검사 PASS
- [x] import_neo4j.py · verify_neo4j.py를 가짜 드라이버로 모의 실행 — 예외 없음, 쿼리 198회, 출력 문구 확인
- [x] queries/*.cypher · README 예시의 레이블 · 관계 타입이 적재 스키마와 일치
- [x] Docker 이미지 neo4j:2026.09.0 태그 존재 확인 (Docker Hub)
- [x] neo4j-mcp-server 1.6.1: Windows · macOS(Intel/Apple) · Linux 휠 존재 확인
- [수정] mcp_launcher.py: 폐기 예정 환경변수 이름 → NEO4J_MCP_* 로 변경, --read-only true 추가 (경고 없이 기동 확인)
- [수정] requirements-mcp.txt: neo4j-mcp-server>=1.6.1,<2 로 고정
- [수정] .env.example · README: 비밀번호 8자 이상 안내 추가
- [정리] tests/__pycache__ 제거
- [ ] 실제 Neo4j 서버 적재 · MCP 도구 호출 — 이 점검 환경에서는 Docker 이미지와 Neo4j 배포 서버에 접속할 수 없어 수행하지 못함

## v1.3 점검 (2026-10-23)

- [수정] company_relationships.csv 네 줄: rel_013 근거 링크·발표일(2023-04-26)·주제, rel_015·rel_016 발표일(2026-09-22), rel_014 근거 링크 — 포스코퓨처엠 보도자료로 직접 확인. reviewed_on은 고친 줄만 2026-10-23
- [재생성] output/kauto_graph.html (render_html.py)
- [x] 단위 테스트 6건 PASS · 숫자 변동 없음(기업 30 · 관계 42 · 고유 출처 12)
- [보강] 교재 앞에 비전공자용 5분 요약, assets/png 데이터 그림 8장, 시작 페이지를 처음 보는 사람 기준으로
- [확인] neo4j-mcp-server 1.6.1이 최신, NEO4J_MCP_* 이름이 맞음(공식 문서 예시는 옛 이름). Neo4j 최신 이미지는 2026.10.0 — 2026.09.0 고정 유지
- [ ] 실제 Neo4j 서버 적재 · MCP 도구 호출 — 여전히 강사 PC 리허설 필요
