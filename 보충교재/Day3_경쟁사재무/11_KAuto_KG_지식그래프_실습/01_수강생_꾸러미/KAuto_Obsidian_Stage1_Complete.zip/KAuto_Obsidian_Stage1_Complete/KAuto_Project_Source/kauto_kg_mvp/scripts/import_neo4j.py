"""Idempotent seed. Writes only namespaced KAuto labels; never deletes data.

Usage: python scripts/import_neo4j.py
Requires an explicit choice to execute (not run automatically by Claude Code).
"""
from __future__ import annotations
from collections import Counter
from hashlib import sha256
from neo4j import GraphDatabase
from common import config, read_csv

CONSTRAINTS = [
    'CREATE CONSTRAINT kauto_company_id IF NOT EXISTS FOR (n:KAutoCompany) REQUIRE n.id IS UNIQUE',
    'CREATE CONSTRAINT kauto_stage_id IF NOT EXISTS FOR (n:KAutoStage) REQUIRE n.id IS UNIQUE',
    'CREATE CONSTRAINT kauto_capability_id IF NOT EXISTS FOR (n:KAutoCapability) REQUIRE n.id IS UNIQUE',
    'CREATE CONSTRAINT kauto_system_id IF NOT EXISTS FOR (n:KAutoSystem) REQUIRE n.id IS UNIQUE',
    'CREATE CONSTRAINT kauto_source_id IF NOT EXISTS FOR (n:KAutoSource) REQUIRE n.id IS UNIQUE',
    'CREATE CONSTRAINT kauto_assertion_id IF NOT EXISTS FOR (n:KAutoRelationAssertion) REQUIRE n.id IS UNIQUE',
]


RELATION_TYPES = {
    'AFFILIATED_WITH', 'SUPPLY_AGREEMENT_WITH', 'SUPPLIES_TO',
    'JOINT_RESEARCH_WITH', 'TECH_PARTNERS_WITH',
    'JOINT_VENTURE_PLAN_WITH', 'BATTERY_COOPERATION_WITH',
    'CO_MEMBER_OF_CONSORTIUM',
}


def import_relationships(driver, db):
    """Upsert source-grounded, typed relation assertions without deleting existing data."""
    rows = read_csv('company_relationships.csv')
    known_companies = {c['id'] for c in read_csv('companies.csv')}
    for edge in rows:
        typ = edge['relation_type']
        if typ not in RELATION_TYPES:
            raise ValueError(f'Unexpected relationship type: {typ}')
        if edge['from_company_id'] not in known_companies or edge['to_company_id'] not in known_companies:
            raise ValueError(f'Unknown company reference: {edge["id"]}')
        if not edge['evidence_url'].startswith('https://'):
            raise ValueError(f'Missing primary-source URL: {edge["id"]}')
        source_id = 'source.rel.' + sha256(edge['evidence_url'].encode()).hexdigest()[:24]
        driver.execute_query('''
            MERGE (s:KAutoSource:Source {id:$id})
            SET s.url=$url, s.source_kind='official_company_release_or_disclosure',
                s.project='kauto-stage1'
        ''', id=source_id, url=edge['evidence_url'], database_=db)
        # Relationship type is drawn only from a hardcoded allowlist.
        query = f'''
            MATCH (a:KAutoCompany {{id:$from_id}}),
                  (b:KAutoCompany {{id:$to_id}}),
                  (s:KAutoSource {{id:$source_id}})
            MERGE (a)-[r:{typ} {{id:$rel_id}}]->(b)
            SET r.label_ko=$label_ko, r.topic=$topic, r.announcement_date=$date,
                r.assertion_status=$status, r.evidence_url=$url,
                r.evidence_summary_ko=$summary, r.evidence_level=$level,
                r.reviewed_on=$reviewed, r.project='kauto-stage1'
            MERGE (claim:KAutoRelationAssertion {{id:$rel_id}})
            SET claim.type=$rel_type, claim.summary_ko=$summary,
                claim.reviewed_on=$reviewed, claim.project='kauto-stage1'
            MERGE (claim)-[:ASSERTS_SOURCE]->(a)
            MERGE (claim)-[:ASSERTS_TARGET]->(b)
            MERGE (claim)-[:SUPPORTED_BY]->(s)
        '''
        driver.execute_query(query,
            from_id='company.'+edge['from_company_id'],
            to_id='company.'+edge['to_company_id'],
            source_id=source_id, rel_id=edge['id'], rel_type=typ,
            label_ko=edge['relation_label_ko'], topic=edge['topic'],
            date=edge['announcement_date'],status=edge['assertion_status'],
            url=edge['evidence_url'],summary=edge['evidence_summary_ko'],
            level=edge['evidence_level'],reviewed=edge['reviewed_on'],database_=db)
    print(f'Company-to-company relation assertions imported: {len(rows)}')


def import_data(driver, db):
    stages = read_csv('stages.csv')
    caps = read_csv('capabilities.csv')
    companies = read_csv('companies.csv')
    links = read_csv('stage_links.csv')

    for q in CONSTRAINTS:
        driver.execute_query(q, database_=db)

    for stage in stages:
        driver.execute_query('''
            MERGE (s:KAutoStage:ValueChainStage {id:$id})
            SET s.name_ko=$name, s.display_order=$order, s.project='kauto-stage1'
        ''', id='stage.'+stage['id'], name=stage['name_ko'], order=int(stage['display_order']), database_=db)

    for cap in caps:
        driver.execute_query('''
            MERGE (z:KAutoSystem:VehicleSystem {id:$system_id})
            SET z.name_ko=$system_name, z.project='kauto-stage1'
            MERGE (p:KAutoCapability:Capability {id:$id})
            SET p.name_ko=$cap_name, p.project='kauto-stage1'
            MERGE (p)-[r:ENABLES_SYSTEM]->(z)
            SET r.evidence_class='ontology_concept_not_a_supply_contract'
        ''', id='cap.'+cap['id'], cap_name=cap['name_ko'],
            system_id='system.'+cap['system_id'], system_name=cap['system_name_ko'], database_=db)

    for link in links:
        driver.execute_query('''
            MATCH (a:KAutoStage {id:$a}), (b:KAutoStage {id:$b})
            MERGE (a)-[r:TYPICALLY_FEEDS]->(b)
            SET r.evidence_class='industry_concept_not_a_company_supply_contract'
        ''', a='stage.'+link['from_stage_id'], b='stage.'+link['to_stage_id'], database_=db)

    for co in companies:
        if co['evidence_status'] not in {'official_page_checked', 'review_required'}:
            raise ValueError(f'Invalid evidence status: {co["id"]}')
        company_id = 'company.' + co['id']
        source_id = 'source.' + co['id']
        driver.execute_query('''
            MERGE (c:KAutoCompany:Company {id:$id})
            SET c.name_ko=$name_ko, c.name_en=$name_en,
                c.source_url=$url, c.evidence_status=$status, c.project='kauto-stage1'
            WITH c
            MATCH (st:KAutoStage {id:$stage_id})
            MERGE (c)-[rs:PARTICIPATES_IN_STAGE]->(st)
            SET rs.evidence_status=$status
            MERGE (so:KAutoSource:Source {id:$source_id})
            SET so.url=$url, so.source_kind=$kind, so.project='kauto-stage1'
            MERGE (c)-[:HAS_REFERENCE]->(so)
        ''', id=company_id, name_ko=co['name_ko'], name_en=co['name_en'],
            url=co['source_url'], status=co['evidence_status'],
            kind=('official_business_or_product_page' if co['evidence_status']=='official_page_checked' else 'reference_needs_manual_review'),
            stage_id='stage.'+co['stage_id'], source_id=source_id, database_=db)
        for cap in co['capability_ids'].split('|'):
            driver.execute_query('''
                MATCH (c:KAutoCompany {id:$co_id}), (p:KAutoCapability {id:$cap_id})
                MERGE (c)-[r:HAS_CAPABILITY]->(p)
                SET r.evidence_status=$status, r.source_url=$url
            ''', co_id=company_id, cap_id='cap.'+cap,
                status=co['evidence_status'], url=co['source_url'], database_=db)

    import_relationships(driver, db)

    print('IMPORT COMPLETED (idempotent MERGE, no deletions).')
    print(f'Input: {len(companies)} companies; {len(caps)} capability categories; {len(stages)} stages.')
    print('Evidence:',dict(Counter(x['evidence_status'] for x in companies)))


def main():
    cfg=config()
    with GraphDatabase.driver(cfg['uri'], auth=(cfg['user'],cfg['password'])) as driver:
        driver.verify_connectivity()
        import_data(driver,cfg['database'])

if __name__=='__main__': main()
