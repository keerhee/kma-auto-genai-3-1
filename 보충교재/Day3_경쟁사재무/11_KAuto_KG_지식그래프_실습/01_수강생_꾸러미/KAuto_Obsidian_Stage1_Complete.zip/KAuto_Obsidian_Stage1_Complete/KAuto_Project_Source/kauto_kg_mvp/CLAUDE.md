# Claude Code Project Rules — K-Auto KG Stage 1

- Project goal: teach Korean auto industry ontology and Neo4j traversal. Stage 2 (NeoQuant, GraphRAG) is OUT OF SCOPE until Stage 1 passes.
- Inspect OS, Docker, ports, existing Neo4j, Python, and Claude Code before installing or running anything. Reuse working installations.
- Never run `docker compose down -v`, delete an existing database, clear volumes, or use `DETACH DELETE`.
- `data/companies.csv` consists of 30 seed candidates; `official_page_checked` is only a manually checked business/product-page reference, not verified commercial supply or exclusivity.
- Never infer A->B customer, supplier, equity, subsidiary or contract relationships from shared category membership.
- 42 seeded company-to-company claims are stored in data/company_relationships.csv with official source URL, announcement date if known, review date, and status. New claims require the same provenance. Group and consortium ties cannot imply actual purchases. Do not use unqualified `SUPPLIES` edges. `SUPPLIES_TO` is allowed only with an explicit officially reported executed supply; announced contracts belong to `SUPPLY_AGREEMENT_WITH`.
- Keep `.env` private; never print passwords/tokens in tool output, comments, logs, or prompts; do not put secrets into `.mcp.json` or Claude CLI args.
- `mcp_launcher.py` reads .env and enforces `NEO4J_READ_ONLY=true`; keep MCP read-only at Stage 1.
- Python seeding has write access; request explicit user permission immediately before importing to a live existing database.
- `output/kauto_graph.html` is a CSV OFFLINE visualization only, not a live view of the Neo4j database.
- Work in sequence: environment check -> local CSV tests -> HTML preview -> DB connectivity -> explicit permission -> seed -> verify -> MCP read-only -> teaching queries -> final report.
- Final report should show observed commands and PASS/FAIL, counts, links to local output; do not claim executed steps that were not actually run.
