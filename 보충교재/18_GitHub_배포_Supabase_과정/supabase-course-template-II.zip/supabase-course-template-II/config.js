// =========================================================
// Supabase 연결 정보 — 본인 프로젝트 값으로 바꾸세요
// 위치: Supabase 대시보드 → Project Settings → API Keys
//
// publishable 키(sb_publishable_…)는 화면 코드에 들어가도 괜찮습니다.
// 데이터는 schema.sql의 RLS 정책이 지켜 줍니다.
// secret 키(sb_secret_…)와 예전 service_role 키는 절대 여기에 넣지 마세요.
// (예전 anon 키도 동작하지만 2026년 말 폐기 예정이므로 publishable 키를 씁니다.)
// =========================================================
export const SUPABASE_URL = "https://YOUR-PROJECT-ID.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_YOUR-KEY";

// 사이트 이름 (화면 상단에 표시)
export const SITE_TITLE = "나의 AI 실습 과정";
