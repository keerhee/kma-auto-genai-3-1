# 과정 사이트 템플릿 (Supabase 회원·과제 관리)

로그인한 수강생이 과제를 제출하고, 관리자(강사)가 전체 현황을 보고 피드백을 남기는 정적 웹사이트입니다. 별도 서버 없이 **GitHub Pages · Vercel · Cloudflare** 어디에든 배포할 수 있습니다.

| 파일 | 역할 |
|---|---|
| `index.html` | 로그인 · 회원가입 |
| `my.html` | 내 과제 제출 · 목록 · 피드백 확인 |
| `admin.html` | 회원 목록 · 전체 제출 · 피드백 작성 · CSV 내려받기 |
| `app.js` | 세 화면의 공통 스크립트 |
| `config.js` | Supabase 연결 정보 (**본인 값으로 교체**) |
| `supabase/schema.sql` | 테이블 · 보안 정책(RLS) · 파일 저장소 설정 |

## 전체 구조

```
수강생 브라우저 ──▶ 사이트(HTML·JS) ──▶ Supabase
                    GitHub Pages /       ├ Auth      회원가입·로그인
                    Vercel / Cloudflare  ├ Database  profiles, submissions
                                         └ Storage   제출 파일 (비공개)
```

---

## 따라 하기 (처음부터 약 30분)

### 1단계 · Supabase 프로젝트 만들기
1. [supabase.com](https://supabase.com) 에 GitHub 계정으로 가입합니다.
2. **New project** → 이름 입력, 데이터베이스 비밀번호 저장, Region은 **Seoul** 선택 → Create.
3. 2분쯤 기다리면 프로젝트가 준비됩니다.

### 2단계 · 데이터베이스 설정
1. 왼쪽 메뉴 **SQL Editor** → **New query**.
2. `supabase/schema.sql` 내용을 통째로 붙여넣고 **Run**.
3. "Success" 가 나오면 끝입니다. **Table Editor** 에 `profiles`, `submissions` 가 보입니다.

> Claude Code에 Supabase MCP를 연결했다면 "schema.sql 을 내 Supabase 프로젝트에 실행해줘" 로 대신할 수 있습니다.
> 연결 명령(프로젝트 ID는 대시보드 주소의 `project/` 뒤 문자열):
> ```
> claude mcp add --scope project --transport http supabase "https://mcp.supabase.com/mcp?project_ref=프로젝트ID"
> ```
> 그다음 `claude` 안에서 `/mcp` → supabase → Authenticate 로 브라우저 로그인합니다. 설정이 끝나면 `&read_only=true` 를 붙여 읽기 전용으로 바꿔 두는 것이 안전합니다.

### 3단계 · 연결 정보 넣기
1. **Project Settings → API Keys** 에서 `Project URL` 과 **publishable 키**(`sb_publishable_…`)를 복사합니다. 키가 없으면 같은 화면에서 만듭니다.
2. `config.js` 의 두 값을 바꿉니다. 사이트 이름(`SITE_TITLE`)도 원하는 대로 고칩니다.

> Claude Code에게: "config.js 에 Supabase URL `…` 과 publishable 키 `…` 를 넣어줘"

### 4단계 · 내 컴퓨터에서 확인
Claude Code에게:
> "이 폴더를 로컬 웹서버로 띄워줘"

브라우저에서 열리면 **회원가입** → 확인 메일의 링크 클릭 → **로그인** → 과제 제출까지 해 봅니다.

### 5단계 · 나를 관리자로 지정
SQL Editor 에서 이메일만 바꿔 실행합니다.

```sql
update public.profiles set role = 'admin' where email = '내이메일@example.com';
```

다시 로그인하면 상단에 **관리자** 메뉴가 생깁니다.

### 6단계 · GitHub에 올리고 배포
Claude Code에게:
> "커밋하고, gh로 저장소 my-course-site 를 만들어 푸시해줘"

**로그인이 있는 사이트는 Cloudflare 또는 Vercel 배포를 권합니다.** GitHub Pages 약관은 비밀번호 같은 민감 정보를 다루는 용도를 피하라고 안내합니다. 해당 서비스에서 이 저장소를 Import 하고 Build command 는 비워 둡니다. (저장소 자체는 GitHub에 그대로 둡니다.)

### 7단계 · 배포 주소를 Supabase에 등록 (빠뜨리기 쉬움)
**Authentication → URL Configuration** 에서
- **Site URL**: 배포된 주소 (예: `https://my-course-site.pages.dev/`)
- **Redirect URLs**: 같은 주소를 추가

이걸 안 하면 가입 확인 메일의 링크가 `localhost` 로 연결됩니다.

---

## 보안 규칙 (꼭 읽기)

- **publishable 키는 공개돼도 됩니다.** `config.js` 째로 GitHub에 올라가도 괜찮습니다. 데이터는 `schema.sql` 의 RLS 정책이 지킵니다. (예전 `anon` 키도 동작하지만 2026년 말 폐기 예정입니다.)
- **secret 키(`sb_secret_…`)와 예전 service_role 키는 절대 코드나 GitHub에 넣지 않습니다.** 이 키는 RLS를 무시합니다.
- 템플릿의 정책 요약:
  - 수강생은 **자기 과제와 자기 파일만** 보고, 올리고, 지울 수 있습니다.
  - 수강생은 자기 **이름만** 고칠 수 있고, 역할(role)은 바꿀 수 없습니다.
  - **피드백은 관리자만** 쓸 수 있습니다.
- 테이블을 새로 만들면 반드시 RLS 를 켜고 정책을 걸어야 합니다.
  > Claude Code에게: "attendance 테이블을 추가하고, 기존과 같은 방식으로 RLS 정책을 걸어줘"
- 개인정보는 이름·이메일만 받습니다. 과정이 끝나면 Authentication → Users 에서 회원을 삭제합니다.

## 무료 플랜 참고
- 일정 기간 사용하지 않으면 프로젝트가 일시정지됩니다. 대시보드에서 다시 켜면 됩니다.
- 가입 확인 메일은 기본 발송 수에 제한이 있습니다. 수강생이 많으면 **Authentication → Sign In / Providers → Email** 에서 "Confirm email" 을 끄거나, 자체 SMTP 를 연결합니다.

## 다음에 해 볼 것 (Claude Code에게 그대로 말하기)
- "구글 로그인 버튼을 추가해줘"
- "출석 체크 화면과 attendance 테이블을 만들어줘"
- "관리자 화면에 과제별 제출률 차트를 넣어줘"
- "공지사항 게시판을 만들어줘. 글쓰기는 관리자만"
