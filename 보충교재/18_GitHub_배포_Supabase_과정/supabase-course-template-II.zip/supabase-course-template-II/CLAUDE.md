# CLAUDE.md — 이 저장소에서 작업할 때의 규칙

- 정적 사이트다. 빌드 도구·프레임워크를 추가하지 않는다. HTML + `app.js`(ES module) + `style.css` 구조를 유지한다.
- Supabase 클라이언트는 `app.js` 상단의 CDN import 하나만 쓴다.
- 새 화면은 `<body data-page="이름">` 으로 만들고 `app.js` 의 `pages` 객체에 함수를 추가한다.
- 새 테이블을 만들 때는 반드시 `supabase/schema.sql` 에 추가하고, RLS 를 켜고, 본인/관리자 정책을 건다. 관리자 판정은 `public.is_admin()` 을 쓴다.
- secret 키(`sb_secret_…`)·service_role 키를 어떤 파일에도 쓰지 않는다. `config.js` 에는 URL 과 publishable 키(`sb_publishable_…`)만 둔다.
- 사용자에게 보이는 문구는 한국어로 쓴다. 저장소 파일 경로는 영어로 쓴다.
- 화면에 데이터를 넣을 때는 `esc()` 로 이스케이프한다.
