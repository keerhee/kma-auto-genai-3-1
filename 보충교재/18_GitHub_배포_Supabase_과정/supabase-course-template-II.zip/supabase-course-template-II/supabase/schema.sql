-- =========================================================
-- 과정 사이트 템플릿 · Supabase 초기 설정 SQL
-- Supabase 대시보드 → SQL Editor → New query 에 전체를 붙여넣고 Run
-- (Claude Code에 Supabase MCP가 연결돼 있으면 "schema.sql 실행해줘"로 대신 가능)
-- =========================================================

-- 1) 회원 프로필 ------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  name        text,
  role        text not null default 'student' check (role in ('student', 'admin')),
  created_at  timestamptz not null default now()
);

-- 관리자 여부 확인 함수 (RLS 정책 안에서 재귀를 피하려고 security definer 사용)
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- 회원가입하면 프로필 행을 자동으로 만든다
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;

drop policy if exists "profiles: 본인 또는 관리자 조회" on public.profiles;
create policy "profiles: 본인 또는 관리자 조회" on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.is_admin());

drop policy if exists "profiles: 본인 이름 수정" on public.profiles;
create policy "profiles: 본인 이름 수정" on public.profiles
  for update to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- 수강생이 자기 role을 admin으로 바꾸지 못하게: name 열만 수정 허용
revoke update on public.profiles from authenticated;
grant update (name) on public.profiles to authenticated;

-- 2) 과제 제출 --------------------------------------------
create table if not exists public.submissions (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  title       text not null,
  note        text,
  file_path   text,
  feedback    text,
  created_at  timestamptz not null default now()
);

alter table public.submissions enable row level security;

drop policy if exists "submissions: 본인 또는 관리자 조회" on public.submissions;
create policy "submissions: 본인 또는 관리자 조회" on public.submissions
  for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists "submissions: 본인 제출" on public.submissions;
create policy "submissions: 본인 제출" on public.submissions
  for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists "submissions: 본인 삭제" on public.submissions;
create policy "submissions: 본인 삭제" on public.submissions
  for delete to authenticated
  using (user_id = auth.uid());

-- 피드백은 관리자만 작성: feedback 열만 수정 허용 + 관리자 정책
drop policy if exists "submissions: 관리자 피드백" on public.submissions;
create policy "submissions: 관리자 피드백" on public.submissions
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

revoke update on public.submissions from authenticated;
grant update (feedback) on public.submissions to authenticated;

-- 3) 파일 저장소 (비공개 버킷) ------------------------------
-- 파일 경로 규칙: submissions/<사용자ID>/<파일명>
insert into storage.buckets (id, name, public)
values ('submissions', 'submissions', false)
on conflict (id) do nothing;

drop policy if exists "files: 본인 폴더 업로드" on storage.objects;
create policy "files: 본인 폴더 업로드" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'submissions'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "files: 본인 또는 관리자 조회" on storage.objects;
create policy "files: 본인 또는 관리자 조회" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'submissions'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );

drop policy if exists "files: 본인 삭제" on storage.objects;
create policy "files: 본인 삭제" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'submissions'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- 4) 관리자 지정 (본인 이메일로 바꿔서, 회원가입 후 한 번 실행) ----
-- update public.profiles set role = 'admin' where email = 'me@example.com';
