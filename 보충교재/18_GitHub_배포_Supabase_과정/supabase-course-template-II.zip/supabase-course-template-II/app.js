// =========================================================
// 공통 스크립트 — 모든 페이지가 이 파일 하나를 씁니다
// 페이지마다 <body data-page="login|my|admin"> 로 구분합니다
// =========================================================
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, SITE_TITLE } from "./config.js";

const sb = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
const $ = (id) => document.getElementById(id);

function show(el, text, kind = "") {
  el.textContent = text;
  el.className = "msg " + kind;
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmt(d) {
  return new Date(d).toLocaleString("ko-KR", { dateStyle: "short", timeStyle: "short" });
}

// 상단 바: 사이트 이름 + 로그인 상태
async function header(profile) {
  document.title = SITE_TITLE;
  $("site-title").textContent = SITE_TITLE;
  const nav = $("nav");
  if (!profile) { nav.innerHTML = ""; return; }
  nav.innerHTML = `
    <span class="muted">${esc(profile.name || profile.email)}</span>
    <a href="my.html">내 과제</a>
    ${profile.role === "admin" ? '<a href="admin.html">관리자</a>' : ""}
    <a href="#" id="logout">로그아웃</a>`;
  $("logout").onclick = async (e) => {
    e.preventDefault();
    await sb.auth.signOut();
    location.href = "index.html";
  };
}

async function currentProfile() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return null;
  const { data } = await sb.from("profiles").select("*").eq("id", session.user.id).single();
  return data;
}

// ---------------------------------------------------------
// 로그인 / 회원가입 (index.html)
// ---------------------------------------------------------
async function pageLogin() {
  const profile = await currentProfile();
  if (profile) { location.href = "my.html"; return; }
  await header(null);

  const msg = $("msg");
  $("btn-login").onclick = async () => {
    const { error } = await sb.auth.signInWithPassword({
      email: $("email").value.trim(), password: $("password").value,
    });
    if (error) return show(msg, "로그인 실패: " + error.message, "error");
    location.href = "my.html";
  };
  $("btn-signup").onclick = async () => {
    const name = $("name").value.trim();
    if (!name) return show(msg, "회원가입에는 이름이 필요합니다.", "error");
    const { error } = await sb.auth.signUp({
      email: $("email").value.trim(),
      password: $("password").value,
      options: { data: { name }, emailRedirectTo: location.origin + location.pathname },
    });
    if (error) return show(msg, "가입 실패: " + error.message, "error");
    show(msg, "가입 확인 메일을 보냈습니다. 메일의 링크를 누른 뒤 로그인하세요.", "ok");
  };
}

// ---------------------------------------------------------
// 내 과제 (my.html)
// ---------------------------------------------------------
async function pageMy() {
  const profile = await currentProfile();
  if (!profile) { location.href = "index.html"; return; }
  await header(profile);
  const msg = $("msg");

  async function load() {
    const { data, error } = await sb.from("submissions")
      .select("*").eq("user_id", profile.id).order("created_at", { ascending: false });
    if (error) return show(msg, error.message, "error");
    $("list").innerHTML = data.length === 0
      ? '<tr><td colspan="4" class="muted">아직 제출한 과제가 없습니다.</td></tr>'
      : data.map((s) => `
        <tr>
          <td><b>${esc(s.title)}</b><br><span class="muted">${esc(s.note)}</span></td>
          <td>${fmt(s.created_at)}</td>
          <td>${s.feedback ? esc(s.feedback) : '<span class="muted">대기</span>'}</td>
          <td class="row">
            ${s.file_path ? `<button class="small secondary" data-open="${esc(s.file_path)}">파일</button>` : ""}
            <button class="small secondary" data-del="${s.id}" data-path="${esc(s.file_path || "")}">삭제</button>
          </td>
        </tr>`).join("");
  }

  $("btn-submit").onclick = async () => {
    const title = $("title").value.trim();
    if (!title) return show(msg, "과제명을 입력하세요.", "error");
    $("btn-submit").disabled = true;
    let file_path = null;
    const file = $("file").files[0];
    if (file) {
      // 한글 파일명은 저장소에서 거부될 수 있어 시간값 + 확장자로 저장
      const ext = file.name.includes(".") ? file.name.split(".").pop() : "bin";
      file_path = `${profile.id}/${Date.now()}.${ext}`;
      const up = await sb.storage.from("submissions").upload(file_path, file);
      if (up.error) { $("btn-submit").disabled = false; return show(msg, "업로드 실패: " + up.error.message, "error"); }
    }
    const { error } = await sb.from("submissions").insert({ title, note: $("note").value.trim(), file_path });
    $("btn-submit").disabled = false;
    if (error) return show(msg, "제출 실패: " + error.message, "error");
    $("title").value = ""; $("note").value = ""; $("file").value = "";
    show(msg, "제출했습니다.", "ok");
    load();
  };

  $("list").onclick = async (e) => {
    const t = e.target;
    if (t.dataset.open) {
      const { data, error } = await sb.storage.from("submissions").createSignedUrl(t.dataset.open, 60);
      if (error) return show(msg, error.message, "error");
      window.open(data.signedUrl, "_blank");
    }
    if (t.dataset.del && confirm("이 과제를 삭제할까요?")) {
      if (t.dataset.path) await sb.storage.from("submissions").remove([t.dataset.path]);
      const { error } = await sb.from("submissions").delete().eq("id", t.dataset.del);
      if (error) return show(msg, error.message, "error");
      load();
    }
  };

  load();
}

// ---------------------------------------------------------
// 관리자 (admin.html) — role이 admin인 계정만
// ---------------------------------------------------------
async function pageAdmin() {
  const profile = await currentProfile();
  if (!profile) { location.href = "index.html"; return; }
  await header(profile);
  if (profile.role !== "admin") {
    $("admin").innerHTML = '<p class="msg error">관리자만 볼 수 있는 화면입니다.</p>';
    return;
  }
  const msg = $("msg");

  async function load() {
    const [members, subs] = await Promise.all([
      sb.from("profiles").select("*").order("created_at"),
      sb.from("submissions").select("*, profiles(name, email)").order("created_at", { ascending: false }),
    ]);
    if (members.error || subs.error) return show(msg, (members.error || subs.error).message, "error");

    $("member-count").textContent = members.data.length;
    $("members").innerHTML = members.data.map((m) => `
      <tr>
        <td>${esc(m.name)}</td><td>${esc(m.email)}</td>
        <td><span class="badge">${m.role}</span></td>
        <td>${subs.data.filter((s) => s.user_id === m.id).length}</td>
        <td>${fmt(m.created_at)}</td>
      </tr>`).join("");

    $("subs").innerHTML = subs.data.map((s) => `
      <tr>
        <td>${esc(s.profiles?.name || s.profiles?.email)}</td>
        <td><b>${esc(s.title)}</b><br><span class="muted">${esc(s.note)}</span></td>
        <td>${fmt(s.created_at)}</td>
        <td>
          ${s.file_path ? `<button class="small secondary" data-open="${esc(s.file_path)}">파일</button>` : "—"}
        </td>
        <td>
          <input data-fb="${s.id}" value="${esc(s.feedback)}" placeholder="피드백 입력 후 Enter">
        </td>
      </tr>`).join("");
  }

  $("subs").onclick = async (e) => {
    const p = e.target.dataset.open;
    if (!p) return;
    const { data, error } = await sb.storage.from("submissions").createSignedUrl(p, 60);
    if (error) return show(msg, error.message, "error");
    window.open(data.signedUrl, "_blank");
  };
  $("subs").onkeydown = async (e) => {
    if (e.key !== "Enter" || !e.target.dataset.fb) return;
    const { error } = await sb.from("submissions")
      .update({ feedback: e.target.value }).eq("id", e.target.dataset.fb);
    show(msg, error ? error.message : "피드백을 저장했습니다.", error ? "error" : "ok");
  };

  // 회원·제출 현황을 CSV로 내려받기 (엑셀에서 열림)
  $("btn-csv").onclick = async () => {
    const { data } = await sb.from("submissions").select("title, note, feedback, created_at, profiles(name, email)");
    const rows = [["이름", "이메일", "과제명", "메모", "피드백", "제출일"]]
      .concat(data.map((s) => [s.profiles?.name, s.profiles?.email, s.title, s.note, s.feedback, fmt(s.created_at)]));
    const csv = "﻿" + rows.map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = "submissions.csv";
    a.click();
  };

  load();
}

const pages = { login: pageLogin, my: pageMy, admin: pageAdmin };
pages[document.body.dataset.page]?.();
