"""golden_compare.py — 검증 운전 결과를 기준값(독립 재계산 값, 있으면 과거 실제 제안서 값)과 대조한다.

사용: python3 -I golden_compare.py <golden.json> --run <output/사례 폴더> [--out 결과.txt]
  golden.json: {"case": "...",
                "values": {"capex_won": {"actual": 312000000, "tol_pct": 5},
                           "payback_years": {"actual": 2.1, "tol_abs": 0.2}},
                "must_have": ["위험성 평가", "보수 시나리오"]}
  실행 폴더에는 파이프라인이 남긴 numbers.json({"키": 값, ...})과 05_proposal.md가 있어야 한다.
  (tools/*.py가 계산 결과를 numbers.json에 모아 쓰도록 2단계에서 맞춘다)
종료 코드: 허용 오차를 넘거나 필수 항목이 빠지면 1
"""
import argparse, json, sys
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("golden")
    ap.add_argument("--run", required=True)
    ap.add_argument("--out")
    a = ap.parse_args()
    g = json.loads(Path(a.golden).read_text(encoding="utf-8"))
    run = Path(a.run)
    nums = json.loads((run / "numbers.json").read_text(encoding="utf-8"))
    prop_p = run / "05_proposal.md"
    prop = prop_p.read_text(encoding="utf-8") if prop_p.exists() else ""
    lines, bad = [f"사례 {g.get('case', '?')}"], 0

    for k, spec in g.get("values", {}).items():
        act = spec["actual"]
        got = nums.get(k)
        if got is None:
            lines.append(f"  [누락] {k}: 이번 실행에 값 없음"); bad += 1; continue
        diff = got - act
        if "tol_pct" in spec:
            lim = abs(act) * spec["tol_pct"] / 100
            tol = f"±{spec['tol_pct']}%"
        else:
            lim = spec.get("tol_abs", 0)
            tol = f"±{lim}"
        ok = abs(diff) <= lim
        pct = f" ({diff / act * 100:+.1f}%)" if act else ""
        dfmt = f"{diff:+,.0f}" if abs(diff) >= 1000 else f"{diff:+.3g}"
        lines.append(f"  [{'일치' if ok else '초과'}] {k}: 실제 {act:,} · 이번 {got:,} · 차이 {dfmt}{pct} · 허용 {tol}")
        bad += 0 if ok else 1

    for item in g.get("must_have", []):
        has = item in prop
        lines.append(f"  [{'있음' if has else '없음'}] 필수 항목 '{item}'")
        bad += 0 if has else 1

    lines.append(f"결과: {'통과' if bad == 0 else f'확인 필요 {bad}건'}")
    txt = "\n".join(lines)
    print(txt)
    if a.out:
        Path(a.out).write_text(txt + "\n", encoding="utf-8")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
