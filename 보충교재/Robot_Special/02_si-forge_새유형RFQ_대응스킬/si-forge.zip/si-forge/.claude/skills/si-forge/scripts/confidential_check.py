"""confidential_check.py — 유형 등록 전에 SI 제안 팀 폴더의 기밀 노출을 점검한다.

사용: python3 -I confidential_check.py <폴더> [--clients 고객사1,고객사2] [--out 결과.txt]
점검: 비밀값·개인정보 패턴(오류) · 고객사 이름·금액 표기가 나오는 파일 위치(경고)
  course-forge의 publish_check.py와 같은 패턴을 쓰되, 공개가 아니라 사내 등록 기준이다.
  금액·고객사 경고는 지우라는 뜻이 아니라 '접근을 좁힌 곳(forge/<type>/golden/)에만 있는가'를 사람이 보라는 뜻이다.
종료 코드: 오류가 있으면 1 (경고는 0)
"""
import argparse, re, sys
from pathlib import Path

SECRET = {
    "GitHub 토큰": r"gh[pousr]_[A-Za-z0-9]{30,}",
    "AWS 키": r"AKIA[0-9A-Z]{16}",
    "API 키(sk-)": r"\bsk-[A-Za-z0-9_\-]{20,}",
    "개인 키": r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    "비밀번호 대입": r"(?i)(password|passwd|secret|api_key)\s*[=:]\s*['\"][^'\"]{6,}",
}
PII = {
    "주민등록번호": r"\b\d{6}-[1-4]\d{6}\b",
    "휴대전화": r"\b01[016789]-\d{3,4}-\d{4}\b",
}
MONEY = r"\d[\d,.]*\s*(억|만)\s*원|\d{1,3}(,\d{3}){2,}\s*원"
TEXT_EXT = {".md", ".py", ".json", ".csv", ".txt", ".yml", ".yaml"}
SKIP_DIRS = {".git", "node_modules", "__pycache__"}
SAFE_DIRS = ("forge/",)  # 정답지·원본은 여기에만 둔다


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--clients", default="", help="쉼표로 구분한 실제 고객사 이름")
    ap.add_argument("--out")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    clients = [c.strip() for c in a.clients.split(",") if c.strip()]
    errs, warns = [], []
    for f in root.rglob("*"):
        rel = f.relative_to(root)
        if f.is_dir() or any(p in SKIP_DIRS for p in rel.parts) or f.suffix.lower() not in TEXT_EXT:
            continue
        r = rel.as_posix()
        t = f.read_text(encoding="utf-8", errors="ignore")
        for k, pat in {**SECRET, **PII}.items():
            if re.search(pat, t):
                errs.append(f"{r}: {k} 패턴")
        if r.startswith(SAFE_DIRS):
            continue
        for c in clients:
            if c in t:
                warns.append(f"{r}: 고객사 '{c}' — forge/ 밖에 있음")
        n = len(re.findall(MONEY, t))
        if n and (r.startswith(".claude/") or r == "CLAUDE.md"):
            warns.append(f"{r}: 금액 표기 {n}곳 — 스킬·에이전트에는 실제 단가 대신 범위·출처만")
    lines = [f"오류 {len(errs)}건 · 경고 {len(warns)}건"] + [f"  [오류] {e}" for e in errs] + [f"  [경고] {w}" for w in warns]
    txt = "\n".join(lines)
    print(txt)
    if a.out:
        Path(a.out).write_text(txt + "\n", encoding="utf-8")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
