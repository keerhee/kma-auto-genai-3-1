# 설비 정비 조치 판정 에이전트 — Day5 보충 실습 데이터

모든 설비·회사·인물은 가상이다(한빛모터스 가상 제1공장). 센서 CSV 두 개는 저장소 `data/Day5`의
`Day5_설비센서_50건_가상.csv`, `Day5_설비센서_단위혼재_함정_가상.csv`와 같은 파일이다.

| 파일 | 내용 |
|---|---|
| data/sensor/sensor_50.csv | 설비A·B × 25시점 진동·온도·압력 (본 강의 데이터) |
| data/sensor/sensor_unit_trap.csv | 같은 데이터에 단위 혼재(℉·psi)를 심은 함정판 |
| data/equipment.json | 설비 대장 7대 — 안전검사 일자, 예방정비 시간, 최근 3회 측정 |
| data/users.json | 데모 계정 3개(정비기사·생산반장·설비책임자) |
| data/standards/vibration-iso20816.json | 진동 구간 A~D 기준 요약 |
| data/standards/manufacturer-limits.json | 제조사 매뉴얼 한계값(가상) |
| data/standards/safety-inspection.json | 산업안전보건법 안전검사 대상·주기 |
| data/maintenance-policy.json | 사내 정비 규정 CP-01~10(가상) |
| data/test-cases.csv | 판정 엔진 자동 테스트용 기대 결과 8건 |
| data/sample-questions.md | AI 상담 테스트 질문 10개 |
| prompts/ | 단계별 프롬프트 원문 |

판정 시각은 2026-09-15 16:00이다. 기준 파일의 `verification`이 "검증 필요"인 항목은 STEP 4에서
Claude Code가 공개 자료와 대조한다. 제조사 한계값은 실습용 가상 값이다.
